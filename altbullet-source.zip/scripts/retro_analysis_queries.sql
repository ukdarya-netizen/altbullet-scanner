-- ============================================================
  -- RETRO PRE-GROWTH ANALYSIS — 774 tokens
  -- Data: retro_pre_growth (T-2/3/4/6/12h before 20% crossing)
  --       growth_leader_log (metrics AT the 20% crossing)
  -- ============================================================

  -- 1. Average metrics by snapshot time (T-Nh before peak)
  SELECT 
    hours_before as hb,
    COUNT(*) as n,
    ROUND(AVG(price_24h)::numeric,1) as p24h_avg,
    ROUND(PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY price_24h)::numeric,1) as p24h_q25,
    ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY price_24h)::numeric,1) as p24h_q75,
    ROUND(AVG(price_3h)::numeric,2) as p3h_avg,
    ROUND(AVG(price_4h)::numeric,2) as p4h_avg,
    ROUND(AVG(oi_30m)::numeric,2) as oi30m_avg,
    ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY oi_30m)::numeric,2) as oi30m_med,
    ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY oi_30m)::numeric,2) as oi30m_q75,
    ROUND(AVG(oi_1h)::numeric,2) as oi1h_avg,
    ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY oi_1h)::numeric,2) as oi1h_med,
    ROUND(AVG(oi_4h)::numeric,2) as oi4h_avg,
    ROUND(AVG(oi_prev_30m)::numeric,2) as prev30m_avg,
    ROUND(AVG(oi_prev_1h)::numeric,2) as prev1h_avg,
    ROUND(AVG(vol_mult)::numeric,2) as vol_avg,
    ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY vol_mult)::numeric,2) as vol_med,
    ROUND(100.0 * COUNT(cvd_1h) FILTER (WHERE cvd_1h=true) / NULLIF(COUNT(cvd_1h),0),0) as cvd1h_bull_pct,
    ROUND(100.0 * COUNT(cvd_30m) FILTER (WHERE cvd_30m=true) / NULLIF(COUNT(cvd_30m),0),0) as cvd30m_bull_pct,
    ROUND(AVG(spot_net_pct)::numeric,1) as spot_net_avg
  FROM retro_pre_growth
  GROUP BY hours_before
  ORDER BY hours_before;

  -- RESULTS:
  -- hb | p24h_avg | p24h_q25 | p24h_q75 | oi30m_avg | oi30m_med | oi4h_avg | vol_med
  -- 2  | 14.3     | 9.9      | 19.3     | 0.69      | 0.00      | 12.46    | 1.03
  -- 3  | 13.4     | 7.7      | 19.2     | 0.56      | 0.00      | 9.99     | 1.02
  -- 4  | 12.4     | 5.3      | 18.1     | 0.28      | 0.00      | 6.93     | 1.00
  -- 6  | 10.6     | 2.7      | 16.8     | 0.48      | 0.00      | 4.44     | 1.00
  -- 12 | 7.3      | -2.1     | 13.6     | 0.48      | 0.00      | 5.23     | 0.98


  -- 2. OI gate pass rates (what % would pass current pattern thresholds)
  SELECT hours_before as hb,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_30m >= 3.5) / COUNT(*)::numeric,1) as oi30m_ge35_pct,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_30m >= 1.0) / COUNT(*)::numeric,1) as oi30m_ge1_pct,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_1h >= 2.0) / COUNT(*)::numeric,1) as oi1h_ge2_pct,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h >= 4.0) / COUNT(*)::numeric,1) as oi4h_ge4_pct,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h >= 5.0) / COUNT(*)::numeric,1) as oi4h_ge5_pct,
    ROUND(100.0*COUNT(*) FILTER(WHERE vol_mult >= 1.5) / COUNT(*)::numeric,1) as vol_ge15_pct,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_30m > 0 AND oi_prev_30m > 0) / COUNT(*)::numeric,1) as two_cycles_pos_pct
  FROM retro_pre_growth
  GROUP BY hours_before ORDER BY hours_before;

  -- RESULTS:
  -- hb | oi30m_ge35 | oi30m_ge1 | oi1h_ge2 | oi4h_ge4 | oi4h_ge5 | vol_ge15 | two_cycles_pos
  -- 2  | 11.2       | 15.6      | 24.7     | 46.3     | 40.4     | 18.0     | 22.7
  -- 4  | 7.8        | 13.2      | 22.7     | 43.2     | 33.3     | 13.3     | 21.1
  -- 12 | 7.2        | 12.4      | 18.0     | 19.9     | 15.5     | 12.4     | 22.7


  -- 3. OI 4h distribution buckets
  SELECT hours_before as hb,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h IS NOT NULL AND oi_4h < 0) / NULLIF(COUNT(oi_4h),0),1) as neg_pct,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h >= 0  AND oi_4h < 2)  / NULLIF(COUNT(oi_4h),0),1) as "0to2",
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h >= 2  AND oi_4h < 5)  / NULLIF(COUNT(oi_4h),0),1) as "2to5",
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h >= 5  AND oi_4h < 10) / NULLIF(COUNT(oi_4h),0),1) as "5to10",
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h >= 10 AND oi_4h < 20) / NULLIF(COUNT(oi_4h),0),1) as "10to20",
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h >= 20) / NULLIF(COUNT(oi_4h),0),1) as "gt20"
  FROM retro_pre_growth
  GROUP BY hours_before ORDER BY hours_before;

  -- RESULTS:
  -- hb | neg   | 0to2  | 2to5  | 5to10 | 10to20 | gt20
  -- 2  | 21.0  | 20.2  | 8.7   | 14.8  | 17.7   | 17.6
  -- 4  | 24.7  | 20.1  | 11.9  | 15.7  | 16.1   | 11.4
  -- 12 | 31.0  | 29.7  | 10.8  | 11.2  | 9.9    | 7.4


  -- 4. Vol distribution
  SELECT hours_before as hb,
    ROUND(100.0*COUNT(*) FILTER(WHERE vol_mult < 0.5)  / COUNT(*)::numeric,1) as "lt05",
    ROUND(100.0*COUNT(*) FILTER(WHERE vol_mult >= 0.5 AND vol_mult < 1.0)  / COUNT(*)::numeric,1) as "05to1",
    ROUND(100.0*COUNT(*) FILTER(WHERE vol_mult >= 1.0 AND vol_mult < 1.5)  / COUNT(*)::numeric,1) as "1to15",
    ROUND(100.0*COUNT(*) FILTER(WHERE vol_mult >= 1.5 AND vol_mult < 2.5)  / COUNT(*)::numeric,1) as "15to25",
    ROUND(100.0*COUNT(*) FILTER(WHERE vol_mult >= 2.5) / COUNT(*)::numeric,1) as "gt25"
  FROM retro_pre_growth
  GROUP BY hours_before ORDER BY hours_before;

  -- RESULTS:
  -- hb | lt05 | 05to1 | 1to15 | 15to25 | gt25
  -- 4  | 6.8  | 42.9  | 37.0  | 8.4    | 4.9
  -- 12 | 9.7  | 46.9  | 31.0  | 7.4    | 5.0


  -- 5. Segment profiles at T-4h
  WITH t4 AS (SELECT * FROM retro_pre_growth WHERE hours_before=4)
  SELECT
    COUNT(*) FILTER(WHERE oi_30m >= 1.0 AND vol_mult >= 1.2) as "A_strong_oi30m_vol_n",
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_30m >= 1.0 AND vol_mult >= 1.2) / COUNT(*)::numeric,1) as "A_pct",
    COUNT(*) FILTER(WHERE oi_1h >= 2.0) as "A2_oi1h_ge2_n",
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_1h >= 2.0) / COUNT(*)::numeric,1) as "A2_pct",
    COUNT(*) FILTER(WHERE oi_4h >= 4 AND oi_30m < 1.0 AND oi_1h < 2.0) as "B_silent_oi4h_n",
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h >= 4 AND oi_30m < 1.0 AND oi_1h < 2.0) / COUNT(*)::numeric,1) as "B_pct",
    COUNT(*) FILTER(WHERE price_3h >= 3 AND oi_4h < 4 AND oi_30m < 1.0) as "C_price_only_n",
    ROUND(100.0*COUNT(*) FILTER(WHERE price_3h >= 3 AND oi_4h < 4 AND oi_30m < 1.0) / COUNT(*)::numeric,1) as "C_pct",
    COUNT(*) FILTER(WHERE oi_4h < 2 AND oi_30m < 0.5 AND price_3h < 2 AND vol_mult < 1.2) as "D_invisible_n",
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h < 2 AND oi_30m < 0.5 AND price_3h < 2 AND vol_mult < 1.2) / COUNT(*)::numeric,1) as "D_pct"
  FROM t4;

  -- RESULTS:
  -- A (strong oi30m+vol): 7.6%
  -- A2 (oi1h >= 2%):      22.7%
  -- B (silent oi4h):      26.0%
  -- C (price only):       11.8%
  -- D (invisible):        18.9%


  -- 6. "Invisible" profile — what ARE these tokens?
  WITH t4 AS (
    SELECT p.*, g.cycle_count
    FROM retro_pre_growth p
    JOIN growth_leader_log g ON g.id = p.retro_log_id
    WHERE p.hours_before=4
      AND p.oi_4h < 2 AND p.oi_30m < 0.5 AND p.price_3h < 2 AND p.vol_mult < 1.2
  )
  SELECT
    COUNT(*) as n,
    ROUND(AVG(price_24h)::numeric,1) as p24h_avg,
    ROUND(AVG(price_4h)::numeric,2) as p4h_avg,
    ROUND(AVG(oi_4h)::numeric,2) as oi4h_avg,
    ROUND(AVG(vol_mult)::numeric,2) as vol_avg,
    ROUND(AVG(cycle_count)::numeric,0) as cycles_avg
  FROM t4;

  -- RESULTS: n=146, p24h=+9.2%, p4h=-1.43%, oi4h=-2.40%, vol=0.86x
  -- INTERPRETATION: tokens in pullback within uptrend
  -- They rose to ~9%, pulled back (p4h negative), then continued to 20%+


  -- 7. OI acceleration and combo gates
  SELECT hours_before,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_30m > 0.5 AND oi_30m > oi_prev_30m*1.3 AND oi_prev_30m > 0) / COUNT(*)::numeric,1) as l5_accel_pct,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_1h > 1 AND oi_4h > 3) / COUNT(*)::numeric,1) as oi1h_and_oi4h_pct,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h > 5 AND oi_prev_1h > 0) / COUNT(*)::numeric,1) as oi4h_steady_pct,
    ROUND(100.0*COUNT(*) FILTER(WHERE oi_4h > 3 AND price_24h BETWEEN 3 AND 20 AND oi_30m < 1) / COUNT(*)::numeric,1) as silent_accum_gate_pct
  FROM retro_pre_growth
  GROUP BY hours_before ORDER BY hours_before;

  -- RESULTS:
  -- hb | l5_accel | oi1h+oi4h | oi4h_steady | silent_accum_gate
  -- 2  | 10.3     | 25.3      | 24.5        | 27.6
  -- 4  | 7.6      | 22.7      | 22.2        | 21.8
  -- 12 | 8.7      | 10.2      | 9.9         | 7.6


  -- ============================================================
  -- KEY FINDINGS SUMMARY
  -- ============================================================
  -- 1. OI 30m median = 0.00 at ALL timepoints (T-2h to T-12h)
  --    => current patterns requiring OI30m >= 3.5% catch only top 11%
  -- 2. OI 4h is the dominant signal: avg grows 5.23% (T-12h) -> 12.46% (T-2h)
  --    => 46% of tokens have OI4h >= 4% already at T-4h
  -- 3. Vol median ~1x at all timepoints; vol >= 1.5x = only 13-18%
  -- 4. CVD bull% = 52-62% (barely above random); coverage only 24% of tokens
  -- 5. "Invisible" 19%: p24h +9.2%, p4h -1.43%, oi4h -2.40% => pullback in uptrend

  -- SEGMENT BREAKDOWN AT T-4h (774 tokens):
  -- A: OI1h >= 2%                           => 22.7% (caught by existing patterns)
  -- B: silent OI4h >= 4 (OI30m/1h quiet)   => 26.0% (NEW PATTERN needed)
  -- B+A: OI4h >= 4 total                    => 46.3%
  -- C: pure price momentum                  => 11.8%
  -- D: invisible (pullback profile)         => 18.9%

  -- RECOMMENDATIONS:
  -- 1. NEW: oi4h_silent_accum (OI4h >= 4% + OI30m < 1% + p24h 3-20% + vol >= 0.5x)
  -- 2. NEW: 4h_pullback_continuation (p24h 5-20% + p4h < -1.5% + OI4h recovering)
  -- 3. FIX: trend_accumulation — remove CVD gate
  -- 4. FIX: trend_accumulation — add OI4h >= 2% as alternative confirmation path
  