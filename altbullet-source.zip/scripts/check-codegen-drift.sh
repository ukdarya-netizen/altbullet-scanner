#!/usr/bin/env bash
set -euo pipefail

GENERATED_PATHS=(
  "lib/api-client-react/src/generated"
  "lib/api-zod/src/generated"
)

restore_generated() {
  git checkout -- "${GENERATED_PATHS[@]}" 2>/dev/null || true
  git clean -fd "${GENERATED_PATHS[@]}" 2>/dev/null || true
}

trap restore_generated EXIT

pnpm --filter @workspace/api-spec run codegen

drift=0

git diff --exit-code "${GENERATED_PATHS[@]}" || drift=1

if git status --porcelain "${GENERATED_PATHS[@]}" | grep -q "^?"; then
  echo "Error: codegen produced untracked files not committed to the repo:"
  git status --porcelain "${GENERATED_PATHS[@]}" | grep "^?"
  drift=1
fi

if [ $drift -ne 0 ]; then
  echo ""
  echo "Drift detected: generated files are out of sync with the OpenAPI spec."
  echo "Run 'pnpm --filter @workspace/api-spec run codegen' and commit the updated generated files."
  exit 1
fi

echo "No drift detected: generated files are in sync with the OpenAPI spec."
