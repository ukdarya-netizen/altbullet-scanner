/**
 * OI2d backtest — полный многомерный анализ:
 *   - priceDeltaPct (рост за 2 дня)
 *   - OI magnitude (oiD1+oiD2 суммарно)
 *   - OI acceleration (oiD2 > oiD1)
 *   - базовый OI ($M)
 *   - дневной объём BingX
 */

import crypto from "node:crypto";

const CG_KEY = process.env.COINGLASS_API_KEY!;
const BX_KEY = process.env.BINGX_API_KEY!;
const BX_SECRET = process.env.BINGX_API_SECRET!;
const OI_THRESH = 8;

if (!CG_KEY || !BX_KEY || !BX_SECRET) {
  console.error("Missing secrets");
  process.exit(1);
}

function bingxSign(p: Record<string, string>) {
  const qs = Object.entries(p)
    .map(([k, v]) => `${k}=${v}`)
    .join("&");
  return crypto.createHmac("sha256", BX_SECRET).update(qs).digest("hex");
}

interface DayBar {
  date: string;
  close: number;
  volume?: number;
}

async function getBingxDaily(symbol: string, limit = 95): Promise<DayBar[]> {
  const p: Record<string, string> = {
    symbol,
    interval: "1d",
    limit: String(limit),
    timestamp: String(Date.now()),
  };
  p.signature = bingxSign(p);
  const res = await fetch(
    `https://open-api.bingx.com/openApi/swap/v3/quote/klines?${new URLSearchParams(p)}`,
    { headers: { "X-BX-APIKEY": BX_KEY }, signal: AbortSignal.timeout(10000) },
  );
  if (!res.ok) return [];
  const j = (await res.json()) as { data?: unknown };
  if (!Array.isArray(j?.data)) return [];
  return (j.data as { time: number; close: string; volume: string }[])
    .sort((a, b) => a.time - b.time)
    .map((k) => ({
      date: new Date(k.time).toISOString().slice(0, 10),
      close: parseFloat(k.close),
      volume: parseFloat(k.volume),
    }));
}

async function getCGOIDaily(base: string, limit = 95): Promise<DayBar[]> {
  const url = `https://open-api-v4.coinglass.com/api/futures/open-interest/aggregated-history?symbol=${encodeURIComponent(base)}&interval=1d&limit=${limit}`;
  const res = await fetch(url, {
    headers: { "CG-API-KEY": CG_KEY },
    signal: AbortSignal.timeout(12000),
  });
  if (!res.ok) return [];
  const j = (await res.json()) as { data?: unknown };
  if (!Array.isArray(j?.data)) return [];
  return (j.data as { time: number; close: string | number }[])
    .sort((a, b) => a.time - b.time)
    .map((r) => ({
      date: new Date(r.time).toISOString().slice(0, 10),
      close: parseFloat(String(r.close)),
    }));
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const SYMBOLS = [
  "SOL",
  "HYPE",
  "AVAX",
  "NEAR",
  "DOGE",
  "TRX",
  "XRP",
  "DOT",
  "TAO",
  "WLD",
  "ADA",
  "SUI",
  "UNI",
  "AAVE",
  "LTC",
  "INJ",
  "BNB",
  "ONDO",
  "JTO",
  "ZEC",
  "ETC",
  "ICP",
  "CRV",
  "APT",
  "ZRO",
  "BEAT",
  "BCH",
  "ARB",
  "XLM",
  "JUP",
  "TIA",
  "PENDLE",
  "LDO",
  "DYDX",
  "LINK",
  "ENA",
  "ORDI",
  "VIRTUAL",
  "KAITO",
  "PARTI",
  "SAHARA",
  "OP",
  "APE",
  "TAIKO",
  "SEI",
  "FIL",
  "ATOM",
  "RENDER",
  "BERA",
  "COMP",
  "CATI",
  "ZK",
  "FET",
  "PNUT",
  "1000BONK",
  "STX",
  "HBAR",
  "CFX",
  "ENS",
  "RIF",
  "W",
  "STRK",
  "MOVE",
  "RUNE",
  "IMX",
  "KAS",
  "FLOKI",
  "POPCAT",
  "AXS",
  "PYTH",
  "ALGO",
  "MANA",
  "SNX",
  "GRT",
  "ZEN",
  "CHZ",
  "CELO",
  "CAKE",
  "SUSHI",
  "VET",
  "IOTA",
  "SAND",
  "PENGU",
  "QNT",
  "AR",
  "NEO",
  "AGLD",
  "TWT",
  "FORM",
  "ORCA",
  "ATH",
  "SLX",
  "ARPA",
  "HOLO",
  "DASH",
  "BOME",
  "FHE",
  "ID",
  "NMR",
  "API3",
  "GALA",
  "SWARMS",
  "GRASS",
  "VELVET",
  "EVAA",
  "ALLO",
].map((s) => `${s}-USDT`);

interface Hit {
  symbol: string;
  date: string;
  priceDelta2d: number;
  return24h: number;
  return48h: number;
  oiD1: number;
  oiD2: number;
  oiSum: number;
  oiAccel: boolean;
  baseOI: number;
  vol: number;
}

const hits: Hit[] = [];

for (let si = 0; si < SYMBOLS.length; si++) {
  const symbol = SYMBOLS[si];
  const base = symbol.replace("-USDT", "");
  const [pxBars, oiBars] = await Promise.all([
    getBingxDaily(symbol),
    getCGOIDaily(base),
  ]);
  await sleep(700);

  if (pxBars.length < 5 || oiBars.length < 5) continue;

  const pxMap = new Map(pxBars.map((b) => [b.date, b]));

  for (let i = 2; i < oiBars.length - 2; i++) {
    const oiD2 =
      oiBars[i - 1].close > 0
        ? ((oiBars[i].close - oiBars[i - 1].close) / oiBars[i - 1].close) * 100
        : 0;
    const oiD1 =
      oiBars[i - 2].close > 0
        ? ((oiBars[i - 1].close - oiBars[i - 2].close) / oiBars[i - 2].close) *
          100
        : 0;
    if (oiD1 < OI_THRESH || oiD2 < OI_THRESH) continue;
    if (oiBars[i].close < 1_000_000) continue;

    const d0 = oiBars[i].date;
    const dm2 = oiBars[i - 2].date;
    const df1 = oiBars[i + 1]?.date;
    const df2 = oiBars[i + 2]?.date;

    const bD0 = pxMap.get(d0);
    const bDm2 = pxMap.get(dm2);
    const bF1 = df1 ? pxMap.get(df1) : undefined;
    const bF2 = df2 ? pxMap.get(df2) : undefined;

    if (!bD0 || !bDm2 || !bF1 || !bF2 || bDm2.close <= 0 || bD0.close <= 0)
      continue;

    const priceDelta2d = (bD0.close / bDm2.close - 1) * 100;
    if (priceDelta2d < 0 || priceDelta2d > 40) continue;

    hits.push({
      symbol,
      date: d0,
      priceDelta2d,
      return24h: (bF1.close / bD0.close - 1) * 100,
      return48h: (bF2.close / bD0.close - 1) * 100,
      oiD1,
      oiD2,
      oiSum: oiD1 + oiD2,
      oiAccel: oiD2 > oiD1,
      baseOI: oiBars[i].close,
      vol: bD0.volume ?? 0,
    });
  }
  if ((si + 1) % 25 === 0)
    process.stdout.write(
      `  [${si + 1}/${SYMBOLS.length}] hits:${hits.length}\n`,
    );
}

console.log(`\nTotal hits: ${hits.length}\n`);

// ── helpers ───────────────────────────────────────────────────────────────────
function row(rows: Hit[], label: string) {
  if (!rows.length) return `  ${label.padEnd(18)} n=  0`;
  const n = rows.length;
  const a24 = rows.reduce((s, h) => s + h.return24h, 0) / n;
  const w24 = rows.filter((h) => h.return24h > 0).length;
  const w2p = rows.filter((h) => h.return24h > 2).length;
  const st = rows.filter((h) => h.return24h < -5).length;
  const a48 = rows.reduce((s, h) => s + h.return48h, 0) / n;
  const w48 = rows.filter((h) => h.return48h > 0).length;
  const f = (v: number) => (v >= 0 ? "+" : "") + v.toFixed(1) + "%";
  const p = (x: number) => Math.round((x / n) * 100) + "%";
  return `  ${label.padEnd(18)} n=${String(n).padStart(3)}  24h avg=${f(a24).padStart(6)} win>0=${p(w24).padStart(4)} win>2%=${p(w2p).padStart(4)} stop<-5%=${p(st).padStart(4)}  |  48h avg=${f(a48).padStart(6)} win>0=${p(w48).padStart(4)}`;
}

const hdr =
  "  " +
  [
    "label",
    "n",
    "24h avg",
    "win>0",
    "win>2%",
    "stop<-5%",
    "48h avg",
    "win>0(48h)",
  ].join("  ");
const sep = "─".repeat(110);

// ── 1. priceDeltaPct ──────────────────────────────────────────────────────────
console.log("═".repeat(110));
console.log(" 1. ЦЕНОВОЙ РОСТ ЗА 2 ДНЯ ДО СИГНАЛА (priceDelta2d)");
console.log("═".repeat(110));
for (const [min, max, lbl] of [
  [0, 2, "0-2%"],
  [2, 5, "2-5%"],
  [5, 8, "5-8%"],
  [8, 10, "8-10%"],
  [10, 15, "10-15%"],
  [15, 40, "15-40%"],
] as [number, number, string][])
  console.log(
    row(
      hits.filter((h) => h.priceDelta2d >= min && h.priceDelta2d < max),
      lbl,
    ),
  );
console.log(sep);
console.log(row(hits, "ИТОГО"));

// ── 2. OI суммарное ──────────────────────────────────────────────────────────
console.log("\n" + "═".repeat(110));
console.log(" 2. СУММАРНЫЙ OI ЗА 2 ДНЯ (oiD1+oiD2) — сила накопления");
console.log("═".repeat(110));
for (const [min, max, lbl] of [
  [16, 25, "16-25%"],
  [25, 35, "25-35%"],
  [35, 50, "35-50%"],
  [50, 999, "50%+"],
] as [number, number, string][])
  console.log(
    row(
      hits.filter((h) => h.oiSum >= min && h.oiSum < max),
      lbl,
    ),
  );

// ── 3. OI ускорение ──────────────────────────────────────────────────────────
console.log("\n" + "═".repeat(110));
console.log(
  " 3. УСКОРЕНИЕ OI (oiD2 > oiD1 = нарастает, oiD2 < oiD1 = замедляется)",
);
console.log("═".repeat(110));
console.log(
  row(
    hits.filter((h) => h.oiAccel),
    "нарастает (accel)",
  ),
);
console.log(
  row(
    hits.filter((h) => !h.oiAccel),
    "замедляется (decel)",
  ),
);

// ── 4. База OI ($M) ──────────────────────────────────────────────────────────
console.log("\n" + "═".repeat(110));
console.log(" 4. БАЗОВЫЙ OI (размер позиции на момент сигнала)");
console.log("═".repeat(110));
for (const [min, max, lbl] of [
  [1e6, 5e6, "$1-5M"],
  [5e6, 20e6, "$5-20M"],
  [20e6, 100e6, "$20-100M"],
  [100e6, 1e12, "$100M+"],
] as [number, number, string][])
  console.log(
    row(
      hits.filter((h) => h.baseOI >= min && h.baseOI < max),
      lbl,
    ),
  );

// ── 5. Комбо: лучшие условия ─────────────────────────────────────────────────
console.log("\n" + "═".repeat(110));
console.log(" 5. КОМБО-ФИЛЬТРЫ (лучшие комбинации)");
console.log("═".repeat(110));
// price 2-8% (оптимальная зона) + acceleration
console.log(
  row(
    hits.filter((h) => h.priceDelta2d >= 2 && h.priceDelta2d < 8 && h.oiAccel),
    "price2-8% + accel",
  ),
);
console.log(
  row(
    hits.filter((h) => h.priceDelta2d >= 2 && h.priceDelta2d < 8 && !h.oiAccel),
    "price2-8% + decel",
  ),
);
console.log(
  row(
    hits.filter((h) => h.priceDelta2d >= 2 && h.priceDelta2d < 8),
    "price2-8% любой",
  ),
);
console.log(
  row(
    hits.filter((h) => h.priceDelta2d < 8 && h.oiAccel && h.baseOI >= 5e6),
    "price<8%+accel+OI>$5M",
  ),
);
console.log(
  row(
    hits.filter((h) => h.priceDelta2d < 8 && h.oiSum >= 35),
    "price<8%+sum≥35%",
  ),
);
console.log(
  row(
    hits.filter((h) => h.priceDelta2d >= 8),
    "price≥8% (всё)",
  ),
);

// ── 6. Топ/худшие ─────────────────────────────────────────────────────────────
const s24 = [...hits].sort((a, b) => b.return24h - a.return24h);
console.log("\n Топ-10 лучших 24h:");
s24
  .slice(0, 10)
  .forEach((h) =>
    console.log(
      `  ${h.symbol.padEnd(16)} ${h.date}  Δp2d=+${h.priceDelta2d.toFixed(1)}%  OI+${h.oiD1.toFixed(0)}%→+${h.oiD2.toFixed(0)}%  accel=${h.oiAccel ? "✓" : "✗"}  OI=$${(h.baseOI / 1e6).toFixed(1)}M  → +${h.return24h.toFixed(1)}%`,
    ),
  );
console.log("\n Топ-10 худших 24h:");
s24
  .slice(-10)
  .reverse()
  .forEach((h) =>
    console.log(
      `  ${h.symbol.padEnd(16)} ${h.date}  Δp2d=+${h.priceDelta2d.toFixed(1)}%  OI+${h.oiD1.toFixed(0)}%→+${h.oiD2.toFixed(0)}%  accel=${h.oiAccel ? "✓" : "✗"}  OI=$${(h.baseOI / 1e6).toFixed(1)}M  → ${h.return24h.toFixed(1)}%`,
    ),
  );
