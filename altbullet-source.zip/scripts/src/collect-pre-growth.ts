/**
 * collect-pre-growth.ts
 *
 * Собирает исторические метрики по 774 ретро-токенам за T-2h/3h/4h/6h/12h
 * ДО момента retro-логирования (когда p24h уже был ≥20%).
 *
 * Источники:
 *  - BingX 1h + 30m klines → price_1h, price_3h, price_24h, vol_mult
 *  - CoinGlass OI 1h + 30m → oi_30m, oi_1h
 *  - CoinGlass SpotTaker 1h → cvd_1h (bool)
 *  - CoinGlass FutTaker 1h  → net_buy_pct
 *
 * Запуск:
 *   DATABASE_URL=<neon_url> BINGX_API_KEY=... BINGX_API_SECRET=... \
 *   COINGLASS_API_KEY=... COINGLASS_API_KEY_2=... ... \
 *   tsx scripts/src/collect-pre-growth.ts
 *
 * Чекпоинт: /tmp/pre-growth-checkpoint.json (resume support)
 */

import pg from "pg";
import fs from "fs";
import crypto from "crypto";

const { Pool } = pg;

// ── Config ─────────────────────────────────────────────────────────────────────

const HOURS_BEFORE = [2, 3, 4, 6, 12];
const BATCH_SIZE = 4;
const BATCH_DELAY_MS = 1200;
const CG_CALL_DELAY = 220;
const CHECKPOINT = "/tmp/pre-growth-checkpoint.json";

// ── CoinGlass keys ─────────────────────────────────────────────────────────────

const CG_KEYS = [
  process.env.COINGLASS_API_KEY,
  process.env.COINGLASS_API_KEY_2,
  process.env.COINGLASS_API_KEY_3,
  process.env.COINGLASS_API_KEY_4,
  process.env.COINGLASS_API_KEY_5,
].filter(Boolean) as string[];

let _cgIdx = 0;
function nextCgKey(): string | null {
  if (CG_KEYS.length === 0) return null;
  return CG_KEYS[_cgIdx++ % CG_KEYS.length]!;
}

// ── Helpers ────────────────────────────────────────────────────────────────────

const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

async function cgFetch<T>(url: string): Promise<T[] | null> {
  const key = nextCgKey();
  if (!key) return null;
  try {
    const res = await fetch(url, {
      headers: { "CG-API-KEY": key, Accept: "application/json" },
      signal: AbortSignal.timeout(12_000),
    });
    if (res.status === 429) {
      console.warn(
        `  ⚠ CG 429 key=...${key.slice(-4)} url=${url.slice(0, 80)}`,
      );
      return null;
    }
    const json = (await res.json()) as { code?: string; data?: T[] };
    if (
      json.code !== "0" ||
      !Array.isArray(json.data) ||
      json.data.length === 0
    )
      return null;
    return json.data;
  } catch {
    return null;
  }
}

// ── BingX klines (with startTime) ─────────────────────────────────────────────

interface BingXKline {
  time: number;
  open: string;
  high: string;
  low: string;
  close: string;
  volume: string;
}

async function fetchBingxKlines(
  symbol: string,
  interval: "1h" | "30m",
  startTimeMs: number,
  limit: number,
): Promise<Array<{ time: number; close: number; volUsd: number }>> {
  const key = process.env.BINGX_API_KEY ?? "";
  const secret = process.env.BINGX_API_SECRET ?? "";

  const params: Record<string, string | number> = {
    symbol,
    interval,
    limit,
    startTime: startTimeMs,
    timestamp: Date.now(),
  };
  const sorted = Object.entries(params).sort(([a], [b]) => a.localeCompare(b));
  const qs = sorted.map(([k, v]) => `${k}=${v}`).join("&");
  const sig = crypto.createHmac("sha256", secret).update(qs).digest("hex");
  const url = `https://open-api.bingx.com/openApi/swap/v3/quote/klines?${qs}&signature=${sig}`;

  try {
    const res = await fetch(url, {
      headers: { "X-BX-APIKEY": key, "X-SOURCE-KEY": "AlphaScanner" },
      signal: AbortSignal.timeout(15_000),
    });
    if (!res.ok) return [];
    const json = (await res.json()) as { data?: BingXKline[] };
    const raw = Array.isArray(json?.data) ? (json.data as BingXKline[]) : [];
    return raw
      .map((k) => ({
        time: k.time,
        close: parseFloat(k.close),
        volUsd: parseFloat(k.volume) * parseFloat(k.close),
      }))
      .filter((k) => k.close > 0)
      .sort((a, b) => a.time - b.time);
  } catch {
    return [];
  }
}

// ── CoinGlass OI ──────────────────────────────────────────────────────────────

interface CgOiPoint {
  time: number;
  open: number;
  close: number;
}
interface CgTakerPt {
  time: number;
  taker_buy_volume_usd: string;
  taker_sell_volume_usd: string;
}

function calcOiPct(
  pts: CgOiPoint[],
  atMs: number,
  windowMs: number,
): number | null {
  const cur = pts.reduce<CgOiPoint | null>(
    (b, p) => (!b || Math.abs(p.time - atMs) < Math.abs(b.time - atMs) ? p : b),
    null,
  );
  if (!cur) return null;
  const prevT = atMs - windowMs;
  const prev = pts.reduce<CgOiPoint | null>((b, p) => {
    if (p.time > atMs - windowMs / 2) return b;
    return !b || Math.abs(p.time - prevT) < Math.abs(b.time - prevT) ? p : b;
  }, null);
  if (!prev || prev.close <= 0) return null;
  return ((cur.close - prev.close) / prev.close) * 100;
}

function sumTaker(pts: CgTakerPt[], atMs: number, windowMs: number) {
  let buy = 0,
    sell = 0;
  for (const p of pts) {
    if (p.time >= atMs - windowMs && p.time <= atMs + 3_600_000) {
      buy += parseFloat(p.taker_buy_volume_usd) || 0;
      sell += parseFloat(p.taker_sell_volume_usd) || 0;
    }
  }
  return { buy, sell };
}

// ── Metrics from klines at a given snapshot time ───────────────────────────────

function klineMetrics(
  bars: Array<{ time: number; close: number; volUsd: number }>,
  atMs: number,
  avgVol: number,
) {
  // find bar closest to atMs
  let best = -1,
    bestDist = Infinity;
  for (let i = 0; i < bars.length; i++) {
    const d = Math.abs(bars[i]!.time - atMs);
    if (d < bestDist) {
      bestDist = d;
      best = i;
    }
  }
  if (best < 0 || bestDist > 2 * 3_600_000) return null; // >2h gap = no data

  const bar = bars[best]!;

  const bar1h = best >= 1 ? bars[best - 1] : null;
  const bar3h = best >= 3 ? bars[best - 3] : null;
  const bar24h = best >= 24 ? bars[best - 24] : null;

  return {
    price: bar.close,
    price_1h:
      bar1h && bar1h.close > 0
        ? ((bar.close - bar1h.close) / bar1h.close) * 100
        : null,
    price_3h:
      bar3h && bar3h.close > 0
        ? ((bar.close - bar3h.close) / bar3h.close) * 100
        : null,
    price_24h:
      bar24h && bar24h.close > 0
        ? ((bar.close - bar24h.close) / bar24h.close) * 100
        : null,
    vol_mult: avgVol > 0 ? bar.volUsd / avgVol : null,
  };
}

// ── DB row ─────────────────────────────────────────────────────────────────────

interface RetroEntry {
  id: number;
  symbol: string;
  logged_at: Date;
}

interface PreGrowthRow {
  retro_log_id: number;
  symbol: string;
  retro_time: Date;
  hours_before: number;
  snapshot_time: Date;
  price: number | null;
  price_1h: number | null;
  price_3h: number | null;
  price_24h: number | null;
  oi_30m: number | null;
  oi_1h: number | null;
  vol_mult: number | null;
  cvd_1h: boolean | null;
  net_buy_pct: number | null;
}

// ── Checkpoint ─────────────────────────────────────────────────────────────────

function loadCp(): Set<string> {
  try {
    if (fs.existsSync(CHECKPOINT)) {
      const d = JSON.parse(fs.readFileSync(CHECKPOINT, "utf8")) as {
        done: string[];
      };
      console.log(`📂 Чекпоинт: ${d.done.length} символов уже готово`);
      return new Set(d.done);
    }
  } catch {
    /* ok */
  }
  return new Set();
}
function saveCp(done: Set<string>): void {
  fs.writeFileSync(CHECKPOINT, JSON.stringify({ done: [...done] }, null, 2));
}

// ── Process one symbol ─────────────────────────────────────────────────────────

async function processSymbol(
  symbol: string,
  entries: RetroEntry[],
  pool: pg.Pool,
): Promise<number> {
  const base = symbol.replace(/-USDT$/, "");
  // Earliest retro time for this symbol → we need data from T-13h before it
  const minTs = Math.min(...entries.map((e) => e.logged_at.getTime()));
  const fetchFrom = minTs - 13 * 3_600_000; // cover T-12h with margin
  // Fetch from fetchFrom-24h to get price_24h at the earliest snapshot
  const klineStart = fetchFrom - 24 * 3_600_000;
  const klineLimit = Math.ceil((Date.now() - klineStart) / 3_600_000) + 5;

  console.log(
    `  [${symbol}] ${entries.length} entries, fetchFrom=${new Date(fetchFrom).toISOString()}`,
  );

  // BingX 1h klines — need ~38 candles per entry min, fetch generously
  const bars1h = await fetchBingxKlines(
    symbol,
    "1h",
    klineStart,
    Math.min(klineLimit, 500),
  );
  await delay(100);

  if (bars1h.length < 5) {
    console.log(`    ⚠ BingX 1h: только ${bars1h.length} свечей — пропускаем`);
    return 0;
  }

  const avgVol1h = bars1h.reduce((s, b) => s + b.volUsd, 0) / bars1h.length;

  // CoinGlass: OI 1h + OI 30m + SpotTaker 1h + FutTaker 1h
  const cgLimit = Math.ceil((Date.now() - fetchFrom) / 3_600_000) + 5;
  const cgStart = fetchFrom;

  const [oi1h, oi30m, spotTaker, futTaker] = await Promise.all([
    cgFetch<CgOiPoint>(
      `https://open-api-v4.coinglass.com/api/futures/open-interest/aggregated-history?symbol=${encodeURIComponent(base)}&interval=1h&start_time=${cgStart}&limit=${Math.min(cgLimit + 5, 200)}`,
    ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
    delay(CG_CALL_DELAY).then(() =>
      cgFetch<CgOiPoint>(
        `https://open-api-v4.coinglass.com/api/futures/open-interest/aggregated-history?symbol=${encodeURIComponent(base)}&interval=30m&start_time=${cgStart}&limit=${Math.min(cgLimit * 2 + 10, 400)}`,
      ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
    ),
    delay(CG_CALL_DELAY * 2).then(() =>
      cgFetch<CgTakerPt>(
        `https://open-api-v4.coinglass.com/api/spot/taker-buy-sell-volume/history?exchange=Binance&symbol=${base}USDT&interval=1h&start_time=${cgStart}&limit=${Math.min(cgLimit + 5, 200)}`,
      ),
    ),
    delay(CG_CALL_DELAY * 3).then(() =>
      cgFetch<CgTakerPt>(
        `https://open-api-v4.coinglass.com/api/futures/taker-buy-sell-volume/history?exchange=Binance&symbol=${base}USDT&interval=1h&start_time=${cgStart}&limit=${Math.min(cgLimit + 5, 200)}`,
      ),
    ),
  ]);

  const rows: PreGrowthRow[] = [];

  for (const entry of entries) {
    const retroMs = entry.logged_at.getTime();

    for (const hb of HOURS_BEFORE) {
      const snapMs = retroMs - hb * 3_600_000;

      const km = klineMetrics(bars1h, snapMs, avgVol1h);
      if (!km) continue; // no kline data near this snapshot time

      // OI
      const oi1hVal = oi1h ? calcOiPct(oi1h, snapMs, 60 * 60_000) : null;
      const oi30mVal = oi30m ? calcOiPct(oi30m, snapMs, 30 * 60_000) : null;

      // SpotTaker CVD
      let cvd1h: boolean | null = null;
      if (spotTaker) {
        const w = sumTaker(spotTaker, snapMs, 3_600_000);
        if (w.buy + w.sell > 0) cvd1h = w.buy > w.sell;
      }

      // FutTaker net_buy_pct
      let netBuyPct: number | null = null;
      if (futTaker) {
        const w = sumTaker(futTaker, snapMs, 3_600_000);
        if (w.buy + w.sell > 0)
          netBuyPct = ((w.buy - w.sell) / (w.buy + w.sell)) * 100;
      }

      rows.push({
        retro_log_id: entry.id,
        symbol,
        retro_time: entry.logged_at,
        hours_before: hb,
        snapshot_time: new Date(snapMs),
        price: km.price,
        price_1h: km.price_1h,
        price_3h: km.price_3h,
        price_24h: km.price_24h,
        oi_30m: oi30mVal,
        oi_1h: oi1hVal,
        vol_mult: km.vol_mult,
        cvd_1h: cvd1h,
        net_buy_pct: netBuyPct,
      });
    }
  }

  if (rows.length === 0) {
    console.log(`    — нет данных`);
    return 0;
  }

  // INSERT
  const vals = rows
    .map((_, i) => {
      const b = i * 15;
      return `($${b + 1},$${b + 2},$${b + 3},$${b + 4},$${b + 5},$${b + 6},$${b + 7},$${b + 8},$${b + 9},$${b + 10},$${b + 11},$${b + 12},$${b + 13},$${b + 14},$${b + 15})`;
    })
    .join(",");

  const params = rows.flatMap((r) => [
    r.retro_log_id,
    r.symbol,
    r.retro_time,
    r.hours_before,
    r.snapshot_time,
    r.price,
    r.price_1h,
    r.price_3h,
    r.price_24h,
    r.oi_30m,
    r.oi_1h,
    r.vol_mult,
    r.cvd_1h,
    r.net_buy_pct,
    null, // reserved
  ]);

  try {
    await pool.query(
      `
      INSERT INTO retro_pre_growth
        (retro_log_id, symbol, retro_time, hours_before, snapshot_time,
         price, price_1h, price_3h, price_24h,
         oi_30m, oi_1h, vol_mult, cvd_1h, net_buy_pct, notes)
      VALUES ${vals}
      ON CONFLICT (retro_log_id, hours_before) DO NOTHING
    `,
      params,
    );
    console.log(`    ✓ ${rows.length} строк вставлено`);
    return rows.length;
  } catch (err) {
    console.warn(`    ✗ INSERT error: ${err}`);
    return 0;
  }
}

// ── Main ───────────────────────────────────────────────────────────────────────

async function main() {
  console.log("🚀 collect-pre-growth: старт");
  console.log(
    `   Снимки: T-${HOURS_BEFORE.join("h, T-")}h до retro-логирования`,
  );

  if (!process.env.DATABASE_URL) {
    console.error("DATABASE_URL не задан");
    process.exit(1);
  }
  if (!process.env.BINGX_API_KEY) {
    console.error("BINGX_API_KEY не задан");
    process.exit(1);
  }

  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 3,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 15_000,
  });

  // ── DDL ─────────────────────────────────────────────────────────────────────
  await pool.query(`
    CREATE TABLE IF NOT EXISTS retro_pre_growth (
      id            SERIAL PRIMARY KEY,
      retro_log_id  INTEGER NOT NULL,
      symbol        TEXT    NOT NULL,
      retro_time    TIMESTAMPTZ NOT NULL,
      hours_before  INTEGER NOT NULL,
      snapshot_time TIMESTAMPTZ NOT NULL,
      price         REAL,
      price_1h      REAL,
      price_3h      REAL,
      price_24h     REAL,
      oi_30m        REAL,
      oi_1h         REAL,
      vol_mult      REAL,
      cvd_1h        BOOLEAN,
      net_buy_pct   REAL,
      notes         TEXT,
      created_at    TIMESTAMPTZ DEFAULT NOW(),
      UNIQUE (retro_log_id, hours_before)
    )
  `);
  console.log("✓ Таблица retro_pre_growth готова");

  // ── Load retro entries ───────────────────────────────────────────────────────
  const { rows: entries } = await pool.query<RetroEntry>(`
    SELECT id, symbol, logged_at
    FROM growth_leader_log
    WHERE retro = true
    ORDER BY symbol, logged_at
  `);
  console.log(
    `📥 Загружено ${entries.length} retro-строк, ${new Set(entries.map((e) => e.symbol)).size} символов`,
  );

  // Group by symbol
  const bySymbol = new Map<string, RetroEntry[]>();
  for (const e of entries) {
    if (!bySymbol.has(e.symbol)) bySymbol.set(e.symbol, []);
    bySymbol.get(e.symbol)!.push(e);
  }
  const symbols = [...bySymbol.keys()];

  // ── Checkpoint ───────────────────────────────────────────────────────────────
  const done = loadCp();
  const todo = symbols.filter((s) => !done.has(s));
  console.log(
    `  → ${todo.length} символов к обработке (${done.size} уже в чекпоинте)\n`,
  );

  let totalRows = 0;

  for (let i = 0; i < todo.length; i += BATCH_SIZE) {
    const batch = todo.slice(i, i + BATCH_SIZE);

    const results = await Promise.allSettled(
      batch.map((sym) => processSymbol(sym, bySymbol.get(sym)!, pool)),
    );

    for (const r of results) {
      if (r.status === "fulfilled") totalRows += r.value;
    }

    for (const sym of batch) done.add(sym);
    saveCp(done);

    const pct = Math.round(
      (Math.min(i + BATCH_SIZE, todo.length) / todo.length) * 100,
    );
    console.log(
      `📊 ${Math.min(i + BATCH_SIZE, todo.length)}/${todo.length} символов (${pct}%) | строк: ${totalRows}\n`,
    );

    if (i + BATCH_SIZE < todo.length) await delay(BATCH_DELAY_MS);
  }

  await pool.end();
  console.log(`\n✅ Готово. Вставлено строк: ${totalRows}`);
  try {
    fs.unlinkSync(CHECKPOINT);
  } catch {
    /* ok */
  }
}

main().catch((err) => {
  console.error("FATAL:", err);
  process.exit(1);
});
