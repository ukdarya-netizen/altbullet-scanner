#!/usr/bin/env python3
"""
Fast liq heatmap + HL whale backfill (large orders already done).
Rate limit: 1200 credits/min. Heatmap = 8 credits each.
224 symbols = 1792 credits → ~90s at 20 credits/sec.
"""
import os, sys, json, time, requests, psycopg2
from datetime import datetime, timezone
from psycopg2.extras import execute_values

CG_KEY = os.environ["COINGLASS_API_KEY"]
DATABASE_URL = os.environ["DATABASE_URL"]
ADMIN_TOKEN = os.environ["ADMIN_TOKEN"]
CG_BASE = "https://open-api-v4.coinglass.com"
ARCHETYPE_API = "http://localhost:8000"
HEADERS = {"CG-API-KEY": CG_KEY}

cg_credits_used = 0

def cg_get(path, params, timeout=20, cost=1):
    global cg_credits_used
    r = requests.get(f"{CG_BASE}{path}", headers=HEADERS, params=params, timeout=timeout)
    if r.status_code != 200:
        return None
    d = r.json()
    if str(d.get("code", "")) not in ("0", ""):
        return None
    cg_credits_used += cost
    return d.get("data")

def get_symbols():
    r = requests.post(
        f"{ARCHETYPE_API}/admin/sql",
        headers={"X-Admin-Token": ADMIN_TOKEN, "Content-Type": "application/json"},
        json={"sql": "SELECT DISTINCT symbol FROM market_snapshots ORDER BY symbol"},
        timeout=15
    )
    return [row["symbol"] for row in r.json()]

def to_base(sym):
    return sym.replace("-USDT", "")

def collect_heatmap(conn, symbols):
    now = datetime.now(timezone.utc)
    snapshot_at = now.replace(minute=0, second=0, microsecond=0)

    # Check already-collected symbols
    with conn.cursor() as cur:
        cur.execute("SELECT symbol FROM cg_liq_heatmap_snapshot")
        already_done = {r[0] for r in cur.fetchall()}

    todo = [s for s in symbols if to_base(s) not in already_done]
    print(f"[Liq heatmap] {len(already_done)} already done, {len(todo)} remaining")

    inserted = 0
    failed = 0
    # 1200 credits/min = 20/sec; 8 credits/call → 2.5 calls/sec max → sleep 0.5s between calls
    SLEEP = 0.45

    for i, sym in enumerate(todo):
        base = to_base(sym)
        if not any(c.isalpha() for c in base):
            failed += 1
            continue
        try:
            data = cg_get("/api/futures/liquidation/aggregated-heatmap/model2",
                          {"symbol": base, "range": "3d"}, cost=8)
            if not data:
                failed += 1
                # Small backoff on API errors
                time.sleep(1.0)
                continue

            y_axis = data.get("y_axis", [])
            liq_data = data.get("liquidation_leverage_data", [])
            candles = data.get("price_candlesticks", [])

            if not y_axis:
                failed += 1
                time.sleep(SLEEP)
                continue

            with conn.cursor() as cur:
                cur.execute(
                    """INSERT INTO cg_liq_heatmap_snapshot
                       (symbol, range, snapshot_at, y_axis, liq_leverage_data, price_candlesticks)
                       VALUES (%s, %s, %s, %s, %s, %s)
                       ON CONFLICT (symbol, range, snapshot_at) DO NOTHING""",
                    (base, "3d", snapshot_at,
                     json.dumps(y_axis), json.dumps(liq_data), json.dumps(candles))
                )
            conn.commit()
            ins = cur.rowcount
            inserted += ins
            if i % 15 == 0:
                print(f"  [{i+1}/{len(todo)}] {base}: {'ok' if ins else 'dup'} | inserted={inserted} | credits={cg_credits_used}")
            time.sleep(SLEEP)
        except Exception as e:
            print(f"  [{i+1}] {base}: ERR {e}")
            failed += 1
            time.sleep(1.0)

    print(f"[Liq heatmap] Done: inserted={inserted}, failed/empty={failed}")
    return inserted

def collect_hl_whale_events(conn):
    print("\n[HL Whale events] Collecting...")
    data = cg_get("/api/hyperliquid/whale-alert", {"limit": 200}, cost=1)
    if not data:
        print("  No data"); return 0
    rows = [(i.get("user"), i.get("symbol"), i.get("position_size"),
             i.get("entry_price"), i.get("liq_price"), i.get("position_value_usd"),
             i.get("position_action"), i.get("create_time")) for i in data]
    with conn.cursor() as cur:
        execute_values(cur,
            """INSERT INTO cg_hl_whale_events
               (user_address, symbol, position_size, entry_price, liq_price,
                position_value_usd, position_action, create_time)
               VALUES %s ON CONFLICT (user_address, symbol, create_time) DO NOTHING""",
            rows)
    conn.commit()
    n = cur.rowcount
    print(f"[HL Whale events] {n} inserted from {len(data)} records")
    return n

def collect_hl_positions(conn):
    print("\n[HL Whale positions] Collecting...")
    snapshot_at = datetime.now(timezone.utc)
    data = cg_get("/api/hyperliquid/whale-position", {"limit": 1000}, cost=1)
    if not data:
        print("  No data"); return 0
    rows = [(i.get("user"), i.get("symbol"), i.get("position_size"),
             i.get("entry_price"), i.get("mark_price"), i.get("liq_price"),
             i.get("leverage"), i.get("margin_balance"), i.get("position_value_usd"),
             i.get("unrealized_pnl"), i.get("funding_fee"), i.get("margin_mode"),
             i.get("create_time"), i.get("update_time"), snapshot_at) for i in data]
    with conn.cursor() as cur:
        execute_values(cur,
            """INSERT INTO cg_hl_whale_positions
               (user_address, symbol, position_size, entry_price, mark_price,
                liq_price, leverage, margin_balance, position_value_usd,
                unrealized_pnl, funding_fee, margin_mode, create_time,
                update_time, snapshot_at)
               VALUES %s ON CONFLICT (user_address, symbol, snapshot_at) DO NOTHING""",
            rows)
    conn.commit()
    n = cur.rowcount
    print(f"[HL Whale positions] {n} inserted from {len(data)} records")
    return n

if __name__ == "__main__":
    print(f"[Start] {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    conn = psycopg2.connect(DATABASE_URL)
    symbols = get_symbols()
    print(f"[Pool] {len(symbols)} symbols")

    collect_heatmap(conn, symbols)
    collect_hl_whale_events(conn)
    collect_hl_positions(conn)

    with conn.cursor() as cur:
        print("\n=== FINAL COUNTS ===")
        for t in ["cg_large_orders_futures", "cg_large_orders_spot",
                  "cg_liq_heatmap_snapshot", "cg_hl_whale_events", "cg_hl_whale_positions"]:
            cur.execute(f"SELECT count(*) FROM {t}")
            print(f"  {t}: {cur.fetchone()[0]}")

    print(f"\n[Done] Total CG credits used: {cg_credits_used}")
    print(f"[Done] {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}")
    conn.close()
