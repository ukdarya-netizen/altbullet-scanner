# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Contains BingX Alpha Scanner — a real-time crypto futures signal detection dashboard.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Frontend**: React + Vite + Tailwind CSS + shadcn/ui

## Architecture

- `artifacts/api-server` — Express backend with BingX API integration, scanner engine, and Telegram alerts
- `artifacts/alpha-scanner` — React frontend dashboard (dark terminal theme)
- `lib/db` — Drizzle ORM schema: `signals`, `settings` tables
- `lib/api-spec` — OpenAPI spec for all endpoints

## Key Features

BingX Futures market scanner — 500+ USDT perpetual pairs, скан каждые ~10 мин.

---

### 🔍 Слои прескана — как токен попадает в батч сканера

Каждый скан-цикл (~10 мин) формирует батч из 500+ токенов. Токен может попасть через несколько слоёв одновременно — теги аккумулируются.

⛔ **Единый фильтр:** price24h > +40% (перегрев) или < −40% (обвал) → вылетает из всех слоёв **кроме WL**.

#### Базовые слои (скоринг + объём)

| Тег | Название | Лимит | Условие попадания |
|-----|----------|-------|-------------------|
| **WL** | Watchlist | Без лимита | Ручной список в настройках — всегда в батче, единый фильтр не применяется |
| **L1** | Hot Movers | Топ-50 | Activity score: объём 24h + OI change + движение цены; топ по совокупному баллу |
| **L2** | Volume | Топ-200 | CoinGlass global vol (на первом цикле — BingX-объём как фолбэк) |
| **L3** | OI Movers | Без лимита | CoinGlass OI спайк: 30m ≥6% / 1h ≥3% / 4h ≥8% / 24h ≥10% |
| **L4** | Vol Awaken | Без лимита | Дельта объёма ×2.5+ от 5-циклового среднего + price24h 3–15% («просыпающиеся») |
| **L5** | OI Accel | Без лимита | OI30m ускоряется между циклами: lastOi30m > prevOi30m × 1.3 + оба >0 |

#### Специальные слои (сигналы + контекст)

| Тег | Название | Условие попадания | Примечание |
|-----|----------|-------------------|------------|
| **L6c** | CG Blind Rescue | CoinGlass timeout/отсутствие данных + Coinalyze OI 30m ≥1.5% → принудительный инжект | Спасение BingX-exclusive токенов от слепой зоны CG; OI Watch cg_timeout 6ч |
| **L7** | OI Watch Orphans | Активные записи `oi_watch` (watching/confirming) без текущего prescan-тега | Каждый цикл добавляет к батчу — гарантирует продолжение сканирования до истечения |
| **L8** | Steady Climbers | Поведенческий тег: growthCycles ≥2 + p24h 0–40% — устойчивый рост без откатов | Навешивается поверх любого источника; scSet — discovery, steadyClimbMap — поведение |
| **L8b** | OI 24h Leaders | Проактивный OI Watch: OI24h ≥8% + price −5..+35% + база OI ≥$1M | Инжектируется в OI Watch на 12ч не дожидаясь паттерна; Layer 7 подхватывает |

#### Пулы — внешние источники (job-based)

| Тег | Название | Job | Условие добавления в пул | Окно |
|-----|----------|-----|--------------------------|------|
| **L9** | Bid Walls | BidWallJob каждые 30 мин | CoinGlass futures orderbook heatmap: стена ≥0.05% MCap + ratio ask/bid ≥2x | 24ч |
| **L10** | Liq Cascade Watch | LiqCascadeWatcher каждые 3 мин | longLiq1h/longLiq24h ≥ 25% + longLiq1h ≥$50K + p24h ≤+5% (лонг-ликвидации спайк) **или** поток liq-ордеров (liq_order_stream) | В пуле `liq_cascade_watch` до подтверждения/истечения |
| **L11** | Whale Alert (Hyperliquid) | WhaleAlertJob каждые 3 мин | Кит открыл лонг ≥$500K на Hyperliquid (CoinGlass whale-alert API) | 24ч; HL Position Tracker 15 мин |
| **L12** | On-Chain Transfers | WhaleOnchainJob каждые 10 мин | CoinGlass Whale Transfer ≥$10M: **withdrawal** с биржи = накопление → пул; deposit + активный сигнал = ⛔ алерт | withdrawal 4ч дедуп / deposit-предупреждение 6ч дедуп |
| **L13** | Whale Watch Spot | Основной скан-цикл | `whale_futures_watchlist` type=`spot` status=`watching` — токены под долгосрочным спот-мониторингом (≤50 записей) | Пока статус `watching` (до 30 дн); бейдж «🌊 долг. накопл.» в UI |

---

### 👁 OI Watch — пути попадания

| Путь | Триггер | Окно |
|------|---------|------|
| **PATH A** (confirmed) | Сканер нашёл сигнал, цена ещё не подтвердила → payload сохранён, ждём +цена% (1.5–2%) | 6ч |
| **PATH B** (steady accum) | OI накапливается, объём не пришёл → ждём turnover ≥15% ИЛИ спот vol ≥1.5x ИЛИ vol ×1.8 от входа **+** SpotCVD | 6ч |
| **Dark Flow / Activity Watch** | Топ-активный без OI данных (CoinGlass timeout / building) | dark_flow 6ч / cg_* 12ч |

---

### 🎯 Паттерны

Бэктест 90д (production tracked_signals, 2026-07-18): EV = (hit_10% × 10) − (SL% × стоп) − прочие × 0.

#### Интрадей / накопление

| Паттерн | Условия | Выход сигнала | Бэктест 90д |
|---------|---------|---------------|-------------|
| 📈🔥 `trend_accumulation` **Трендовое накопление** | OI30m ≥3.5% + prevOI30m ≥**0.3%** (2 цикла) + цена ≥1% + vol ≥0.5x + p24h ≤**20%** + cycleCount ≥3 + SpotCVD (fail-open при CG timeout) | OI Watch PATH A → price +2% | 34 сигн. · 26% hit+10% · 18% SL · avg_peak 7.0% · **EV +1.2** |
| 📊 `bullish_accumulation` **Бычье накопление** *(fallback)* | OI floor: cgOI ≥**3.5%** / OI1h ≥2% / OI4h ≥2.5% + prevOI30m ≥**−0.3%** (2 цикла) + SpotCVD1h (fail-open) + vol ≥**1.0x** (с OI) / **1.8x** (без) + **p24h ≤10%** *(19.07: ≤25%→≤10%; бэктест: win avg p24h=0.7%, stop avg=16.4%; 0 побед выше 5%)* + **OI30m ≤2.5%** *(19.07: новый гейт; стопы avg=4.33%, победители avg=0.78%)* + cycleCount ≤**25** | Прямой / OI Watch | 18 сигн. · 33% hit+10% · 33% SL · avg_peak 9.7% · **EV +0.4** *(до фильтров 19.07)* |
| 📊🌊 `spot_vol_accumulation` **Спот объём накопление** | spotVol ≥**2.5x** + SpotCVD 1h+4h + MCap gate + p24h −5…+40% + **prescan cycles ≥10** *(19.07: стопы avg=6 циклов, победители avg=24)*; OI-skip только при экстремальном OI (≥15%/10%) | Прямой сигнал, стоп −5% | 22 сигн. · 41% hit+10% · 9% SL · avg_peak 11.7% · **EV +3.6** ⭐ |

#### Киты / спецслои

| Паттерн | Условия | Выход сигнала | Бэктест 90д |
|---------|---------|---------------|-------------|
| 🐋🎯 `whale_alert` **Киты L11 (Hyperliquid)** | Кит лонг ≥$500K на Hyperliquid → подтверждение BingX: OI30m ≥1% / OI1h ≥1.5% / SpotCVD1h / taker ≥10% + гейт лимитниками (false блокирует, null = fail-open); p24h >40% отсечён | Прямой (confirmed fire), стоп −8%; whale-профиль 8/12/7; HL Position Tracker 15мин | — |
| 🐳 `whale_futures` **WhaleFutures** | OI ≥15% + боковая цена 14–90 дней + price gate ≤20% от точки обнаружения | Отдельный цикл (WhaleFutures трекер); whale-профиль 8/12/7 | 69 сигн. · 9% hit+10% · 13% SL · avg_peak 5.2% · **EV −0.2** |
| 📤 **Киты L12 (On-Chain)** *(не паттерн)* | Whale Transfer ≥$10M: withdrawal с биржи → пул `whale_onchain_pool` (24ч) + инжект в скан как L12; deposit + активный сигнал = ⛔ предупреждение в Telegram | Инжект токенов в батч; стандартные паттерны применяются | — |

> **Удалены и сохранены только для истории в БД:**
> - `dip_accumulation`, `spot_trend_accumulation`, `spot_divergence`, `quiet_oi_accumulation`, `volume_taker`, `spot_absorption`, `spot_vol_breakout`, `spot_taker_lead`, `early_vol_oi`, `spot_oi4h_build`, `short_squeeze`, `accumulation_breakout`
> - `oi24h_accumulation` — удалён 2026-07-15 (море ложных сигналов)
> - `daily_oi_accum_experiment` (OI2д) — удалён 2026-07-18 (перенесён в отдельный трекер, сигналы не выдаёт)
> - `impulse_buy` — удалён 2026-07-19 (90д бэктест: 0/12 hit_10%, 50% SL, avg_pnl −12%; price3h≥8% при высоком vol = поздний вход, не накопление)
> - `whale_watch`, `bid_wall_absorption`, `liq_magnet_squeeze`, `exchange_outflow_accum`, `oversold_reversal`, `smart_money_divergence`, `4h_momentum`, `oi1h_breakout`, `bingx_exclusive`, `oi4h_silent_accum`, `quiet_trend_rider` — удалены 2026-07-19 (чистка: отрицательный или незначимый EV по бэктесту 90д)
> - `ob_smart_accumulation` — удалён 2026-07-24 (паттерн L14/spot_ob_pool полностью удалён; бэктест не собран)

> **Примечание:** `liquidation_cascade` из этого списка НЕ удалён. Старая реализация (scanner.ts) удалена 2026-07-15, но паттерн был одновременно переработан в **L10 фоновый job** (`_runLiqCascadeFireCycle` в watcher.ts, каждые 3 мин). Job активен и выдаёт реальные сигналы.

---

### ⚙️ Прочее

- **📐 CG-латентность (2026-07-15):** строка «Scan complete» содержит телеметрию CoinGlass (cgReq/cgReqPerMin/cgTimeoutPct/cgP50/p95/max) + лаг event loop (elLagP50/p95/max) за окно цикла. Инструментированы только OI-батч и SpotCVD (горячие пути с circuit breaker) — cgReqPerMin занижает общий CG-трафик. Интерпретация: высокий elLagP95 (сотни мс) = инстанс захлёбывается; низкий elLag + высокий cgP95 = медленный CoinGlass. Решение по глобальному лимитеру (~4 req/s) и таймауту OI 5с→8с отложено до дня данных
- **🛡 Стопы (2026-07-15):** liq-heatmap стоп клампится сверху паттерн-лимитом `PATTERN_MAX_STOP` (watcher-config.ts): −5% spot_vol_accumulation · −8% whale_alert. Если heatmap недоступен — паттерн-стоп персистится напрямую (stopSource="pattern"). Паттерны вне карты (в т.ч. trend_accumulation/whale_futures) — глобальный −10%. Причина: avgLoss −15.45% на проде — liq-кластер −13…−15% сохранялся без ограничения
- **📊 Метрики входа (2026-07-15):** trackSignal универсально обогащает ВСЕ сигналы: OI 30m/1h/4h + CVD 30m/1h/4h + futVolMult добираются из prescanTracker (params приоритет), плюс новые entryRsi1h (CoinGlass), entryFundingRate (BingX raw decimal), entryBtc24h (рыночный режим), entryWhaleIndex (пер-токенный Whale Index); всё fail-open с таймаутом 4с
- **🐳 Пер-токенный Whale Index (2026-07-15):** CoinGlass whale-index/history по токену (Binance-фьючерсы, 4h) — строка в алерте после BTC-строки (пороги ±10 условные, чисто инфо) + entryWhaleIndex в tracked_signals. Тянется только при выстреле сигнала (кэш 10 мин / null 60 мин, через cgTimedFetch). Покрытие неполное: BingX-эксклюзивы и часть мелочи (PEPE → 500) данных не имеют — fail-open. Статистика 2-3 недели прежде чем пускать в скоринг. Схема в прод: идемпотентные ALTER в runStartupMigration (entry_rsi_1h/funding/btc_24h/whale_index)
- **⚠️ HighRisk «свежий мувер» (2026-07-15):** сигнал по токену с <3 циклов в прескане + price24h ≥5% получает предупреждение в Telegram-алерте (не блокируется). Основание: 30д статистика — 43% отмен в этом сегменте; growth-leader анализ (1616 записей) — муверы без futures-истории дампят в 46% при p24h 10–20%, дальше растут только 11%
- **🔒 Unlock-фильтр:** CoinGlass `coin-unlock-list` (4h кэш) — блок сигнала если разлок ≤3 дн + ≥1% supply (не watchlist, не BTC/ETH); предупреждение в алерте при 4–7 дн; fail-open если CG недоступен
- **Stale cancel:** сигнал автоотменяется через 3ч если пик < 2%
- **🐋 Exit-профиль китов (ЭКСПЕРИМЕНТ):** паттерны с префиксом `whale_` (whale_futures/whale_alert) — цель +8% / трейлинг с +12% / отступ 7% (глобально: 10/15/10). Оценка через 2-3 недели.
- **entrySpotVolMult:** записывается универсально для всех сигналов confirmed-fire пути (мост из loop1), не только spot_vol_* паттернов
- **🐋 Whale Tracker:** ежедневные OI-снимки, еженедельный отчёт (Сб 10:00 МСК), `/whalewatch` по требованию
- **Telegram:** уведомления на русском, метки скорости 🚀/⏳/⚠️, price confirmation
- **Дайджесты:** ежедневный / еженедельный / ежемесячный
- **UI:** настройка порогов через страницу Settings, авто-обновление 5–10с

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

## Required Secrets

- `BINGX_API_KEY` — BingX API key
- `BINGX_API_SECRET` — BingX API secret
- `TELEGRAM_BOT_TOKEN` — Telegram bot token
- `TELEGRAM_CHAT_ID` — Telegram chat ID for alerts
