import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "./schema";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // Neon serverless: держим малый пул — большое число одновременных соединений
  // вызывает "Authentication timed out" при cold-start и исчерпании слотов.
  max: 8,
  // Neon закрывает TCP на своей стороне через ~5 мин; keepAlive помогает
  // удержать соединение активным между запросами и снизить число реконнектов.
  keepAlive: true,
  // Отдаём idle-соединение обратно в пул быстро — чтобы Neon не успел его убить,
  // а пул не пытался переиспользовать мёртвое соединение.
  idleTimeoutMillis: 10_000,
  // Лимит на ожидание свободного слота в пуле.
  connectionTimeoutMillis: 15_000,
  allowExitOnIdle: false,
});

// Ловим ошибки на idle-клиентах (например, Neon закрыл соединение пока оно лежало в pool).
// Без этого Node.js кидает unhandled 'error' event и процесс может упасть.
pool.on("error", (err) => {
  void err;
});

export const db = drizzle(pool, { schema });

export * from "./schema";
