import {
  pgTable,
  serial,
  text,
  real,
  doublePrecision,
  integer,
  timestamp,
  boolean,
  pgEnum,
  jsonb,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const signalTypeEnum = pgEnum("signal_type", [
  "volume_spike",
  "oi_increase",
  "funding_rate",
  "strict_alpha",
  "alpha",
  "super_alpha",
  "short_sniper",
  "bingx_volume",
  "mexc_pump",
  "whale_watch",
]);

export const signalsTable = pgTable("signals", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  type: signalTypeEnum("type").notNull(),
  value: real("value").notNull(),
  threshold: real("threshold").notNull(),
  price: real("price").notNull(),
  priceChangePercent: real("price_change_percent").notNull(),
  volume24h: real("volume_24h").notNull(),
  avgVolume: real("avg_volume").notNull(),
  openInterest: real("open_interest"),
  oiChangePercent: real("oi_change_percent"),
  fundingRate: real("funding_rate"),
  tradingViewUrl: text("trading_view_url").notNull(),
  // New fields for alpha/super_alpha
  cmcRank: integer("cmc_rank"),
  cmcSource: text("cmc_source"),
  liquidationsUsd: real("liquidations_usd"),
  liquidationsMultiple: real("liquidations_multiple"),
  sentiment: text("sentiment"),
  sentimentKey: text("sentiment_key"),
  alphaScore: integer("alpha_score"),
  isContinuing: boolean("is_continuing").default(false),
  cumulativeOiChange: real("cumulative_oi_change"),
  entryCvd30m: boolean("entry_cvd_30m"),
  entryCvd1h: boolean("entry_cvd_1h"),
  entryCvd4h: boolean("entry_cvd_4h"),
  detectedAt: timestamp("detected_at").notNull().defaultNow(),
});

export const insertSignalSchema = createInsertSchema(signalsTable).omit({
  id: true,
});
export type InsertSignal = z.infer<typeof insertSignalSchema>;
export type Signal = typeof signalsTable.$inferSelect;

export const settingsTable = pgTable("settings", {
  id: serial("id").primaryKey(),
  volumeMultiplier: real("volume_multiplier").notNull().default(2),
  oiChangePercent: real("oi_change_percent").notNull().default(5),
  fundingRateThreshold: real("funding_rate_threshold")
    .notNull()
    .default(0.0005),
  scanIntervalMs: integer("scan_interval_ms").notNull().default(1800000),
  telegramEnabled: boolean("telegram_enabled").notNull().default(true),
  maxSymbols: integer("max_symbols").notNull().default(50),
  channelId: text("channel_id"),
  watchlist: text("watchlist"), // comma-separated symbols always included in scan, e.g. "IOST-USDT,BIO-USDT"
  watchlistAddedAt: text("watchlist_added_at").default("{}"), // JSON: { "SYMBOL": timestamp }
  whaleWatchStagesJson: text("whale_watch_stages_json"), // persisted whale watch stages across restarts
  lastDailyReportAt: timestamp("last_daily_report_at"), // daily report dedup
  lastWeeklyDigestAt: timestamp("last_weekly_digest_at"), // weekly digest dedup
  lastMonthlyDigestAt: timestamp("last_monthly_digest_at"), // monthly digest dedup
  lastRestartNotifiedAt: timestamp("last_restart_notified_at"), // restart notification dedup across processes
  lastManualCheckSentAt: timestamp("last_manual_check_sent_at"), // manual-check near-stop dedup across processes
  lastPositionsReportAt: timestamp("last_positions_report_at"), // positions update dedup across processes
  scannerLastScanAt: timestamp("scanner_last_scan_at"), // cross-process: last successful scan completion time
  scannerScanStartedAt: timestamp("scanner_scan_started_at"), // cross-process: when current/last scan started (isScanning = startedAt > lastScanAt)
  lastCoinalyzeBatchAt: timestamp("last_coinalyze_batch_at"), // cross-process dedup for Coinalyze OI 24h batch
  lastCoinalyze30mAt: timestamp("last_coinalyze_30m_at"), // cross-process dedup for Coinalyze OI 30m batch
  lastCoinglassOutageAt: timestamp("last_coinglass_outage_at"), // cross-process dedup for CoinGlass outage alert
  lastWatchdogAlertAt: timestamp("last_watchdog_alert_at"), // cross-process watchdog dedup (prevents dual-worker double sends)
  retroStartedAt: timestamp("retro_started_at"), // cross-process mutex: retro job runs only on one process
  coinalyzeBatchJson: text("coinalyze_batch_json"), // cross-process Coinalyze 30m snapshot (JSON)
  // ── Smart Cancel thresholds ──────────────────────────────────────────────────
  smartCancelOiPct: real("smart_cancel_oi_pct").default(5.0), // мин. рост OI за 4ч (%) для блокировки отмены
  // ── Moonshot Momentum thresholds ─────────────────────────────────────────────
  moonshotVolMult: real("moonshot_vol_mult").default(5.0), // мин. объём (x) для паттерна Moonshot
  moonshotPriceChange: real("moonshot_price_change").default(15.0), // мин. рост цены (%) за 30m свечу
  moonshotOiChange: real("moonshot_oi_change").default(10.0), // мин. рост OI (%) для Moonshot
  moonshotAskWallUsd: real("moonshot_ask_wall_usd").default(50_000), // мин. стена на продажу ($) которая БЛОКИРУЕТ Moonshot
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const insertSettingsSchema = createInsertSchema(settingsTable).omit({
  id: true,
});
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settingsTable.$inferSelect;

// ── OI baselines: persisted across restarts ───────────────────────────────────
export const oiBaselinesTable = pgTable("oi_baselines", {
  symbol: text("symbol").primaryKey(),
  oi: real("oi").notNull(),
  takenAt: timestamp("taken_at").notNull(),
});

// ── Alpha Watcher: signal outcome tracking ────────────────────────────────────
export const trackedStatusEnum = pgEnum("tracked_status", [
  "active", // Freshly created, being monitored
  "in_run", // Hit first target +10% — now trailing stop active
  "profit", // Closed in profit (trailing stop hit)
  "stop_loss", // Hit stop loss (-5% long / +5% short)
  "bu_stop", // Stopped at breakeven (in_run, price returned to entry) — counts as profit
  "accumulation", // 24h passed, still in range — watching up to 7 days
  "breakeven", // 7 days passed, no clear result
  "re_entry", // Spike detected while in accumulation
  "cancelled", // Trade invalidated: OI dropped ≥ 5% or volume dried up
]);

export const trackedSignalsTable = pgTable("tracked_signals", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  signalId: integer("signal_id").references(() => signalsTable.id),
  signalType: text("signal_type").notNull(), // "alpha" | "super_alpha" | "short_sniper"
  sentiment: text("sentiment"),
  sentimentKey: text("sentiment_key"),
  alphaScore: integer("alpha_score"),
  isShort: boolean("is_short").notNull().default(false), // true for short_sniper
  entryPrice: real("entry_price").notNull(),
  entryOi: real("entry_oi"), // OI (base asset) at the moment of signal detection
  exitPrice: real("exit_price"),
  pnlPercent: real("pnl_percent"),
  peakPrice: real("peak_price"), // Best price seen (highest for long, lowest for short)
  trailingStopLevel: real("trailing_stop_level"), // peakPrice * 0.95 — dynamic exit level
  lastMilestone: integer("last_milestone"), // Last milestone % announced (25, 50, 100, 200…)
  lastHourlyAt: timestamp("last_hourly_at"), // hourly update dedup
  lastPeriodicUpdateAt: timestamp("last_periodic_update_at"), // 4h periodic update dedup
  lastVolBuildAt: timestamp("last_vol_build_at"), // accum vol-building alert dedup
  lastOiBuildAt: timestamp("last_oi_build_at"), // accum OI-building alert dedup
  lastSmartCancelCheckAt: timestamp("last_smart_cancel_check_at"), // smart cancel pause: первое срабатывание
  originalEntryPrice: real("original_entry_price"), // DCA: первоначальный вход до усреднений
  dipBuyCount: integer("dip_buy_count").notNull().default(0), // DCA: число выполненных докупов (макс 3)
  price24hAtFire: real("price_24h_at_fire"), // price24h% в момент детекта (из prescanTracker)
  prescanCycles: integer("prescan_cycles"), // cycleCount из prescanTracker в момент детекта
  oiWatchEntryPrice: real("oi_watch_entry_price"), // цена входа в OI Watch (если сигнал пришёл из очереди)
  cancelReason: text("cancel_reason"), // причина отмены (stale/oi_drop/no_price/…)
  entryCvd30m: boolean("entry_cvd_30m"), // Spot CVD 30m при создании сигнала
  entryCvd1h: boolean("entry_cvd_1h"), // Spot CVD 1h  при создании сигнала
  entryCvd4h: boolean("entry_cvd_4h"), // Spot CVD 4h  при создании сигнала
  marketCapUsd: real("market_cap_usd"), // Market cap USD при детекте (CoinGecko/SpotPool)
  // ── Entry metrics: OI/vol snapshot at the moment signal fires ─────────────
  entryOi30m: real("entry_oi_30m"), // CoinGlass OI Δ30m % при детекте
  entryOi1h: real("entry_oi_1h"), // CoinGlass OI Δ1h % при детекте
  entryOi4h: real("entry_oi_4h"), // CoinGlass OI Δ4h % при детекте
  entryOi24h: real("entry_oi_24h"), // CoinGlass OI Δ24h % при детекте
  entryPrice1h: real("entry_price_1h"), // price % change за 1h в момент детекта (из prescanTracker)
  entryFutTakerNetBuy: real("entry_fut_taker_net_buy"), // Futures taker net buy % (CoinGlass) при детекте
  entrySpotVolMult: real("entry_spot_vol_mult"), // Спот vol mult (lastSpotVol1h/avg) при детекте
  entryFutVolMult: real("entry_fut_vol_mult"), // Фьюч vol mult (BingX 30m curVol/avgVol) при детекте
  // ── Диагностика spot/mcap гейтов (CONFIRMED FIRE, whale_watch, Pre-Breakout/Dark Flow) ──
  // Раньше считалось на лету в гейте и терялось (только logger.info). Копим 2-4 недели
  // для пересмотра порогов на реальных данных вместо догадок.
  entrySpotVol24h: real("entry_spot_vol_24h"), // Спот-объём 24h (USD) в момент срабатывания гейта
  entrySpotMcapPct: real("entry_spot_mcap_pct"), // spotVol24h / marketCapUsd * 100, вычислено в момент срабатывания
  // ── Spot taker / net-buy метрики (2026-07-15) — пишутся для ВСЕХ паттернов ──
  // Для тюнинга паттернов: кто из покупателей «давил» в момент сигнала.
  entrySpotTakerNetBuy: real("entry_spot_taker_net_buy"), // Spot taker net buy % (CoinGlass, последний ~30m цикл) — >0 давят покупки
  entrySpotNetBuy1h: real("entry_spot_net_buy_1h"), // Spot net buy 1h % (CoinGlass) — агрегат за час
  entrySpotNetBuy4h: real("entry_spot_net_buy_4h"), // Spot net buy 4h % (CoinGlass)
  entrySpotNetBuy24h: real("entry_spot_net_buy_24h"), // Spot net buy 24h % (CoinGlass)
  // OI Watch PATH B часто стреляет под общим лейблом sentimentKey (напр. "trend_accumulation"),
  // хотя запись изначально была добавлена по совсем другой причине (tSteady/cg_timeout/layer8/…).
  // entrySource хранит w.triggerTf в момент выстрела — реальный источник записи, отдельно от лейбла.
  entrySource: text("entry_source"),
  // ── Универсальные метрики входа (2026-07-15) — пишутся для ВСЕХ паттернов ──
  // Общий знаменатель для анализа победителей vs проигравших. Fail-open: null при недоступности.
  entryRsi1h: real("entry_rsi_1h"), // CoinGlass RSI 1h в момент входа
  entryFundingRate: real("entry_funding_rate"), // BingX funding rate (raw decimal, 0.0001 = 0.01%) в момент входа
  entryLiqLong1h: real("entry_liq_long1h"), // longLiq1h (USD) при детекте liqCascade; null для других паттернов
  entryLiqLong24h: real("entry_liq_long24h"), // longLiq24h (USD) при детекте liqCascade
  entryLiqRatio: real("entry_liq_ratio"), // longLiq1h/longLiq24h при детекте (триггерное соотношение)
  entryLiqReason: text("entry_liq_reason"), // "liq_spike" | "liq_order_stream" — тип триггера
  entryBtc24h: real("entry_btc_24h"), // BTC price24h% в момент входа (рыночный режим)
  entryWhaleIndex: real("entry_whale_index"), // CoinGlass Whale Index по токену (Binance, 4h) в момент входа; null = нет данных (BingX-эксклюзив и т.п.)
  entryObBids: real("entry_ob_bids"), // BingX orderbook: суммарный объём бидов USD в момент входа (топ-20 уровней)
  entryObAsks: real("entry_ob_asks"), // BingX orderbook: суммарный объём асков USD в момент входа
  entryObRatio: real("entry_ob_ratio"), // bid/ask ratio (entryObBids / entryObAsks): >1 = покупатели давят, <1 = продавцы
  // ── Индивидуальные стоп/тейки по Liquidation Heatmap (CoinGlass Professional) ──
  // null = стандартный стоп -10% (старые сигналы и токены без heatmap-данных)
  stopLossPrice: real("stop_loss_price"), // абсолютный уровень стопа (кластер ликвидаций − 2%)
  stopLossPct: real("stop_loss_pct"), // глубина стопа в % от входа (положительное число)
  stopSource: text("stop_source"), // "liq_heatmap" | "standard" (null = standard)
  takeTargets: jsonb("take_targets"), // [{price, pctFromEntry, liqUsd}] — цели по кластерам шорт-ликвидаций
  status: trackedStatusEnum("status").notNull().default("active"),
  reEntryCount: integer("re_entry_count").notNull().default(0),
  detectedAt: timestamp("detected_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  closedAt: timestamp("closed_at"),
  // Цена через 72ч после закрытия (cancel/stop_loss) — ретро-аудит: правильно ли мы вышли?
  price72hAfterExitPct: real("price_72h_after_exit_pct"),
});

export const insertTrackedSignalSchema = createInsertSchema(
  trackedSignalsTable,
).omit({ id: true });
export type InsertTrackedSignal = z.infer<typeof insertTrackedSignalSchema>;
export type TrackedSignal = typeof trackedSignalsTable.$inferSelect;

// ── OI Watch List: symbols with OI spike but no volume yet ───────────────────
// When OI threshold met but volume is too low to fire a signal,
// we park the symbol here and monitor every 2 min for volume/price confirmation.
export const oiWatchStatusEnum = pgEnum("oi_watch_status", [
  "watching", // active, being monitored every 2 min
  "fired", // signal fired from watch list (volume confirmed)
  "expired", // 2h elapsed without confirmation
  "confirming", // detected condition, waiting 7 min to confirm move is sustained (not flash pump)
]);

export const oiWatchTable = pgTable(
  "oi_watch",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(),
    triggerTf: text("trigger_tf").notNull(), // "5m"|"30m"|"1h"|"4h"|"24h" — what TF triggered OI
    oiChange: real("oi_change").notNull(), // OI change % at detection
    priceAtEntry: real("price_at_entry").notNull(), // price when added to watch
    volumeMultiplier: real("volume_multiplier").notNull(), // vol at detection
    sentimentKey: text("sentiment_key"), // predicted pattern
    oi30mChange: real("oi_30m"), // CoinGlass 30m OI % at detection
    oi1hChange: real("oi_1h"), // CoinGlass 1h OI % at detection
    oi24hChange: real("oi_24h"), // CoinGlass 24h OI % at detection
    price1hChange: real("price_1h_change"), // price % change 1h at entry
    price24hChange: real("price_24h_change"), // price % change 24h at entry
    currentVolMult: real("current_vol_mult"), // live vol multiplier updated each watcher cycle
    volStatusReason: text("vol_status_reason"), // why volConfirmed is true/false: no_turnover|cvd_unavail|cvd_negative|confirmed
    entryVolMult: real("entry_vol_mult"), // volMult в момент добавления в watch (для межцикловой дельты)
    entryCgTurnover: real("entry_cg_turnover"), // CoinGlass turnover (vol/OI) при добавлении
    lastOiCheck: real("last_oi_check"), // OI 30m при последней проверке PATH B (для отслеживания динамики)
    prevOiCheck: real("prev_oi_check"), // OI 30m при предпоследней проверке PATH B
    prevOiCheck2: real("prev_oi_check2"), // OI 30m двумя циклами ранее (для 3-цикловой проверки падения)
    status: oiWatchStatusEnum("status").notNull().default("watching"),
    addedAt: timestamp("added_at").notNull().defaultNow(),
    expiresAt: timestamp("expires_at").notNull(),
    firedAt: timestamp("fired_at"),
    avgVolume: real("avg_volume"), // stored to avoid re-fetching klines
    // ── Two-stage confirmation fields ──────────────────────────────────────────
    isVolConfirmed: boolean("is_vol_confirmed").notNull().default(false), // vol was already ≥ 2x at scanner time
    signalPayload: jsonb("signal_payload"), // full AlphaResult + InsertSignal — used to fire from watcher
  },
  (table) => ({
    symbolStatusIdx: index("oi_watch_symbol_status_idx").on(
      table.symbol,
      table.status,
    ),
    statusIdx: index("oi_watch_status_idx").on(table.status),
  }),
);

export type OiWatch = typeof oiWatchTable.$inferSelect;
export type InsertOiWatch = typeof oiWatchTable.$inferInsert;

// ── Daily OI Snapshots: long-term whale accumulation tracking ─────────────────
// One row per symbol per day. Used to detect sustained whale accumulation over weeks/months.
export const oiDailySnapshotsTable = pgTable("oi_daily_snapshots", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  date: text("date").notNull(), // "YYYY-MM-DD" — one entry per symbol per day
  oiUsd: real("oi_usd"), // Open Interest in USD from CoinGlass
  oiChange24h: real("oi_change_24h"), // 24h OI change %
  priceUsd: real("price_usd"), // price at snapshot time
  volume24h: real("volume_24h"), // 24h volume USD
  takenAt: timestamp("taken_at").notNull().defaultNow(),
});

export type OiDailySnapshot = typeof oiDailySnapshotsTable.$inferSelect;
export type InsertOiDailySnapshot = typeof oiDailySnapshotsTable.$inferInsert;

// ── Whale Watch 2.0: Spot CVD Accumulation Watchlist ─────────────────────────
// Each row = one symbol being monitored for whale accumulation via Spot CVD.
// avgBuyPrice tracks weighted-average price of accumulation periods for Smart Cancel.
export const whaleWatchlistTable = pgTable("whale_watchlist", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().unique(),
  firstSeenAt: timestamp("first_seen_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  /** Накопленный спот CVD (сумма нетто-покупок в USD) за период наблюдения */
  accumulatedCvdUsd: real("accumulated_cvd_usd").notNull().default(0),
  /** Количество накопительных 5m периодов подряд (или с момента добавления) */
  accumPeriods: integer("accum_periods").notNull().default(0),
  /** Средневзвешенная цена накопления (для Smart Cancel) */
  avgBuyPrice: real("avg_buy_price"),
  /** Market Cap токена USD (CoinGecko, кэш 24ч) */
  marketCapUsd: real("market_cap_usd"),
  /** 24h объём споте USD на момент добавления */
  vol24hUsd: real("vol24h_usd"),
  /** Цена при первом обнаружении */
  priceAtEntry: real("price_at_entry"),
  /** Последняя известная цена */
  lastPrice: real("last_price"),
  /** Алерт о входе в накопление уже отправлен */
  alertedAt: timestamp("alerted_at"),
  /** Сигнал пробоя уже отправлен (breakout fired) */
  breakoutFiredAt: timestamp("breakout_fired_at"),
  /** Статус: watching | accumulating | breakout | expired */
  status: text("status").notNull().default("watching"),
});

export type WhaleWatchlistRow = typeof whaleWatchlistTable.$inferSelect;
export type InsertWhaleWatchlist = typeof whaleWatchlistTable.$inferInsert;

// ── Prescan Tracker: persist cycle counts across restarts ─────────────────────
// Key fields saved after every scan cycle so cycleCount / firstSeenAt survive
// server rebuilds. Volatile per-cycle fields (lastOi*, lastScore, etc.) are
// recomputed on the next scan and are NOT stored here.

export const prescanTrackerTable = pgTable("prescan_tracker", {
  symbol: text("symbol").primaryKey(),
  cycleCount: integer("cycle_count").notNull().default(1),
  firstSeenAt: real("first_seen_at").notNull(), // unix ms (stored as float)
  bestRank: integer("best_rank").notNull().default(1),
  firstPrice: real("first_price").notNull(),
  firstPrice24h: real("first_price_24h").notNull(),
  firstScore: real("first_score").notNull(),
  lastFiredAt: real("last_fired_at").notNull().default(0), // unix ms; 0 = never
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  // Live fields: persisted every cycle so DB-fallback path also shows current data
  lastPrice: real("last_price"), // текущая цена (обновляется каждый цикл)
  lastOi30m: real("last_oi_30m"), // OI Δ30m %
  lastOi1h: real("last_oi_1h"), // OI Δ1h %
  lastOi4h: real("last_oi_4h"), // OI Δ4h %
  lastOi24h: real("last_oi_24h"), // OI Δ24h %
  prevOi30m: real("prev_oi_30m"), // OI Δ30m % прошлого цикла (для расчёта ускорения)
  prevOi4h: real("prev_oi_4h"), // OI Δ4h % прошлого цикла
  lastPrice1h: real("last_price_1h"), // Изменение цены за 1ч (%)
  // null = ещё не проверяли; true = CG таймаут; false = CG спросили, данных нет (не покрывает токен)
  lastCgTimedOut: boolean("last_cg_timed_out"),
  // ── Progression fields: счётчики прогрессии между циклами ───────────────────
  // Эти поля раньше жили только в памяти и сбрасывались при каждом рестарте.
  // Теперь персистируются чтобы история накопления переживала деплои.
  cvdPositiveCycles: integer("cvd_positive_cycles"), // циклов подряд spot CVD 5m > 0 (сбрасывается при первом минусе)
  takerPositiveCycles: integer("taker_positive_cycles"), // циклов подряд futures taker netBuyPct > 0 (из CoinGlass)
  oiAccel30m: real("oi_accel_30m"), // ускорение OI 30m: lastOi30m / prevOi30m (>1 = растёт)
  oi4hConsecGrowth: integer("oi_4h_consec_growth"), // сколько подряд циклов OI4h растёт (для spot_oi4h_build)
  // ── Спот объём 1h (CoinGlass pairs-markets) ──────────────────────────────────
  lastSpotVol1h: real("last_spot_vol_1h"), // спот объём 1h USD (последний цикл)
  prevSpotVol1h: real("prev_spot_vol_1h"), // спот объём 1h USD (прошлый цикл)
  lastSpotVol4h: real("last_spot_vol_4h"), // спот объём 4h USD
  lastSpotNetBuy1h: real("last_spot_net_buy_1h"), // (buy-sell)/(buy+sell)*100 за 1h
  spotVolAvg1h: real("spot_vol_avg_1h"), // скользящее среднее за 5 циклов
  spotVolCycles: integer("spot_vol_cycles").notNull().default(0), // количество накопленных циклов
  layers: text("layers").array().notNull().default([]), // prescan layers последнего цикла: WL/L1/L2/L3/L4/L5/L7/L8
  // ── Futures vs Spot Volume (CoinGlass futures_spot_volume_ratio, Binance+OKX+Bybit) ─
  futVolUsd24h: real("fut_vol_usd_24h"), // фьючерсный объём 24h USD
  spotVolUsd24h: real("spot_vol_usd_24h"), // спотовый объём 24h USD
  futSpotRatio: real("fut_spot_ratio"), // futVolUsd24h / spotVolUsd24h
  futVolPctMcap: real("fut_vol_pct_mcap"), // futVolUsd24h / mcapUsd * 100
  spotVolPctMcap: real("spot_vol_pct_mcap"), // spotVolUsd24h / mcapUsd * 100
  // ── Первичный снимок OI при входе в prescan ──────────────────────────────────
  // Устанавливаются при первом INSERT (COALESCE — никогда не перезаписываются).
  // Ключевые для калибровки: что было видно ДО начала роста токена.
  firstOi30m: real("first_oi_30m"), // OI Δ30m % при первом появлении
  firstOi1h: real("first_oi_1h"), // OI Δ1h % при первом появлении
  firstOi4h: real("first_oi_4h"), // OI Δ4h % при первом появлении
  lastWhaleIndex: real("last_whale_index"), // Whale Index по токену (CoinGlass, Binance futures) — обновляется раз в цикл для OI Watch + топ prescan
  lastPrice24h: real("last_price_24h"), // последнее ненулевое priceChangePercent% (обновляется каждый цикл; персистируется для корректной загрузки после рестарта)
  // ── Taker / CVD verdicts: персистируются чтобы после рестарта UI/гейты не показывали "—" до следующего скана ─
  lastNetBuyPct: real("last_net_buy_pct"), // последний netBuyPct (%) из getCoinglassTakerFlow (futures taker)
  lastSpotTakerNetBuy: real("last_spot_taker_net_buy"), // netBuyPct% последней 30m спот свечи
  lastSpotTakerDominance: text("last_spot_taker_dominance"), // "buy" | "sell" | "neutral"
  lastCvd30m: boolean("last_cvd_30m"), // spot CVD 30m verdict (null = не проверяли)
  lastCvd1h: boolean("last_cvd_1h"), // spot CVD 1h verdict
  lastCvd4h: boolean("last_cvd_4h"), // spot CVD 4h verdict
});

export type PrescanTrackerRow = typeof prescanTrackerTable.$inferSelect;

// ── Prescan History: per-cycle OI/CVD snapshot for top-30 tokens ──────────────
// Пишем снимок каждый скан-цикл для топ-30 пресканера.
// TTL 7 дней — старые строки удаляются в savePrescanHistory() перед каждой записью.
// Используется для ретроспективного анализа: когда OI 4h стал отрицательным,
// как менялся CVD между циклами, почему токен не получил сигнал.
export const prescanHistoryTable = pgTable(
  "prescan_history",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(),
    ts: timestamp("ts").notNull().defaultNow(),
    cycleCount: integer("cycle_count"),
    rank: integer("rank"),
    score: real("score"),
    price24h: real("price_24h"),
    price1h: real("price_1h"),
    oi30m: real("oi_30m"),
    oi1h: real("oi_1h"),
    oi4h: real("oi_4h"),
    oi24h: real("oi_24h"),
    volMult: real("vol_mult"),
    cvd30m: boolean("cvd_30m"),
    cvd1h: boolean("cvd_1h"),
    netBuyPct: real("net_buy_pct"), // futures taker net buy %
    spotTakerNetBuy: real("spot_taker_net_buy"), // spot taker net buy %
    oiAccel30m: real("oi_accel_30m"), // OI 30m acceleration ratio (lastOi30m / prevOi30m)
    futSpotRatio: real("fut_spot_ratio"), // futures / spot volume ratio
  },
  (table) => ({
    symbolTsIdx: index("prescan_history_symbol_ts_idx").on(
      table.symbol,
      table.ts,
    ),
    tsIdx: index("prescan_history_ts_idx").on(table.ts),
  }),
);

export type PrescanHistoryRow = typeof prescanHistoryTable.$inferSelect;

// ── Growth Leader Log: периодические снимки топ-гейнеров ─────────────────────
// Каждый скан-цикл (~10 мин) записываем топ-50 по price24h% с полным OI/CVD/vol
// контекстом на этот момент. TTL 30 дней.
// Цель: калибровка паттернов — что видел сканер у будущих лидеров роста ДО пампа.
export const growthLeaderLogTable = pgTable(
  "growth_leader_log",
  {
    id: serial("id").primaryKey(),
    loggedAt: timestamp("logged_at").notNull().defaultNow(),
    symbol: text("symbol").notNull(),
    rank: integer("rank"), // ранг по price24h (1 = самый большой рост)
    price: real("price"), // текущая цена
    price24h: real("price_24h"), // % рост за 24ч — главный критерий
    price1h: real("price_1h"), // % рост за 1ч
    growthFromEntry: real("growth_from_entry"), // % от first_price при входе в prescan
    cycleCount: integer("cycle_count"), // циклов в prescan (возраст токена)
    firstSeenAt: real("first_seen_at"), // когда впервые попал в prescan (unix ms)
    layers: text("layers").array(), // prescan layers этого цикла
    oi30m: real("oi_30m"),
    oi1h: real("oi_1h"),
    oi4h: real("oi_4h"),
    cvd1h: boolean("cvd_1h"),
    cvd30m: boolean("cvd_30m"),
    spotVolMult: real("spot_vol_mult"), // lastSpotVol1h / spotVolAvg1h
    volMult: real("vol_mult"), // BingX 30m vol mult
    source: text("source").notNull().default("scan"), // 'scan' | 'retroactive'
    // ── Метрики НА МОМЕНТ ВХОДА в prescan ────────────────────────────────────────
    // Из prescan_tracker.first_oi_* (COALESCE — никогда не перезаписываются в источнике).
    // Позволяют сравнить «что было видно ДО роста» с текущим состоянием.
    entryPrice: real("entry_price"), // цена при первом попадании в prescan
    entryPrice24h: real("entry_price_24h"), // p24h% при первом попадании в prescan
    entryOi30m: real("entry_oi_30m"), // OI Δ30m % при первом попадании
    entryOi1h: real("entry_oi_1h"), // OI Δ1h % при первом попадании
    entryOi4h: real("entry_oi_4h"), // OI Δ4h % при первом попадании
    netBuyPct: real("net_buy_pct"), // Спот taker net buy % (последний цикл, из prescanTracker)
    spotTakerBuyUsd: real("spot_taker_buy_usd"), // CG спот taker buy USD (Binance, 2 × 1h свечи)
    spotTakerSellUsd: real("spot_taker_sell_usd"), // CG спот taker sell USD (Binance, 2 × 1h свечи)
    // ── Дополнительные поля (ретро + forward коллекция) ──────────────────────────
    price3h: real("price_3h"), // % рост за 3ч
    price4h: real("price_4h"), // % рост за 4ч
    fundingRate: real("funding_rate"), // funding rate в момент снапшота (decimal, not %)
    oiUsdAbs: real("oi_usd_abs"), // OI в USD абсолютный (CoinGlass, "All exchanges")
    futVolUsd24h: real("fut_vol_usd_24h"), // Фьючерсный объём за 24ч USD (BingX quoteVolume)
    retro: boolean("retro").default(false), // true = ретроспективная запись (не real-time)
    // ── Ретро v2: расширенные метрики (собираются ретро-джобом v2) ───────────────
    prevOi30m: real("prev_oi_30m"), // OI 30m Δ предыдущего цикла
    prevOi1h: real("prev_oi_1h"), // OI 1h Δ предыдущего цикла
    prevOi4h: real("prev_oi_4h"), // OI 4h Δ предыдущего цикла
    oi24hD1: real("oi_24h_d1"), // OI Δ за 1 день до пампа (daily ТФ)
    oi24hD2: real("oi_24h_d2"), // OI Δ за 2 дня до пампа (daily ТФ)
    spotCvd4h: boolean("spot_cvd_4h"), // SpotCVD 4h бычий (CG aggregated-cvd/history)
    cvdStrength1h: real("cvd_strength_1h"), // (spotBuy1h-spotSell1h)/(buy+sell) [-1..1]
    cvdDelta4h: real("cvd_delta_4h"), // Δ cum_vol_delta за 4h в USD (CG SpotCVD)
    spotTakerNetBuyPct: real("spot_taker_net_buy_pct"), // Спот taker net buy % за 1h
    prevSpotVolMult: real("prev_spot_vol_mult"), // BingX 30m: предыдущая свеча vol vs среднее
    prevPrice30m: real("prev_price_30m"), // Δ цены предыдущей 30m свечи %
    cgOiAvailable: boolean("cg_oi_available"), // было ли CG OI покрытие для символа
    matchedPattern: text("matched_pattern"), // паттерн, по которому выстрелил сигнал (заполняется при fire)
  },
  (table) => ({
    loggedAtIdx: index("growth_leader_log_logged_at_idx").on(table.loggedAt),
    symbolIdx: index("growth_leader_log_symbol_idx").on(table.symbol),
  }),
);

export type GrowthLeaderLogRow = typeof growthLeaderLogTable.$inferSelect;

// ── Pattern Debug Log: persistent history of per-cycle check/pass/reject counts ──
// Was in-memory only (lastPatternDebug in scanner.ts), reset every performScan()
// cycle (~10 min) — no way to see week-long gate rejection trends per pattern.
// One row per (pattern, cycle): checked/passed counters + rejectedAt as JSON text
// (gate → rejection count).
// TTL: no auto-cleanup — rows accumulate for analysis; prune manually if needed.
export const patternDebugLogTable = pgTable(
  "pattern_debug_log",
  {
    id: serial("id").primaryKey(),
    pattern: text("pattern").notNull(),
    cycleNumber: integer("cycle_number"),
    checked: integer("checked").notNull(),
    passed: integer("passed").notNull(),
    rejectedAt: text("rejected_at"), // JSON string: {"gate": count, ...}
    // symbol/cvdDiag: populated only for per-candidate diagnostic rows (e.g. OI-gate
    // rejects with a parallel "would CVD have passed?" check) — null on the regular
    // aggregate per-cycle snapshot rows above. Lets us later correlate CVD-gate
    // outcome vs price action for candidates the OI gate killed before CVD ran.
    symbol: text("symbol"),
    cvdDiag: text("cvd_diag"), // e.g. "would_pass" | "no_data" | "negative" | "no_confirm" | "mtf_fail"
    loggedAt: timestamp("logged_at").notNull().defaultNow(),
  },
  (table) => ({
    patternIdx: index("pattern_debug_pattern_idx").on(table.pattern),
    loggedAtIdx: index("pattern_debug_logged_at_idx").on(table.loggedAt),
    symbolIdx: index("pattern_debug_symbol_idx").on(table.symbol),
  }),
);

export type PatternDebugLog = typeof patternDebugLogTable.$inferSelect;
export type PatternDebugLogInsert = typeof patternDebugLogTable.$inferInsert;

// ── Layer 10: Liquidation Cascade Watch ────────────────────────────────────────
// Кандидаты обнаруженные independent job (price24h ≤ -7%, объём ≥ $300K).
// Инжектируются в основной скан (Layer 10) для проверки liquidation_cascade паттерна.
// Окно наблюдения: 2ч. По истечении без сигнала → missed_signals_log.
export const liqCascadeWatchTable = pgTable(
  "liq_cascade_watch",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(),
    status: text("status").notNull().default("watching"), // watching | fired | expired
    detectedAt: timestamp("detected_at").notNull().defaultNow(),
    expiresAt: timestamp("expires_at").notNull(),

    // Snapshot at detection time (из BingX ticker)
    priceAtDetect: real("price_at_detect"),
    price24hAtDetect: real("price24h_at_detect"), // % за 24ч в момент детекта
    price1hAtDetect: real("price1h_at_detect"), // % за 1ч (из prescanTracker если есть)

    // OI snapshot (из prescanTracker если токен уже в пуле)
    oi30mAtDetect: real("oi30m_at_detect"),
    oi1hAtDetect: real("oi1h_at_detect"),
    oi4hAtDetect: real("oi4h_at_detect"),

    // Spot volume snapshot
    spotVol24hAtDetect: real("spot_vol24h_at_detect"), // BingX quoteVolume 24h (USD)
    spotVolMultAtDetect: real("spot_vol_mult_at_detect"), // mult vs avg (если есть)
    spotVolMcapPct: real("spot_vol_mcap_pct"), // quoteVol24h / mcap * 100

    // CVD snapshot (из prescanTracker если токен уже в пуле)
    cvd30mAtDetect: boolean("cvd30m_at_detect"),
    cvd1hAtDetect: boolean("cvd1h_at_detect"),
    cvd4hAtDetect: boolean("cvd4h_at_detect"),

    // Live tracking (обновляется каждые 3 мин)
    currentPrice: real("current_price"),
    currentPctChange: real("current_pct_change"), // % от priceAtDetect
    lastCheckAt: timestamp("last_check_at"),

    // Outcome
    signalId: integer("signal_id"),
    missReason: text("miss_reason"),

    // CoinGlass liquidation coin-list snapshot (USD)
    longLiq1hAtDetect: real("long_liq1h_at_detect"),
    longLiq4hAtDetect: real("long_liq4h_at_detect"),
    longLiq24hAtDetect: real("long_liq24h_at_detect"),
    currentLongLiq1h: real("current_long_liq1h"), // обновляется каждые 3 мин
    liqExhausted: boolean("liq_exhausted"), // текущий longLiq1h < 30% от at-detect

    // CoinGlass retail positioning + bid walls (обновляется каждые 3 мин)
    globalLongPct: real("global_long_pct"), // % аккаунтов в лонге (Binance)
    largeBidUsd: real("large_bid_usd"), // крупные биды в пределах -6% от цены (USD)

    // Путь попадания в watch (Task #3): dump_filter (p24h ≤ -7%) | liq_order_stream (ранний real-time триггер)
    entryReason: text("entry_reason").default("dump_filter"),
    // Real-time liq order stream snapshot при детекте (rolling 15 мин, все биржи)
    liqOrdersCountAtDetect: integer("liq_orders_count_at_detect"), // кол-во long-liq ордеров ≥$10K
    liqOrdersUsdAtDetect: real("liq_orders_usd_at_detect"), // сумма USD long-liq ордеров

    // prescan cycle count при детекте — для ретроспективного SQL-аудита gate ≤5
    cycleCountAtDetect: integer("cycle_count_at_detect"),
  },
  (table) => ({
    symbolStatusIdx: index("liq_cascade_watch_symbol_status_idx").on(
      table.symbol,
      table.status,
    ),
    detectedAtIdx: index("liq_cascade_watch_detected_at_idx").on(
      table.detectedAt,
    ),
  }),
);

export type LiqCascadeWatch = typeof liqCascadeWatchTable.$inferSelect;
export type InsertLiqCascadeWatch = typeof liqCascadeWatchTable.$inferInsert;

// ── Market Cap persistent cache ────────────────────────────────────────────────
// Хранит MCap данные между рестартами сервера.
// TTL 7 дней: устаревшие записи игнорируются при загрузке.
// doublePrecision (float8) вместо real (float4) — MCap BTC ~$1.3T, нужна точность.
export const marketCapCacheTable = pgTable("market_cap_cache", {
  symbol: text("symbol").primaryKey(), // base symbol без -USDT (напр. "BTC")
  mcapUsd: doublePrecision("mcap_usd").notNull(), // market cap в USD
  source: text("source").notNull(), // "coinglass" | "coingecko" | "coinpaprika"
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ── Layer 11: Whale Alert Pool (Hyperliquid) ──────────────────────────────────
// Киты открывшие крупные лонги на Hyperliquid (CoinGlass /hyperliquid/whale-alert).
// Только position_action=1 (открытие) и position_size>0 (лонг), только токены
// торгуемые на BingX (маппинг HL base → BingX pair, k-префикс → 1000-префикс).
// Инжектируются в основной скан через Layer 11 на 24ч.
// Подтверждение: live large-limit-order фьюч + спот (fail-open: null = нет данных).
// Live-метрики обновляются каждый скан-цикл из prescanTracker;
// история по циклам — в whale_alert_watch_log.
export const whaleAlertPoolTable = pgTable(
  "whale_alert_pool",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(), // BingX pair, напр. "HYPE-USDT"
    hlSymbol: text("hl_symbol").notNull(), // Hyperliquid base, напр. "HYPE" / "kPEPE"
    status: text("status").notNull().default("watching"), // watching | fired | expired
    detectedAt: timestamp("detected_at").notNull().defaultNow(),
    expiresAt: timestamp("expires_at").notNull(),
    firedAt: timestamp("fired_at"),

    // Снапшот кита в момент детекта (крупнейший алерт)
    whaleAddress: text("whale_address"), // адрес кита (user)
    positionValueUsd: doublePrecision("position_value_usd"), // размер позиции USD
    positionSizeTokens: doublePrecision("position_size_tokens"),
    whaleEntryPrice: doublePrecision("whale_entry_price"), // цена входа кита на HL
    liqPrice: doublePrecision("liq_price"), // цена ликвидации кита
    alertTime: timestamp("alert_time"), // create_time алерта

    // Агрегация повторных алертов пока запись активна
    whaleCount: integer("whale_count").notNull().default(1), // уникальных китов
    totalWhaleUsd: doublePrecision("total_whale_usd"), // суммарный USD всех алертов

    // Цена BingX при детекте
    entryPrice: real("entry_price"),

    // Подтверждение крупными лимитниками (fail-open: null = нет данных CG)
    futLargeOrderConfirmed: boolean("fut_large_order_confirmed"),
    futLargeOrderBidUsd: real("fut_large_order_bid_usd"),
    spotLargeOrderConfirmed: boolean("spot_large_order_confirmed"),
    spotLargeOrderBidUsd: real("spot_large_order_bid_usd"),

    // Live-метрики (обновляются каждый скан-цикл из prescanTracker)
    currentPrice: real("current_price"),
    priceChangePct: real("price_change_pct"), // % от entryPrice
    oi30m: real("oi_30m"),
    oi1h: real("oi_1h"),
    oi4h: real("oi_4h"),
    oi24h: real("oi_24h"),
    spotVol1h: real("spot_vol_1h"),
    spotVol4h: real("spot_vol_4h"),
    spotVol24h: real("spot_vol_24h"),
    spotVolMult: real("spot_vol_mult"),
    spotVolMcapPct: real("spot_vol_mcap_pct"),
    cvd30m: boolean("cvd_30m"),
    cvd1h: boolean("cvd_1h"),
    cvd4h: boolean("cvd_4h"),
    cycleCount: integer("cycle_count").notNull().default(0),
    lastCycleAt: timestamp("last_cycle_at"),
    // Цена через 72ч после выстрела/истечения — для ретроспективной оценки качества (NULL до тех пор)
    price72hPct: real("price_72h_pct"),
  },
  (table) => ({
    symbolStatusIdx: index("whale_alert_pool_symbol_status_idx").on(
      table.symbol,
      table.status,
    ),
    detectedAtIdx: index("whale_alert_pool_detected_at_idx").on(
      table.detectedAt,
    ),
    // Дедуп между 2 прод-воркерами: только одна watching-запись на символ
    symbolWatchingUq: uniqueIndex("whale_alert_pool_symbol_watching_uq")
      .on(table.symbol)
      .where(sql`status = 'watching'`),
  }),
);

export type WhaleAlertPoolRow = typeof whaleAlertPoolTable.$inferSelect;
export type InsertWhaleAlertPool = typeof whaleAlertPoolTable.$inferInsert;

// ── Layer 11: Whale Alert Watch Log — история метрик по циклам ────────────────
// Пишется каждый скан-цикл пока символ активен в whale_alert_pool (status=watching).
export const whaleAlertWatchLogTable = pgTable(
  "whale_alert_watch_log",
  {
    id: serial("id").primaryKey(),
    poolId: integer("pool_id").notNull(),
    symbol: text("symbol").notNull(),
    ts: timestamp("ts").notNull().defaultNow(),
    price: real("price"),
    oi30m: real("oi_30m"),
    oi1h: real("oi_1h"),
    oi4h: real("oi_4h"),
    oi24h: real("oi_24h"),
    spotVol1h: real("spot_vol_1h"),
    spotVol4h: real("spot_vol_4h"),
    spotVol24h: real("spot_vol_24h"),
    spotVolMult: real("spot_vol_mult"),
    spotVolMcapPct: real("spot_vol_mcap_pct"),
    cvd30m: boolean("cvd_30m"),
    cvd1h: boolean("cvd_1h"),
    cvd4h: boolean("cvd_4h"),
  },
  (table) => ({
    symbolTsIdx: index("whale_alert_log_symbol_ts_idx").on(
      table.symbol,
      table.ts,
    ),
    poolIdIdx: index("whale_alert_log_pool_id_idx").on(table.poolId),
  }),
);

export type WhaleAlertWatchLogRow = typeof whaleAlertWatchLogTable.$inferSelect;
export type InsertWhaleAlertWatchLog =
  typeof whaleAlertWatchLogTable.$inferInsert;

// ── Layer 11: Whale Alert Seen — персистентный дедуп обработанных алертов ─────
// Ключ `${user}:${symbol}:${createTime}`. Без персиста после рестарта job заново
// агрегирует те же алерты CoinGlass → detected/totalWhaleUsd задваиваются.
// TTL чистится в job'е (SEEN_TTL_MS).
export const whaleAlertSeenTable = pgTable("whale_alert_seen", {
  seenKey: text("seen_key").primaryKey(),
  ts: timestamp("ts").notNull().defaultNow(),
});

export type WhaleAlertSeenRow = typeof whaleAlertSeenTable.$inferSelect;
export type InsertWhaleAlertSeen = typeof whaleAlertSeenTable.$inferInsert;

// ── Scan Reject Log — per-symbol per-pattern reject reasons ───────────────────
// Зачем: аудит "почему сканер не поймал токен X перед его памповым ростом".
// Три уровня: (a) gate — ранние фильтры; (b) inline-pattern pre-check;
// (c) no_match — прошёл все гейты но ни один паттерн не сработал.
// TTL: 7 дней (cleanup в runStartupMigration).
export const scanRejectLogTable = pgTable(
  "scan_reject_log",
  {
    id: serial("id").primaryKey(),
    cycleAt: timestamp("cycle_at", { withTimezone: true }).notNull(),
    symbol: text("symbol").notNull(),
    pattern: text("pattern").notNull(),
    reason: text("reason").notNull(),
    oi30m: real("oi30m"),
    volMult: real("vol_mult"),
    price24h: real("price24h"),
    prescanCycles: integer("prescan_cycles"),
  },
  (t) => [
    index("scan_reject_log_sym_idx").on(t.symbol, t.cycleAt),
    index("scan_reject_log_cycle_idx").on(t.cycleAt),
  ],
);
export type ScanRejectLogRow = typeof scanRejectLogTable.$inferSelect;

// ── Layer 14: Inflow/Outflow Pool ─────────────────────────────────────────────
// CoinGlass exchange/chain/tx transfers (тип 2 = вывод с биржи = накопление).
// Крупные on-chain переводы ≥$2M: токены с чистым оттоком с бирж → пул 24ч.
// Цель: токены которые умные деньги выводят с бирж (накопление в холодных кошельках).
export const inflowOutflowL14PoolTable = pgTable(
  "inflow_outflow_l14_pool",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(), // BingX pair, напр. "ETH-USDT"
    coinSymbol: text("coin_symbol").notNull(), // raw монета, напр. "ETH"
    status: text("status").notNull().default("watching"), // watching | expired
    detectedAt: timestamp("detected_at").notNull().defaultNow(),
    expiresAt: timestamp("expires_at").notNull(),
    entryPrice: real("entry_price"), // BingX цена при обнаружении
    txCount: integer("tx_count").default(0), // кол-во outflow транзакций
    totalOutflowUsd: doublePrecision("total_outflow_usd"), // суммарный USD оттока
    exchangeName: text("exchange_name"), // биржа (Binance/OKX/Coinbase...)
    transferType: text("transfer_type").default("outflow"), // "outflow" | "inflow"
    balanceChange7dPct: real("balance_change_7d_pct"), // % изменение баланса биржи за 7д
    matchedPattern: text("matched_pattern"),
  },
  (table) => ({
    symbolStatusIdx: index("inflow_outflow_l14_symbol_status_idx").on(
      table.symbol,
      table.status,
    ),
    detectedAtIdx: index("inflow_outflow_l14_detected_at_idx").on(
      table.detectedAt,
    ),
  }),
);

export type InflowOutflowL14Pool =
  typeof inflowOutflowL14PoolTable.$inferSelect;
export type InsertInflowOutflowL14Pool =
  typeof inflowOutflowL14PoolTable.$inferInsert;

// ── Candidate Growth Tracking — единый кросс-слойный индекс кандидатов ────────
// Заполняется всеми слоями обнаружения: L10/L11/L14/OI Watch/Prescan.
// Позволяет: SELECT count(*) FROM candidate_growth_tracking GROUP BY detection_source
// и отслеживать рост от момента входа (growthFromEntryPct обновляется job'ом).
export const candidateGrowthTrackingTable = pgTable(
  "candidate_growth_tracking",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(),
    detectionSource: text("detection_source").notNull(), // L10|L11|L14|oi_watch|prescan
    entryPrice: real("entry_price"),
    entryTimestamp: timestamp("entry_timestamp").notNull().defaultNow(),
    growthFromEntryPct: real("growth_from_entry_pct"), // обновляется периодически
    matchedPattern: text("matched_pattern"), // null до выстрела сигнала
    status: text("status").notNull().default("watching"), // watching|fired|expired|cancelled
    sourceTableId: integer("source_table_id"), // id в исходной таблице-пуле
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    symbolSourceIdx: index("candidate_growth_tracking_symbol_source_idx").on(
      table.symbol,
      table.detectionSource,
    ),
    statusIdx: index("candidate_growth_tracking_status_idx").on(table.status),
    entryTsIdx: index("candidate_growth_tracking_entry_ts_idx").on(
      table.entryTimestamp,
    ),
    symbolSourceUq: uniqueIndex("candidate_growth_tracking_symbol_source_uq")
      .on(table.symbol, table.detectionSource)
      .where(sql`status = 'watching'`),
  }),
);

export type CandidateGrowthTracking =
  typeof candidateGrowthTrackingTable.$inferSelect;
export type InsertCandidateGrowthTracking =
  typeof candidateGrowthTrackingTable.$inferInsert;

// ── Overheat Log: токены выкинутые из прескана фильтром перегрева (price24h > 40%) ──
// Пишется при каждом цикле скана, когда tracked-токен (в prescan_tracker) пересекает
// порог +40% и выкидывается из всех слоёв. Дедупликация: 4ч окно на символ (in-memory).
// TTL: 30 дней (DELETE в runStartupMigration). Цель — анализ поведения и калибровка.
export const overheatLogTable = pgTable(
  "overheat_log",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(),
    kickedAt: timestamp("kicked_at").notNull().defaultNow(),
    // Состояние в момент кика (из BingX тикера)
    price24h: real("price_24h").notNull(), // p24h% в момент кика (>40)
    price: real("price"), // текущая цена в момент кика
    // Entry-метрики (из prescanTracker.first_*) — что было видно КОГДА токен вошёл в prescan
    entryPrice: real("entry_price"), // цена при первом попадании в prescan
    entryPrice24h: real("entry_price_24h"), // p24h% при первом попадании
    entryOi30m: real("entry_oi_30m"),
    entryOi1h: real("entry_oi_1h"),
    entryOi4h: real("entry_oi_4h"),
    // Prescan-контекст в момент кика
    cycleCount: integer("cycle_count"),
    layers: text("layers").array(),
    matchedPattern: text("matched_pattern"), // сигнал если был за время нахождения в prescan
    // Аналитические поля для ретроанализа
    entryVol24h: real("entry_vol_24h"), // quoteVolume BingX в момент кика (USDT)
    firstSeenAt: timestamp("first_seen_at"), // когда токен первый раз вошёл в prescan
    // Периодические снапшоты цены — обновляются каждый скан-цикл для всех overheat-токенов
    snapshotPrice: real("snapshot_price"), // последняя известная цена (из BingX тикера)
    snapshotAt: timestamp("snapshot_at"), // когда был последний снапшот
    /** true = строка создана startup-бэкфилом (данные при входе в prescan, а не в момент перегрева) */
    retro: boolean("retro").notNull().default(false),
  },
  (table) => ({
    kickedAtIdx: index("overheat_log_kicked_at_idx").on(table.kickedAt),
    symbolIdx: index("overheat_log_symbol_idx").on(table.symbol),
  }),
);

export type OverheatLogRow = typeof overheatLogTable.$inferSelect;

// ── RSI Watch: токены с RSI 1h < 30 — зона перепроданности ──────────────────
// Обновляется каждые ~15 мин отдельным job-ом в watcher.ts.
// TTL: 7 дней (DELETE в runStartupMigration).
// Статус: watching → expired (RSI поднялся выше 45 или истекло 7 дней).
export const rsiWatchTable = pgTable(
  "rsi_watch",
  {
    id: serial("id").primaryKey(),
    symbol: text("symbol").notNull(), // BingX pair, напр. "BTC-USDT"
    status: text("status").notNull().default("watching"), // watching | expired
    addedAt: timestamp("added_at").notNull().defaultNow(),
    expiresAt: timestamp("expires_at").notNull(),
    // Снапшот при добавлении
    priceAtAdd: real("price_at_add"),
    price24hAtAdd: real("price_24h_at_add"),
    rsiAtAdd: real("rsi_at_add"), // RSI 1h при добавлении (<30)
    emaAtAdd: real("ema_at_add"), // EMA 1h при добавлении
    macdAtAdd: real("macd_at_add"), // MACD histogram 1h при добавлении
    // Текущие метрики (обновляются каждый цикл)
    currentPrice: real("current_price"),
    pctChange: real("pct_change"), // % от priceAtAdd
    currentRsi: real("current_rsi"),
    currentEma: real("current_ema"),
    currentMacd: real("current_macd"),
    lastUpdatedAt: timestamp("last_updated_at"),
  },
  (table) => ({
    symbolStatusIdx: index("rsi_watch_symbol_status_idx").on(
      table.symbol,
      table.status,
    ),
    addedAtIdx: index("rsi_watch_added_at_idx").on(table.addedAt),
  }),
);

export type RsiWatchRow = typeof rsiWatchTable.$inferSelect;
export type InsertRsiWatch = typeof rsiWatchTable.$inferInsert;

// ── TA Scanner cache — мульти-TF TA данные (MA/EMA/MACD/TD/ATR) ──────────────
// Одна строка (id=1). Обновляется каждые 5 мин runTaScannerCycle().
// Цель: вкладка Layer TA не пустеет после деплоя — данные подгружаются
// из БД немедленно при старте, до первого 19-минутного цикла.
export const taScannerCacheTable = pgTable("ta_scanner_cache", {
  id: integer("id").primaryKey().default(1),
  entries: jsonb("entries").$type<Record<string, unknown>[]>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});
