/**
 * Spot NetFlow Cache — batch fetch /api/spot/netflow-list every 5 min.
 *
 * Fetches 3 pages × 200 symbols = up to 600 top coins from CoinGlass.
 * Returns net flow as % of total taker volume for 1h / 4h / 24h / 7d.
 *
 * Symbol key: CoinGlass base ticker (e.g. "BTC", "ETH", "PEPE").
 * BingX "1000PEPE-USDT" → "PEPE", "BTC-USDT" → "BTC".
 */

import { logger } from "./logger.js";
import { getNextCgKey } from "./coinglass_keys.js";

const CACHE_MS = 5 * 60 * 1000; // 5 min refresh
const PAGES = 3; // 3 × 200 = 600 symbols

// ── Per-symbol supplement ─────────────────────────────────────────────────────
// Для символов не попавших в top-600 batch — тихий per-symbol фетч.
// Ключ — BingX символ (BTC-USDT). TTL совпадает с batch TTL.
const _perSymbolMap = new Map<
  string,
  { entry: SpotNetflowEntry; ts: number }
>();
// Очередь символов для supplement-фетча; пополняется при fire сигналов.
const _supplementQueue = new Set<string>();

/** Регистрирует BingX-символ для supplement-фетча после следующего batch-обновления. */
export function registerSnfSymbol(bingxSymbol: string): void {
  _supplementQueue.add(bingxSymbol);
}

export interface SpotNetflowEntry {
  netPct1h: number | null;
  netPct4h: number | null;
  netPct24h: number | null;
  netPct7d: number | null;
}

interface RawRow {
  symbol: string;
  taker_buy_volume_usd_1h: number;
  taker_sell_volume_usd_1h: number;
  net_flow_usd_1h: number;
  taker_buy_volume_usd_4h: number;
  taker_sell_volume_usd_4h: number;
  net_flow_usd_4h: number;
  taker_buy_volume_usd_24h: number;
  taker_sell_volume_usd_24h: number;
  net_flow_usd_24h: number;
  taker_buy_volume_usd_7d: number;
  taker_sell_volume_usd_7d: number;
  net_flow_usd_7d: number;
}

let _cache: Map<string, SpotNetflowEntry> = new Map();
let _cacheTs = 0;
let _inFlight: Promise<void> | null = null;

function pct(net: number, buy: number, sell: number): number | null {
  const total = buy + sell;
  if (!total) return null;
  return (net / total) * 100;
}

/** Вычисляет SpotNetflowEntry из сырых 15m свечей (limit=96 → 1h/4h/24h). */
interface RawCandle {
  taker_buy_volume_usd: number | string;
  taker_sell_volume_usd: number | string;
}

function entryFromCandles(candles: RawCandle[]): SpotNetflowEntry {
  const aggregate = (slice: RawCandle[]) => {
    let buy = 0,
      sell = 0;
    for (const c of slice) {
      buy += Number(c.taker_buy_volume_usd);
      sell += Number(c.taker_sell_volume_usd);
    }
    const total = buy + sell;
    return total > 0 ? ((buy - sell) / total) * 100 : null;
  };
  return {
    netPct1h: aggregate(candles.slice(-4)), // 4 × 15m = 1h
    netPct4h: aggregate(candles.slice(-16)), // 16 × 15m = 4h
    netPct24h: aggregate(candles.slice(-96)), // 96 × 15m = 24h
    netPct7d: null, // не доступен per-symbol
  };
}

/** BingX-символ → CG-совместимый spot-symbol для Binance (BTCUSDT) или BingX (BTC-USDT). */
function toSpotSymbol(
  bingxSymbol: string,
  exchange: "Binance" | "BingX",
): string {
  return exchange === "Binance" ? bingxSymbol.replace("-", "") : bingxSymbol;
}

/**
 * Фетч per-symbol spot netflow через /api/spot/taker-buy-sell-volume/history (limit=96 = 24h).
 * Пробует Binance → BingX. Кэширует в _perSymbolMap.
 */
async function fetchPerSymbol(bingxSymbol: string): Promise<void> {
  const cached = _perSymbolMap.get(bingxSymbol);
  if (cached && Date.now() - cached.ts < CACHE_MS) return; // свежий

  const apiKey = getNextCgKey();
  if (!apiKey) return;

  for (const exchange of ["Binance", "BingX"] as const) {
    try {
      const symbol = toSpotSymbol(bingxSymbol, exchange);
      const url = `https://open-api-v4.coinglass.com/api/spot/taker-buy-sell-volume/history?symbol=${encodeURIComponent(symbol)}&exchange=${exchange}&interval=15m&limit=96`;
      const res = await fetch(url, {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(8_000),
      });
      if (!res.ok) continue;
      const d = (await res.json()) as { code: string; data?: RawCandle[] };
      if (d.code !== "0" || !d.data?.length) continue;
      _perSymbolMap.set(bingxSymbol, {
        entry: entryFromCandles(d.data),
        ts: Date.now(),
      });
      return; // успех
    } catch {
      // try next exchange
    }
  }
  // Если не удалось — записываем пустой с коротким TTL (30s), чтобы не спамить
  _perSymbolMap.set(bingxSymbol, {
    entry: { netPct1h: null, netPct4h: null, netPct24h: null, netPct7d: null },
    ts: Date.now() - CACHE_MS + 30_000,
  });
}

async function fetchAndRefresh(): Promise<void> {
  const map = new Map<string, SpotNetflowEntry>();

  for (let page = 1; page <= PAGES; page++) {
    const apiKey = getNextCgKey();
    if (!apiKey) break;

    try {
      const url = `https://open-api-v4.coinglass.com/api/spot/netflow-list?per_page=200&page=${page}`;
      const res = await fetch(url, {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(10_000),
      });
      if (!res.ok) {
        logger.warn(
          { status: res.status, page },
          "SpotNetflowCache: HTTP error",
        );
        break;
      }

      const d = (await res.json()) as { code: string; data?: RawRow[] };
      if (d.code !== "0" || !d.data?.length) break;

      for (const row of d.data) {
        map.set(row.symbol.toUpperCase(), {
          netPct1h: pct(
            row.net_flow_usd_1h,
            row.taker_buy_volume_usd_1h,
            row.taker_sell_volume_usd_1h,
          ),
          netPct4h: pct(
            row.net_flow_usd_4h,
            row.taker_buy_volume_usd_4h,
            row.taker_sell_volume_usd_4h,
          ),
          netPct24h: pct(
            row.net_flow_usd_24h,
            row.taker_buy_volume_usd_24h,
            row.taker_sell_volume_usd_24h,
          ),
          netPct7d: pct(
            row.net_flow_usd_7d,
            row.taker_buy_volume_usd_7d,
            row.taker_sell_volume_usd_7d,
          ),
        });
      }

      if (d.data.length < 200) break; // last page
    } catch (err) {
      logger.warn({ page, err }, "SpotNetflowCache: fetch error");
      break;
    }
  }

  if (map.size > 0) {
    _cache = map;
    _cacheTs = Date.now();
    logger.info({ count: map.size }, "SpotNetflowCache: refreshed");
  }

  // ── Supplement: per-symbol fetch для символов не попавших в batch ────────────
  if (_supplementQueue.size > 0) {
    const cgBase = (s: string) => {
      const b = s.replace("-USDT", "");
      return /^1000[A-Z]/.test(b) ? b.slice(4) : b;
    };
    const missing: string[] = [];
    for (const sym of _supplementQueue) {
      if (!map.has(cgBase(sym).toUpperCase())) missing.push(sym);
    }
    if (missing.length > 0) {
      logger.debug(
        { count: missing.length },
        "SpotNetflowCache: supplement per-symbol fetch",
      );
      // Батчами по 5 с небольшой задержкой — не перегружаем CG API
      for (let i = 0; i < missing.length; i += 5) {
        await Promise.all(missing.slice(i, i + 5).map(fetchPerSymbol));
        if (i + 5 < missing.length)
          await new Promise((r) => setTimeout(r, 300));
      }
    }
  }
}

/** BingX "BTC-USDT" → "BTC", "1000PEPE-USDT" → "PEPE" */
export function bingxToCg(bingxSymbol: string): string {
  const base = bingxSymbol.replace("-USDT", "");
  return /^1000[A-Z]/.test(base) ? base.slice(4) : base;
}

export function getSpotNetflowEntry(
  bingxSymbol: string,
): SpotNetflowEntry | null {
  // Batch первый (cross-exchange aggregate), per-symbol как fallback
  return (
    _cache.get(bingxToCg(bingxSymbol).toUpperCase()) ??
    _perSymbolMap.get(bingxSymbol)?.entry ??
    null
  );
}

export function getAllSpotNetflow(): Record<string, SpotNetflowEntry> {
  // Merge: per-symbol под ключом CG-base (для UI snfMap)
  const out: Record<string, SpotNetflowEntry> = Object.fromEntries(_cache);
  for (const [bingxSym, { entry }] of _perSymbolMap) {
    const cgKey = bingxToCg(bingxSym).toUpperCase();
    if (!out[cgKey]) out[cgKey] = entry; // batch имеет приоритет
  }
  return out;
}

export function getCacheUpdatedAt(): number {
  return _cacheTs;
}

export async function ensureSpotNetflowFresh(): Promise<void> {
  if (Date.now() - _cacheTs < CACHE_MS) return;
  if (!_inFlight) {
    _inFlight = fetchAndRefresh().finally(() => {
      _inFlight = null;
    });
  }
  await _inFlight;
}

export function startSpotNetflowRefresh(): void {
  fetchAndRefresh().catch(() => {});
  setInterval(() => {
    if (!_inFlight) {
      _inFlight = fetchAndRefresh().finally(() => {
        _inFlight = null;
      });
    }
  }, CACHE_MS);
}
