/**
 * growthLeaderEnrich.ts
 *
 * Бэкфилл NULL-полей growth_leader_log (price24h >= 20%) исключительно через CoinGlass:
 *
 *   cvd_30m          — bool, SpotCVD 30m бычий
 *   spot_cvd_4h      — bool, SpotCVD 4h бычий
 *   cvd_delta_4h     — real, Δ cum_vol_delta USD за 4h
 *   funding_rate     — real, funding rate на момент logged_at
 *   entry_price_24h  — real, p24h% на момент first_seen_at
 *   growth_from_entry— real, рост от entry_price до price (если оба есть — DB-only)
 *
 * Запускается через POST /api/admin/enrich-growth-leaders (requireAdminToken).
 * Статус: GET /api/admin/enrich-growth-leaders-status
 * CSV:    GET /api/admin/enrich-growth-leaders-csv
 *
 * Синглтон — только один запуск одновременно. Чекпоинт /tmp/enrich-checkpoint.json.
 * Финальный CSV /tmp/growth-leaders-enriched.csv.
 */

import fs from "fs";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { logger } from "./logger.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";

// ── Config ────────────────────────────────────────────────────────────────────

const CHECKPOINT_PATH = "/tmp/enrich-checkpoint.json";
const CSV_PATH = "/tmp/growth-leaders-enriched.csv";
const MIN_PRICE24H = 20;
const BATCH_SIZE = 4; // символов параллельно
const CG_DELAY_MS = 250; // мс между CG-запросами одного символа
const BATCH_DELAY_MS = 1200; // мс между батчами

const CG_EXCHANGES = "Binance,Bybit,Bitget,OKX";

// ── Job state (singleton) ─────────────────────────────────────────────────────

export interface EnrichJobStatus {
  running: boolean;
  startedAt: string | null;
  totalSymbols: number;
  processedSymbols: number;
  updatedRows: number;
  skippedSymbols: number;
  errors: number;
  csvReady: boolean;
  finishedAt: string | null;
}

let _jobStatus: EnrichJobStatus = {
  running: false,
  startedAt: null,
  totalSymbols: 0,
  processedSymbols: 0,
  updatedRows: 0,
  skippedSymbols: 0,
  errors: 0,
  csvReady: false,
  finishedAt: null,
};

export function getEnrichJobStatus(): EnrichJobStatus {
  return { ..._jobStatus };
}

// ── CoinGlass fetch ───────────────────────────────────────────────────────────

const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

interface CgCvdCandle {
  time: number;
  agg_taker_buy_vol: number;
  agg_taker_sell_vol: number;
  cum_vol_delta: number;
}
interface CgFundingBar {
  time: number;
  fundingRate: number;
}
interface CgPriceBar {
  time: number;
  o: number;
  h: number;
  l: number;
  c: number;
  v?: number;
}

async function cgGet<T>(url: string): Promise<T[] | null> {
  const key = getNextCgKey();
  if (!key) return null;
  try {
    const res = await fetch(url, {
      headers: { "CG-API-KEY": key, Accept: "application/json" },
      signal: AbortSignal.timeout(12_000),
    });
    if (res.status === 429) {
      logCg429(key, { url });
      return null;
    }
    if (!res.ok) return null;
    const json = (await res.json()) as { code?: string; data?: T[] };
    if (
      json.code !== "0" ||
      !Array.isArray(json.data) ||
      json.data.length === 0
    )
      return null;
    return json.data;
  } catch {
    return null;
  }
}

/** CVD history: 15m свечи с start_time — тот же endpoint что fetchAggCvd, + start_time для истории */
async function fetchCvdHistory(
  base: string,
  startMs: number,
  limit: number,
): Promise<CgCvdCandle[] | null> {
  return cgGet<CgCvdCandle>(
    `https://open-api-v4.coinglass.com/api/spot/aggregated-cvd/history` +
      `?symbol=${encodeURIComponent(base)}&exchange_list=${CG_EXCHANGES}&interval=15m&start_time=${startMs}&limit=${Math.min(limit, 500)}`,
  );
}

/** Funding rate history: 8h свечи */
async function fetchFundingHistory(
  base: string,
  startMs: number,
  limit: number,
): Promise<CgFundingBar[] | null> {
  return cgGet<CgFundingBar>(
    `https://open-api-v4.coinglass.com/api/futures/funding-rate/history` +
      `?symbol=${encodeURIComponent(base)}USDT&interval=8h&start_time=${startMs}&limit=${Math.min(limit, 100)}`,
  );
}

/** Price/OHLCV history для entry_price_24h и growth_from_entry */
async function fetchPriceHistory(
  base: string,
  startMs: number,
  limit: number,
): Promise<CgPriceBar[] | null> {
  return cgGet<CgPriceBar>(
    `https://open-api-v4.coinglass.com/api/futures/price/history` +
      `?exchange=Binance&symbol=${encodeURIComponent(base)}USDT&interval=1h&start_time=${startMs}&limit=${Math.min(limit, 500)}`,
  );
}

// ── Вычисления ────────────────────────────────────────────────────────────────

/** Ближайшая свеча ≤ targetMs в пределах toleranceMs */
function nearestBar<T extends { time: number }>(
  arr: T[],
  targetMs: number,
  toleranceMs: number,
): T | null {
  let best: T | null = null;
  let bestDist = Infinity;
  for (const c of arr) {
    if (c.time > targetMs) continue;
    const d = targetMs - c.time;
    if (d < bestDist && d <= toleranceMs) {
      best = c;
      bestDist = d;
    }
  }
  return best;
}

/** CVD 30m бычий: сумма agg_taker_buy_vol > agg_taker_sell_vol за 2 свечи × 15m до targetMs */
function calcCvd30m(
  cvd: CgCvdCandle[] | null,
  targetMs: number,
): boolean | null {
  if (!cvd) return null;
  const windowStart = targetMs - 30 * 60_000;
  const candles = cvd.filter(
    (c) => c.time >= windowStart && c.time <= targetMs,
  );
  if (candles.length === 0) return null;
  const buy = candles.reduce((s, c) => s + c.agg_taker_buy_vol, 0);
  const sell = candles.reduce((s, c) => s + c.agg_taker_sell_vol, 0);
  return buy + sell > 0 ? buy > sell : null;
}

/** CVD 4h бычий: cum_vol_delta последней свечи в 4h-окне > 0 */
function calcCvd4h(
  cvd: CgCvdCandle[] | null,
  targetMs: number,
): boolean | null {
  if (!cvd) return null;
  const windowStart = targetMs - 4 * 3_600_000;
  const candles = cvd.filter(
    (c) => c.time >= windowStart && c.time <= targetMs,
  );
  if (candles.length === 0) return null;
  candles.sort((a, b) => b.time - a.time);
  const last = candles[0]!;
  return last.cum_vol_delta !== 0 ? last.cum_vol_delta > 0 : null;
}

/** cvd_delta_4h: Δ cum_vol_delta за 4h (последняя - первая в окне) */
function calcCvdDelta4h(
  cvd: CgCvdCandle[] | null,
  targetMs: number,
): number | null {
  if (!cvd) return null;
  const windowStart = targetMs - 4 * 3_600_000;
  const candles = cvd.filter(
    (c) => c.time >= windowStart && c.time <= targetMs,
  );
  if (candles.length < 2) return null;
  candles.sort((a, b) => a.time - b.time);
  return candles[candles.length - 1]!.cum_vol_delta - candles[0]!.cum_vol_delta;
}

/** funding_rate: ближайшая запись ≤ targetMs + 8h */
function calcFunding(
  funding: CgFundingBar[] | null,
  targetMs: number,
): number | null {
  if (!funding) return null;
  return (
    nearestBar(funding, targetMs + 8 * 3_600_000, 16 * 3_600_000)
      ?.fundingRate ?? null
  );
}

/**
 * entry_price_24h: p24h% на момент first_seen_at
 * = (close[first_seen_at] - close[first_seen_at - 24h]) / close[first_seen_at - 24h] * 100
 */
function calcEntryPrice24h(
  price: CgPriceBar[] | null,
  firstSeenMs: number,
): number | null {
  if (!price) return null;
  const barNow = nearestBar(price, firstSeenMs, 2 * 3_600_000);
  const bar24h = nearestBar(price, firstSeenMs - 24 * 3_600_000, 2 * 3_600_000);
  if (!barNow || !bar24h || bar24h.c <= 0) return null;
  return ((barNow.c - bar24h.c) / bar24h.c) * 100;
}

/**
 * growth_from_entry: рост от entry_price (first_seen_at) до price (logged_at)
 * Приоритет: если entry_price есть в DB — считаем из него.
 * Иначе берём close[first_seen_at] из price history.
 */
function calcGrowthFromEntry(
  priceHistory: CgPriceBar[] | null,
  loggedAtMs: number,
  firstSeenMs: number,
  entryPriceDb: number | null,
  priceAtLogDb: number | null,
): number | null {
  // Вариант 1: оба значения в DB
  if (entryPriceDb != null && entryPriceDb > 0 && priceAtLogDb != null) {
    return ((priceAtLogDb - entryPriceDb) / entryPriceDb) * 100;
  }
  // Вариант 2: через price history
  if (!priceHistory) return null;
  const barLog = nearestBar(priceHistory, loggedAtMs, 2 * 3_600_000);
  const barEntry = nearestBar(priceHistory, firstSeenMs, 2 * 3_600_000);
  if (!barLog || !barEntry || barEntry.c <= 0) return null;
  return ((barLog.c - barEntry.c) / barEntry.c) * 100;
}

// ── CSV helpers ───────────────────────────────────────────────────────────────

function toCsv(v: unknown): string {
  if (v == null) return "";
  if (v instanceof Date) return v.toISOString();
  const s = String(v);
  return s.includes(",") || s.includes('"') || s.includes("\n")
    ? `"${s.replace(/"/g, '""')}"`
    : s;
}

// ── Main job ──────────────────────────────────────────────────────────────────

type Row = {
  id: number;
  symbol: string;
  logged_at: Date;
  first_seen_at: number | null;
  price: number | null;
  entry_price: number | null;
  cvd_30m: boolean | null;
  spot_cvd_4h: boolean | null;
  cvd_delta_4h: number | null;
  funding_rate: number | null;
  entry_price_24h: number | null;
  growth_from_entry: number | null;
  [k: string]: unknown;
};

interface Checkpoint {
  doneSymbols: string[];
}

function loadCp(): Checkpoint {
  try {
    if (fs.existsSync(CHECKPOINT_PATH)) {
      const c = JSON.parse(
        fs.readFileSync(CHECKPOINT_PATH, "utf8"),
      ) as Checkpoint;
      logger.info({ done: c.doneSymbols.length }, "enrich: чекпоинт загружен");
      return c;
    }
  } catch {
    /* ignore */
  }
  return { doneSymbols: [] };
}

function saveCp(cp: Checkpoint) {
  fs.writeFileSync(CHECKPOINT_PATH, JSON.stringify(cp));
}

export async function runEnrichJob(): Promise<void> {
  if (_jobStatus.running) return;
  _jobStatus = {
    running: true,
    startedAt: new Date().toISOString(),
    totalSymbols: 0,
    processedSymbols: 0,
    updatedRows: 0,
    skippedSymbols: 0,
    errors: 0,
    csvReady: false,
    finishedAt: null,
  };

  logger.info({ minPrice24h: MIN_PRICE24H }, "enrich-growth-leaders: старт");

  try {
    // 1. Загрузить строки из DB
    const allRows = await db.execute<Row>(sql`
      SELECT * FROM growth_leader_log
      WHERE price_24h >= ${MIN_PRICE24H}
        AND (
          cvd_30m           IS NULL OR
          spot_cvd_4h       IS NULL OR
          cvd_delta_4h      IS NULL OR
          funding_rate      IS NULL OR
          entry_price_24h   IS NULL OR
          growth_from_entry IS NULL
        )
      ORDER BY logged_at
    `);

    const rows = allRows.rows as unknown as Row[];
    logger.info({ count: rows.length }, "enrich: строк загружено");

    if (rows.length === 0) {
      _jobStatus.running = false;
      _jobStatus.finishedAt = new Date().toISOString();
      _jobStatus.csvReady = false;
      return;
    }

    // 2. Группировка по символу
    const bySymbol = new Map<string, Row[]>();
    for (const r of rows) {
      if (!bySymbol.has(r.symbol)) bySymbol.set(r.symbol, []);
      bySymbol.get(r.symbol)!.push(r);
    }
    const symbols = [...bySymbol.keys()];
    _jobStatus.totalSymbols = symbols.length;

    // 3. Чекпоинт
    const cp = loadCp();
    const doneSet = new Set(cp.doneSymbols);
    const todo = symbols.filter((s) => !doneSet.has(s));
    logger.info(
      { todo: todo.length, skipped: doneSet.size },
      "enrich: символов к обработке",
    );

    // 4. CSV: все колонки + обогащённые
    const allCols = Object.keys(rows[0]!);
    fs.writeFileSync(CSV_PATH, allCols.join(",") + "\n", "utf8");

    // 5. Батчи
    for (let i = 0; i < todo.length; i += BATCH_SIZE) {
      const batch = todo.slice(i, i + BATCH_SIZE);

      await Promise.all(
        batch.map((sym) => processSym(sym, bySymbol.get(sym)!, allCols)),
      );

      // Чекпоинт каждые 50 символов
      const processed = i + batch.length;
      cp.doneSymbols = [...doneSet, ...todo.slice(0, processed)];
      saveCp(cp);

      logger.info(
        { processed, total: todo.length, updated: _jobStatus.updatedRows },
        `enrich: прогресс ${Math.round((processed / todo.length) * 100)}%`,
      );

      if (i + BATCH_SIZE < todo.length) await delay(BATCH_DELAY_MS);
    }

    _jobStatus.csvReady = true;
    _jobStatus.finishedAt = new Date().toISOString();

    // Удалить чекпоинт при успехе
    try {
      fs.unlinkSync(CHECKPOINT_PATH);
    } catch {
      /* ok */
    }

    logger.info(
      {
        updatedRows: _jobStatus.updatedRows,
        skipped: _jobStatus.skippedSymbols,
        errors: _jobStatus.errors,
      },
      "enrich-growth-leaders: завершён",
    );
  } catch (err) {
    logger.error({ err }, "enrich-growth-leaders: fatal error");
    _jobStatus.errors++;
  } finally {
    _jobStatus.running = false;
  }
}

async function processSym(
  sym: string,
  rows: Row[],
  allCols: string[],
): Promise<void> {
  const base = sym.replace("-USDT", "");
  const tsOf = (v: Date | string | number | null | undefined): number =>
    v instanceof Date
      ? v.getTime()
      : v
        ? new Date(v as string).getTime()
        : Date.now();
  const minTs = Math.min(...rows.map((r) => tsOf(r.logged_at)));
  const maxTs = Math.max(...rows.map((r) => tsOf(r.logged_at)));
  const firstSeen = Math.min(
    ...rows.map((r) =>
      r.first_seen_at != null ? Number(r.first_seen_at) : tsOf(r.logged_at),
    ),
  );

  // Окно: от первого first_seen_at - 26h до maxTs + 1h
  const windowStart = Math.min(firstSeen, minTs) - 26 * 3_600_000;
  const windowEnd = maxTs + 3_600_000;
  const hoursSpan = Math.ceil((windowEnd - windowStart) / 3_600_000);

  // CG fetch — CVD (15m свечи), funding (8h), price (1h)
  const cvdLimit = Math.ceil(hoursSpan * 4) + 20; // 15m свечей
  const fundingLimit = Math.ceil(hoursSpan / 8) + 5;
  const priceLimit = hoursSpan + 10;

  let cvdHist: CgCvdCandle[] | null = null;
  let fundingHist: CgFundingBar[] | null = null;
  let priceHist: CgPriceBar[] | null = null;

  try {
    cvdHist = await fetchCvdHistory(base, windowStart, cvdLimit);
    await delay(CG_DELAY_MS);

    fundingHist = await fetchFundingHistory(base, windowStart, fundingLimit);
    await delay(CG_DELAY_MS);

    priceHist = await fetchPriceHistory(base, windowStart, priceLimit);
  } catch (err) {
    logger.warn({ err, sym }, "enrich: CG fetch error");
    _jobStatus.errors++;
    return;
  }

  const hasData = cvdHist != null || fundingHist != null || priceHist != null;
  if (!hasData) {
    logger.debug({ sym }, "enrich: нет данных CG — BingX-exclusive?");
    _jobStatus.skippedSymbols++;
    return;
  }

  // Вычислить значения для каждой строки
  type Update = {
    id: number;
    cvd_30m: boolean | null;
    spot_cvd_4h: boolean | null;
    cvd_delta_4h: number | null;
    funding_rate: number | null;
    entry_price_24h: number | null;
    growth_from_entry: number | null;
  };
  const updates: Update[] = [];
  const enriched: Record<string, unknown>[] = [];

  for (const row of rows) {
    const ts = tsOf(row.logged_at);
    const fstMs = row.first_seen_at != null ? Number(row.first_seen_at) : ts;

    const cvd30m = row.cvd_30m ?? calcCvd30m(cvdHist, ts);
    const cvd4h = row.spot_cvd_4h ?? calcCvd4h(cvdHist, ts);
    const cvdDelta = row.cvd_delta_4h ?? calcCvdDelta4h(cvdHist, ts);
    const funding = row.funding_rate ?? calcFunding(fundingHist, ts);
    const ep24h = row.entry_price_24h ?? calcEntryPrice24h(priceHist, fstMs);
    const growth =
      row.growth_from_entry ??
      calcGrowthFromEntry(priceHist, ts, fstMs, row.entry_price, row.price);

    updates.push({
      id: row.id,
      cvd_30m: cvd30m,
      spot_cvd_4h: cvd4h,
      cvd_delta_4h: cvdDelta,
      funding_rate: funding,
      entry_price_24h: ep24h,
      growth_from_entry: growth,
    });
    enriched.push({
      ...row,
      cvd_30m: cvd30m,
      spot_cvd_4h: cvd4h,
      cvd_delta_4h: cvdDelta,
      funding_rate: funding,
      entry_price_24h: ep24h,
      growth_from_entry: growth,
    });
  }

  // DB UPDATE (COALESCE — не перезаписывает уже заполненные)
  try {
    const v = (x: unknown): string => {
      if (x == null) return "NULL";
      if (typeof x === "boolean") return x ? "TRUE" : "FALSE";
      if (typeof x === "number" && isFinite(x)) return String(x);
      return "NULL";
    };
    const valRows = updates
      .map(
        (u) =>
          `(${v(u.id)},${v(u.cvd_30m)},${v(u.spot_cvd_4h)},${v(u.cvd_delta_4h)},${v(u.funding_rate)},${v(u.entry_price_24h)},${v(u.growth_from_entry)})`,
      )
      .join(",");
    await db.execute(
      sql.raw(`
      UPDATE growth_leader_log AS t
      SET
        cvd_30m           = COALESCE(t.cvd_30m,           v.c30::boolean),
        spot_cvd_4h       = COALESCE(t.spot_cvd_4h,       v.c4h::boolean),
        cvd_delta_4h      = COALESCE(t.cvd_delta_4h,      v.cdelta::real),
        funding_rate      = COALESCE(t.funding_rate,       v.fund::real),
        entry_price_24h   = COALESCE(t.entry_price_24h,   v.ep24h::real),
        growth_from_entry = COALESCE(t.growth_from_entry, v.growth::real)
      FROM (VALUES ${valRows}) AS v(id,c30,c4h,cdelta,fund,ep24h,growth)
      WHERE t.id = v.id::int
    `),
    );
    _jobStatus.updatedRows += updates.length;
  } catch (err) {
    logger.error({ err, sym }, "enrich: DB update error");
    _jobStatus.errors += updates.length;
  }

  // Append to CSV
  const lines = enriched
    .map((r) => allCols.map((c) => toCsv(r[c])).join(","))
    .join("\n");
  fs.appendFileSync(CSV_PATH, lines + "\n", "utf8");

  _jobStatus.processedSymbols++;
}

export function getCsvPath(): string {
  return CSV_PATH;
}
