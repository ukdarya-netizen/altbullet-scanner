/**
 * CoinGlass — Net Position V2 (изменение чистых позиций лонг/шорт).
 *
 * Endpoint: GET /api/futures/net-position-v2
 *   ?symbol=BTC&exchange=Binance&interval=30m&limit=4
 * Header: CG-API-KEY
 *
 * netShortChangePct — доля прироста OI от коротких позиций:
 *   shortChange / (|longChange| + |shortChange|)
 *   ≥ 0.65 = шорты доминируют в росте OI → признак медвежьего накопления.
 *   При bullish_accumulation: если ≥0.65 → alphaScore -1 (не блокирующий гейт).
 *
 * Cache: 10 мин. Fail-open: null при любой ошибке.
 */

import { logger } from "./logger.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";

export interface NetPositionResult {
  /** Доля прироста от коротких позиций: shortChange / totalChange. Диапазон 0..1 */
  netShortChangePct: number;
  /** Абсолютное суммарное изменение длинных позиций (все свечи, abs) */
  longChange: number;
  /** Абсолютное суммарное изменение коротких позиций (все свечи, abs) */
  shortChange: number;
}

const CACHE_TTL = 10 * 60 * 1000;
const _cache = new Map<
  string,
  { data: NetPositionResult | null; ts: number }
>();

type NpCandle = Record<string, unknown>;

function extractNum(obj: NpCandle, ...keys: string[]): number {
  for (const k of keys) {
    const v = obj[k];
    if (typeof v === "number" && isFinite(v)) return v;
  }
  return 0;
}

/**
 * Получить изменение чистых позиций (лонг/шорт) за последние 4 свечи 30m.
 * Fail-open: null при любой ошибке.
 */
export async function getNetPosition(
  bingxSymbol: string,
): Promise<NetPositionResult | null> {
  const cached = _cache.get(bingxSymbol);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.data;

  const apiKey = getNextCgKey();
  if (!apiKey) return null;

  const base = bingxSymbol.replace("-USDT", "");

  try {
    const url = new URL(
      "https://open-api-v4.coinglass.com/api/futures/net-position-v2",
    );
    url.searchParams.set("symbol", base);
    url.searchParams.set("exchange", "Binance");
    url.searchParams.set("interval", "30m");
    url.searchParams.set("limit", "4");

    const res = await fetch(url.toString(), {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(6000),
    });

    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "net-position-v2", symbol: base });
      _cache.set(bingxSymbol, { data: null, ts: Date.now() });
      return null;
    }
    if (!res.ok) {
      _cache.set(bingxSymbol, { data: null, ts: Date.now() });
      return null;
    }

    const json = (await res.json()) as { code?: string; data?: NpCandle[] };
    if (
      json.code !== "0" ||
      !Array.isArray(json.data) ||
      json.data.length === 0
    ) {
      _cache.set(bingxSymbol, { data: null, ts: Date.now() });
      return null;
    }

    // Aggregate long/short change over returned candles
    let totalLongChange = 0,
      totalShortChange = 0;
    for (const c of json.data) {
      const lc = extractNum(
        c,
        "long_position_change",
        "longPositionChange",
        "long_change",
        "longChange",
        "long_delta",
        "longDelta",
      );
      const sc = extractNum(
        c,
        "short_position_change",
        "shortPositionChange",
        "short_change",
        "shortChange",
        "short_delta",
        "shortDelta",
      );
      totalLongChange += Math.abs(lc);
      totalShortChange += Math.abs(sc);
    }

    const totalChange = totalLongChange + totalShortChange;
    if (totalChange <= 0) {
      _cache.set(bingxSymbol, { data: null, ts: Date.now() });
      return null;
    }

    const result: NetPositionResult = {
      netShortChangePct: totalShortChange / totalChange,
      longChange: totalLongChange,
      shortChange: totalShortChange,
    };

    logger.debug(
      {
        symbol: bingxSymbol,
        netShortChangePct: result.netShortChangePct.toFixed(2),
        longChange: result.longChange.toFixed(0),
        shortChange: result.shortChange.toFixed(0),
      },
      "Net Position V2",
    );

    _cache.set(bingxSymbol, { data: result, ts: Date.now() });
    return result;
  } catch {
    return null;
  }
}
