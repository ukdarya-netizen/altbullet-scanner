import { logger } from "./logger.js";
import type { CgAskBidsResult } from "./coinglass_orderbook.js";
import type { OrderBookAnalysis } from "./bingx.js";
import { getFundingRate } from "./bingx.js";
import type { Signal } from "@workspace/db";
import { db, subscribersTable, settingsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  getAllWhaleAccumCandidates,
  getWhaleDataCoverage,
} from "./whaleTracker.js";
import { buildPositionsStatusText, POSITIONS_IMG } from "./positionsReport.js";
import { getPatternTgLabel } from "./pattern-labels.js";
import { tickerTag, patternTag } from "./watcher-formatters.js";
import { getLiqLevels, getMaxPain } from "./coinglass_liq_heatmap.js";
import { getWhaleIndexLine, getTokenWhaleIndex } from "./whale_index.js";
import { isWhaleStillHolding } from "./whale-position-state.js";
import {
  getPatternMaxStop,
  getPatternMinStop,
  getNoTouchStopMs,
  STOP_LOSS,
} from "./watcher-config.js";

const TELEGRAM_API = "https://api.telegram.org";

// ── Channel ID in-memory cache ────────────────────────────────────────────────
// Греется при старте, обновляется при изменении settings.channelId.
// Используется как fallback в getTargets() когда DB недоступна.
let _channelIdCache: string | null = null;

export function setChannelIdCache(id: string | null) {
  _channelIdCache = id?.trim() || null;
}

export async function warmChannelIdCache(): Promise<void> {
  try {
    const rows = await db
      .select({ channelId: settingsTable.channelId })
      .from(settingsTable)
      .limit(1);
    _channelIdCache = rows[0]?.channelId?.trim() || null;
    if (_channelIdCache)
      logger.info({ channelId: _channelIdCache }, "Channel ID cache warmed");
  } catch (err) {
    logger.warn({ err }, "warmChannelIdCache: DB недоступна — кэш не прогрет");
  }
}

// ── Картинки для паттернов (отправляются вместо текста при одиночном сигнале) ──
const _assetUrl = (name: string) =>
  new URL(`../assets/${name}`, import.meta.url).pathname;
/** In-memory кэш Telegram file_id для паттерн-картинок.
 *  После первой загрузки файла Telegram кэширует его по file_id —
 *  повторные отправки надёжнее и быстрее (не зависят от readFileSync). */
const _patternPhotoCache = new Map<string, string>();

export const PATTERN_SIGNAL_IMGS: Record<string, string> = {
  // ── OI / накопление ────────────────────────────────────────────────────────
  bullish_accumulation: _assetUrl("pattern_bullish_accum.png"),
  trend_accumulation: _assetUrl("pattern_trend_accum.png"),
  // ── Спот / объём ────────────────────────────────────────────────────────────
  spot_vol_accumulation: _assetUrl("pattern_spot_vol_accumulation.png"),
  whale_alert: _assetUrl("pattern_whale_alert.png"),
  liquidation_cascade: _assetUrl("pattern_liquidation_cascade.png"),
  demark: _assetUrl("pattern_demark.png"),
  "4h_pullback_continuation": _assetUrl("pattern_4h_pullback_continuation.png"),
  // ── Price-Led ───────────────────────────────────────────────────────────────
  price_led_momentum: _assetUrl("pattern_price_led_momentum.png"),
  balanced_grind: _assetUrl("pattern_balanced_grind.png"),
  // ── Stealth ─────────────────────────────────────────────────────────────────
  stealth_breakout: _assetUrl("pattern_stealth_breakout.png"),
};

export async function sendMessage(
  chatId: number | string,
  text: string,
): Promise<boolean> {
  if (process.env.NODE_ENV === "development") {
    logger.debug(
      { chatId, preview: text.slice(0, 80) },
      "DEV: Telegram suppressed",
    );
    return false;
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;

  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN not configured");
    return false;
  }

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: false,
      }),
    });
    if (!res.ok) {
      const err = await res.text();
      logger.warn({ err, chatId }, "Telegram send failed");
      if (res.status === 403) {
        await db
          .update(subscribersTable)
          .set({ active: false, unsubscribedAt: new Date() })
          .where(eq(subscribersTable.chatId, Number(chatId)));
      }
      return false;
    }
    return true;
  } catch (err) {
    logger.error({ err }, "Telegram send error");
    return false;
  }
}

export async function sendPhotoCaption(
  chatId: number | string,
  photoPath: string,
  caption: string,
): Promise<boolean> {
  if (process.env.NODE_ENV === "development") {
    logger.debug(
      { chatId, caption: caption.slice(0, 80) },
      "DEV: Telegram photo suppressed",
    );
    return false;
  }
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN not configured");
    return false;
  }
  try {
    const { readFileSync } = await import("fs");
    const { basename } = await import("path");
    const fileData = readFileSync(photoPath);
    const form = new FormData();
    form.append("chat_id", String(chatId));
    form.append("caption", caption.slice(0, 1024));
    form.append("parse_mode", "HTML");
    form.append(
      "photo",
      new Blob([fileData], { type: "image/png" }),
      basename(photoPath),
    );
    const res = await fetch(`${TELEGRAM_API}/bot${token}/sendPhoto`, {
      method: "POST",
      body: form,
    });
    if (!res.ok) {
      const errText = await res.text();
      logger.warn({ errText, chatId }, "Telegram sendPhoto failed");
      return false;
    }
    return true;
  } catch (err) {
    logger.error({ err }, "Telegram sendPhoto error");
    return false;
  }
}

export async function sendPhotoByFileId(
  chatId: number | string,
  fileId: string,
  caption: string,
): Promise<boolean> {
  if (process.env.NODE_ENV === "development") {
    logger.debug(
      { chatId, fileId, caption: caption.slice(0, 80) },
      "DEV: Telegram photo(fileId) suppressed",
    );
    return false;
  }
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN not configured");
    return false;
  }
  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/sendPhoto`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        photo: fileId,
        caption: _stripHtml(caption).slice(0, 1024),
      }),
    });
    if (!res.ok) {
      const errText = await res.text();
      logger.warn({ errText, chatId }, "Telegram sendPhoto(fileId) failed");
      return false;
    }
    return true;
  } catch (err) {
    logger.error({ err }, "Telegram sendPhoto(fileId) error");
    return false;
  }
}

export async function testConnection(): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return false;

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/getMe`);
    return res.ok;
  } catch {
    return false;
  }
}

export async function getBotInfo(): Promise<{
  username?: string;
  firstName?: string;
} | null> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return null;

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/getMe`);
    if (!res.ok) return null;
    const data = (await res.json()) as {
      ok: boolean;
      result: { username?: string; first_name?: string };
    };
    return {
      username: data.result.username,
      firstName: data.result.first_name,
    };
  } catch {
    return null;
  }
}

export async function answerCallbackQuery(
  callbackQueryId: string,
  text?: string,
): Promise<void> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return;
  try {
    await fetch(`${TELEGRAM_API}/bot${token}/answerCallbackQuery`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        callback_query_id: callbackQueryId,
        text: text ?? "",
      }),
    });
  } catch (err) {
    logger.error({ err }, "answerCallbackQuery error");
  }
}

export async function sendMessageWithKeyboard(
  chatId: number | string,
  text: string,
  inlineKeyboard: Array<
    Array<{ text: string; callback_data?: string; url?: string }>
  >,
): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN not configured");
    return false;
  }
  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: true,
        reply_markup: { inline_keyboard: inlineKeyboard },
      }),
    });
    if (!res.ok) {
      const err = await res.text();
      logger.warn({ err, chatId }, "Telegram sendMessageWithKeyboard failed");
      return false;
    }
    return true;
  } catch (err) {
    logger.error({ err }, "sendMessageWithKeyboard error");
    return false;
  }
}

const DIGEST_KEYBOARD = [
  [
    { text: "📅 Недельный", callback_data: "digest:weekly" },
    { text: "📆 Месячный", callback_data: "digest:monthly" },
  ],
  [{ text: "⚙️ Настройки", callback_data: "settings" }],
];

export async function registerBotCommands(): Promise<void> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return;
  const commands = [
    { command: "start", description: "Начать / Подписаться" },
    { command: "prices", description: "Цены на подписку" },
    { command: "menu", description: "Меню дайджестов" },
    { command: "status", description: "Текущие позиции" },
    { command: "whalewatch", description: "Whale Watch анализ" },
    { command: "myid", description: "Узнать свой Chat ID" },
    { command: "stop", description: "Отписаться" },
  ];
  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/setMyCommands`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ commands }),
    });
    const data = (await res.json()) as { ok: boolean; description?: string };
    if (data.ok) {
      logger.info("Bot commands registered with Telegram");
    } else {
      logger.warn(
        { description: data.description },
        "Failed to register bot commands",
      );
    }
  } catch (err) {
    logger.error({ err }, "Error registering bot commands");
  }
}

export async function setWebhook(webhookUrl: string): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return false;

  try {
    const res = await fetch(`${TELEGRAM_API}/bot${token}/setWebhook`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url: webhookUrl,
        allowed_updates: ["message", "callback_query"],
        drop_pending_updates: true,
      }),
    });
    const data = (await res.json()) as { ok: boolean; description?: string };
    if (!data.ok) {
      logger.warn({ description: data.description }, "Failed to set webhook");
      return false;
    }
    logger.info({ webhookUrl }, "Telegram webhook registered");
    return true;
  } catch (err) {
    logger.error({ err }, "Error setting webhook");
    return false;
  }
}

export interface AlphaResult {
  symbol: string;
  grade: "alpha" | "super_alpha";
  price: number;
  priceChange30m: number;
  currentVolume: number;
  avgVolume: number;
  volumeMultiplier: number;
  oiChangePercent: number;
  openInterest: number | null;
  cmcRank: number | null;
  cmcSource: string | null;
  cmcAvailable: boolean;
  liquidationsUsd: number | null;
  liquidationsMultiple: number | null;
  coinglassAvailable: boolean;
  globalOiChange?: number | null;
  globalOiConfirmed?: boolean;
  isExhaustedSqueeze?: boolean;
  isNewListing?: boolean;
  pumpFromOpen?: number | null;
  candleCount?: number;
  sentiment: string;
  sentimentKey: string;
  traderAction: string;
  alphaScore: number;
  isContinuing: boolean;
  cumulativeOiChange: number;
  tradingViewUrl: string;
  bingxUrl: string;
  /** Какой ТФ OI сработал: "30m", "1h" или комбинация */
  oiTriggerTf?: string;
  /** Значение 1h OI изменения */
  oiChange1h?: number | null;
  /** Значение 4h OI изменения */
  oiChange4h?: number | null;
  /** Значение 24h OI изменения */
  oiChange24h?: number | null;
  /** Проскальзывание цены с момента kline до fresh price (%) */
  klineSlippage?: number;
  /** Символ уже встречался в сигналах за последние 24ч */
  isRepeatSignal?: boolean;
  /** Фандинг рейт в процентах (напр. -0.04 = -0.04% за 8ч; источник: CoinGlass aggregate) */
  fundingRate?: number | null;
  /** Mark price (перп) */
  markPrice?: number | null;
  /** Index price (спотовый агрегат) */
  indexPrice?: number | null;
  /** Насколько цена уже выросла с момента обнаружения до момента выстрела (%) */
  priceConfirmPct?: number | null;
  /** Анализ стакана (CoinGlass/Binance): bidAskRatio, bias, scoreBonus */
  obImbalance?: CgAskBidsResult | null;
  /** MTF Spot CVD: 1h/4h таймфреймы не подтверждают — только скальп */
  isScalpOnly?: boolean;
  /** BingX spot market 24h volume (USDT) — ориентир для сравнения с futures */
  spotVol24h?: number | null;
  /** SpotCVD/спот-история gate note (для диагностики) */
  spotGateNote?: string | null;
  /** Market cap токена (CoinGecko, USD) — для расчёта % оборачиваемости */
  marketCapUsd?: number | null;
  // ── Индивидуальный стоп/тейки по Liquidation Heatmap (CoinGlass) ───────────
  /** Уровень стопа: кластер лонг-ликвидаций ниже входа − 2% (null = стандарт) */
  liqStopPrice?: number | null;
  /** Глубина стопа в % от входа (положительное число) */
  liqStopPct?: number | null;
  /** Источник стопа: heatmap кластер / паттерн-стоп / стандартный */
  liqStopSource?: "liq_heatmap" | "pattern" | "standard";
  /** Цели: кластеры шорт-ликвидаций выше входа (ближняя первой) */
  liqTakes?: { price: number; pctFromEntry: number; liqUsd: number }[] | null;
  /** Ближайший кластер лонг-ликвидаций ниже входа: % дистанция (отрицательное число, напр. -3.2) */
  liqClusterBelowPct?: number | null;
  /** USD объём ближайшего кластера лонг-ликвидаций ниже входа */
  liqClusterBelowUsd?: number | null;
  /** Предстоящий разлок токена (CoinGlass): daysUntil = дней до разлока, pctSupply = % supply */
  upcomingUnlock?: { daysUntil: number; pctSupply: number } | null;
  /** Свежий мувер: <3 циклов в прескане + цена уже ≥5% за 24ч на момент обнаружения.
   *  Статистика 30д: 43% отмен в этом сегменте (growth-leader анализ 2026-07-15). */
  freshMoverRisk?: { cycles: number; price24h: number } | null;
  /** Пер-токенный Whale Index (CoinGlass, Binance 4h) — обогащается в broadcastBatchAlert.
   *  null = данных нет (BingX-эксклюзив и т.п.), undefined = ещё не тянули. */
  tokenWhaleIndex?: number | null;
  /** Liquidation Max Pain (CoinGlass batch, 24h) — только для крупных монет.
   *  longPct/shortPct = % дистанция max-pain цены от входа. null = не покрыто. */
  maxPain?: {
    longPrice: number;
    shortPrice: number;
    longPct: number; // ((longMaxPainPrice - entry) / entry) * 100
    shortPct: number; // ((shortMaxPainPrice - entry) / entry) * 100
  } | null;
  /** Через какой OI Watch путь прошёл сигнал (A = price gate, B = vol/CVD gate).
   *  Undefined = прямой сигнал без OI Watch. Тег #path_a/#path_b в Telegram. */
  _oiWatchPath?: "A" | "B";
  /** BingX orderbook snapshot в момент выстрела сигнала (top-20 уровней).
   *  Снимается в trackSignal для всех паттернов. null = не удалось получить (fail-open). */
  entryOb?: OrderBookAnalysis | null;
  /** Краткая расшифровка Bullet Score для Telegram: OI/Vol/CVD/Taker/FR/ctx компоненты */
  scoreBreakdown?: string;
}

export function formatAlphaSignal(s: AlphaResult): string {
  // Метка скорости: сколько ждать движения (короткая фраза)
  const speedLabel = (() => {
    const key = s.sentimentKey;
    if (key === "bullish_accumulation" && s.oiTriggerTf === "4h_early")
      return `🕯 Движение за 4ч+`;
    if (key === "bullish_accumulation") return `🕯 Движение за 4ч+`;
    if (key === "trend_accumulation") return `⏳ Движение за 6–24ч`;
    return null;
  })();

  // Score breakdown line (под scoreLine): компактная расшифровка компонентов
  const breakdownLine = s.scoreBreakdown ? `↳ ${s.scoreBreakdown}` : "";

  // Funding rate (текущий, 8ч период) — BingX lastFundingRate × 100 → %.
  // Обогащается в broadcastBatchAlert для всех сигналов.
  // Пороги для текущей 8ч ставки (типичный нейтральный ≈ ±0.01%):
  //   ≤ -0.05%  шорты в ловушке | ≤ -0.01%  шорты платят | -0.01..+0.02%  нейтральный
  //   ≥ +0.02%  лонги платят    | ≥ +0.10%  лонги перегреты | ≥ +0.15%  экстремальный
  let fundingLine = "";
  if (s.fundingRate != null) {
    const fr = s.fundingRate;
    const frPct = fr.toFixed(3);
    const frSign = fr >= 0 ? "+" : "";
    let frLabel: string;
    if (fr <= -0.05) {
      frLabel = `💰 Фандинг (8ч): ${frSign}${frPct}% — шорты в ловушке, сквиз-давление`;
    } else if (fr <= -0.01) {
      frLabel = `💰 Фандинг (8ч): ${frSign}${frPct}% — шорты платят, позитивно`;
    } else if (fr >= 0.1) {
      frLabel = `⚠️ Фандинг (8ч): ${frSign}${frPct}% — лонги перегреты`;
    } else if (fr >= 0.02) {
      frLabel = `📈 Фандинг (8ч): ${frSign}${frPct}% — лонги платят`;
    } else {
      frLabel = `⚖️ Фандинг (8ч): ${frSign}${frPct}%`;
    }
    fundingLine = frLabel;
  }

  // Экстремальный фандинг — отдельная строка-предупреждение (≥ +0.15% за 8ч)
  let extremeFundingLine = "";
  if (s.fundingRate != null && s.fundingRate >= 0.15) {
    extremeFundingLine = `⚠️ <b>ВНИМАНИЕ: Экстремальный фандинг</b> — лонги критически перегреты, риск каскадных ликвидаций`;
  }

  // Scalp Only: спот CVD 1h/4h не подтверждён — риск разворота на старших ТФ
  const scalpOnlyLine = s.isScalpOnly
    ? `⚠️ <b>SCALP ONLY</b> — спот CVD 1h/4h не подтверждён, высокий риск разворота`
    : "";

  // Alpha Score bar: filled blocks out of 10
  const filled = Math.round(s.alphaScore);
  const scoreBar = "█".repeat(filled) + "░".repeat(10 - filled);
  const scoreLine = `🎯 <b>Bullet Score: ${s.alphaScore}/10</b>  <code>${scoreBar}</code>`;

  // Russian pattern names (полные описания для Telegram)
  const is4hEarly = s.oiTriggerTf === "4h_early";
  const patternRuName: Record<string, string> = {
    trend_accumulation: "📈🔥 Трендовое накопление — OI + цена движутся вместе",
    dip_accumulation: "💎 Накопление на дипе — умные деньги откупают падение",
    bullish_accumulation: is4hEarly
      ? "📊🕯 Накопление (4h Grind) — OI + цена, SpotCVD 4h за 4ч+"
      : "📊 Бычье накопление — OI + цена растут, стандартный паттерн",
    spot_vol_accumulation:
      "📊🌊 Спот объём накопление — спот-объём ≥2.5x, cvd1h подтверждён, прямой сигнал",
    whale_alert:
      "🐋🎯 Кит открыл лонг — Hyperliquid whale ≥$500K в лонге, рынок BingX подтвердил",
    liquidation_cascade:
      "💥🔄 Каскад ликвидаций → разворот — long-ликвидации выдохлись, OI стабилизировался",
    demark:
      "🕯 ДеМарк TD9 разворот — 9 последовательных баров истощения, сетап завершён, ждём отскок",
  };

  const _pEmoji = getPatternTgLabel(s.sentimentKey).split(" ")[0] ?? "🔹";
  const patternLine = `🏷 <b>Паттерн:</b> ${patternRuName[s.sentimentKey] ?? getPatternTgLabel(s.sentimentKey)}`;
  const continuingLine = s.isContinuing
    ? `📡 <i>Продолжает движение (OI ${s.cumulativeOiChange >= 0 ? "+" : ""}${s.cumulativeOiChange.toFixed(1)}% суммарно)</i>`
    : "";

  // Ценовое подтверждение — показываем насколько цена уже прошла до выстрела
  const confirmLine =
    s.priceConfirmPct != null && s.priceConfirmPct >= 1
      ? `✅ <b>Подтверждён:</b> цена уже +${s.priceConfirmPct.toFixed(1)}% с момента обнаружения`
      : "";

  // Повторный сигнал — символ уже был в сигналах за последние 24ч
  const repeatLine = s.isRepeatSignal
    ? `🔁 <i>Повторный сигнал за 24ч — тезис подтвердился снова, вход ещё актуален</i>`
    : "";

  // HighRisk warning — BingX Exclusive: нет кросс-биржевых данных

  // HighRisk warning — свежий мувер: токен без истории накопления, цена уже подросла.
  // Данные (30д): в этом сегменте 43% сигналов отменяются (пик <2% за 3ч), winrate ниже.
  // Growth-leader анализ: муверы без futures-подтверждения дампят в 46% при p24h 10-20%.
  const freshMoverLine = s.freshMoverRisk
    ? `⚠️ <b>HIGH RISK — Свежий мувер:</b> токен в прескане всего ${s.freshMoverRisk.cycles} ${s.freshMoverRisk.cycles === 1 ? "цикл" : s.freshMoverRisk.cycles >= 2 && s.freshMoverRisk.cycles <= 4 ? "цикла" : "циклов"} (нет истории накопления), а цена уже +${s.freshMoverRisk.price24h.toFixed(1)}% за 24ч. По статистике такие входы чаще пустые — уменьши размер или пропусти.`
    : "";

  // Exhaustion warning — SHORT_SQUEEZE с CoinGlass OI < -20%
  const exhaustionLine = s.isExhaustedSqueeze
    ? `⚠️ <b>ВНИМАНИЕ:</b> Global OI ${s.globalOiChange != null ? s.globalOiChange.toFixed(0) : ""}% — шорты уже выдавлены, вход может быть поздним`
    : "";

  // Slippage warning — цена успела уйти пока шёл CoinGlass batch
  const slippageLine =
    s.klineSlippage != null && Math.abs(s.klineSlippage) >= 5
      ? `⚠️ <b>ПОЗДНИЙ ВХОД:</b> цена ушла на ${s.klineSlippage >= 0 ? "+" : ""}${s.klineSlippage.toFixed(1)}% пока шёл анализ`
      : "";

  // ── Стоп лосс ────────────────────────────────────────────────────────────────
  // Источники стопа (liqStopSource):
  //   liq_heatmap — кластер лонг-ликвидаций (возможно клампирован до паттерн-лимита)
  //   pattern     — паттерн-стоп (heatmap недоступен, но у паттерна есть задокументированный стоп)
  //   standard    — глобальный STOP_LOSS (10%), у паттерна нет специального стопа
  const fmtPrice = (p: number) =>
    p < 1 ? p.toFixed(6) : p < 100 ? p.toFixed(4) : p.toFixed(2);
  const fmtUsdM = (v: number) =>
    v >= 1_000_000
      ? `$${(v / 1_000_000).toFixed(1)}M`
      : v >= 1_000
        ? `$${(v / 1_000).toFixed(0)}K`
        : `$${v.toFixed(0)}`;
  const hasLiqStop =
    s.liqStopPrice != null && s.liqStopPct != null && s.liqStopPct > 0;
  const _patternStopPct = getPatternMaxStop(s.sentimentKey);
  let stopLine: string;
  if (hasLiqStop) {
    const src = s.liqStopSource;
    const stopLabel =
      src === "pattern"
        ? `паттерн-стоп`
        : src === "liq_heatmap"
          ? `кластер ликвидаций`
          : `кластер ликвидаций`;
    const stopIcon = src === "pattern" ? "🛑" : "🛡";
    stopLine = `${stopIcon} <b>Стоп:</b> $${fmtPrice(s.liqStopPrice!)} (−${s.liqStopPct!.toFixed(1)}% — ${stopLabel})`;
  } else {
    stopLine = `🛑 <b>Стоп:</b> $${fmtPrice(s.price * (1 - _patternStopPct / 100))} (−${_patternStopPct}%)`;
  }
  const takesLine =
    s.liqTakes && s.liqTakes.length > 0
      ? `🎯 <b>Цели (heatmap):</b> ${s.liqTakes.map((t) => `$${fmtPrice(t.price)} (+${t.pctFromEntry.toFixed(1)}%)`).join(" → ")}`
      : "";

  // ── Ближайшие кластеры ликвидаций (дистанция от входа в %) ──────────────────
  // Ниже входа: liqClusterBelowPct < 0 (кластер лонгов — потенциальная поддержка/стоп)
  // Выше входа: liqTakes[0].pctFromEntry > 0 (кластер шортов — потенциальная цель)
  const _clBelow = s.liqClusterBelowPct ?? null;
  const _clAbove = s.liqTakes?.[0] ?? null;
  const _clParts: string[] = [];
  if (_clBelow != null) {
    const _usdStr =
      s.liqClusterBelowUsd != null && s.liqClusterBelowUsd > 0
        ? ` (${fmtUsdM(s.liqClusterBelowUsd)})`
        : "";
    _clParts.push(`▼ −${Math.abs(_clBelow).toFixed(1)}% лонги${_usdStr}`);
  }
  if (_clAbove != null) {
    const _usdStr = _clAbove.liqUsd > 0 ? ` (${fmtUsdM(_clAbove.liqUsd)})` : "";
    _clParts.push(`▲ +${_clAbove.pctFromEntry.toFixed(1)}% шорты${_usdStr}`);
  }
  const liqClustersLine =
    _clParts.length > 0
      ? `📍 <b>Кластеры ликв.:</b> ${_clParts.join(" | ")}`
      : "";

  // Max Pain (24h): показываем только когда данные есть (крупные монеты)
  let maxPainLine = "";
  if (s.maxPain) {
    const mp = s.maxPain;
    const fmtPct = (v: number) =>
      v >= 0 ? `+${v.toFixed(1)}%` : `${v.toFixed(1)}%`;
    // shortMaxPainPrice — куда рынок может упасть; longMaxPainPrice — куда вырасти
    const shortDir = mp.shortPct >= 0 ? "↑" : "↓";
    const longDir = mp.longPct >= 0 ? "↑" : "↓";
    maxPainLine = `🎭 <b>Max Pain (24h):</b> шорты ${shortDir}${fmtPct(mp.shortPct)} | лонги ${longDir}${fmtPct(mp.longPct)}`;
  }

  // No-touch period notice — стоп не срабатывает первые N часов после открытия
  const _noTouchH = getNoTouchStopMs(s.sentimentKey) / 3_600_000;
  const noTouchLine = `⏱ <i>Стоп неактивен первые ${_noTouchH}ч с момента сигнала</i>`;

  const entryBlock = [
    liqClustersLine,
    maxPainLine,
    stopLine,
    noTouchLine,
    takesLine,
  ]
    .filter(Boolean)
    .join("\n");

  const priceFormatted = fmtPrice(s.price);
  const cgBase = s.symbol.replace("-USDT", "");
  const cgLink = `https://www.coinglass.com/futures/${cgBase}`;
  const linksLine = `📊 <a href="${s.tradingViewUrl}">Chart</a>  |  📈 <a href="${s.bingxUrl}">BingX</a>  |  🔍 <a href="${cgLink}">OI (CoinGlass)</a>  |  💵 $${priceFormatted}`;
  const pathTag =
    s._oiWatchPath === "A"
      ? "#path_a"
      : s._oiWatchPath === "B"
        ? "#path_b"
        : null;
  const tagsLine = [tickerTag(s.symbol), patternTag(s.sentimentKey), pathTag]
    .filter(Boolean)
    .join(" ");

  // Whale Index (BTC, 4h) — рыночный контекст в каждом алерте; null = нет данных, строка пропускается
  // Для whale_alert: добавляем «🐋 держит» если кит ещё не закрыл позицию на Hyperliquid
  const _rawWhaleIndexLine = getWhaleIndexLine();
  const _hlHolding =
    s.sentimentKey === "whale_alert" && isWhaleStillHolding(s.symbol) === true;
  const whaleIndexLine =
    _rawWhaleIndexLine != null
      ? `${_rawWhaleIndexLine}${_hlHolding ? " | 🐋 держит" : ""}`
      : _hlHolding
        ? `🐋 держит позицию на Hyperliquid`
        : "";

  // ── Компактная строка метрик входа: WI · OB ─────────────────────────────────
  // Показываем значения в одной строке когда данные есть.
  // Отсутствующие значения опускаются — строка не показывается если все три null.
  const _compactParts: string[] = [];

  // WI (пер-токенный Whale Index, CoinGlass Binance 4h)
  if (s.tokenWhaleIndex != null) {
    const _wiSign = s.tokenWhaleIndex >= 0 ? "+" : "";
    const _wiMood =
      s.tokenWhaleIndex >= 10 ? "🟢" : s.tokenWhaleIndex <= -10 ? "🔴" : "⚪";
    _compactParts.push(
      `WI ${_wiSign}${s.tokenWhaleIndex.toFixed(0)}${_wiMood}`,
    );
  }

  // OB ratio (BingX стакан при детекте; CoinGlass если доступен)
  const _obData = s.obImbalance ?? s.entryOb;
  if (_obData != null && _obData.bidAskRatio > 0) {
    const _obEmoji =
      _obData.bidAskRatio >= 1.5
        ? "🟢"
        : _obData.bidAskRatio <= 0.7
          ? "🔴"
          : "⚪";
    _compactParts.push(`OB ${_obData.bidAskRatio.toFixed(2)}x${_obEmoji}`);
  }

  const compactMetricsLine =
    _compactParts.length > 0 ? `📊 ${_compactParts.join(" · ")}` : "";

  // Unlock warning — разлок токена в течение 4-7 дней
  const unlockLine =
    s.upcomingUnlock != null
      ? `⚠️ <b>Разлок через ${s.upcomingUnlock.daysUntil} дн:</b> ${s.upcomingUnlock.pctSupply.toFixed(1)}% supply — риск дампа после разлока`
      : "";

  return [
    patternLine,
    speedLabel,
    unlockLine,
    confirmLine,
    scalpOnlyLine,
    scoreLine,
    breakdownLine,
    ``,
    entryBlock,
    ``,
    whaleIndexLine,
    compactMetricsLine,
    fundingLine,
    extremeFundingLine,
    repeatLine,
    freshMoverLine,
    exhaustionLine,
    slippageLine,
    continuingLine,
    linksLine,
    ``,
    tagsLine,
  ]
    .filter((l) => l !== undefined && l !== null && l !== "")
    .join("\n");
}

// Cache: @username → numeric chat ID (resolved once via Telegram API, persists for process lifetime)
const _chatIdCache = new Map<string, number>();

async function resolveToNumericId(chatId: string): Promise<number | null> {
  const key = chatId.toLowerCase();
  if (_chatIdCache.has(key)) return _chatIdCache.get(key)!;
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return null;
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/getChat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId }),
    });
    if (!res.ok) return null;
    const data = (await res.json()) as { ok: boolean; result?: { id: number } };
    if (data.ok && data.result?.id) {
      _chatIdCache.set(key, data.result.id);
      return data.result.id;
    }
  } catch {
    /* ignore — fall back to string dedup */
  }
  return null;
}

export async function getTargets(): Promise<(number | string)[]> {
  const seenNumeric = new Set<number>();
  const seenString = new Set<string>();
  const targets: (number | string)[] = [];

  // Dedup by numeric ID when possible (prevents duplicate sends when TELEGRAM_CHAT_ID
  // is a numeric chat ID and settings.channelId is the same channel as @username)
  const addTarget = async (id: number | string) => {
    if (typeof id === "number") {
      if (!seenNumeric.has(id)) {
        seenNumeric.add(id);
        targets.push(id);
      }
    } else if (id.startsWith("@")) {
      const numId = await resolveToNumericId(id);
      if (numId !== null) {
        if (!seenNumeric.has(numId)) {
          seenNumeric.add(numId);
          targets.push(numId);
        }
      } else {
        const key = id.toLowerCase();
        if (!seenString.has(key)) {
          seenString.add(key);
          targets.push(id);
        }
      }
    } else {
      const key = id.toLowerCase();
      if (!seenString.has(key)) {
        seenString.add(key);
        targets.push(id);
      }
    }
  };

  // Always include TELEGRAM_CHAT_ID from env if it's a valid numeric ID or @channel
  const envId = process.env.TELEGRAM_CHAT_ID?.trim();
  if (envId) {
    const asNum = Number(envId);
    if (!isNaN(asNum) && asNum !== 0) await addTarget(asNum);
    else if (envId.startsWith("@")) await addTarget(envId);
    // else: bot username or invalid — skip silently
  }

  // Add active subscribers (non-critical — DB may be under load; TELEGRAM_CHAT_ID fallback above)
  try {
    const activeSubscribers = await db
      .select({ chatId: subscribersTable.chatId })
      .from(subscribersTable)
      .where(eq(subscribersTable.active, true));
    for (const s of activeSubscribers) await addTarget(s.chatId);
  } catch {
    // DB timeout/error — skip subscribers, env target already added
  }

  // Always add channelId from settings so the channel receives every message.
  // Primary: DB query; Fallback: in-memory cache (populated at startup, updated on settings change).
  let channelIdResolved: string | null = null;
  try {
    const rows = await db
      .select({ channelId: settingsTable.channelId })
      .from(settingsTable)
      .limit(1);
    channelIdResolved = rows[0]?.channelId?.trim() || null;
    if (channelIdResolved) _channelIdCache = channelIdResolved; // keep cache fresh
  } catch {
    channelIdResolved = _channelIdCache;
    if (channelIdResolved) {
      logger.warn(
        { channelId: channelIdResolved },
        "getTargets: DB недоступна — используем кэш channelId",
      );
    } else {
      logger.error(
        "getTargets: DB недоступна и кэш channelId пуст — канал пропущен",
      );
    }
  }
  if (channelIdResolved) await addTarget(channelIdResolved);

  return targets;
}

/** Убирает HTML-теги из строки — для безопасного обрезания caption до 1024 символов. */
function _stripHtml(s: string): string {
  return s.replace(/<[^>]*>/g, "");
}

/** Загружает паттерн-картинку через Telegram API и возвращает file_id для последующего кэширования.
 *  При ошибке возвращает null (вызывающий должен fallback на sendMessage). */
async function _uploadPatternPhoto(
  chatId: number | string,
  photoPath: string,
  caption: string,
): Promise<string | null> {
  if (process.env.NODE_ENV === "development") return null;
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) return null;
  try {
    const { readFileSync } = await import("fs");
    const { basename } = await import("path");
    const fileData = readFileSync(photoPath);
    const form = new FormData();
    form.append("chat_id", String(chatId));
    form.append("caption", _stripHtml(caption).slice(0, 1024));
    form.append(
      "photo",
      new Blob([fileData], { type: "image/png" }),
      basename(photoPath),
    );
    const res = await fetch(`${TELEGRAM_API}/bot${token}/sendPhoto`, {
      method: "POST",
      body: form,
    });
    if (!res.ok) {
      const errText = await res.text();
      logger.warn({ errText, chatId }, "Telegram sendPhoto failed");
      return null;
    }
    type TgPhotoResp = {
      ok: boolean;
      result?: { photo?: Array<{ file_id: string }> };
    };
    const data = (await res.json()) as TgPhotoResp;
    return data.result?.photo?.at(-1)?.file_id ?? null;
  } catch (err) {
    logger.error({ err }, "Telegram sendPhoto error");
    return null;
  }
}

export async function broadcastBatchAlert(
  signals: AlphaResult[],
): Promise<number> {
  if (signals.length === 0) return 0;

  const targets = await getTargets();
  if (targets.length === 0) {
    logger.warn("No Telegram targets to send to");
    return 0;
  }

  // ── Обогащение: персональный стоп/тейки по Liquidation Heatmap ────────────
  // trackSignal() уже вызвал getLiqLevels перед INSERT — результат в кэше (10 мин),
  // повторный вызов здесь бесплатный.
  // Логика: стоп клампируется паттерн-лимитом (getPatternMaxStop).
  // Если heatmap недоступен и у паттерна есть документированный стоп (<10%) — используем его.
  await Promise.all(
    signals.map(async (s) => {
      if (s.liqStopPrice !== undefined) return; // уже обогащён вызывающим кодом
      const patternMax = getPatternMaxStop(s.sentimentKey);
      const patternMin = getPatternMinStop(s.sentimentKey);
      try {
        const liq = await getLiqLevels(s.symbol, s.price);
        if (liq) {
          const clampedMax = liq.stopPct > patternMax;
          const clampedMin = patternMin > 0 && liq.stopPct < patternMin;
          const stopPct = clampedMax
            ? patternMax
            : clampedMin
              ? patternMin
              : liq.stopPct;
          const stopPrice =
            clampedMax || clampedMin
              ? s.price * (1 - stopPct / 100)
              : liq.stopPrice;
          s.liqStopPrice = stopPrice;
          s.liqStopPct = stopPct;
          s.liqStopSource =
            clampedMax || clampedMin ? "pattern" : "liq_heatmap";
          s.liqTakes = liq.takes.length > 0 ? liq.takes : null;
          s.liqClusterBelowPct = ((liq.clusterPrice - s.price) / s.price) * 100;
          s.liqClusterBelowUsd = liq.clusterLiqUsd;
        } else if (patternMax < STOP_LOSS) {
          // Heatmap недоступен, паттерн имеет документированный стоп строже 10%
          s.liqStopPrice =
            s.price > 0 ? s.price * (1 - patternMax / 100) : null;
          s.liqStopPct = patternMax;
          s.liqStopSource = "pattern";
          s.liqClusterBelowPct = null;
        } else {
          s.liqStopPrice = null;
          s.liqStopPct = null;
          s.liqStopSource = "standard";
          s.liqClusterBelowPct = null;
        }
      } catch {
        if (patternMax < STOP_LOSS) {
          s.liqStopPrice =
            s.price > 0 ? s.price * (1 - patternMax / 100) : null;
          s.liqStopPct = patternMax;
          s.liqStopSource = "pattern";
        } else {
          s.liqStopPrice = null;
          s.liqStopPct = null;
          s.liqStopSource = "standard";
        }
        s.liqClusterBelowPct = null;
      }
    }),
  );

  // ── Обогащение: пер-токенный Whale Index (CoinGlass, Binance 4h) ──────────
  // trackSignal() уже тянул его перед INSERT — результат в кэше (10 мин),
  // повторный вызов бесплатный. Fail-open: нет данных → строка не показывается.
  await Promise.all(
    signals.map(async (s) => {
      if (s.tokenWhaleIndex !== undefined) return; // уже обогащён вызывающим кодом
      try {
        s.tokenWhaleIndex = await getTokenWhaleIndex(s.symbol);
      } catch {
        s.tokenWhaleIndex = null;
      }
    }),
  );

  // ── Обогащение: Liquidation Max Pain (CoinGlass batch, 24h) ─────────────
  // Один батч-запрос на весь список → раскладываем по токенам.
  // Fail-open: null для большинства альтов (только крупные монеты покрыты).
  await Promise.all(
    signals.map(async (s) => {
      if (s.maxPain !== undefined) return;
      try {
        const mp = await getMaxPain(s.symbol);
        if (mp && s.price > 0) {
          s.maxPain = {
            longPrice: mp.longMaxPainPrice,
            shortPrice: mp.shortMaxPainPrice,
            longPct: ((mp.longMaxPainPrice - s.price) / s.price) * 100,
            shortPct: ((mp.shortMaxPainPrice - s.price) / s.price) * 100,
          };
        } else {
          s.maxPain = null;
        }
      } catch {
        s.maxPain = null;
      }
    }),
  );

  // ── Обогащение: текущий фандинг рейт (BingX, последний 8ч период) ────────
  // Перезаписываем для ВСЕХ сигналов — текущая ставка актуальнее 7d-накопленной.
  // BingX lastFundingRate — raw decimal (0.0001 = 0.01% за 8ч) → умножаем на 100 для %.
  // Fail-open: если BingX недоступен → fundingRate = null → строка не показывается.
  await Promise.all(
    signals.map(async (s) => {
      try {
        const fr = await getFundingRate(s.symbol);
        if (fr?.lastFundingRate != null) {
          const val = parseFloat(fr.lastFundingRate) * 100; // raw → %
          s.fundingRate = Number.isFinite(val) ? val : null;
        } else {
          s.fundingRate = null;
        }
      } catch {
        /* fail-open — фандинг не критичен */
        s.fundingRate = s.fundingRate ?? null;
      }
    }),
  );

  if (signals.length === 0) return 0;

  // Sort: SUPER ALPHA first, then ALPHA
  const sorted = [...signals].sort((a, b) => {
    if (a.grade === "super_alpha" && b.grade !== "super_alpha") return -1;
    if (b.grade === "super_alpha" && a.grade !== "super_alpha") return 1;
    return 0;
  });

  const superCount = sorted.filter((s) => s.grade === "super_alpha").length;
  const alphaCount = sorted.filter((s) => s.grade === "alpha").length;

  const headerParts: string[] = [];
  if (superCount > 0) headerParts.push(`${superCount} SUPER BULLET`);
  if (alphaCount > 0) headerParts.push(`${alphaCount} BULLET`);
  const getGradeHeader = (sig: AlphaResult) =>
    sig.grade === "super_alpha"
      ? `⚡️⚡️ <b>SUPER BULLET DETECTED: ${sig.symbol}</b>`
      : `⚡️ <b>BULLET DETECTED: ${sig.symbol}</b>`;

  const singleSym = sorted[0]!.symbol.replace("-USDT", "");
  const singleHeader =
    sorted[0]!.grade === "super_alpha"
      ? `🟣🔔🔔 <b>NEW SIGNAL — SUPER BULLET DETECTED</b>\n🪙 <b>${singleSym}</b>`
      : `🟣🔔 <b>NEW SIGNAL — BULLET DETECTED</b>\n🪙 <b>${singleSym}</b>`;

  const multiHeaderStr =
    superCount > 0 && alphaCount > 0
      ? `${superCount} SUPER BULLET + ${alphaCount} BULLET`
      : superCount > 0
        ? `${superCount} SUPER BULLET`
        : `${alphaCount} BULLET`;

  const text =
    signals.length === 1
      ? `${singleHeader}\n▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬\n\n` + formatAlphaSignal(sorted[0]!)
      : [
          `🟣🔔 <b>NEW SIGNALS — ${multiHeaderStr}</b>`,
          `▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬`,
          ``,
          sorted
            .map((s) => `${getGradeHeader(s)}\n${formatAlphaSignal(s)}`)
            .join("\n\n─────────────────────\n\n"),
        ].join("\n");

  logger.info(
    { count: signals.length, targets: targets.length },
    "Broadcasting alpha batch alert",
  );

  let totalSent = 0;
  for (const chatId of targets) {
    // Для одиночного сигнала с картинкой паттерна — отправляем фото
    const patternImg =
      signals.length === 1
        ? PATTERN_SIGNAL_IMGS[sorted[0]!.sentimentKey]
        : undefined;
    let _targetSent = false;
    if (patternImg) {
      // Сначала пробуем кэшированный file_id (надёжнее, не зависит от readFileSync)
      const _sentKey = sorted[0]!.sentimentKey;
      const _cachedFid = _patternPhotoCache.get(_sentKey);
      let _photoSent = false;
      if (_cachedFid) {
        _photoSent = await sendPhotoByFileId(chatId, _cachedFid, text);
        if (!_photoSent) _patternPhotoCache.delete(_sentKey); // file_id протух → сбрасываем
      }
      if (!_photoSent) {
        // Первая отправка или file_id протух — загружаем файл и кэшируем новый file_id
        const _newFid = await _uploadPatternPhoto(chatId, patternImg, text);
        if (_newFid) {
          _patternPhotoCache.set(_sentKey, _newFid);
          _photoSent = true;
        }
      }
      if (_photoSent) {
        _targetSent = true;
      } else {
        _targetSent = await sendMessage(chatId, text);
      }
    } else {
      _targetSent = await sendMessage(chatId, text);
    }
    if (_targetSent) totalSent++;
    else
      logger.warn(
        { chatId, symbols: signals.map((s) => s.symbol) },
        "broadcastBatchAlert: отправка провалилась для таргета",
      );
    await new Promise((r) => setTimeout(r, 50));
  }

  if (totalSent === 0 && targets.length > 0) {
    logger.error(
      { symbols: signals.map((s) => s.symbol), targets: targets.length },
      "broadcastBatchAlert: ВСЕ ОТПРАВКИ ПРОВАЛИЛИСЬ — TG сообщение не доставлено ни одному таргету",
    );
  }

  return totalSent;
}

/** Broadcast a raw pre-formatted text message to all configured Telegram targets */
export async function broadcastRawAlert(text: string): Promise<void> {
  const targets = await getTargets();
  if (targets.length === 0) {
    logger.warn("broadcastRawAlert: нет получателей");
    return;
  }
  for (const target of targets) {
    try {
      await sendMessage(target, text);
      await new Promise((r) => setTimeout(r, 50));
    } catch (err) {
      logger.error(
        { err, target },
        "broadcastRawAlert: не удалось отправить сообщение",
      );
    }
  }
}

// Single-signal broadcast wrapper
export async function broadcastSignalAlert(
  signal: Omit<Signal, "id">,
): Promise<void> {
  const data: AlphaResult = {
    symbol: signal.symbol,
    grade: (signal.type === "super_alpha" ? "super_alpha" : "alpha") as
      | "alpha"
      | "super_alpha",
    price: signal.price,
    priceChange30m: signal.priceChangePercent,
    currentVolume: signal.volume24h,
    avgVolume: signal.avgVolume,
    volumeMultiplier: signal.value,
    oiChangePercent: signal.oiChangePercent ?? 0,
    openInterest: signal.openInterest ?? 0,
    cmcRank: null,
    cmcSource: null,
    cmcAvailable: false,
    liquidationsUsd: null,
    liquidationsMultiple: null,
    coinglassAvailable: false,
    sentiment: (signal as any).sentiment ?? "Аномальная активность",
    sentimentKey: (signal as any).sentimentKey ?? "unknown",
    traderAction: "Наблюдение",
    alphaScore: (signal as any).alphaScore ?? 5,
    isContinuing: false,
    cumulativeOiChange: signal.oiChangePercent ?? 0,
    tradingViewUrl: signal.tradingViewUrl,
    bingxUrl: `https://bingx.com/en/trade/${signal.symbol.replace("-", "")}/`,
  };
  await broadcastBatchAlert([data]);
}

// ── Whale Accumulation Signal ──────────────────────────────────────────────────

// ── Whale Watch 2.0 ───────────────────────────────────────────────────────────

export interface WhaleWatchV2Entry {
  symbol: string;
  accumulatedCvdUsd: number;
  accumPeriods: number;
  avgBuyPrice: number | null;
  marketCapUsd: number | null;
  accumPct: number | null;
  priceAtEntry: number | null;
  lastPrice: number | null;
  firstSeenAt: Date;
  status: string;
}

export function formatWhaleWatchV2Alert(entries: WhaleWatchV2Entry[]): string {
  const lines: string[] = [
    `🟣👁 <b>WATCHLIST — Spot CVD накопление</b>`,
    ``,
    `Токены с устойчивым спотовым выкупом при плоской цене:`,
    ``,
  ];

  const top = entries.slice(0, 10);
  for (const e of top) {
    const coin = e.symbol.replace("-USDT", "");
    const cvdStr =
      e.accumulatedCvdUsd >= 1_000_000
        ? `$${(e.accumulatedCvdUsd / 1_000_000).toFixed(1)}M`
        : `$${(e.accumulatedCvdUsd / 1_000).toFixed(0)}K`;
    const accumPctStr =
      e.accumPct != null ? ` (${e.accumPct.toFixed(2)}% mcap)` : "";
    const priceStr =
      e.lastPrice && e.priceAtEntry
        ? ` | цена ${e.lastPrice >= e.priceAtEntry ? "+" : ""}${(((e.lastPrice - e.priceAtEntry) / e.priceAtEntry) * 100).toFixed(1)}%`
        : "";
    const statusEmoji = e.status === "breakout" ? "🚀" : "🔵";
    const periodsStr =
      e.accumPeriods > 0 ? ` | ${e.accumPeriods} периодов` : "";
    lines.push(
      `${statusEmoji} <b>${coin}</b> — CVD: <b>${cvdStr}${accumPctStr}</b>${priceStr}${periodsStr}`,
    );
  }

  if (entries.length > 10)
    lines.push(``, `...и ещё ${entries.length - 10} токенов`);

  lines.push(
    ``,
    `⚡️ Это наблюдение, не сигнал входа. При пробое — обычный NEW SIGNAL.`,
    `#whale_watch`,
  );
  return lines.join("\n");
}

/** Одиночный breakout alert для Whale Watch 2.0 */
export function formatWhaleBreakoutAlert(e: WhaleWatchV2Entry): string {
  const coin = e.symbol.replace("-USDT", "");
  const cvdStr =
    e.accumulatedCvdUsd >= 1_000_000
      ? `$${(e.accumulatedCvdUsd / 1_000_000).toFixed(1)}M`
      : `$${(e.accumulatedCvdUsd / 1_000).toFixed(0)}K`;
  const accumPctStr =
    e.accumPct != null ? ` (${e.accumPct.toFixed(2)}% от mcap)` : "";
  const priceFromEntry =
    e.lastPrice && e.priceAtEntry
      ? (((e.lastPrice - e.priceAtEntry) / e.priceAtEntry) * 100).toFixed(1)
      : null;
  const avgBuyStr = e.avgBuyPrice
    ? `\n💰 <b>Avg whale buy:</b> ${e.avgBuyPrice.toPrecision(4)}`
    : "";

  return [
    `🟣🔔 <b>NEW SIGNAL — BULLET DETECTED</b>`,
    `▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬`,
    ``,
    `${coin}/USDT`,
    `🏷 ${getPatternTgLabel("whale_watch")} — накопление подтверждено движением цены`,
    ``,
    `📊 <b>Накоплено CVD:</b> ${cvdStr}${accumPctStr}`,
    `🕐 <b>Периодов накопления:</b> ${e.accumPeriods}`,
    avgBuyStr,
    priceFromEntry ? `📈 <b>Рост от входа:</b> +${priceFromEntry}%` : ``,
    ``,
    `📊 <a href="https://www.tradingview.com/chart/?symbol=BYBIT:${coin}USDT.P">TradingView</a>`,
    ``,
    `${tickerTag(e.symbol)} ${patternTag("whale_watch")}`,
  ]
    .filter(Boolean)
    .join("\n");
}

/** @deprecated Whale Watch 2.0 broadcast engine removed as dead code (2026-07-10) — no-op */
export async function broadcastWhaleAccumAlert(
  _signals: unknown[],
): Promise<void> {
  // kept for backward compat — no-op
}

// ── Тексты бота ──────────────────────────────────────────────────────────────

const WELCOME_TEXT = [
  `🚀 <b>AltBullet — Твой радар в океане крипты</b>`,
  ``,
  `Хватит заходить в монеты, когда они уже «улетели». AltBullet находит следы крупных игроков (Whales) ДО начала основного движения.`,
  ``,
  `<b>Что ты получаешь внутри:</b>`,
  ``,
  `✅ <b>Whale Watch:</b> Уникальный алгоритм, который видит скрытое накопление китов на споте в течение дней и недель.`,
  `✅ <b>10 торговых паттернов:</b> От Short Squeeze до импульсных пробоев — бот классифицирует каждое движение.`,
  `✅ <b>Анализ реальных денег:</b> Мы смотрим не только на график, но и на Spot CVD, открытый интерес (OI) и ликвидации.`,
  `✅ <b>Умное сопровождение:</b> Бот сам ведет сделку, уведомляет о целях и дает сигнал на выход (Smart Cancel), если кит начал разгружаться.`,
  ``,
  `💎 <b>Доступ ограничен</b>`,
  `Бот работает в закрытом режиме для сохранения эффективности сигналов.`,
  ``,
  `Стань тем, кто покупает у китов, а не об кого они закрываются. Удачной охоты! 🐋🚀`,
].join("\n");

const PAYMENT_KEYBOARD = [
  [{ text: "💳 Оформить подписку", callback_data: "payment_pending" }],
  [{ text: "✍️ Написать админу", url: "https://t.me/darshakl" }],
];

const PRICES_TEXT = [
  `💎 <b>AltBullet — Тарифы</b>`,
  ``,
  `🗓 <b>1 месяц</b> — <b>10 000 ₽</b>`,
  `📅 <b>3 месяца</b> — <b>25 000 ₽</b> <i>(экономия 5 000 ₽)</i>`,
  `🏆 <b>1 год</b> — <b>100 000 ₽</b> <i>(экономия 20 000 ₽)</i>`,
  ``,
  `<b>Что входит во все тарифы:</b>`,
  `• Сигналы 24/7 по 500+ фьючерсным парам`,
  `• 10 паттернов: Short Squeeze, Hidden Accumulation, Breakout и др.`,
  `• 🐋 Whale Watch — скрытое накопление китов`,
  `• Smart Cancel — автоматический выход до стопа`,
  `• Ежедневные + еженедельные отчёты`,
  ``,
  `Для оплаты или вопросов — напиши админу 👇`,
].join("\n");

const ALREADY_SUBSCRIBED_TEXT = [
  `✅ <b>У тебя уже есть доступ!</b>`,
  ``,
  `Сигналы приходят автоматически. Используй /menu для дайджеста.`,
].join("\n");

const ACTIVATION_TEXT = [
  `✅ <b>Оплата получена — доступ открыт!</b>`,
  ``,
  `🚀 <b>AltBullet: Полное руководство для подписчиков</b>`,
  ``,
  `Добро пожаловать в AltBullet — профессиональный инструмент для поиска аномальной активности на крипторынке. Этот бот анализирует тысячи данных в секунду, чтобы найти следы «умных денег» (Whales) до того, как монета улетит в космос.`,
  ``,
  `🔍 <b>1. Список паттернов: Что они значат?</b>`,
  ``,
  `🔴 <b>Short Squeeze</b> — Шортисты набились, цена пошла против. Ликвидации толкают цену вверх. Скальп-лонг.`,
  `🟡 <b>Hidden Accumulation</b> — Кит тихо выкупает лимитками, OI растет, цена стоит. Мощное движение через 6–24ч.`,
  `🟠 <b>Bear Trap</b> — Цена падает, заманивая шортов, киты выкупают. Резкий разворот вверх.`,
  `🔥 <b>Aggressive Breakout</b> — Агрессивные покупатели, объём и цена растут одновременно. Вход по рынку.`,
  `🟢 <b>Bullish Accumulation</b> — Устойчивый рост, подтверждённый набором позиций. Удержание по тренду.`,
  `⚡ <b>Sharp Impulse</b> — Взрывная свеча на огромном объёме. Быстрый вход, короткий стоп.`,
  `🐋 <b>Whale Watch</b> — Серия крупных покупок на споте за дни/недели. Инвестиционный лонг.`,
  ``,
  `🛠 <b>2. Как торговать сигналы?</b>`,
  ``,
  `<b>Вход:</b> Никогда не заходите на всю котлету по рынку. Сетка: 30% по текущей / 40% чуть ниже / 30% у стопа.`,
  ``,
  `<b>Сопровождение — бот делает автоматически:</b>`,
  `1. <b>+5-10%</b> → предложит зафиксировать часть и перенести стоп в БУ`,
  `2. <b>+15%</b> → активируется трейлинг-стоп`,
  `3. <b>Smart Cancel</b> → если кит начал разгружаться — сигнал на выход до стопа`,
  ``,
  `📊 <b>3. Ежедневные отчёты (11:00 МСК)</b>`,
  `Sentiment рынка · Top Gainers · Open Positions`,
  ``,
  `<b>Хэштеги для поиска:</b> #in_run · #moonshot · #BTC · #ETH`,
  ``,
  `💡 <b>Важно:</b> Фиксируйте части прибыли на целях. Слушайте Smart Cancel — бот видит выход денег раньше вас. Whale Watch отрабатывает дольше, но приносит максимальный профит.`,
  ``,
  `AltBullet — твой радар в океане крипты. Удачной охоты! 🐋🚀`,
].join("\n");

// ── Вспомогательная функция активации подписчика ─────────────────────────────

export async function activateSubscriber(
  chatId: number,
  username: string | null,
  firstName: string | null,
  lastName: string | null,
): Promise<void> {
  await db
    .insert(subscribersTable)
    .values({
      chatId,
      username,
      firstName,
      lastName,
      active: true,
      subscribedAt: new Date(),
      unsubscribedAt: null,
    })
    .onConflictDoUpdate({
      target: subscribersTable.chatId,
      set: {
        active: true,
        username,
        firstName,
        lastName,
        unsubscribedAt: null,
      },
    });
}

// ── Webhook handler ───────────────────────────────────────────────────────────

export async function handleWebhookUpdate(update: unknown): Promise<void> {
  const upd = update as {
    message?: {
      chat: { id: number; username?: string };
      from?: {
        id: number;
        username?: string;
        first_name?: string;
        last_name?: string;
      };
      text?: string;
      caption?: string;
      photo?: { file_id: string; width: number; height: number }[];
    };
    channel_post?: {
      chat: { id: number; username?: string };
      from?: {
        id: number;
        username?: string;
        first_name?: string;
        last_name?: string;
      };
      text?: string;
      caption?: string;
      photo?: { file_id: string; width: number; height: number }[];
    };
  };

  const msg = upd.message ?? upd.channel_post;
  if (!msg) return;

  // chatId = куда отвечать (группа, канал или личка)
  const chatId = msg.chat.id;
  // userId = кто отправил (личный Telegram ID пользователя)
  // В личке from.id === chat.id, в группе/канале они разные
  const userId = msg.from?.id ?? msg.chat.id;
  const text = msg.text ?? "";
  const command = text.split("@")[0].toLowerCase();

  // Владелец бота: приоритет OWNER_CHAT_ID (личный Telegram ID),
  // если не задан — проверяем TELEGRAM_CHAT_ID (обычно ID канала, не личный).
  const ownerChatIdRaw =
    process.env.OWNER_CHAT_ID ?? process.env.TELEGRAM_CHAT_ID;
  const ownerChatIdParsed = ownerChatIdRaw ? Number(ownerChatIdRaw) : null;
  const ownerChatId =
    ownerChatIdParsed !== null && !isNaN(ownerChatIdParsed)
      ? ownerChatIdParsed
      : null;
  const isOwner = ownerChatId !== null && userId === ownerChatId;

  // Проверяем статус подписки по личному ID пользователя (не по ID чата/группы)
  const [sub] = await db
    .select()
    .from(subscribersTable)
    .where(eq(subscribersTable.chatId, userId))
    .limit(1);
  const isSubscriber = sub?.active === true;

  // ── Входящее фото от владельца → рассылаем всем подписчикам ─────────────────
  if (msg.photo && msg.photo.length > 0) {
    if (!isOwner) {
      return;
    }
    const largestPhoto = msg.photo[msg.photo.length - 1];
    const fileId = largestPhoto.file_id;
    const caption = msg.caption ?? "";
    logger.info(
      { fileId, caption: caption.slice(0, 80) },
      "Owner sent photo — broadcasting to subscribers",
    );
    const subscribers = await db
      .select({ chatId: subscribersTable.chatId })
      .from(subscribersTable)
      .where(eq(subscribersTable.active, true));
    let sent = 0;
    for (const s of subscribers) {
      const ok = await sendPhotoByFileId(s.chatId, fileId, caption);
      if (!ok) await sendMessage(s.chatId, caption);
      else sent++;
    }
    await sendMessage(
      chatId,
      `✅ Фото отправлено ${sent} подписчикам${caption ? ` с подписью: "${caption.slice(0, 60)}"` : ""}.`,
    );
    return;
  }

  // /myid — доступна всем, без проверки подписки (нужна для первичной настройки)
  if (command === "/myid") {
    await sendMessage(
      chatId,
      `🆔 Твой Telegram User ID: <code>${userId}</code>\n\nПередай его администратору для активации.`,
    );
    return;
  }

  if (command === "/start") {
    if (isSubscriber) {
      await sendMessage(chatId, ALREADY_SUBSCRIBED_TEXT);
    } else {
      await sendMessageWithKeyboard(chatId, WELCOME_TEXT, PAYMENT_KEYBOARD);
      logger.info(
        { chatId, username: msg.chat.username },
        "Shown welcome + pay screen",
      );
    }
    return;
  }

  if (command === "/prices" || command === "/pricing") {
    await sendMessageWithKeyboard(chatId, PRICES_TEXT, [
      [{ text: "✍️ Написать админу", url: "https://t.me/darshakl" }],
    ]);
    return;
  }

  // Тестовая команда для владельца: симулирует оплату
  if (command === "/activate_test" && isOwner) {
    await activateSubscriber(
      userId,
      msg.from?.username ?? null,
      msg.from?.first_name ?? null,
      msg.from?.last_name ?? null,
    );
    await sendMessageWithKeyboard(chatId, ACTIVATION_TEXT, DIGEST_KEYBOARD);
    logger.info({ userId }, "Owner test activation");
    return;
  }

  // /addsub <chat_id> [username] [firstname] — только для владельца
  if (command.startsWith("/addsub") && isOwner) {
    const parts = text.trim().split(/\s+/);
    const targetId = Number(parts[1]);
    if (!parts[1] || isNaN(targetId) || targetId === 0) {
      await sendMessage(
        chatId,
        `❌ Использование: /addsub &lt;chat_id&gt; [username] [firstname]\nПример: /addsub 7818695412 darshakl Darya`,
      );
      return;
    }
    const username = parts[2]?.replace(/^@/, "") ?? null;
    const firstName = parts[3] ?? null;
    await activateSubscriber(targetId, username, firstName, null);
    await sendMessage(
      chatId,
      `✅ Подписчик <code>${targetId}</code>${username ? ` (@${username})` : ""} добавлен в базу.`,
    );
    logger.info(
      { targetId, username, firstName, addedBy: userId },
      "Owner /addsub",
    );
    return;
  }

  // /removesub <chat_id> — только для владельца
  if (command.startsWith("/removesub") && isOwner) {
    const parts = text.trim().split(/\s+/);
    const targetId = Number(parts[1]);
    if (!parts[1] || isNaN(targetId) || targetId === 0) {
      await sendMessage(chatId, `❌ Использование: /removesub &lt;chat_id&gt;`);
      return;
    }
    await db
      .update(subscribersTable)
      .set({ active: false, unsubscribedAt: new Date() })
      .where(eq(subscribersTable.chatId, targetId));
    await sendMessage(
      chatId,
      `✅ Подписчик <code>${targetId}</code> деактивирован.`,
    );
    logger.info({ targetId, removedBy: userId }, "Owner /removesub");
    return;
  }

  // /listsubs — список активных подписчиков для владельца
  if (command === "/listsubs" && isOwner) {
    const subs = await db
      .select()
      .from(subscribersTable)
      .where(eq(subscribersTable.active, true));
    if (subs.length === 0) {
      await sendMessage(chatId, `📋 Активных подписчиков нет.`);
      return;
    }
    const lines = subs.map(
      (s) =>
        `• <code>${s.chatId}</code>${s.username ? ` @${s.username}` : ""}${s.firstName ? ` ${s.firstName}` : ""}`,
    );
    await sendMessage(
      chatId,
      `📋 <b>Активные подписчики (${subs.length}):</b>\n\n${lines.join("\n")}`,
    );
    return;
  }

  // Все остальные команды — только для подписчиков (и владельца)
  if (!isSubscriber && !isOwner) {
    await sendMessageWithKeyboard(chatId, WELCOME_TEXT, PAYMENT_KEYBOARD);
    return;
  }

  if (command === "/menu") {
    await sendMessageWithKeyboard(
      chatId,
      [
        `📋 <b>Меню дайджестов</b>`,
        ``,
        `Выбери период — получишь статистику прямо сейчас:`,
      ].join("\n"),
      DIGEST_KEYBOARD,
    );
  } else if (command === "/stop" || command === "/unsubscribe") {
    await db
      .update(subscribersTable)
      .set({ active: false, unsubscribedAt: new Date() })
      .where(eq(subscribersTable.chatId, userId));

    await sendMessage(
      chatId,
      `❌ <b>Unsubscribed.</b>\n\nYou will no longer receive signals.\nSend /start to subscribe again.`,
    );
    logger.info({ userId }, "Subscriber unsubscribed");
  } else if (command === "/status" || command === "/positions") {
    await sendMessage(chatId, `📊 Загружаю позиции...`);
    try {
      const text = await buildPositionsStatusText();
      const photoSent = await sendPhotoCaption(chatId, POSITIONS_IMG, "");
      if (!photoSent)
        logger.debug(
          { chatId },
          "positions command: photo not sent (dev mode or Telegram error)",
        );
      await sendMessage(chatId, text);
    } catch (err) {
      logger.error({ err }, "positions command error");
      await sendMessage(
        chatId,
        `❌ Ошибка при загрузке позиций. Попробуй позже.`,
      );
    }
  } else if (command === "/whalewatch") {
    await sendMessage(chatId, `🐋 Анализирую данные...`);
    try {
      const coverage = await getWhaleDataCoverage();
      const candidates = await getAllWhaleAccumCandidates();

      if (coverage.total === 0 || coverage.ready === 0) {
        await sendMessage(
          chatId,
          [
            `🐋 <b>Whale Watch — данных пока недостаточно</b>`,
            ``,
            `Система собирает снимки OI ежедневно.`,
            `Для анализа нужно минимум 14 дней данных.`,
            ``,
            `📊 Токенов с данными: <b>${coverage.total}</b>`,
            `✅ Готовы к анализу (14+ дней): <b>${coverage.ready}</b>`,
            coverage.oldestDate
              ? `📅 Самые ранние данные: <b>${coverage.oldestDate}</b>`
              : `📅 Данных пока нет`,
            ``,
            `Первые сигналы появятся через ~14 дней после запуска.`,
            `Каждую субботу в 10:00 МСК отправляется Whale Watch отчёт.`,
          ].join("\n"),
        );
        return;
      }

      if (candidates.length === 0) {
        await sendMessage(
          chatId,
          [
            `🐋 <b>Whale Watch — активных накоплений не найдено</b>`,
            ``,
            `📊 Токенов в базе: <b>${coverage.total}</b>`,
            `✅ Проанализировано (14+ дней): <b>${coverage.ready}</b>`,
            ``,
            `Нет токенов с устойчивым ростом OI при плоской цене.`,
            `Обновлённый отчёт — каждую субботу в 10:00 МСК.`,
          ].join("\n"),
        );
        return;
      }

      // Показываем топ-5 кандидатов
      const top5 = candidates.slice(0, 5);
      const lines: string[] = [
        `🐋 <b>Whale Watch — ${candidates.length} токенов в накоплении</b>`,
        ``,
      ];

      for (const c of top5) {
        const coin = c.symbol.replace("-USDT", "");
        const conf = c.confidence === "high" ? "🔴 HIGH" : "🟡 MED";
        const pStr =
          c.priceChangePct >= 0
            ? `+${c.priceChangePct.toFixed(1)}%`
            : `${c.priceChangePct.toFixed(1)}%`;
        lines.push(`${conf} <b>${coin}</b>`);
        lines.push(
          `  OI +${c.oiGrowthPct.toFixed(0)}% за ${c.daysTracked}д | цена ${pStr} | постоянство ${c.consistencyPct.toFixed(0)}%`,
        );
        lines.push(``);
      }

      if (candidates.length > 5) {
        lines.push(`...и ещё ${candidates.length - 5} токенов`);
        lines.push(``);
      }

      lines.push(`📊 Всего проанализировано: <b>${coverage.ready}</b> токенов`);
      lines.push(`🕒 Полный отчёт — каждую субботу в 10:00 МСК`);

      await sendMessage(chatId, lines.join("\n"));
    } catch (err) {
      logger.error({ err }, "whalewatch command error");
      await sendMessage(chatId, `❌ Ошибка при анализе. Попробуй позже.`);
    }
  }
}
