// ── Watcher constants ─────────────────────────────────────────────────────────

export const PARTIAL_TARGET = 5; // % частичная фиксация и перенос стопа в БУ
export const FIRST_TARGET = 10; // % первая цель: фиксируем часть, переставляем стоп в БУ
export const TRAILING_ACTIVATION_PCT = 15; // % от входа: активируем трейлинг
export const TRAILING_FIXED_PCT = 10; // % отступ трейлинга от пика (фиксированный)
export const STOP_LOSS = 10; // % стоп лосс от входа (только для active до первой цели)
export const CANCEL_STOP_LOSS_PCT = 5; // % порог: отмена с pnl ≤ -5% засчитывается как стоп лосс
export const ACCUMULATION_H = 24; // часов до статуса ACCUMULATION
export const ACCUMULATION_REENTRY_H = 12; // часов в статусе accumulation до проверки re-entry
export const ACCUM_REMINDER_H = 6; // ч: промежуточное напоминание в статусе accumulation
export const ACCUM_SCOUT_COOLDOWN_MS = 4 * 60 * 60 * 1000; // 4ч кулдаун между pre-breakout алертами
export const ACCUM_OI_COOLDOWN_MS = 2 * 60 * 60 * 1000; // 2ч кулдаун между OI-алертами
export const MAX_WATCH_DAYS = 4; // максимум наблюдения
export const RE_ENTRY_VOL_MULT = 3; // объём для RE-ENTRY
export const FAST_CYCLE_MS = 2 * 60 * 1000; // 2 мин — быстрый цикл для in_run

// Milestones для Moonshot уведомлений (%)
// +20, +25, +50, +100, затем каждые +50 до бесконечности — генерируем первые 20
export const MILESTONES = [
  20,
  25,
  30,
  50,
  55,
  60,
  65,
  70,
  75,
  80,
  85,
  90,
  95,
  ...Array.from({ length: 20 }, (_, i) => 100 + i * 50),
];

// ── Per-pattern exit profiles ─────────────────────────────────────────────────
// Whale-паттерны (whale_watch, whale_alert):
// анализ июнь-июль 2026 показал, что входы точные (profit 6 / stop 1), но выходы
// отдают прибыль: 9 сигналов с пиками +6.5..+14.2% закрылись в БУ (не дотянули
// до FIRST_TARGET=10 / TRAILING_ACTIVATION=15), KAITO/NMR с пиками +19-20%
// закрылись по 4д-таймауту. Профиль: цель ниже (8), трейлинг раньше (12) и
// плотнее (7). ЭКСПЕРИМЕНТ — оценка через 2-3 недели живой статистики.
export interface ExitProfile {
  firstTarget: number; // % первая цель (частичная фиксация, стоп в БУ)
  trailingActivation: number; // % от входа: активация трейлинга
  trailingGap: number; // % отступ трейлинга от пика
}

const DEFAULT_EXIT_PROFILE: ExitProfile = {
  firstTarget: FIRST_TARGET,
  trailingActivation: TRAILING_ACTIVATION_PCT,
  trailingGap: TRAILING_FIXED_PCT,
};

const WHALE_EXIT_PROFILE: ExitProfile = {
  firstTarget: 8,
  trailingActivation: 12,
  trailingGap: 7,
};

// Префикс "whale_" покрывает whale_watch и whale_alert. silent_whale НЕ попадает (другой префикс).
export function getExitProfile(
  sentimentKey: string | null | undefined,
): ExitProfile {
  if (sentimentKey && sentimentKey.startsWith("whale_"))
    return WHALE_EXIT_PROFILE;
  return DEFAULT_EXIT_PROFILE;
}

// ── Per-pattern max watch days ────────────────────────────────────────────────
// whale_alert: киты входят рано, движение приходит через 1-3 недели → 14д окно.
// Все остальные паттерны: стандартные 4 дня.
export function getMaxWatchDays(
  sentimentKey: string | null | undefined,
): number {
  if (sentimentKey === "whale_alert") return 14;
  // demark: TD9 сигналы быстро устаревают — если разворот не пришёл за 2 дня, тезис мёртв.
  if (sentimentKey === "demark") return 2;
  return MAX_WATCH_DAYS;
}

// ── Smart cancel minimum signal age ──────────────────────────────────────────
// Бэктест 90д: smart_cancel_oi_taker даёт 37.8% ошибочных отмен.
// Не проверяем smart cancel пока сигнал моложе 4ч — CVD может временно уходить
// в минус на обычной волатильности после входа.
export const SMART_CANCEL_MIN_AGE_MS = 4 * 60 * 60 * 1000; // 4 часа

// ── No-touch period for stop-loss ────────────────────────────────────────────
// Бэктест 90д: 67.8% стоп-лоссов были преждевременными — токен отскакивал >5%
// в течение 3д после выхода (avg пик +30%). Стоп не срабатывает в первые N часов.
// whale_alert: 4ч (волатильность выше, вход по киту требует времени).
// Остальные паттерны: 2ч.
export const NO_TOUCH_STOP_MS = 2 * 60 * 60 * 1000; // 2 часа (default)
const _WHALE_NO_TOUCH_STOP_MS = 4 * 60 * 60 * 1000; // 4 часа (whale паттерны)

/** Минимальный возраст сигнала (мс) перед тем как стоп-лосс может сработать. */
export function getNoTouchStopMs(
  sentimentKey: string | null | undefined,
): number {
  if (sentimentKey === "whale_alert") return _WHALE_NO_TOUCH_STOP_MS;
  // demark: разворот требует времени для подтверждения — 4ч no-touch как у whale.
  if (sentimentKey === "demark") return _WHALE_NO_TOUCH_STOP_MS;
  return NO_TOUCH_STOP_MS;
}

// ── Per-pattern max stop depth ────────────────────────────────────────────────
// Документированные стопы паттернов (справочник replit.md / scanner-patterns.ts).
// Введено 2026-07-15: анализ прода показал avgLoss −15.45% при avgProfit +10.29% —
// liq-heatmap стоп сохранялся БЕЗ ограничения глубины (кластер мог лежать на
// −13…−15%+), а паттерн-стопы −5…−8% существовали только в документации.
// Использование: (а) liq-стоп клампится сверху этим значением;
// (б) если liq heatmap недоступен — паттерн-стоп персистится напрямую.
// Паттерны, отсутствующие в карте, работают по глобальному STOP_LOSS (10%).
// НЕ ужесточать сверх документированного — память проекта: пере-ужесточение
// порогов уже убивало сигналы (trend_accumulation).
export const PATTERN_MAX_STOP: Record<string, number> = {
  spot_vol_accumulation: 5,
  stealth_breakout: 5,
  "4h_pullback_continuation": 6,
  price_led_momentum: 6,
  whale_alert: 8,
  // demark: TD Sequential Buy — ATR-based stop ≈ 2×ATR_1h, кап 8% (medium-high risk)
  demark: 8,
  liquidation_cascade: 10,
};

/** Максимальная глубина стопа для паттерна (положительное число, % от входа). */
export function getPatternMaxStop(
  sentimentKey: string | null | undefined,
): number {
  if (sentimentKey && PATTERN_MAX_STOP[sentimentKey] != null)
    return PATTERN_MAX_STOP[sentimentKey];
  return STOP_LOSS;
}

// ── Per-pattern min stop depth ────────────────────────────────────────────────
// Минимальная глубина стопа: кластер слишком близко к входу = стоп на шуме.
// Если liq-кластер мельче этого порога — стоп подтягивается до минимума.
// whale_alert: кластер на -1.5% + 2% отступа → стоп -3.4% — слишком жёстко для SOL.
export const PATTERN_MIN_STOP: Record<string, number> = {
  whale_alert: 4, // не ставить стоп ближе 4% от входа
};

/** Минимальная глубина стопа для паттерна (0 = без минимума). */
export function getPatternMinStop(
  sentimentKey: string | null | undefined,
): number {
  if (sentimentKey && PATTERN_MIN_STOP[sentimentKey] != null)
    return PATTERN_MIN_STOP[sentimentKey];
  return 0;
}

// ── Per-pattern bu_stop milestone ────────────────────────────────────────────
// bullish_accumulation: milestone повышен до 10% — анализ 9 исторических bu_stop
// показал 5/9 ошибочных отмен (BANK +216%, EPIC +30%, DEXE +8.9%, ALLO +8.5%,
// 0G +6.7% за 72ч после выхода). 45% BA-сигналов реально достигают ≥8%,
// 35% — ≥10% (17 из 49 закрытых). Направление требует проверки на новых данных.
// Все остальные паттерны: стандартные 5% (PARTIAL_TARGET).
export function getBuStopMilestone(
  sentimentKey: string | null | undefined,
): number {
  if (sentimentKey === "bullish_accumulation") return 10;
  return PARTIAL_TARGET;
}
