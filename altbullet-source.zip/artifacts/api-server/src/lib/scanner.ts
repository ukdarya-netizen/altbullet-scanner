import { logger } from "./logger.js";
import { saveDailyOiSnapshots } from "./whaleTracker.js";
import {
  getFutureTickers,
  getFutureTicker,
  getKlines,
  getOpenInterest,
  batchGetBingxDirectOI,
  testConnection as testBingX,
  type BingXTicker,
  type BingXKline,
} from "./bingx.js";
import { getCgAskBids } from "./coinglass_orderbook.js";
import { getCrossExchangeVolMult } from "./orderbook_external.js";
import {
  broadcastBatchAlert,
  broadcastRawAlert,
  testConnection as testTelegram,
} from "./telegram.js";
import { trackSignal, consumeObAtFire } from "./watcher.js";
import { getTrendingRank } from "./trending.js";
import { getLiquidations } from "./liquidations.js";
import {
  batchGetCoinglassOI,
  clearCoinglassOICache,
  CoinglassOutageError,
  getCgSupportedCoinsSet,
  CG_SYMBOL_ALIAS,
  type CoinglassOIResult,
} from "./coinglass_oi.js";
import { getCoinalyzeOI, getCoinalyzeOI24hCached } from "./coinalyze.js";
import {
  getTakerFlowCached,
  prefetchNetflowBatch,
  resetNetflowTelemetry,
  getNetflowTelemetry,
} from "./coinglass_taker.js";
import { snapshotCgTelemetry, type CgTelemetrySnapshot } from "./cg_latency.js";
import {
  getSpotCvdMtf,
  getCoinglassAggregateFunding,
} from "./coinglass_spot_cvd.js";
import { fetchMarketCap } from "./whale_watch_v2.js";
import { getTdAtrEntry } from "./ta-cache.js";
import { getSpotPoolEntry, triggerRefresh } from "./spotPool.js";
import { getSpotTakerFlow } from "./coinglass_spot_taker.js";
import { fetchLiqCoinList, fetchLiqOrders } from "./coinglass_liquidation.js";
import { getNetPosition } from "./coinglass_net_position.js";
import {
  getSpotVolume,
  getSpotVolumeExchangeData,
} from "./coinglass_spot_volume.js";
import { getFsVolume } from "./coinglass_fs_volume.js";
import { getUpcomingUnlocks } from "./coinglass_unlock.js";
import { getTokenWhaleIndex } from "./whale_index.js";
import { getSpotNetflowEntry } from "./spot-netflow-cache.js";
import {
  db,
  signalsTable,
  settingsTable,
  oiBaselinesTable,
  oiWatchTable,
  trackedSignalsTable,
  prescanTrackerTable,
  prescanHistoryTable,
  growthLeaderLogTable,
  patternDebugLogTable,
  marketCapCacheTable,
  scanRejectLogTable,
  overheatLogTable,
  type InsertSignal,
} from "@workspace/db";
import { dbWriteBestEffort, dbWriteStrict } from "./dbWriteFast.js";
import { gte, gt, lt, sql, eq, and, inArray, isNull, or } from "drizzle-orm";

// ── Concurrency helper ──────────────────────────────────────────────────────
// Runs fn on each item with at most `concurrency` items in-flight at once.
// Used for parallel pre-fetching of klines and SpotCVD before the scan loop.
async function runConcurrent<T>(
  items: T[],
  concurrency: number,
  fn: (item: T) => Promise<void>,
): Promise<void> {
  if (items.length === 0) return;
  const iter = items[Symbol.iterator]();
  await Promise.all(
    Array.from({ length: Math.min(concurrency, items.length) }, async () => {
      for (let step = iter.next(); !step.done; step = iter.next()) {
        await fn(step.value);
      }
    }),
  );
}

export interface ScannerState {
  running: boolean;
  lastScanAt: Date | null;
  nextScanAt: Date | null;
  marketsScanned: number;
  scanIntervalMs: number;
  bingxConnected: boolean;
  telegramConnected: boolean;
  /** Когда последний раз успешно вставили запись в oiWatchTable (любой путь) */
  oiWatchLastInsertAt: Date | null;
  /** Сколько INSERT'ов в oiWatchTable упало с исключением с момента старта сервера */
  oiWatchInsertErrors: number;
  /** Текст последнего пойманного исключения при INSERT в oiWatchTable */
  oiWatchLastInsertError: string | null;
  /** Сколько записей в oiWatchTable успешно создано в последнем скан-цикле */
  oiWatchInsertsLastScan: number;
  /** Сколько токенов получили cgTimeout/cgBuilding fallback в последнем скан-цикле */
  cgTimeoutsLastScan: number;
  /** true пока performScan выполняется */
  isScanning: boolean;
  /** Длительность последнего завершённого скана в мс */
  lastScanDurationMs: number | null;
  /** Телеметрия CoinGlass последнего завершённого скана (null до первого скана) */
  lastCgTelemetry: CgTelemetrySnapshot | null;
}

const state: ScannerState = {
  running: false,
  lastScanAt: null,
  nextScanAt: null,
  marketsScanned: 0,
  scanIntervalMs: 600_000,
  bingxConnected: false,
  telegramConnected: false,
  oiWatchLastInsertAt: null,
  oiWatchInsertErrors: 0,
  oiWatchLastInsertError: null,
  oiWatchInsertsLastScan: 0,
  cgTimeoutsLastScan: 0,
  isScanning: false,
  lastScanDurationMs: null,
  lastCgTelemetry: null,
};

/**
 * Персистентный кеш глобальных объёмов из CoinGlass (volUsd).
 * Накапливается между сканами — не сбрасывается.
 * Ключ: baseSymbol без USDT (например "DYDX"), значение: volUsd в USD.
 * После 1-го скана используется вместо BingX-объёма для пре-скрина Layer 2.
 */
const cgVolumeCache = new Map<string, number>();

// Whale Tracker: дневной снимок OI пишется 1 раз в сутки (UTC), не каждый скан-цикл —
// иначе saveDailyOiSnapshots() делает ~500 лишних SELECT на дубли каждые ~10 мин.
let lastOiSnapshotDate: string | null = null;

// ── Persistent Pre-screen Tracker ───────────────────────────────────────────
// Ловит Ghost Pump: токены которые стабильно держатся в топ-N prescan 2+ цикла
// без полноценного OI/vol сигнала — ранняя поимка на старте движения.
interface PrescanEntry {
  firstPrice24h: number; // price24h% при первом появлении в топ-N
  lastPrice24h: number; // актуальное price24h% (обновляется каждый цикл)
  firstSeenAt: number; // timestamp первого появления
  firstPrice: number; // цена при первом появлении (для расчёта реального движения)
  cycleCount: number; // сколько циклов подряд в топ-N
  bestRank: number; // лучший ранг в топ-N (1 = самый горячий)
  lastScore: number; // activity score последнего цикла (тренд)
  firstScore: number; // activity score первого цикла (база для тренда)
  lastPrice: number; // текущая цена (для алерта)
  lastFiredAt: number; // timestamp последнего алерта (кулдаун)
  lastCvdOk?: boolean; // последняя CVD проверка: cvdRising2 (2 цикла нетто-покупок)
  lastNetBuyPct?: number; // последний netBuyPct (%) из getCoinglassTakerFlow
  lastOi30m?: number | null; // OI 30m %
  lastOi1h?: number | null; // OI 1h %
  lastOi4h?: number | null; // OI 4h %
  lastOi24h?: number | null; // OI 24h %
  lastPrice1h?: number | null; // Изменение цены за последний 1ч (2×30m свечи назад)
  lastPrice3h?: number | null; // Изменение цены за последние 3ч (6×30m свечи назад)
  lastCvd30m?: boolean | null; // spot CVD 30m verdict
  lastCvd1h?: boolean | null; // spot CVD 1h TF verdict
  lastCvd4h?: boolean | null; // spot CVD 4h TF verdict
  lastVolMult?: number | null; // BingX 30m volume multiplier (curVol/avgVol)
  lastAvgVol?: number | null; // среднее BingX 30m candle volume в USDT (из klines, прошлый цикл)
  prevVolMult?: number | null; // volMult предыдущего цикла (для расчёта ускорения)
  firstOi30m?: number | null; // OI 30m % при первом попадании в prescan (entry snapshot)
  firstOi1h?: number | null; // OI 1h % при первом попадании в prescan
  firstOi4h?: number | null; // OI 4h % при первом попадании в prescan
  lastCgTimedOut?: boolean; // последний CG запрос упал по таймауту (≠ BingX Only)
  cgNoDataCount?: number; // сколько ПОДРЯД циклов CG вернул available=false+timedOut=false
  lastSkipReason?: string | null; // причина пропуска в последнем цикле: "no_pattern" | "late_pump" | null
  lastOiAt?: number | null; // timestamp последнего обновления OI данных (Date.now())
  prevOi30m?: number | null; // OI 30m % прошлого цикла (для расчёта ускорения)
  prevOi4h?: number | null; // OI 4h % прошлого цикла
  oiAccel30m?: number | null; // ускорение OI 30m: lastOi30m / prevOi30m (>1 = растёт)
  oi4hConsecGrowth?: number; // счётчик: сколько подряд циклов OI4h растёт
  // ── Межцикловые счётчики ────────────────────────────────────────────────────
  volAccelSpike?: boolean; // объём удвоился за цикл (lastVolMult/prevVolMult ≥ 2.0) + cycleCount ≥ 5
  cvdPositiveCycles?: number; // сколько циклов подряд CVD 30m положительный (сбрасывается при первом минусе)
  takerPositiveCycles?: number; // сколько циклов подряд taker netBuyPct > 0 (прокси: cvd30m === true)
  // ── Спот тейкер (только дашборд, не влияет на паттерны) ─────────────────────
  lastSpotTakerNetBuy?: number | null; // netBuyPct% последней 30m спот свечи
  lastSpotTakerDominance?: "buy" | "sell" | "neutral" | null;
  lastSpotTakerExchange?: "Binance" | "BingX" | null;
  // ── Спот объём 1h (CoinGlass pairs-markets, только дашборд) ──────────────────
  lastSpotVol1h?: number | null; // суммарный спот объём за 1h по всем биржам (USD)
  prevSpotVol1h?: number | null; // прошлый цикл
  lastSpotVol4h?: number | null; // суммарный спот объём за 4h
  lastSpotNetBuy1h?: number | null; // (buy-sell)/(buy+sell)*100 за 1h
  spotVolAvg1h?: number | null; // скользящее среднее 5 циклов (для вычисления mult)
  spotVolCycles?: number; // сколько циклов накоплено
  droppedFromPoolCycles?: number; // счётчик "льготных" циклов после выпадения из currentTopSymbols
  // (пока spotVolCycles < 2 — не удаляем сразу, см. SPOT_VOL_GRACE_CYCLES)
  bingxDirectOI?: number | null; // OI из /v2/quote/openInterest (для BingX-exclusive токенов)
  layers?: string[]; // prescan layers текущего цикла: WL/L1/L2/.../L8
  // ── Futures vs Spot Volume (CoinGlass futures_spot_volume_ratio, Binance+OKX+Bybit) ─
  futVolUsd24h?: number | null; // фьючерсный объём 24h USD
  spotVolUsd24h?: number | null; // спотовый объём 24h USD
  futSpotRatio?: number | null; // futVolUsd24h / spotVolUsd24h
  futVolPctMcap?: number | null; // futVolUsd24h / mcapUsd * 100
  spotVolPctMcap?: number | null; // spotVolUsd24h / mcapUsd * 100
  lastWhaleIndex?: number | null; // Whale Index по токену (CoinGlass, Binance futures); обновляется раз в цикл для OI Watch + топ prescan
}
const prescanTracker = new Map<string, PrescanEntry>();
// Содержит все символы BingX фьючерсов из последнего скан-цикла.
// Обновляется после getFutureTickers() — используется для различия
// "нет на BingX" vs "есть на BingX, но вне топ-N пресканера".
const bingxFuturesSymbols = new Set<string>();

// Coverage-фикс для spot_vol_* паттернов: runSpotVolBatch делает 1 проход за цикл,
// поэтому токену нужно минимум 2 цикла в пуле чтобы накопить spotVolCycles >= 2
// (порог паттернов spot_vol_accumulation/breakout). Раньше кандидат удалялся из
// prescanTracker в ТОТ ЖЕ цикл, когда выпадал из currentTopSymbols (Layer 1/3/4/5) —
// большинство токенов не доживало до 2-го спот-объёмного цикла. Даём 3 льготных
// цикла (~30-45 мин при типичном интервале скана) на "дожитие", после чего удаляем
// как раньше, если spotVolCycles так и не достиг 2.
const SPOT_VOL_GRACE_CYCLES = 3;

// Кэш quoteVolume для Layer 4: per-token EMA дельт между циклами.
// Структура: { prev — quoteVolume прошлого цикла; ema — бегущая EMA дельт или null (прогрев) }
// Холодный старт: 1-й цикл → prev=curVol, ema=null, gate не проверяется.
//                2-й цикл → ema=delta1, gate не проверяется (только инициализация).
//                3-й цикл+ → нормальный gate: delta > ema * 2.5 && delta > VOL_AWAKEN_MIN_DELTA_USD.
const prevQuoteVolCache = new Map<
  string,
  { prev: number; ema: number | null }
>();

// Минимальная абсолютная дельта объёма за цикл для L4 gate (USD).
// Защита от ложных пробуждений тихих токенов: у них EMA ≈ 0, и 2.5× от нуля → всё пройдёт.
// $50k delta/цикл ≈ базовый объём токена $288k+/день — нижняя граница осмысленного сигнала.
const _VOL_AWAKEN_MIN_DELTA_USD = 50_000;

// Layer 8: Steady Climbers — трекер устойчивого роста цены между циклами.
// Каждые ~10 минут обновляем lastPrice для ВСЕХ ~520 токенов.
// Если цена растёт на +0.8–8% подряд 3+ цикла → токен инжектируется в глубокий скан.
const steadyClimbMap = new Map<
  string,
  { growthCycles: number; lastPrice: number }
>();

// Постоянный кэш последних известных live-данных по символу.
// В отличие от prescanTracker, записи НИКОГДА не удаляются (только перезаписываются).
// Используется как fallback в getLiveMarketData для открытых позиций,
// чья монета уже "остыла" и выпала из топ-N prescan.
const lastKnownLiveData = new Map<
  string,
  {
    oi30m: number | null;
    oi1h: number | null;
    oi4h: number | null;
    oi24h: number | null;
    cvd30m: boolean | null;
    cvd1h: boolean | null;
    cvd4h: boolean | null;
    netBuyPct: number | null;
    price1h: number | null;
    spotTakerNetBuy: number | null;
    spotTakerDominance: string | null;
    whaleIndex: number | null;
    updatedAt: number;
  }
>();
// Throttle для "греется" алертов: символ → timestamp последней отправки
// const heatingAlertThrottle = new Map<string, number>(); // DISABLED: HeatingAlert отключён
// Фильтры: топ-10 + 3 цикла подряд (~30 мин) — только горячие токены с устойчивым присутствием
const _PERSIST_MIN_CYCLES = 3;
const _PERSIST_MIN_PRICE24H = 5.0; // % 24h изменение (стандартный ghost pump)
const _PERSIST_MAX_PRICE24H = 12.0; // % 24h cap — не стрелять если движение уже случилось
const _PERSIST_MAX_RANK = 30; // топ-30 (расширено с топ-10)
const _PERSIST_COOLDOWN_MS = 4 * 60 * 60 * 1000; // 4ч между алертами одного токена
// Ранний ghost pump: ловим накопление ДО старта движения
const _PERSIST_EARLY_MIN_CYCLES = 2; // 2 цикла (~20 мин) — раньше стандартного
const _PERSIST_EARLY_MAX_RANK = 10; // только топ-10 — самые горячие
const _PERSIST_EARLY_MAX_PRICE24H = 10.0; // цена ещё не двинулась сильно — накопление

// ── Whale Watch: Real-time accumulation stage tracker ───────────────────────
// Tracks short-term intraday whale buying stages per symbol.
// Signal fires after 3 stages in a 60-min rolling window → PATH A +1% in 60 min.
interface WhaleWatchStageEntry {
  ts: number;
  price: number;
  buyPct: number;
}
interface WhaleWatchPathARecord {
  detectedAt: number;
  priceAt3rd: number;
  expiresAt: number;
}
const whaleWatchStages = new Map<string, WhaleWatchStageEntry[]>();
const whaleWatchPathA = new Map<string, WhaleWatchPathARecord>();

// ── Cycle candidates snapshot ─────────────────────────────────────────────────
// Сохраняется после каждого цикла — для вкладки "Кандидаты цикла" в UI.
interface CycleCandidateEntry {
  symbol: string;
  layers: string[]; // ["L1", "L3"] — источники попадания в батч
  price24h: number;
  price: number;
  score: number;
  cycledAt: number; // unix ms
}
let lastCycleCandidates: CycleCandidateEntry[] = [];
let lastCycleAt: number | null = null;

export interface LayerDebugStats {
  exhaustedByTicker: number;
  l3CandidatesTotal: number;
  l3PassedToBatch: number;
  l4CandidatesTotal: number;
  l4PassedToBatch: number;
  l5CandidatesTotal: number;
  l5PassedToBatch: number;
  l8SteadyGrowthCycles: number;
  l8PassedToBatch: number;
  l8bOiLeadersTotal: number;
  l8bInsertedToWatch: number;
  l6cRescuedTotal: number;
  quietPrescanAdded: number;
  l10LiqCascadeAdded: number;
  l11WhaleAlertAdded: number;
  l15WhalePositionAdded: number;
  cycleNumber: number;
}
export let lastLayerDebug: LayerDebugStats = {
  exhaustedByTicker: 0,
  l3CandidatesTotal: 0,
  l3PassedToBatch: 0,
  l4CandidatesTotal: 0,
  l4PassedToBatch: 0,
  l5CandidatesTotal: 0,
  l5PassedToBatch: 0,
  l8SteadyGrowthCycles: 0,
  l8PassedToBatch: 0,
  l8bOiLeadersTotal: 0,
  l8bInsertedToWatch: 0,
  l6cRescuedTotal: 0,
  quietPrescanAdded: 0,
  l10LiqCascadeAdded: 0,
  l11WhaleAlertAdded: 0,
  l15WhalePositionAdded: 0,
  cycleNumber: 0,
};

export interface PatternDebugEntry {
  checked: number;
  passed: number;
  rejectedAt: Record<string, number>;
}
const _pdbNew = (): PatternDebugEntry => ({
  checked: 0,
  passed: 0,
  rejectedAt: {},
});
export function _pdbCheck(key: string) {
  const e = (lastPatternDebug[key] ??= _pdbNew());
  e.checked++;
}
export function _pdbPass(key: string) {
  const e = (lastPatternDebug[key] ??= _pdbNew());
  e.passed++;
}
export function _pdbReject(key: string, gate: string) {
  const e = (lastPatternDebug[key] ??= _pdbNew());
  e.rejectedAt[gate] = (e.rejectedAt[gate] ?? 0) + 1;
}
// Инициализирует запись в lastPatternDebug без инкремента счётчиков.
export function _pdbEnsure(key: string) {
  lastPatternDebug[key] ??= _pdbNew();
}

// ── Diagnostic-only: паттерн прошёл свой внутренний гейт (_pdbPass) — но
// _pdbPass не хранит символ, только агрегатный счётчик за цикл. Для редких
// паттернов (0-3 прохода за цикл) это делает невозможным трассировку "прошёл
// гейт → дошёл до сигнала ИЛИ потерян на cooldown/chronic-token/alphaScore
// ниже по пайплайну" (та же категория проблемы, что и spot_taker_lead —
// сигнал теряется НЕ на своём гейте, а на отдельном фильтре дальше).
// Пишем symbol + cycleNumber в pattern_debug_log (cvdDiag="passed_gate"),
// чтобы потом сверить с signals/tracked_signals по времени и символу.
// Не влияет на поведение — только диагностика. Best-effort, fire-and-forget.
// bulletScore/detKey are only known in loop2 (Phase 3, over `candidates`), while the
// gate-pass itself happens in loop1 (Phase 1, over `usdtTickers`) — see _passedGatePatternsMap
// which bridges the two loops per symbol (same convention as _spotCvdMapScan).
function diagPatternPassed(
  pattern: string,
  sym: string,
  bulletScore?: number | null,
  detKey?: string | null,
): void {
  // Строка добавляется в очередь _pendingDiagRows и сбрасывается одним bulk INSERT
  // в конце performScan (flushPendingDiagRows). Устраняет 100+ per-symbol inserts
  // mid-scan, конкурирующих с основными reads за Neon pool.
  _pendingDiagRows.push({
    pattern,
    cycleNumber: scanCycleCounter,
    checked: 0,
    passed: 0,
    rejectedAt:
      bulletScore !== undefined || detKey !== undefined
        ? JSON.stringify({
            bulletScore: bulletScore ?? null,
            detKey: detKey ?? null,
          })
        : null,
    symbol: sym,
    cvdDiag:
      bulletScore !== undefined || detKey !== undefined
        ? "passed_gate_scored"
        : "passed_gate",
  });
}

export let lastPatternDebug: Record<string, PatternDebugEntry> = {};
const lastCycleLayers = new Map<string, string[]>(); // symbol → prescan layers для текущего цикла

// ── Pending pattern_debug rows queue ─────────────────────────────────────────
// diagPatternPassed / diagCvdIfOiRejected накапливают строки сюда mid-scan.
// flushPendingDiagRows() сбрасывает одним bulk INSERT в конце цикла, после того
// как основные DB-reads скана завершились и пул освободился.
const _pendingDiagRows: Array<{
  pattern: string;
  cycleNumber: number;
  checked: number;
  passed: number;
  rejectedAt: string | null;
  symbol: string;
  cvdDiag: string | null;
}> = [];

async function flushPendingDiagRows(): Promise<void> {
  if (_pendingDiagRows.length === 0) return;
  const rows = _pendingDiagRows.splice(0); // drain atomically
  await dbWriteBestEffort(
    "flushDiagRows",
    () => db.insert(patternDebugLogTable).values(rows),
    {
      perAttemptTimeoutMs: 8000,
      retryDelayMs: 2000,
    },
  );
}

// ── Scan reject log — per-symbol per-pattern причины отклонения ───────────────
// Три уровня: (a) gate — ранние фильтры (exhaustedPump/deepNeg/cvdFail/contra/stalePump)
//             (b) inline pre-check — паттерн-специфичные условия до det
//             (c) no_match — прошёл все гейты, ни один паттерн не сработал
// Накапливается в _symRejLog весь цикл; persistSymRejectLog() вызывается в НАЧАЛЕ
// следующего цикла (вместе с persistPatternDebugSnapshot и flushPendingDiagRows).
let _symRejCycleAt = new Date(0);
const _symRejLog: Array<{
  cycleAt: Date;
  symbol: string;
  pattern: string;
  reason: string;
  oi30m: number | null;
  volMult: number | null;
  price24h: number | null;
  prescanCycles: number | null;
}> = [];

function _symRej(
  symbol: string,
  pattern: string,
  reason: string,
  oi30m: number | null,
  vol: number | null,
  price24h: number | null,
  cycles: number | null,
): void {
  _symRejLog.push({
    cycleAt: _symRejCycleAt,
    symbol,
    pattern,
    reason,
    oi30m,
    volMult: vol,
    price24h,
    prescanCycles: cycles,
  });
}

async function persistSymRejectLog(): Promise<void> {
  if (_symRejLog.length === 0) return;
  const rows = [..._symRejLog]; // copy first — splice ONLY after confirmed write
  try {
    // Promise.race с 8с таймаутом: голый await db.insert() зависает молча
    // когда Neon pool под нагрузкой в конце скана; try/catch не срабатывает
    // и данные остаются в _symRejLog вечно (memory leak).
    const insertPromise = db.insert(scanRejectLogTable).values(rows);
    const timeoutPromise = new Promise<never>((_, reject) =>
      setTimeout(
        () => reject(new Error("ScanRejectLog: insert timeout (8s)")),
        8000,
      ),
    );
    await Promise.race([insertPromise, timeoutPromise]);
    _symRejLog.splice(0, rows.length);
    // Cleanup: keep last 3 days to prevent unbounded growth
    void dbWriteBestEffort(
      "ScanRejectLog: cleanup",
      () =>
        db
          .delete(scanRejectLogTable)
          .where(
            lt(
              scanRejectLogTable.cycleAt,
              new Date(Date.now() - 3 * 24 * 3600_000),
            ),
          ),
      { attempts: 1 },
    );
  } catch (err) {
    logger.warn(
      { err, count: rows.length },
      "ScanRejectLog: write failed, keeping for next cycle",
    );
    if (_symRejLog.length > 30_000)
      _symRejLog.splice(0, _symRejLog.length - 15_000);
  }
}

// ── Persist pattern-debug snapshot before reset ────────────────────────────────
// lastPatternDebug раньше жил только в памяти и обнулялся каждый performScan()
// (~10 мин) — недельная статистика по отклонениям паттернов терялась. Пишем
// снапшот текущего цикла в pattern_debug_log перед сбросом (по аналогии с
// missed_signals_log). Best-effort: сбой записи не должен ломать цикл скана.
async function persistPatternDebugSnapshot(cycleNumber: number): Promise<void> {
  const entries = Object.entries(lastPatternDebug);
  if (entries.length === 0) return;
  const rows = entries.map(([pattern, e]) => ({
    pattern,
    cycleNumber,
    checked: e.checked,
    passed: e.passed,
    rejectedAt: JSON.stringify(e.rejectedAt),
  }));
  // dbWriteBestEffort: 8с таймаут + 2 попытки — защищает от silent hang.
  // Голый await db.insert() без таймаута зависает когда Neon pool под нагрузкой
  // в конце скана: try/catch никогда не срабатывает, данные теряются молча.
  await dbWriteBestEffort(
    "persistPatternDebugSnapshot",
    () => db.insert(patternDebugLogTable).values(rows),
    { perAttemptTimeoutMs: 8000, attempts: 2, retryDelayMs: 1000 },
  );
}

// ── In-memory OI Watch confirming fallback ────────────────────────────────────
// Используется когда DB INSERT для confirming-записей падает из-за connection timeout.
// Зеркалирует поля oi_watch таблицы необходимые для логики окна подтверждения.
// TTL: 90 минут — записи старше удаляются при каждом скане.
interface ConfirmingWatchEntry {
  symbol: string;
  triggerTf: string;
  oiChange: number;
  priceAtEntry: number;
  volumeMultiplier: number;
  sentimentKey: string | null;
  addedAt: Date;
  expiresAt: Date;
  avgVolume: number;
  oi30mChange: number | null;
  oi1hChange: number | null;
  oi24hChange: number | null;
}
const confirmingWatchMap = new Map<string, ConfirmingWatchEntry>();
const CONFIRMING_WATCH_TTL_MS = 90 * 60 * 1000; // 90 минут
// Volume Breakout Spot: независимый кулдаун (не связан с VB Futures lastFiredAt)
const _vbSpotLastFiredAt = new Map<string, number>();
// Demark TD9: кулдаун 4ч — td1h=9 может сохраняться несколько скан-циклов,
// не даём повторно стрелять пока не истекут 4ч.
const _demarkCooldown = new Map<string, number>();
const DEMARK_COOLDOWN_MS = 4 * 60 * 60 * 1000;

// Последняя известная цена для OI Watch символов — обновляется в confirming-цикле.
// Используется в getStatusSnapshot() как фолбэк когда символ выпал из prescanTracker.
// Только display: не влияет ни на какие gate-условия.
const oiWatchPriceCache = new Map<string, number>();

// market_cap_cache DB кэш (module-level, 5 мин TTL).
// Используется в getScannerCandidates как fallback для mcapUsd когда spotPool не заполнен.
// Не влияет ни на какие gate-условия — только для display Спот/MCap%.
let _mcapDbCache: Map<string, number | null> = new Map();
let _mcapDbCacheAt = 0;
const MCAP_DB_CACHE_TTL_MS = 5 * 60_000;

async function loadWhaleWatchStagesFromDb(): Promise<void> {
  try {
    const rows = await db
      .select({ json: settingsTable.whaleWatchStagesJson })
      .from(settingsTable)
      .limit(1);
    const json = rows[0]?.json;
    if (!json) return;
    const data = JSON.parse(json) as {
      stages: Record<string, WhaleWatchStageEntry[]>;
      pathA: Record<string, WhaleWatchPathARecord>;
    };
    const now = Date.now();
    for (const [sym, entries] of Object.entries(data.stages ?? {})) {
      const fresh = entries.filter((s) => now - s.ts < 60 * 60 * 1000);
      if (fresh.length > 0) whaleWatchStages.set(sym, fresh);
    }
    for (const [sym, entry] of Object.entries(data.pathA ?? {})) {
      if (entry.expiresAt > now) whaleWatchPathA.set(sym, entry);
    }
    if (whaleWatchStages.size > 0 || whaleWatchPathA.size > 0)
      logger.info(
        { symbols: whaleWatchStages.size, pathA: whaleWatchPathA.size },
        "🐋 Whale Watch stages restored from DB",
      );
  } catch (err) {
    logger.warn({ err }, "loadWhaleWatchStages: failed (non-critical)");
  }
}

export interface WhaleWatchStateStage {
  symbol: string;
  stageCount: number;
  latestBuyPct: number;
  firstStageAt: number;
  latestStageAt: number;
}
export interface WhaleWatchStatePathA {
  symbol: string;
  detectedAt: number;
  priceAt3rd: number;
  expiresAt: number;
}

/**
 * Определяет volStatusReason для OI Watch по данным спот CVD.
 * Значения: "confirmed" | "cvd_unavail" | "cvd_negative"
 */
function cgVolStatusReason(
  spotCvd: {
    available: boolean;
    cvd1h: boolean | null;
    cvd4h: boolean | null;
  } | null,
): string {
  if (!spotCvd?.available) return "cvd_unavail";
  if (spotCvd.cvd1h === false || spotCvd.cvd4h === false) return "cvd_negative";
  return "confirmed";
}

/** Возвращает текущее состояние real-time Whale Watch (этапы + PATH A очередь). */
export function getWhaleWatchState(): {
  stages: WhaleWatchStateStage[];
  pathA: WhaleWatchStatePathA[];
} {
  const now = Date.now();
  const stages: WhaleWatchStateStage[] = [];
  for (const [symbol, entries] of whaleWatchStages) {
    const fresh = entries.filter((s) => now - s.ts < 60 * 60 * 1000);
    if (fresh.length > 0) {
      stages.push({
        symbol,
        stageCount: fresh.length,
        latestBuyPct: fresh[fresh.length - 1].buyPct,
        firstStageAt: fresh[0].ts,
        latestStageAt: fresh[fresh.length - 1].ts,
      });
    }
  }
  stages.sort(
    (a, b) => b.stageCount - a.stageCount || b.latestStageAt - a.latestStageAt,
  );
  const pathA: WhaleWatchStatePathA[] = [];
  for (const [symbol, entry] of whaleWatchPathA) {
    pathA.push({ symbol, ...entry });
  }
  return { stages, pathA };
}

// ── In-memory state ─────────────────────────────────────────────────────────

/**
 * OI baseline — time-based.
 * Activity-score approach: the same "hot" tokens are scanned every 10 min,
 * so we can build baselines quickly and measure OI delta over ~20-60 min.
 */
interface OIBaseline {
  oi: number;
  takenAt: number;
}
const oiBaseline = new Map<string, OIBaseline>();
// Hot tokens are rescanned every 10 min — measure OI over a ~20-60 min window
const MIN_BASELINE_AGE_MS = 20 * 60 * 1000; // update baseline no more than once per 20 min
const MAX_BASELINE_AGE_MS = 60 * 60 * 1000; // baseline older than 60 min is too stale

/** Fetch fresh market price for a symbol at the moment of oiWatchTable insert.
 *  Prevents stale priceAtEntry caused by long scan loops (10-15 min lag). */
async function getFreshPrice(
  symbol: string,
  fallback: number,
): Promise<number> {
  try {
    const ticker = await getFutureTicker(symbol);
    if (ticker) {
      const p = parseFloat((ticker as any).lastPrice);
      if (p > 0) return p;
    }
  } catch {
    /* non-critical */
  }
  return fallback;
}

/** Load OI baselines from DB on startup so restarts don't cause blind spots */
async function loadBaselinesFromDb(): Promise<void> {
  try {
    const rows = await db.select().from(oiBaselinesTable);
    const cutoff = Date.now() - MAX_BASELINE_AGE_MS;
    let loaded = 0;
    for (const row of rows) {
      const takenAt = row.takenAt.getTime();
      if (takenAt >= cutoff) {
        oiBaseline.set(row.symbol, { oi: row.oi, takenAt });
        loaded++;
      }
    }
    logger.info({ loaded, total: rows.length }, "OI baselines loaded from DB");
  } catch (err) {
    logger.warn(
      { err },
      "Failed to load OI baselines from DB — starting fresh",
    );
  }
}

let _lastBaselinePersist = 0;
const BASELINE_PERSIST_INTERVAL_MS = 5 * 60 * 1000; // persist to DB every 5 min

/**
 * Периодическое обновление OI-baseline через прямой BingX-запрос.
 * Без этого oiBaseline никогда не пополняется после старта процесса —
 * BingX-фоллбэк (Level 1) всегда возвращает bingxDirectOIChange = null.
 * Обновляем не чаще MIN_BASELINE_AGE_MS на символ, иначе "изменение за 30 мин"
 * будет на самом деле посчитано от точки часовой давности — это уже не сигнал, а шум.
 */
async function refreshOiBaselines(symbols: string[]): Promise<number> {
  if (symbols.length === 0) return 0;
  try {
    const oiMap = await batchGetBingxDirectOI(symbols);
    const now = Date.now();
    let updated = 0;
    for (const [symbol, oi] of oiMap.entries()) {
      if (oi !== null && oi > 0) {
        oiBaseline.set(symbol, { oi, takenAt: now });
        updated++;
      }
    }
    if (updated > 0) {
      logger.info(
        { requested: symbols.length, updated },
        "OI baseline refresh: BingX прямой OI записан в baseline",
      );
    }
    return updated;
  } catch (err) {
    logger.warn({ err }, "Failed to refresh OI baselines from BingX");
    return 0;
  }
}

/** Persist changed baselines to DB (called after each scan) */
async function persistBaselinesToDb(): Promise<void> {
  const now = Date.now();
  if (now - _lastBaselinePersist < BASELINE_PERSIST_INTERVAL_MS) return;
  _lastBaselinePersist = now;
  const values = [...oiBaseline.entries()].map(([symbol, b]) => ({
    symbol,
    oi: b.oi,
    takenAt: new Date(b.takenAt),
  }));
  if (values.length === 0) return;
  // dbWriteBestEffort: Promise.race с таймаутом 8с — защищает от зависания
  // Neon на выполнении INSERT (connectionTimeoutMillis защищает только acquire,
  // но не выполнение запроса), что ранее убивало loop скана на часы.
  await dbWriteBestEffort(
    "persistBaselinesToDb",
    () =>
      db
        .insert(oiBaselinesTable)
        .values(values)
        .onConflictDoUpdate({
          target: oiBaselinesTable.symbol,
          set: { oi: sql`excluded.oi`, takenAt: sql`excluded.taken_at` },
        }),
    { perAttemptTimeoutMs: 8000, attempts: 1 },
  );
}

// ── Prescan Tracker persistence ───────────────────────────────────────────────

/** On startup: restore prescan entries from DB so cycleCount survives rebuilds.
 *  Entries older than 24h are ignored (stale, token likely cooled down).
 *  Retries once after a 12s delay if the first attempt throws (Neon pool timeout
 *  at startup permanently leaves the tracker empty otherwise). */
async function loadPrescanFromDb(): Promise<void> {
  async function attempt(): Promise<void> {
    const rows = await db.select().from(prescanTrackerTable);
    const cutoff = Date.now() - 72 * 60 * 60 * 1000; // 72h cutoff
    let loaded = 0;
    for (const row of rows) {
      const updatedAt = row.updatedAt.getTime();
      if (updatedAt < cutoff) continue; // skip stale entries
      prescanTracker.set(row.symbol, {
        firstPrice24h: row.firstPrice24h,
        lastPrice24h: row.lastPrice24h ?? row.firstPrice24h, // DB-персистированное значение; фолбэк на first при холодном старте
        firstSeenAt: row.firstSeenAt,
        firstPrice: row.firstPrice,
        cycleCount: row.cycleCount,
        bestRank: row.bestRank,
        lastScore: row.firstScore,
        firstScore: row.firstScore,
        lastPrice: row.lastPrice ?? row.firstPrice,
        lastFiredAt: row.lastFiredAt,
        lastOi30m: row.lastOi30m ?? undefined,
        lastOi1h: row.lastOi1h ?? undefined,
        lastOi4h: row.lastOi4h ?? undefined,
        lastOi24h: row.lastOi24h ?? undefined,
        lastPrice1h: row.lastPrice1h ?? undefined,
        prevOi30m: row.prevOi30m ?? undefined,
        prevOi4h: row.prevOi4h ?? undefined,
        cvdPositiveCycles: row.cvdPositiveCycles ?? undefined,
        takerPositiveCycles: row.takerPositiveCycles ?? undefined,
        oiAccel30m: row.oiAccel30m ?? undefined,
        oi4hConsecGrowth: row.oi4hConsecGrowth ?? undefined,
        spotVolCycles: row.spotVolCycles ?? undefined,
        lastSpotVol1h: row.lastSpotVol1h ?? undefined,
        prevSpotVol1h: row.prevSpotVol1h ?? undefined,
        lastSpotVol4h: row.lastSpotVol4h ?? undefined,
        lastSpotNetBuy1h: row.lastSpotNetBuy1h ?? undefined,
        spotVolAvg1h: row.spotVolAvg1h ?? undefined,
        layers: row.layers ?? [],
        futVolUsd24h: row.futVolUsd24h ?? undefined,
        spotVolUsd24h: row.spotVolUsd24h ?? undefined,
        futSpotRatio: row.futSpotRatio ?? undefined,
        futVolPctMcap: row.futVolPctMcap ?? undefined,
        spotVolPctMcap: row.spotVolPctMcap ?? undefined,
        firstOi30m: row.firstOi30m ?? undefined,
        firstOi1h: row.firstOi1h ?? undefined,
        firstOi4h: row.firstOi4h ?? undefined,
        lastWhaleIndex: row.lastWhaleIndex ?? undefined,
        lastNetBuyPct: row.lastNetBuyPct ?? undefined,
        lastSpotTakerNetBuy: row.lastSpotTakerNetBuy ?? undefined,
        lastSpotTakerDominance:
          (row.lastSpotTakerDominance as
            | "buy"
            | "sell"
            | "neutral"
            | undefined) ?? undefined,
        lastCvd30m: row.lastCvd30m ?? undefined,
        lastCvd1h: row.lastCvd1h ?? undefined,
        lastCvd4h: row.lastCvd4h ?? undefined,
      });
      loaded++;
    }
    logger.info(
      { loaded, total: rows.length },
      "Prescan tracker loaded from DB",
    );
  }

  try {
    await attempt();
  } catch (firstErr) {
    logger.warn(
      { err: firstErr },
      "Failed to load prescan tracker from DB — retrying in 12s",
    );
    await new Promise((resolve) => setTimeout(resolve, 12_000));
    try {
      await attempt();
    } catch (secondErr) {
      logger.warn(
        { err: secondErr },
        "Failed to load prescan tracker from DB after retry — starting fresh",
      );
    }
  }
}

/** Split-brain fix (autoscale deployment can run 1-N concurrent instances,
 *  each with its own in-memory prescanTracker Map — loadPrescanFromDb() only
 *  runs once at startup, so an instance that never personally fetched spot
 *  volume for a symbol keeps spotVolMult=null forever even though another
 *  instance's fetch is already sitting in the DB).
 *  Runs frequently (every 5 min) and adopts DB state ONLY when it's strictly
 *  ahead of what this instance has observed itself (dbCycles > localCycles) —
 *  never clobbers data this instance already fetched more recently. */
async function refreshSpotVolFromDb(): Promise<void> {
  const symbols = Array.from(prescanTracker.keys());
  if (symbols.length === 0) return;
  try {
    const rows = await db
      .select({
        symbol: prescanTrackerTable.symbol,
        spotVolCycles: prescanTrackerTable.spotVolCycles,
        spotVolAvg1h: prescanTrackerTable.spotVolAvg1h,
        lastSpotVol1h: prescanTrackerTable.lastSpotVol1h,
        prevSpotVol1h: prescanTrackerTable.prevSpotVol1h,
        lastSpotVol4h: prescanTrackerTable.lastSpotVol4h,
        lastSpotNetBuy1h: prescanTrackerTable.lastSpotNetBuy1h,
        futVolUsd24h: prescanTrackerTable.futVolUsd24h,
        spotVolUsd24h: prescanTrackerTable.spotVolUsd24h,
        futSpotRatio: prescanTrackerTable.futSpotRatio,
        futVolPctMcap: prescanTrackerTable.futVolPctMcap,
        spotVolPctMcap: prescanTrackerTable.spotVolPctMcap,
      })
      .from(prescanTrackerTable)
      .where(inArray(prescanTrackerTable.symbol, symbols));
    let adopted = 0;
    for (const row of rows) {
      const pe = prescanTracker.get(row.symbol);
      if (!pe) continue;
      const dbCycles = row.spotVolCycles ?? 0;
      const localCycles = pe.spotVolCycles ?? 0;
      if (
        dbCycles > localCycles &&
        row.spotVolAvg1h != null &&
        row.lastSpotVol1h != null
      ) {
        pe.spotVolCycles = dbCycles;
        pe.spotVolAvg1h = row.spotVolAvg1h;
        pe.lastSpotVol1h = row.lastSpotVol1h ?? pe.lastSpotVol1h;
        pe.prevSpotVol1h = row.prevSpotVol1h ?? pe.prevSpotVol1h;
        pe.lastSpotVol4h = row.lastSpotVol4h ?? pe.lastSpotVol4h;
        pe.lastSpotNetBuy1h = row.lastSpotNetBuy1h ?? pe.lastSpotNetBuy1h;
        adopted++;
      }
      // FS volume fields: always adopt latest non-null values regardless of cycleCount
      if (row.futVolUsd24h != null) pe.futVolUsd24h = row.futVolUsd24h;
      if (row.spotVolUsd24h != null) pe.spotVolUsd24h = row.spotVolUsd24h;
      if (row.futSpotRatio != null) pe.futSpotRatio = row.futSpotRatio;
      if (row.futVolPctMcap != null) pe.futVolPctMcap = row.futVolPctMcap;
      if (row.spotVolPctMcap != null) pe.spotVolPctMcap = row.spotVolPctMcap;
    }
    if (adopted > 0) {
      logger.info(
        { adopted, checked: symbols.length },
        "SpotVol DB resync: adopted fresher state from another instance",
      );
    }
  } catch (err) {
    logger.warn({ err }, "SpotVol DB resync failed");
  }
}

/** Persist current prescan tracker state to DB (upsert all active entries).
 *  Splits into batches of 15 rows to avoid Neon connection timeout on large INSERTs. */
/** cycleCount at which each symbol was last written to DB — skips unchanged rows */
const _prescanWrittenCycles = new Map<string, number>();

async function savePrescanToDb(): Promise<void> {
  try {
    const allEntries = Array.from(prescanTracker.entries());
    if (allEntries.length === 0) return;

    // Only UPSERT entries whose cycleCount advanced since last DB write.
    // Tokens not processed this cycle have unchanged cycleCount → skip.
    const entries = allEntries.filter(
      ([sym, e]) =>
        (e.cycleCount ?? 0) > (_prescanWrittenCycles.get(sym) ?? -1),
    );

    const skipped = allEntries.length - entries.length;
    if (skipped > 0) {
      logger.debug(
        { skipped, dirty: entries.length, total: allEntries.length },
        "savePrescanToDb: skipping unchanged rows",
      );
    }

    if (entries.length > 0) {
      const now = new Date();
      const values = entries.map(([symbol, e]) => ({
        symbol,
        cycleCount: e.cycleCount,
        firstSeenAt: e.firstSeenAt,
        bestRank: e.bestRank,
        firstPrice: e.firstPrice,
        firstPrice24h: e.firstPrice24h,
        firstScore: e.firstScore,
        lastFiredAt: e.lastFiredAt,
        updatedAt: now,
        lastPrice: e.lastPrice,
        lastOi30m: e.lastOi30m ?? null,
        lastOi1h: e.lastOi1h ?? null,
        lastOi4h: e.lastOi4h ?? null,
        lastOi24h: e.lastOi24h ?? null,
        lastPrice1h: e.lastPrice1h ?? null,
        prevOi30m: e.prevOi30m ?? null,
        prevOi4h: e.prevOi4h ?? null,
        cvdPositiveCycles: e.cvdPositiveCycles ?? null,
        takerPositiveCycles: e.takerPositiveCycles ?? null,
        oiAccel30m: e.oiAccel30m ?? null,
        oi4hConsecGrowth: e.oi4hConsecGrowth ?? null,
        lastSpotVol1h: e.lastSpotVol1h ?? null,
        prevSpotVol1h: e.prevSpotVol1h ?? null,
        lastSpotVol4h: e.lastSpotVol4h ?? null,
        lastSpotNetBuy1h: e.lastSpotNetBuy1h ?? null,
        spotVolAvg1h: e.spotVolAvg1h ?? null,
        spotVolCycles: e.spotVolCycles ?? 0,
        layers: e.layers ?? [],
        futVolUsd24h: e.futVolUsd24h ?? null,
        spotVolUsd24h: e.spotVolUsd24h ?? null,
        futSpotRatio: e.futSpotRatio ?? null,
        futVolPctMcap: e.futVolPctMcap ?? null,
        spotVolPctMcap: e.spotVolPctMcap ?? null,
        // first_oi_* — передаём текущие значения; COALESCE в conflict SET сохранит только первые
        firstOi30m: e.lastOi30m ?? null,
        firstOi1h: e.lastOi1h ?? null,
        firstOi4h: e.lastOi4h ?? null,
        lastWhaleIndex: e.lastWhaleIndex ?? null,
        lastPrice24h: e.lastPrice24h,
        lastNetBuyPct: e.lastNetBuyPct ?? null,
        lastSpotTakerNetBuy: e.lastSpotTakerNetBuy ?? null,
        lastSpotTakerDominance: e.lastSpotTakerDominance ?? null,
        lastCvd30m: e.lastCvd30m ?? null,
        lastCvd1h: e.lastCvd1h ?? null,
        lastCvd4h: e.lastCvd4h ?? null,
      }));

      const BATCH_SIZE = 15;
      for (let i = 0; i < values.length; i += BATCH_SIZE) {
        const batch = values.slice(i, i + BATCH_SIZE);
        await dbWriteBestEffort("prescanTracker/upsert-batch", () =>
          db
            .insert(prescanTrackerTable)
            .values(batch)
            .onConflictDoUpdate({
              target: prescanTrackerTable.symbol,
              set: {
                // GREATEST — защита от dual-process: worker после рестарта не обнуляет
                // счётчик другого процесса который уже накопил больший cycleCount.
                cycleCount: sql`GREATEST(${prescanTrackerTable.cycleCount}, excluded.cycle_count)`,
                bestRank: sql`excluded.best_rank`,
                lastFiredAt: sql`excluded.last_fired_at`,
                updatedAt: sql`excluded.updated_at`,
                lastPrice: sql`excluded.last_price`,
                lastOi30m: sql`excluded.last_oi_30m`,
                lastOi1h: sql`excluded.last_oi_1h`,
                lastOi4h: sql`excluded.last_oi_4h`,
                lastOi24h: sql`excluded.last_oi_24h`,
                lastPrice1h: sql`excluded.last_price_1h`,
                prevOi30m: sql`excluded.prev_oi_30m`,
                prevOi4h: sql`excluded.prev_oi_4h`,
                cvdPositiveCycles: sql`excluded.cvd_positive_cycles`,
                takerPositiveCycles: sql`excluded.taker_positive_cycles`,
                oiAccel30m: sql`excluded.oi_accel_30m`,
                oi4hConsecGrowth: sql`excluded.oi_4h_consec_growth`,
                lastSpotVol1h: sql`COALESCE(excluded.last_spot_vol_1h, ${prescanTrackerTable.lastSpotVol1h})`,
                prevSpotVol1h: sql`COALESCE(excluded.prev_spot_vol_1h, ${prescanTrackerTable.prevSpotVol1h})`,
                lastSpotVol4h: sql`COALESCE(excluded.last_spot_vol_4h, ${prescanTrackerTable.lastSpotVol4h})`,
                lastSpotNetBuy1h: sql`COALESCE(excluded.last_spot_net_buy_1h, ${prescanTrackerTable.lastSpotNetBuy1h})`,
                spotVolAvg1h: sql`COALESCE(excluded.spot_vol_avg_1h, ${prescanTrackerTable.spotVolAvg1h})`,
                spotVolCycles: sql`GREATEST(${prescanTrackerTable.spotVolCycles}, excluded.spot_vol_cycles)`,
                layers: sql`excluded.layers`,
                futVolUsd24h: sql`COALESCE(excluded.fut_vol_usd_24h,  ${prescanTrackerTable.futVolUsd24h})`,
                spotVolUsd24h: sql`COALESCE(excluded.spot_vol_usd_24h, ${prescanTrackerTable.spotVolUsd24h})`,
                futSpotRatio: sql`COALESCE(excluded.fut_spot_ratio,   ${prescanTrackerTable.futSpotRatio})`,
                futVolPctMcap: sql`excluded.fut_vol_pct_mcap`,
                spotVolPctMcap: sql`excluded.spot_vol_pct_mcap`,
                // COALESCE: сохраняем первое значение — при повторных UPDATE не перезаписываем
                firstOi30m: sql`COALESCE(${prescanTrackerTable.firstOi30m}, excluded.first_oi_30m)`,
                firstOi1h: sql`COALESCE(${prescanTrackerTable.firstOi1h},  excluded.first_oi_1h)`,
                firstOi4h: sql`COALESCE(${prescanTrackerTable.firstOi4h},  excluded.first_oi_4h)`,
                // COALESCE: WI обновляется только раз в несколько циклов (батч) — сохраняем предыдущее значение если новое null
                lastWhaleIndex: sql`COALESCE(excluded.last_whale_index, ${prescanTrackerTable.lastWhaleIndex})`,
                // last_price_24h: сохраняем ненулевое значение — NULLIF защищает от перезаписи нулём
                lastPrice24h: sql`COALESCE(NULLIF(excluded.last_price_24h, 0), ${prescanTrackerTable.lastPrice24h}, excluded.last_price_24h)`,
                // Taker / CVD: COALESCE — если в этом цикле поле не обновлялось (null), сохраняем предыдущее DB-значение
                lastNetBuyPct: sql`COALESCE(excluded.last_net_buy_pct,          ${prescanTrackerTable.lastNetBuyPct})`,
                lastSpotTakerNetBuy: sql`COALESCE(excluded.last_spot_taker_net_buy,   ${prescanTrackerTable.lastSpotTakerNetBuy})`,
                lastSpotTakerDominance: sql`COALESCE(excluded.last_spot_taker_dominance, ${prescanTrackerTable.lastSpotTakerDominance})`,
                lastCvd30m: sql`COALESCE(excluded.last_cvd_30m, ${prescanTrackerTable.lastCvd30m})`,
                lastCvd1h: sql`COALESCE(excluded.last_cvd_1h,  ${prescanTrackerTable.lastCvd1h})`,
                lastCvd4h: sql`COALESCE(excluded.last_cvd_4h,  ${prescanTrackerTable.lastCvd4h})`,
              },
            }),
        );
      }

      // Mark written cycleCount so next call skips these unless they change again
      for (const [sym, e] of entries) {
        _prescanWrittenCycles.set(sym, e.cycleCount ?? 0);
      }

      logger.debug(
        {
          count: values.length,
          skipped,
          batches: Math.ceil(values.length / BATCH_SIZE),
        },
        "Prescan tracker saved to DB",
      );
    }

    // Cleanup uses ALL in-memory entries (not just dirty subset) to correctly
    // identify which DB rows are still active.
    const activeSymbols = allEntries.map(([s]) => s);
    // dbWriteBestEffort: защита от зависания при нагрузке на Neon pool
    await dbWriteBestEffort("prescanTracker/cleanup-delete", () =>
      db.delete(prescanTrackerTable).where(
        sql`symbol NOT IN (${sql.join(
          activeSymbols.map((s) => sql`${s}`),
          sql`, `,
        )}) AND updated_at < NOW() - INTERVAL '15 minutes'`,
      ),
    );
  } catch (err) {
    logger.warn({ err }, "Failed to save prescan tracker to DB");
  }
}

/** Batch-update Whale Index for high-priority tokens after each scan cycle.
 *  Fire-and-forget: updates prescanTracker in-memory; persisted on next savePrescanToDb().
 *  Targets: OI Watch active + top-30 prescan by score + active tracked signals (≤70 symbols).
 *  Uses getTokenWhaleIndex cache (10-min TTL) — no redundant CG calls within one cycle. */
async function batchUpdateWhaleIndex(): Promise<void> {
  try {
    const [oiWatchRows, activeSignalRows] = await Promise.all([
      db
        .select({ symbol: oiWatchTable.symbol })
        .from(oiWatchTable)
        .where(
          and(
            inArray(oiWatchTable.status, ["watching", "confirming"]),
            gt(oiWatchTable.expiresAt, new Date()),
          ),
        ),
      db
        .select({ symbol: trackedSignalsTable.symbol })
        .from(trackedSignalsTable)
        .where(
          inArray(trackedSignalsTable.status, [
            "active",
            "accumulation",
            "in_run",
            "re_entry",
          ]),
        ),
    ]);
    const topPrescan = Array.from(prescanTracker.entries())
      .sort((a, b) => b[1].lastScore - a[1].lastScore)
      .slice(0, 30)
      .map(([sym]) => sym);
    const symbolSet = new Set([
      ...oiWatchRows.map((r) => r.symbol),
      ...activeSignalRows.map((r) => r.symbol),
      ...topPrescan,
    ]);
    const symbols = Array.from(symbolSet).slice(0, 70);
    if (symbols.length === 0) return;
    await runConcurrent(symbols, 3, async (symbol) => {
      const wi = await getTokenWhaleIndex(symbol);
      const pe = prescanTracker.get(symbol);
      if (pe && wi !== null) pe.lastWhaleIndex = wi;
    });
    logger.debug({ count: symbols.length }, "batchUpdateWhaleIndex: completed");
  } catch (err) {
    logger.warn({ err }, "batchUpdateWhaleIndex failed");
  }
}

/** Fetch spot volume for all prescan tracker symbols and persist to DB.
 *  Runs as fire-and-forget after each scan AND on a 60-min periodic timer
 *  (first run 2 min after startup) so data appears without waiting for scan completion. */
async function runSpotVolBatch(): Promise<void> {
  const symbols = Array.from(prescanTracker.keys());
  if (symbols.length === 0) return;
  // Fetch pairs-markets (1h/4h/netBuyPct) + FS volume ratio (24h totals + futures vol) concurrently
  const [svResults, fsResults] = await Promise.all([
    Promise.allSettled(symbols.map((sym) => getSpotVolume(sym))),
    Promise.allSettled(symbols.map((sym) => getFsVolume(sym))),
  ]);
  let spotVolUpdated = 0;
  let spotVolNoData = 0;
  let fsVolUpdated = 0;
  for (let i = 0; i < symbols.length; i++) {
    const sym = symbols[i];
    const pe = prescanTracker.get(sym);
    if (!pe) continue;

    // ── Pairs-markets: spot 1h/4h/netBuyPct + running average ──────────────
    const r = svResults[i];
    if (r.status === "fulfilled" && r.value.available) {
      const sv = r.value;
      pe.prevSpotVol1h = pe.lastSpotVol1h ?? null;
      pe.lastSpotVol1h = sv.volumeUsd1h;
      pe.lastSpotVol4h = sv.volumeUsd4h;
      pe.lastSpotNetBuy1h = sv.netBuyPct1h;
      pe.spotVolCycles = (pe.spotVolCycles ?? 0) + 1;
      if (pe.spotVolAvg1h == null) {
        pe.spotVolAvg1h = sv.volumeUsd1h;
      } else {
        pe.spotVolAvg1h = (pe.spotVolAvg1h * 4 + (sv.volumeUsd1h ?? 0)) / 5;
      }
      spotVolUpdated++;
    } else {
      spotVolNoData++;
    }

    // ── FS volume ratio: absolute 24h futures + spot (Binance+OKX+Bybit) ───
    const fr = fsResults[i];
    if (fr.status === "fulfilled" && fr.value.available) {
      const fv = fr.value;
      pe.futVolUsd24h = fv.futVolUsd24h;
      pe.spotVolUsd24h = fv.spotVolUsd24h;
      pe.futSpotRatio = fv.futSpotRatio;
      // %mcap: use spotPool mcapUsd as fallback; null if not available
      const mcap = getSpotPoolEntry(sym)?.mcapUsd ?? null;
      pe.futVolPctMcap =
        fv.futVolUsd24h && mcap ? (fv.futVolUsd24h / mcap) * 100 : null;
      pe.spotVolPctMcap =
        fv.spotVolUsd24h && mcap ? (fv.spotVolUsd24h / mcap) * 100 : null;
      // Populate cgVolumeCache with futures volume (used for L2 ranking)
      if (fv.futVolUsd24h) {
        const base = sym.replace(/-?USDT$/i, "").replace(/-/g, "");
        cgVolumeCache.set(base, fv.futVolUsd24h);
      }
      fsVolUpdated++;
    }
  }
  logger.info(
    {
      symbols: symbols.length,
      spotUpdated: spotVolUpdated,
      spotNoData: spotVolNoData,
      fsUpdated: fsVolUpdated,
    },
    "SpotVol+FsVol batch complete",
  );
  if (spotVolUpdated > 0 || fsVolUpdated > 0) {
    await saveSpotVolToDb().catch((e) =>
      logger.warn(
        { err: e },
        "SpotVol: saveSpotVolToDb failed after all retries",
      ),
    );
  }
}

/** Lightweight spot-vol-only DB persist. Runs after the spot vol fire-and-forget batch.
 *  Only touches the 6 spot-vol fields, only for symbols that already have data.
 *  Uses targeted UPDATE per symbol (not a full INSERT upsert) to minimise Neon pool pressure.
 *  Retries up to 3× with backoff so Neon connection timeouts don't silently drop the data. */
async function saveSpotVolToDb(): Promise<void> {
  const entries = Array.from(prescanTracker.entries()).filter(
    ([, e]) => (e.spotVolCycles ?? 0) > 0 && e.lastSpotVol1h != null,
  );
  if (entries.length === 0) {
    logger.info("SpotVol DB save: no symbols with spot vol data");
    return;
  }
  const BATCH_SIZE = 20;
  const MAX_RETRIES = 3;
  let saved = 0;
  let failed = 0;
  for (let i = 0; i < entries.length; i += BATCH_SIZE) {
    const batch = entries.slice(i, i + BATCH_SIZE);
    let lastErr: unknown;
    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      try {
        await Promise.all(
          batch.map(([symbol, e]) =>
            db
              .update(prescanTrackerTable)
              .set({
                lastSpotVol1h: e.lastSpotVol1h ?? null,
                prevSpotVol1h: e.prevSpotVol1h ?? null,
                lastSpotVol4h: e.lastSpotVol4h ?? null,
                lastSpotNetBuy1h: e.lastSpotNetBuy1h ?? null,
                spotVolAvg1h: e.spotVolAvg1h ?? null,
                spotVolCycles: sql`GREATEST(${prescanTrackerTable.spotVolCycles}, ${e.spotVolCycles ?? 1})`,
                ...(e.futVolUsd24h != null
                  ? { futVolUsd24h: e.futVolUsd24h }
                  : {}),
                ...(e.spotVolUsd24h != null
                  ? { spotVolUsd24h: e.spotVolUsd24h }
                  : {}),
                ...(e.futSpotRatio != null
                  ? { futSpotRatio: e.futSpotRatio }
                  : {}),
                ...(e.futVolPctMcap != null
                  ? { futVolPctMcap: e.futVolPctMcap }
                  : {}),
                ...(e.spotVolPctMcap != null
                  ? { spotVolPctMcap: e.spotVolPctMcap }
                  : {}),
              })
              .where(eq(prescanTrackerTable.symbol, symbol)),
          ),
        );
        saved += batch.length;
        lastErr = undefined;
        break;
      } catch (err) {
        lastErr = err;
        if (attempt < MAX_RETRIES)
          await new Promise((r) => setTimeout(r, 3000 * attempt));
      }
    }
    if (lastErr) {
      failed += batch.length;
      logger.warn(
        { err: lastErr, batchIdx: i / BATCH_SIZE + 1 },
        "SpotVol DB: batch failed after retries",
      );
    }
  }
  logger.info(
    { total: entries.length, saved, failed },
    "SpotVol DB save complete",
  );
  // Diagnostic: verify actual DB state after UPDATE
  try {
    const check = await db.execute(sql`
      SELECT COUNT(*) as not_null_count,
             MIN(spot_vol_avg_1h) as min_avg,
             MAX(spot_vol_avg_1h) as max_avg,
             (SELECT symbol || ':' || COALESCE(spot_vol_avg_1h::text, 'NULL') || '/' || spot_vol_cycles::text
              FROM prescan_tracker WHERE spot_vol_avg_1h IS NOT NULL LIMIT 1) as sample
      FROM prescan_tracker WHERE spot_vol_avg_1h IS NOT NULL`);
    logger.info(
      { dbCheck: check.rows[0] },
      "SpotVol DB verify: post-save check",
    );
    const symCheck = await db.execute(sql`
      SELECT symbol, spot_vol_avg_1h, spot_vol_cycles FROM prescan_tracker
      WHERE symbol = ${entries[0]?.[0] ?? "NONE"} LIMIT 1`);
    logger.info(
      { symCheck: symCheck.rows[0], firstSym: entries[0]?.[0] },
      "SpotVol DB verify: first symbol check",
    );
  } catch (e) {
    logger.warn({ err: e }, "SpotVol DB verify: check failed");
  }
}

/** Write prescan snapshot to prescan_history for OI/CVD history analysis.
 *  Captures ALL scored tokens (not just top-30) so overheat candidates get full history.
 *  TTL: 14 days. Fire-and-forget. */
async function savePrescanHistory(
  scored: Array<{ ticker: { symbol: string }; score: number }>,
): Promise<void> {
  try {
    // TTL cleanup: delete rows older than 14 days
    const cutoff = new Date(Date.now() - 14 * 24 * 60 * 60 * 1000);
    await dbWriteBestEffort("prescanHistory/cleanup-delete", () =>
      db.delete(prescanHistoryTable).where(lt(prescanHistoryTable.ts, cutoff)),
    );

    const now = new Date();
    const rows = scored
      .map((s) => {
        const sym = s.ticker.symbol;
        const entry = prescanTracker.get(sym);
        if (!entry) return null;
        return {
          symbol: sym,
          ts: now,
          cycleCount: entry.cycleCount,
          rank: null as number | null,
          score: s.score,
          price24h: entry.lastPrice24h ?? null,
          price1h: entry.lastPrice1h ?? null,
          oi30m: entry.lastOi30m ?? null,
          oi1h: entry.lastOi1h ?? null,
          oi4h: entry.lastOi4h ?? null,
          oi24h: entry.lastOi24h ?? null,
          volMult: entry.lastVolMult ?? null,
          cvd30m: entry.lastCvd30m ?? null,
          cvd1h: entry.lastCvd1h ?? null,
          netBuyPct: entry.lastNetBuyPct ?? null,
          spotTakerNetBuy: entry.lastSpotTakerNetBuy ?? null,
          oiAccel30m: entry.oiAccel30m ?? null,
          futSpotRatio: entry.futSpotRatio ?? null,
        };
      })
      .filter((r): r is NonNullable<typeof r> => r !== null);

    if (rows.length === 0) return;
    await dbWriteBestEffort("prescanHistory/insert", () =>
      db.insert(prescanHistoryTable).values(rows),
    );
    logger.debug({ count: rows.length }, "Prescan history saved");
  } catch (err) {
    logger.warn({ err }, "Failed to save prescan history");
  }
}

/** Log top growth leaders to growth_leader_log each scan cycle.
 *  Captures ALL BingX top-gainers (p24h > 3%), not only prescan pool tokens.
 *  For tokens IN prescan_tracker: full OI/CVD/vol data (source='scan').
 *  For tokens NOT in prescan_tracker: BingX price/vol only (source='bingx_only').
 *  No TTL — rows are kept indefinitely for backtest purposes.
 *  After INSERT: backfills matched_pattern for any row where a signal recently fired.
 *  Fire-and-forget — errors never bubble up. */
// ── Overheat log: dedup (symbol → last logged timestamp ms) ─────────────────
const _overheatLastKicked = new Map<string, number>();
const OVERHEAT_DEDUP_MS = 4 * 60 * 60 * 1000;

/** Логирует prescan-токены выкинутые фильтром перегрева (price24h > 40%).
 *  Fire-and-forget. Дедупликация: один символ — не чаще раза в 4 часа.
 *  Только токены из prescanTracker — т.е. те, которых сканер реально отслеживал. */
async function logOverheatedTokens(
  scored: Array<{ ticker: BingXTicker; score: number }>,
): Promise<void> {
  try {
    const now = Date.now();
    const rows: (typeof overheatLogTable.$inferInsert)[] = [];

    for (const { ticker } of scored) {
      const p24h = parseFloat(ticker.priceChangePercent);

      const sym = ticker.symbol;
      const pe = prescanTracker.get(sym);
      if (!pe) continue; // Пропускаем токены без prescan-данных (новые листинги, призраки)

      // Перегрет через p24h > 40% (основной фильтр prescan) ИЛИ через рост от точки входа ≥ 40%
      const curPrice = parseFloat(ticker.lastPrice) || 0;
      const growthFromEntry =
        pe.firstPrice && pe.firstPrice > 0
          ? ((curPrice - pe.firstPrice) / pe.firstPrice) * 100
          : null;
      const isOverheatedByP24h = p24h > 40;
      const isOverheatedByGrowth =
        growthFromEntry !== null && growthFromEntry >= 40;
      if (!isOverheatedByP24h && !isOverheatedByGrowth) continue;

      const lastKicked = _overheatLastKicked.get(sym) ?? 0;
      if (now - lastKicked < OVERHEAT_DEDUP_MS) continue;

      _overheatLastKicked.set(sym, now);

      rows.push({
        symbol: sym,
        kickedAt: new Date(now),
        price24h: p24h,
        price: parseFloat(ticker.lastPrice) || null,
        entryPrice: pe?.firstPrice ?? null,
        entryPrice24h: pe?.firstPrice24h ?? null,
        entryOi30m: pe?.firstOi30m ?? null,
        entryOi1h: pe?.firstOi1h ?? null,
        entryOi4h: pe?.firstOi4h ?? null,
        cycleCount: pe?.cycleCount ?? null,
        layers: pe?.layers ?? [],
        matchedPattern: null,
        entryVol24h: parseFloat(ticker.quoteVolume) || null,
        firstSeenAt: pe?.firstSeenAt ? new Date(pe.firstSeenAt) : null,
      });
    }

    if (rows.length === 0) return;

    // Задержка 60s — INSERT идёт в конце скана когда пул Neon перегружен (14min scan)
    await new Promise<void>((resolve) => setTimeout(resolve, 60_000));

    await dbWriteBestEffort(
      "OverheatLog: insert",
      () => db.insert(overheatLogTable).values(rows),
      {
        perAttemptTimeoutMs: 15_000,
        attempts: 3,
      },
    );

    // Бэкфил matched_pattern из tracked_signals (если сигнал уже был на этот символ)
    const symbols = rows.map((r) => r.symbol);
    void dbWriteBestEffort(
      "OverheatLog: backfill pattern",
      async () => {
        // ANY(${array}) в raw SQL передаёт массив как строку → malformed array literal;
        // используем IN с явными биндингами
        await db.execute(sql`
        UPDATE overheat_log o
        SET matched_pattern = ts.sentiment_key
        FROM tracked_signals ts
        WHERE o.symbol = ts.symbol
          AND o.matched_pattern IS NULL
          AND ts.detected_at > NOW() - INTERVAL '7 days'
          AND o.kicked_at > NOW() - INTERVAL '1 hour'
          AND o.symbol IN (${sql.join(
            symbols.map((s) => sql`${s}`),
            sql`, `,
          )})
      `);
      },
      { perAttemptTimeoutMs: 8_000, attempts: 2 },
    );

    logger.info(
      { count: rows.length, symbols: rows.map((r) => r.symbol) },
      "Overheat log: зафиксированы перегретые prescan-токены",
    );
  } catch (err) {
    logger.warn({ err }, "logOverheatedTokens: ошибка (non-critical)");
  }
}

/** Обновляет snapshot_price / snapshot_at для всех overheat_log-токенов за последние 60 дней.
 *  Запускается каждый скан-цикл после получения BingX тикеров — данные уже в памяти, нет лишних запросов.
 *  Гарантирует живые цены даже через 2 недели после того как токен покинул prescan. */
async function refreshOverheatSnapshots(
  scored: Array<{ ticker: BingXTicker; score: number }>,
): Promise<void> {
  try {
    const priceMap = new Map<string, number>();
    for (const { ticker } of scored) {
      const price = parseFloat(ticker.lastPrice);
      if (price > 0) priceMap.set(ticker.symbol, price);
    }
    if (priceMap.size === 0) return;

    const cutoffDate = new Date(Date.now() - 60 * 24 * 3600_000); // 60 дней
    const symbols = Array.from(priceMap.keys());

    // Получаем distinct overheat-символы за 60 дней которые есть в BingX тикере
    const overheatRows = await db
      .selectDistinct({ symbol: overheatLogTable.symbol })
      .from(overheatLogTable)
      .where(
        and(
          inArray(overheatLogTable.symbol, symbols),
          gt(overheatLogTable.kickedAt, cutoffDate),
        ),
      );

    if (overheatRows.length === 0) return;

    const toUpdate = overheatRows
      .map((r) => r.symbol)
      .filter((s) => priceMap.has(s));

    if (toUpdate.length === 0) return;

    // Batch-update: один UPDATE на символ, все параллельно (обычно ≤100 символов за 60 дней)
    await Promise.allSettled(
      toUpdate.map((sym) =>
        db
          .update(overheatLogTable)
          .set({ snapshotPrice: priceMap.get(sym)!, snapshotAt: new Date() })
          .where(
            and(
              eq(overheatLogTable.symbol, sym),
              gt(overheatLogTable.kickedAt, cutoffDate),
            ),
          ),
      ),
    );

    logger.debug(
      { count: toUpdate.length },
      "Overheat snapshots: обновлены цены",
    );
  } catch (err) {
    logger.warn({ err }, "refreshOverheatSnapshots: ошибка (non-critical)");
  }
}

async function saveGrowthLeadersToLog(
  allTickers: BingXTicker[],
): Promise<void> {
  try {
    const now = new Date();

    // Все BingX фьючерсные тикеры: берём топ-100 по price24h > 3%
    // Исключаем stock-trackers (NCS*, NCC*, *2USD) — как в isCryptoFuture внутри performScan
    const topBingx = allTickers
      .filter((t) => {
        if (!t.symbol.endsWith("-USDT")) return false;
        const p = parseFloat(t.priceChangePercent);
        if (isNaN(p) || p <= 3) return false;
        const base = t.symbol.replace("-USDT", "");
        return (
          !base.includes("2USD") &&
          !base.startsWith("NCS") &&
          !base.startsWith("NCC") &&
          !base.startsWith("NCFX")
        );
      })
      .sort(
        (a, b) =>
          parseFloat(b.priceChangePercent) - parseFloat(a.priceChangePercent),
      )
      .slice(0, 100);

    if (topBingx.length === 0) return;

    // spot_taker_buy_usd / spot_taker_sell_usd / spot_fp_buy_pct — пишутся null.
    // Бэкфилл (growthLeaderBackfill.ts) заполняет их батчами без нагрузки на скан-цикл.
    const rows = topBingx.map((t, i) => {
      const symbol = t.symbol;
      const price24h = parseFloat(t.priceChangePercent);
      const price = parseFloat(t.lastPrice) || null;

      // Обогащаем данными из prescan_tracker если токен там есть
      const pe = prescanTracker.get(symbol);
      if (pe) {
        const growthFromEntry =
          pe.firstPrice > 0 && pe.lastPrice > 0
            ? (pe.lastPrice / pe.firstPrice - 1) * 100
            : null;
        const spotVolMult =
          pe.lastSpotVol1h != null &&
          pe.spotVolAvg1h != null &&
          pe.spotVolAvg1h > 0
            ? pe.lastSpotVol1h / pe.spotVolAvg1h
            : null;
        const prevSpotVolMult =
          pe.prevSpotVol1h != null &&
          pe.spotVolAvg1h != null &&
          pe.spotVolAvg1h > 0
            ? pe.prevSpotVol1h / pe.spotVolAvg1h
            : null;
        // cgNoDataCount >= 3 имеет приоритет — токен BingX-exclusive даже если lastOi30m
        // заполнен из BingX Direct OI (не из CoinGlass). Инвертированный порядок проверки.
        const cgOiAvailable =
          (pe.cgNoDataCount ?? 0) >= 3
            ? false
            : pe.lastOi30m != null
              ? true
              : null;
        return {
          loggedAt: now,
          symbol,
          rank: i + 1,
          price: pe.lastPrice ?? price,
          price24h: pe.lastPrice24h ?? price24h,
          price1h: pe.lastPrice1h ?? null,
          growthFromEntry,
          cycleCount: pe.cycleCount,
          firstSeenAt: pe.firstSeenAt,
          layers: pe.layers ?? [],
          oi30m: pe.lastOi30m ?? null,
          oi1h: pe.lastOi1h ?? null,
          oi4h: pe.lastOi4h ?? null,
          cvd1h: pe.lastCvd1h ?? null,
          cvd30m: pe.lastCvd30m ?? null,
          spotVolMult,
          volMult: pe.lastVolMult ?? null,
          source: "scan" as const,
          entryPrice: pe.firstPrice || null,
          entryPrice24h: pe.firstPrice24h ?? null,
          entryOi30m: pe.firstOi30m ?? null,
          entryOi1h: pe.firstOi1h ?? null,
          entryOi4h: pe.firstOi4h ?? null,
          netBuyPct: pe.lastSpotTakerNetBuy ?? null,
          spotTakerBuyUsd: null,
          spotTakerSellUsd: null,
          prevOi30m: pe.prevOi30m ?? null,
          prevOi4h: pe.prevOi4h ?? null,
          spotCvd4h: pe.lastCvd4h ?? null,
          spotTakerNetBuyPct: pe.lastSpotNetBuy1h ?? null,
          prevSpotVolMult,
          cgOiAvailable,
        };
      }

      // Токен НЕ в prescan — логируем только BingX данные
      const bxVol = parseFloat(t.quoteVolume) || null;
      return {
        loggedAt: now,
        symbol,
        rank: i + 1,
        price,
        price24h,
        price1h: null,
        growthFromEntry: null,
        cycleCount: null,
        firstSeenAt: null,
        layers: [],
        oi30m: null,
        oi1h: null,
        oi4h: null,
        cvd1h: null,
        cvd30m: null,
        spotVolMult: null,
        volMult: bxVol != null && bxVol > 0 ? 1.0 : null,
        source: "bingx_only" as const,
        netBuyPct: null,
        spotTakerBuyUsd: null,
        spotTakerSellUsd: null,
        prevOi30m: null,
        prevOi4h: null,
        spotCvd4h: null,
        spotTakerNetBuyPct: null,
        prevSpotVolMult: null,
        cgOiAvailable: null,
      };
    });

    const inPrescan = rows.filter((r) => r.source === "scan").length;

    // Пауза 15с: Neon пул восстанавливается после тяжёлого конца скан-цикла.
    // 100 строк × 47 колонок = 4700 параметров — слишком большой INSERT при перегруженном пуле.
    await new Promise((r) => setTimeout(r, 15_000));

    // Разбиваем на батчи по 20 строк чтобы каждый INSERT был лёгким.
    const BATCH_SIZE = 20;
    let insertedTotal = 0;
    for (let i = 0; i < rows.length; i += BATCH_SIZE) {
      const batch = rows.slice(i, i + BATCH_SIZE);
      const result = await dbWriteBestEffort(
        `GrowthLeaderLog: insert batch ${Math.floor(i / BATCH_SIZE) + 1}/${Math.ceil(rows.length / BATCH_SIZE)}`,
        () =>
          db.insert(growthLeaderLogTable).values(batch).onConflictDoNothing(),
        { perAttemptTimeoutMs: 15_000, attempts: 3, retryDelayMs: 2_000 },
      );
      if (result !== null) insertedTotal += batch.length;
      if (i + BATCH_SIZE < rows.length) {
        await new Promise((r) => setTimeout(r, 500));
      }
    }

    // Fire-and-forget: sync matched_pattern for recent rows that already have a tracked signal.
    // Runs after INSERT so newly inserted rows are also covered.
    const logSymbols = rows.map((r) => r.symbol);
    if (logSymbols.length > 0) {
      db.update(growthLeaderLogTable)
        .set({
          matchedPattern: sql`(
            SELECT sentiment_key FROM tracked_signals ts
            WHERE ts.symbol = growth_leader_log.symbol
              AND ts.detected_at > NOW() - INTERVAL '48 hours'
              AND ts.status <> 'cancelled'
            ORDER BY ts.detected_at DESC
            LIMIT 1
          )`,
        })
        .where(
          and(
            inArray(growthLeaderLogTable.symbol, logSymbols),
            isNull(growthLeaderLogTable.matchedPattern),
            gt(
              growthLeaderLogTable.loggedAt,
              new Date(Date.now() - 48 * 60 * 60 * 1000),
            ),
          ),
        )
        .catch((e: unknown) =>
          logger.debug(
            { err: e },
            "growth_leader_log matched_pattern backfill skipped",
          ),
        );
    }

    logger.info(
      {
        total: rows.length,
        inserted: insertedTotal,
        inPrescan,
        bingxOnly: rows.length - inPrescan,
        top3: rows
          .slice(0, 3)
          .map((r) => `${r.symbol}(${r.price24h?.toFixed(1)}%,${r.source})`),
      },
      "Growth leader log saved",
    );
  } catch (err) {
    logger.warn({ err }, "Failed to save growth leader log");
  }
}

interface SymbolSignalState {
  firstSignalAt: Date;
  signalCount: number;
  cumulativeOiChange: number;
}
const signalHistory = new Map<string, SymbolSignalState>();

let scanTimer: ReturnType<typeof setTimeout> | null = null;
let lastScanHeartbeatTimer: ReturnType<typeof setInterval> | null = null;
let scanCycleCounter = 0; // инкрементируется каждый performScan; используется для quiet prescan

// ── Settings ────────────────────────────────────────────────────────────────
async function getSettings() {
  const rows = await db.select().from(settingsTable).limit(1);
  if (rows.length === 0) {
    const inserted = await db
      .insert(settingsTable)
      .values({
        volumeMultiplier: 3,
        oiChangePercent: 8,
        fundingRateThreshold: 0.0005,
        scanIntervalMs: 300_000,
        telegramEnabled: true,
        maxSymbols: 200,
      })
      .returning();
    return inserted[0];
  }
  return rows[0];
}

import {
  type SentimentResult,
  type AlphaResult,
  detectSentiment,
  calcBulletScore,
  evaluatePattern,
} from "./scanner-patterns.js";

// ── Main scan ────────────────────────────────────────────────────────────────
export async function performScan(): Promise<{
  signalsFound: number;
  marketsScanned: number;
  durationMs: number;
}> {
  const startTime = Date.now();
  scanCycleCounter++;
  // Флаги ставим ДО первых await — watchdog никогда не увидит «старый» lastScanAt
  // в фазах до скана (persistPatternDebugSnapshot, persistSymRejectLog, getSettings).
  // Ранее стояли на ~50 строк ниже, после нескольких await, что давало ложные
  // watchdog-алерты если Neon pool зависал на 25+ мин в начале цикла.
  state.lastScanAt = new Date();
  state.isScanning = true;
  // Cross-process: Worker B infers isScanning = scannerScanStartedAt > scannerLastScanAt
  void dbWriteBestEffort(
    "scannerScanStartedAt",
    () =>
      db.update(settingsTable).set({ scannerScanStartedAt: state.lastScanAt }),
    { attempts: 1 },
  );
  const _spotVolDiag = {
    notInMap: 0,
    noAvg: 0,
    noLast: 0,
    hasMult: 0,
    sample: [] as Array<{
      sym: string;
      inMap: boolean;
      avg: number | null;
      last: number | null;
      cycles: number | null;
    }>,
  };
  resetNetflowTelemetry();
  lastLayerDebug = {
    exhaustedByTicker: 0,
    l3CandidatesTotal: 0,
    l3PassedToBatch: 0,
    l4CandidatesTotal: 0,
    l4PassedToBatch: 0,
    l5CandidatesTotal: 0,
    l5PassedToBatch: 0,
    l8SteadyGrowthCycles: 0,
    l8PassedToBatch: 0,
    l8bOiLeadersTotal: 0,
    l8bInsertedToWatch: 0,
    l6cRescuedTotal: 0,
    quietPrescanAdded: 0,
    l10LiqCascadeAdded: 0,
    l11WhaleAlertAdded: 0,
    l15WhalePositionAdded: 0,
    cycleNumber: scanCycleCounter,
  };
  // Записываем снапшот ПРЕДЫДУЩЕГО цикла пока pool свежий (простоял ~10 мин без нагрузки).
  // await (не void) — начало скана, pool свободен, блокировка ~10-50ms, данные гарантированы.
  // Вызов ДО сброса: lastPatternDebug и _pendingDiagRows ещё содержат данные цикла N-1.
  // ScanRejectLog: flush предыдущего цикла пока pool свежий.
  // Аналогично PDB/DiagRows: в конце скана Neon pool перегружен → таймаут накапливает 1173+ строк.
  // В начале следующего цикла pool простоял ~10 мин и принимает INSERT мгновенно.
  await persistSymRejectLog();
  if (Object.keys(lastPatternDebug).length > 0) {
    await persistPatternDebugSnapshot(scanCycleCounter - 1);
  }
  await flushPendingDiagRows();
  lastPatternDebug = {};

  const settings = await getSettings();

  // T3: прогрев liq-кэшей (coin-list batch + order stream) — fire-and-forget,
  // чтобы fire-сайты читали тёплый кэш без per-symbol ожиданий.
  void fetchLiqCoinList().catch(() => null);
  void fetchLiqOrders().catch(() => null);

  // Очищаем устаревшие записи signalHistory (TTL: 48 часов).
  // Без TTL история растёт вечно — символы которые давно не скануются остаются в памяти.
  const TTL_MS = 48 * 60 * 60 * 1000;
  for (const [sym, st] of signalHistory.entries()) {
    if (Date.now() - st.firstSignalAt.getTime() > TTL_MS) {
      signalHistory.delete(sym);
    }
  }

  // Sweep: помечаем все OI Watch записи у которых истёк expiresAt.
  // Без этого символы выпавшие из топ-пресскана висят в "watching"/"confirming" вечно.
  try {
    // ВАЖНО: firedAt здесь НЕ проставляем — это поле означает момент реального
    // срабатывания сигнала (алерт в Telegram), а не момент технической зачистки
    // просроченной записи. Ранее ошибочно проставлялось в этом же UPDATE, из-за
    // чего "confirmed" записи выглядели как fired→expired (ложное подозрение на
    // гонку процессов) — на деле broadcastBatchAlert тут никогда не вызывался.
    // dbWriteBestEffort: защита от зависания при нагрузке на Neon pool
    await dbWriteBestEffort("oiWatch/expired-sweep", () =>
      db
        .update(oiWatchTable)
        .set({ status: "expired" })
        .where(
          and(
            inArray(oiWatchTable.status, ["watching", "confirming"]),
            lt(oiWatchTable.expiresAt, new Date()),
          ),
        ),
    );
  } catch (err) {
    logger.warn({ err }, "OI Watch expired sweep failed");
  }

  // Очищаем кэш CoinGlass перед каждым сканом — данные всегда свежие
  clearCoinglassOICache();
  logger.info("Starting AltBullet Scanner (15m TF, 30m OI, multi-pattern)...");

  state.oiWatchInsertsLastScan = 0;
  state.cgTimeoutsLastScan = 0;

  let tickers;
  try {
    tickers = await getFutureTickers();
  } catch (err) {
    logger.error({ err }, "Failed to fetch BingX tickers");
    state.bingxConnected = false;
    state.isScanning = false;
    state.lastScanAt = new Date();
    return {
      signalsFound: 0,
      marketsScanned: 0,
      durationMs: Date.now() - startTime,
    };
  }
  state.bingxConnected = true;

  // Обновляем множество символов BingX (для isBingXFutures)
  bingxFuturesSymbols.clear();
  for (const t of tickers) bingxFuturesSymbols.add((t as BingXTicker).symbol);

  // ── Activity-score pre-screening (ALL tokens, 1 API call) ───────────────────
  // Score every USDT token using already-fetched ticker data (free, no extra calls).
  // Hot tokens (big price move + big volume) get deep-scanned every 10 min,
  // so OI baselines build up within 20 min — not 100 min like with rotation.
  //
  // score = abs(priceChange24h%) × log10(quoteVolumeUSD + 1)
  // This ranks: tokens with big price moves in liquid markets first.
  // Exclude index/stock trackers (NCS*, NCC*, symbols with "2USD" — e.g. NCSKSPY2USD-USDT)
  const isCryptoFuture = (symbol: string) => {
    const base = symbol.replace("-USDT", "");
    return (
      !base.includes("2USD") &&
      !base.startsWith("NCS") &&
      !base.startsWith("NCC") &&
      !base.startsWith("NCFX")
    );
  };

  const scored = tickers
    .filter((t) => t.symbol.endsWith("-USDT") && isCryptoFuture(t.symbol))
    .map((t) => {
      const pctChange = Math.abs(parseFloat(t.priceChangePercent) || 0);
      const vol = parseFloat(t.quoteVolume) || 0;
      const baseScore = pctChange * Math.log10(vol + 1);
      // Бонус за ускорение объёма: если volMult вырос по сравнению с прошлым циклом.
      // Данные из prescanTracker (прошлый deep scan). Первый цикл — бонуса нет.
      const _pe = prescanTracker.get(t.symbol);
      const volAccel =
        _pe?.lastVolMult && _pe?.prevVolMult && _pe.prevVolMult > 0
          ? _pe.lastVolMult / _pe.prevVolMult
          : 1.0;
      const accelBonus = volAccel >= 2.0 ? 2.0 : volAccel >= 1.5 ? 1.5 : 1.0;
      // Бонус за ускорение OI: если oi30m растёт от цикла к циклу — токен поднимается в топ.
      const oiAccel = _pe?.oiAccel30m ?? 1.0;
      const oiAccelBonus =
        oiAccel >= 3.0
          ? 1.4
          : oiAccel >= 2.0
            ? 1.25
            : oiAccel >= 1.5
              ? 1.1
              : 1.0;
      const score = baseScore * accelBonus * oiAccelBonus;
      return { ticker: t, score };
    })
    .sort((a, b) => b.score - a.score);

  // ── Layer 0: user watchlist — always scanned regardless of rank ──────────────
  const watchlistSymbols: string[] = String(settings.watchlist ?? "")
    .split(",")
    .map((s: string) => s.trim().toUpperCase())
    .filter((s: string) => s.length > 0)
    .map((s: string) => (s.includes("-") ? s : `${s}-USDT`)); // auto-append -USDT if missing

  const watchlistSet = new Set([...watchlistSymbols]);
  const watchlistTickers = tickers.filter((t) => watchlistSet.has(t.symbol));
  const watchlistSymbolsFound = new Set(watchlistTickers.map((t) => t.symbol));

  // ── Exhausted pump pre-filter (free — BingX ticker data, no extra API calls) ─
  // Монеты с >25% за 24h уже отработали свой памп. Новый сигнал невозможен —
  // это подтверждено паттерном (exhausted pump filter на глубоком скане).
  // Исключаем ЗДЕСЬ чтобы не тратить дорогие слоты CoinGlass API на мёртвые монеты.
  // Исключение: watchlist — пользователь явно хочет их отслеживать.
  const isExhaustedByTicker = (sym: string, pctChange24h: string): boolean => {
    if (watchlistSet.has(sym)) return false;
    const pct = parseFloat(pctChange24h) || 0;
    // Убираем только явно перегретые (памп >40%) или обвальные (<-40%) токены.
    // Диапазон -40%..+40% остаётся в пуле: накопление на дипе (-28% и т.п.) — валидный сигнал.
    const exhausted = pct > 40 || pct < -40;
    if (exhausted && pct > 40) {
    }
    return exhausted;
  };

  // ── Layer 1: top-N by activity score (current hot movers)
  const activityLimit = settings.maxSymbols; // default 50
  const topByActivity = scored
    .filter(
      (s) => !isExhaustedByTicker(s.ticker.symbol, s.ticker.priceChangePercent),
    )
    .slice(0, activityLimit)
    .map((s) => s.ticker);
  const activeSymbols = new Set(topByActivity.map((t) => t.symbol));
  lastLayerDebug.exhaustedByTicker = scored.filter((s) => {
    const p = parseFloat(s.ticker.priceChangePercent);
    return p > 40 || p < -40;
  }).length;

  // Логируем overheated prescan-токены (p24h > 40% И в prescanTracker) — анализ и калибровка
  void logOverheatedTokens(scored);
  // Обновляем snapshot цены для всех overheat_log-токенов (данные уже в памяти — бесплатно)
  void refreshOverheatSnapshots(scored);

  // ── Layer 2: top-200 by volume — BingX только как fallback для первого скана.
  //    После 1-го скана используем cgVolumeCache (global volUsd от CoinGlass):
  //    DYDX с $246M OI и высоким global volume попадёт в пул даже при низком BingX-объёме.
  const useCgVolume = cgVolumeCache.size > 0;
  const topByVolume = [...scored]
    .filter(
      (s) => !isExhaustedByTicker(s.ticker.symbol, s.ticker.priceChangePercent),
    )
    .sort((a, b) => {
      const symA = a.ticker.symbol.replace("USDT", "").replace("-", "");
      const symB = b.ticker.symbol.replace("USDT", "").replace("-", "");
      const volA = useCgVolume
        ? (cgVolumeCache.get(symA) ??
          cgVolumeCache.get(a.ticker.symbol) ??
          (parseFloat(a.ticker.quoteVolume) || 0))
        : parseFloat(a.ticker.quoteVolume) || 0;
      const volB = useCgVolume
        ? (cgVolumeCache.get(symB) ??
          cgVolumeCache.get(b.ticker.symbol) ??
          (parseFloat(b.ticker.quoteVolume) || 0))
        : parseFloat(b.ticker.quoteVolume) || 0;
      return volB - volA;
    })
    .slice(0, 200)
    .map((s) => s.ticker)
    .filter(
      (t) =>
        !activeSymbols.has(t.symbol) && !watchlistSymbolsFound.has(t.symbol),
    );

  // ── OI Universe Discovery: CoinGlass OI для ВСЕХ ~500 токенов ────────────────
  // Первичный фильтр — OI спайк на любом ТФ. Токены с глобальным ростом OI
  // попадают в пул независимо от объёма на BingX.
  // Standard plan: 300 req/min, 50ms задержка. Холодный старт: ~500 × 50ms ≈ 25с.
  // Кэш TTL 5 мин — повторные обращения в deep scan мгновенны (данные уже в кэше).
  const allBingxSymbols = scored.map((s) => s.ticker.symbol);
  logger.info(
    { count: allBingxSymbols.length },
    "OI Universe Discovery: CoinGlass OI для всех токенов...",
  );
  // prefetchNetflowBatch — 1 запрос заменяет 10 per-symbol taker-вызовов для топ-100 символов
  // symbolsNeedingBaseline — токены, у которых oiBaseline отсутствует или старше MIN_BASELINE_AGE_MS.
  // Без этого BingX-фоллбэк (Level 1, строка ~2890) никогда не получает точку отсчёта.
  const symbolsNeedingBaseline = allBingxSymbols.filter((sym) => {
    const b = oiBaseline.get(sym);
    return !b || Date.now() - b.takenAt >= MIN_BASELINE_AGE_MS;
  });
  // Карта цен для кросс-валидации CoinGlass OI против прямого BingX OI
  // (ловит коллизии коротких/общих тикеров типа US-USDT — см. coinglass_oi.ts).
  const bingxPriceMap = new Map<string, number>();
  for (const s of scored) {
    const p = parseFloat(s.ticker.lastPrice);
    if (Number.isFinite(p) && p > 0) bingxPriceMap.set(s.ticker.symbol, p);
  }
  // Определяем токены без CG-покрытия — пропускаем в batch-запросе (экономия ~3-4 мин/цикл).
  // PRIMARY: GET /api/futures/supported-coins → официальный список монет CoinGlass.
  //   Токен не в списке → 100% BingX-exclusive, skip навсегда.
  //   Токен в списке   → CG должен иметь данные; cgNoDataCount не используется как gate.
  // FALLBACK (whitelist не загружен): старая эвристика cgNoDataCount >= 3, retry каждые 12 циклов.
  const cgSupportedCoins = getCgSupportedCoinsSet();
  const cgNoDataSkipSet = new Set<string>(
    [...prescanTracker.entries()]
      .filter(([sym, pe]) => {
        const base = sym.replace("-USDT", "");
        const cgBase = CG_SYMBOL_ALIAS[base] ?? base;
        if (cgSupportedCoins !== null) {
          return !cgSupportedCoins.has(cgBase);
        }
        return (
          (pe.cgNoDataCount ?? 0) >= 3 && (pe.cgNoDataCount ?? 0) % 12 !== 0
        );
      })
      .map(([sym]) => sym),
  );

  const [coinglassOIMap] = await Promise.all([
    batchGetCoinglassOI(allBingxSymbols, bingxPriceMap, cgNoDataSkipSet),
    prefetchNetflowBatch().catch(() => ({ fetched: 0 })),
    refreshOiBaselines(symbolsNeedingBaseline),
  ]);

  // ── Whale Tracker: дневной снимок OI (1 раз в сутки, UTC) ──────────────────
  // saveDailyOiSnapshots() сама игнорирует дубли (symbol+date), но гейт по дате
  // здесь нужен чтобы не делать ~500 лишних SELECT на дубли каждый скан-цикл.
  const todayUtc = new Date().toISOString().slice(0, 10);
  if (todayUtc !== lastOiSnapshotDate) {
    lastOiSnapshotDate = todayUtc;
    const priceMap = new Map<string, number>();
    const volume24hMap = new Map<string, number>();
    for (const s of scored) {
      priceMap.set(s.ticker.symbol, parseFloat(s.ticker.lastPrice) || 0);
      volume24hMap.set(s.ticker.symbol, parseFloat(s.ticker.quoteVolume) || 0);
    }
    saveDailyOiSnapshots(coinglassOIMap, priceMap, volume24hMap).catch((err) =>
      logger.error({ err }, "Whale Tracker: daily OI snapshot save failed"),
    );
  }

  // ── Prescan OI refresh (early, unconditional) ──────────────────────────────
  // coinglassOIMap содержит данные для всех ~500 токенов.
  // OI пишется в prescanTracker также внутри глубокого скана (строки ~1460),
  // НО туда попадают только токены из usdtTickers (топ-N по activity score,
  // отфильтрованные isExhaustedByTicker >25%).
  // Токены в prescanTracker с price24h > 25% вылетают из usdtTickers →
  // их OI-поля никогда не обновляются → показывают "BingX Only" навсегда.
  // Решение: обновляем OI для ВСЕХ prescan-записей прямо здесь, из только
  // что полученного coinglassOIMap — до глубокого скана.
  for (const [sym, pe] of prescanTracker.entries()) {
    const cg = coinglassOIMap.get(sym);
    if (!cg) continue;
    if (cg.available) {
      // prevOi30m приходит прямо из OHLC candle[-2] — цикл-сдвиг больше не нужен.
      pe.prevOi30m = cg.prevOi30m ?? null;
      pe.prevOi4h = pe.lastOi4h ?? null;
      pe.lastOi30m = cg.oiChange30m ?? null;
      pe.lastOi1h = cg.oiChange1h ?? null;
      pe.lastOi4h = cg.oiChange4h ?? null;
      pe.lastOi24h = cg.oiChange24h ?? null;
      pe.lastCgTimedOut = false;
      pe.cgNoDataCount = 0;
      pe.lastOiAt = Date.now();
      // Ускорение OI 30m: отношение текущего к предыдущему (оба должны быть > 0).
      pe.oiAccel30m =
        pe.prevOi30m != null && pe.prevOi30m > 0 && (pe.lastOi30m ?? 0) > 0
          ? (pe.lastOi30m ?? 0) / pe.prevOi30m
          : null;
      // Подряд 4h-периодов роста OI — из OHLC напрямую (точнее, чем per-cycle счётчик).
      pe.oi4hConsecGrowth = cg.oi4hConsecFromOhlc ?? 0;
    } else if (cg.timedOut) {
      pe.lastCgTimedOut = true;
      // cgNoDataCount НЕ сбрасываем: CG timeout ≠ токен покрывается CoinGlass.
      // Подтверждённые BingX-only токены не должны терять статус при временных сбоях CG.
    } else {
      // available=false + timedOut=false → пустой ответ CoinGlass.
      // НЕ помечаем сразу "BingX only" — может быть временный сбой API, формат символа, rate limit.
      // Только после 3 ПОДРЯД пустых ответов считаем подтверждённым отсутствием данных.
      logger.debug(
        { symbol: sym },
        "CG OI: available=false, timedOut=false — токен не покрывается CoinGlass",
      );
      pe.cgNoDataCount = (pe.cgNoDataCount ?? 0) + 1;
      if (pe.cgNoDataCount >= 3) {
        pe.lastCgTimedOut = false; // 3+ циклов подряд: действительно нет данных
      } else {
        pe.lastCgTimedOut = true; // 1-2 цикла: трактуем как временный сбой, ретраим в след цикле
      }
    }
  }

  // ── Prescan-stale OI fallback ────────────────────────────────────────────
  // Когда CG circuit breaker срабатывает (pending=500+), ~500 токенов получают
  // available=false. Восстанавливаем OI из prescanTracker (данные прошлого
  // цикла) чтобы OI-паттерны продолжали работать.
  // Вставлено ПОСЛЕ saveDailyOiSnapshots + prescan OI refresh — не портит
  // daily OI snapshots для oi24h_accumulation.
  {
    let staleFallbackCount = 0;
    for (const sym of allBingxSymbols) {
      const existing = coinglassOIMap.get(sym);
      if (existing?.available) continue; // live CG data есть — не трогаем
      if (existing?.collisionSuspected) continue; // коллизия тикера — fail-open запрещён
      const pe = prescanTracker.get(sym);
      if (!pe) continue;
      if (pe.lastOi30m == null && pe.lastOi1h == null) continue; // нет кэшированных данных
      coinglassOIMap.set(sym, {
        oiChange30m: pe.lastOi30m ?? null,
        prevOi30m: pe.prevOi30m ?? null,
        oiChange1h: pe.lastOi1h ?? null,
        oiChange4h: pe.lastOi4h ?? null,
        oiChange24h: null,
        oiUsd: null,
        cgVolUsd: null,
        bingxOiChange30m: null,
        positiveCandles6h: null,
        oiConsecutiveUp: null,
        oi4hConsecFromOhlc: pe.oi4hConsecGrowth ?? null,
        available: true,
        timedOut: false,
        source: "prescan_stale",
        collisionSuspected: false,
      });
      staleFallbackCount++;
    }
    if (staleFallbackCount > 0) {
      logger.info(
        { staleFallbackCount },
        "CoinGlass OI: prescan-stale fallback применён (circuit breaker сработал)",
      );
    }
  }

  // ── Prescan OI DB refresh: обновляем стейл-записи в DB ───────────────────
  // Токены удалённые из in-memory prescanTracker (вышли из топ-N или isExhaustedByTicker)
  // оставляют в DB запись с null OI-полями → UI показывает "BingX only" ошибочно.
  // Решение: если CG знает токен (available=true) — записываем свежие OI данные прямо в DB,
  // минуя in-memory tracker. Fire-and-forget, не блокирует скан-цикл.
  void (async () => {
    try {
      const inMemSymbols = new Set(prescanTracker.keys());
      const dbRows = await db
        .select({ symbol: prescanTrackerTable.symbol })
        .from(prescanTrackerTable);
      const now = new Date();
      let updated = 0;
      for (const { symbol } of dbRows) {
        if (inMemSymbols.has(symbol)) continue;
        const cg = coinglassOIMap.get(symbol);
        if (!cg?.available) continue;
        // void + dbWriteBestEffort: per-symbol в цикле — зависание без таймаута умножается
        // на кол-во символов; fire-and-forget (некритичное обновление OI)
        void dbWriteBestEffort("prescanTracker/oi-update", () =>
          db
            .update(prescanTrackerTable)
            .set({
              lastOi30m: cg.oiChange30m ?? null,
              lastOi1h: cg.oiChange1h ?? null,
              lastOi4h: cg.oiChange4h ?? null,
              lastOi24h: cg.oiChange24h ?? null,
              // false = "CG asked, no data" (vs null = never asked, true = timed out)
              lastCgTimedOut: false,
              updatedAt: now,
            })
            .where(eq(prescanTrackerTable.symbol, symbol)),
        );
        updated++;
      }
      if (updated > 0)
        logger.debug(
          { updated },
          "Prescan OI DB refresh: стейл-записи обновлены",
        );
    } catch (err) {
      logger.warn({ err }, "Prescan OI DB refresh: ошибка");
    }
  })();

  const tickerBySymbol = new Map(
    scored.map((s) => [s.ticker.symbol, s.ticker]),
  );
  const topByVolumeSet = new Set(topByVolume.map((t) => t.symbol));

  const oiMoverTickers: BingXTicker[] = [];
  let _l3Total = 0;
  for (const [sym, oi] of coinglassOIMap.entries()) {
    if (!oi.available) continue;
    const hasSpike =
      (oi.oiChange30m !== null && Math.abs(oi.oiChange30m) >= 6.0) ||
      (oi.oiChange1h !== null && Math.abs(oi.oiChange1h) >= 3.0) ||
      (oi.oiChange4h !== null && Math.abs(oi.oiChange4h) >= 8.0) ||
      (oi.oiChange24h !== null && Math.abs(oi.oiChange24h) >= 10.0);
    if (!hasSpike) continue;
    _l3Total++;
    if (
      activeSymbols.has(sym) ||
      watchlistSymbolsFound.has(sym) ||
      topByVolumeSet.has(sym)
    )
      continue;
    const ticker = tickerBySymbol.get(sym);
    if (!ticker) continue;
    if (isExhaustedByTicker(sym, ticker.priceChangePercent)) continue;
    oiMoverTickers.push(ticker);
  }
  lastLayerDebug.l3CandidatesTotal = _l3Total;
  lastLayerDebug.l3PassedToBatch = oiMoverTickers.length;
  if (oiMoverTickers.length > 0) {
    logger.info(
      {
        count: oiMoverTickers.length,
        symbols: oiMoverTickers.slice(0, 10).map((t) => t.symbol),
      },
      "🌐 OI Universe Discovery: найдены OI movers за пределами топ-N BingX",
    );
  }

  // ── Layer 4: BingX Volume Awakening — объём растёт без OI и без activity score ─
  // Ловит монеты которые «просыпаются» по объёму до того как price24h вырос
  // достаточно для попадания в Layer 1/2/3.
  //
  // Формула: per-token EMA дельт quoteVolume между соседними циклами (~10 мин).
  // Gate: delta > ema * 2.5 && delta > VOL_AWAKEN_MIN_DELTA_USD
  //
  // EMA (α=0.3): адаптируется к нормальному ритму каждого токена.
  // Токен с постоянно высокими дельтами имеет высокую базу → относительный порог защищает.
  // Абсолютный пол $50k → защита от "2.5× от нуля" для тихих токенов.
  //
  // Холодный старт (2 цикла прогрева, gate не проверяется):
  //   Цикл 1: нет записи → prev=curVol, ema=null, пропуск.
  //   Цикл 2: ema=null → ema=delta, пропуск (инициализация, не сравнение).
  //   Цикл 3+: нормальный gate.
  const volAwakenSet = new Set([
    ...activeSymbols,
    ...watchlistSymbolsFound,
    ...topByVolumeSet,
    ...oiMoverTickers.map((t) => t.symbol),
  ]);
  const volAwakenTickers: BingXTicker[] = [];
  for (const s of scored) {
    const sym = s.ticker.symbol;
    if (volAwakenSet.has(sym)) continue;

    const _price24h = parseFloat(s.ticker.priceChangePercent) || 0;
    const curVol = parseFloat(s.ticker.quoteVolume) || 0;
    const cached = prevQuoteVolCache.get(sym);

    // Всегда обновляем кэш ДО gate — иначе токены вне price24h-диапазона
    // теряют дельту в момент перехода в диапазон (Fix A, сохраняем поведение).
    if (!cached) {
      // Цикл 1: первое наблюдение — только затравка, no gate.
      prevQuoteVolCache.set(sym, { prev: curVol, ema: null });
      continue;
    }
    const { prev: prevVol, ema: prevEma } = cached;
    const delta = curVol - prevVol;

    if (prevEma === null) {
      // Цикл 2: инициализируем EMA = delta (без gate — нечего сравнивать).
      prevQuoteVolCache.set(sym, { prev: curVol, ema: Math.max(0, delta) });
      continue;
    }

    // Цикл 3+: обновляем EMA и проверяем gate.
    // Math.max снаружи: отрицательная delta РЕАЛЬНО тянет EMA вниз (симметрично),
    // но итоговое значение не уходит в минус. Если бы клампали delta до подстановки
    // (Math.max(0,delta)), EMA не реагировала бы на затухание — база залипала бы
    // на прошлом спайке надолго.
    const newEma = Math.max(0, 0.3 * delta + 0.7 * prevEma);
    prevQuoteVolCache.set(sym, { prev: curVol, ema: newEma });

    // ── Layer 4: Spot Volume surge ───────────────────────────────────────────
    // Единственное условие: спот объём 1h вырос ≥2x vs 5-цикловое среднее.
    // Фьюч-дельта (delta > EMA × 2.5) убрана — Layer 4 теперь только спот.
    {
      const _peL4 = prescanTracker.get(sym);
      if (_peL4?.spotVolAvg1h && _peL4?.lastSpotVol1h) {
        lastLayerDebug.l4CandidatesTotal++;
      }
      if (
        (_peL4?.spotVolCycles ?? 0) >= 2 &&
        _peL4?.spotVolAvg1h &&
        _peL4?.lastSpotVol1h
      ) {
        const spotMult = _peL4.lastSpotVol1h / _peL4.spotVolAvg1h;
        if (spotMult >= 1.5) {
          const ticker = tickerBySymbol.get(sym);
          if (ticker) {
            volAwakenTickers.push(ticker);
            volAwakenSet.add(sym);
          }
          continue;
        }
      }
    }
  }
  if (volAwakenTickers.length > 0) {
    logger.info(
      {
        count: volAwakenTickers.length,
        symbols: volAwakenTickers.slice(0, 10).map((t) => t.symbol),
      },
      "📊 Layer 4 Volume Awakening: монеты с ускорением объёма вне топ-N",
    );
  }
  lastLayerDebug.l4PassedToBatch = volAwakenTickers.length;
  {
    const l4PrescanWithSpotData = [...prescanTracker.values()].filter(
      (pe) =>
        pe.spotVolAvg1h && pe.lastSpotVol1h && (pe.spotVolCycles ?? 0) >= 2,
    ).length;
    logger.info(
      { total: l4PrescanWithSpotData, passed: volAwakenTickers.length },
      "📊 L4 debug: токенов с spotVol данными / прошло в батч",
    );
  }

  // ── BingX Direct OI — обогащение для BingX-exclusive токенов ─────────────────
  // Для токенов из Layer 4 у которых тикер вернул openInterest: null —
  // запрашиваем OI напрямую per-symbol. Обычно 10-30 токенов → приемлемо.
  {
    const needDirectOI = volAwakenTickers
      .filter((t) => {
        const oiVal = parseFloat(
          (t as unknown as Record<string, string>)["openInterest"] ?? "",
        );
        return isNaN(oiVal) || oiVal === 0;
      })
      .map((t) => t.symbol);

    if (needDirectOI.length > 0) {
      logger.info(
        { count: needDirectOI.length },
        "🔍 BingX Direct OI: запрашиваем для BingX-exclusive токенов",
      );
      try {
        const directOIMap = await batchGetBingxDirectOI(needDirectOI);
        for (const [sym, oi] of directOIMap.entries()) {
          if (oi !== null && oi > 0) {
            const pe = prescanTracker.get(sym);
            if (pe) {
              pe.bingxDirectOI = oi;
            }
            logger.debug(
              { symbol: sym, bingxDirectOI: oi },
              "BingX Direct OI получен",
            );
          }
        }
      } catch (err) {
        logger.warn(
          { err },
          "BingX Direct OI batch failed — продолжаем без него",
        );
      }
    }
  }

  // ── Layer 5: OI Acceleration — ускоряющийся OI без объёмного спайка ──────────
  // Детектирует паттерн "Slow Whale Bleed" (тип ROSE): OI маленький (0.3–1%/30m),
  // но растёт от цикла к циклу: prev=0.3% → cur=0.58% → oiAccel=1.9x.
  // Ни Layer 1–4 не ловят: нет volMult спайка, OI ниже порогов Layer 3.
  // Необходимо: prevOi30m > 0 (значит CG отвечал в прошлом цикле тоже).
  const oiAccelSet = new Set([
    ...activeSymbols,
    ...watchlistSymbolsFound,
    ...topByVolumeSet,
    ...oiMoverTickers.map((t) => t.symbol),
    ...volAwakenTickers.map((t) => t.symbol),
  ]);
  const oiAccelTickers: BingXTicker[] = [];
  for (const [sym, pe] of prescanTracker.entries()) {
    if (oiAccelSet.has(sym)) continue;
    if ((pe.lastOi30m ?? 0) < 0.3) continue; // минимальный OI сигнал
    if ((pe.prevOi30m ?? 0) < 0.15) continue; // прошлый цикл тоже был положительный
    if ((pe.oiAccel30m ?? 0) < 1.3) continue; // ускорение ≥1.3x — не случайный шум
    const ticker = tickerBySymbol.get(sym);
    if (!ticker) continue;
    if (isExhaustedByTicker(sym, ticker.priceChangePercent)) continue;
    oiAccelTickers.push(ticker);
    oiAccelSet.add(sym);
  }
  if (oiAccelTickers.length > 0) {
    logger.info(
      {
        count: oiAccelTickers.length,
        symbols: oiAccelTickers.slice(0, 8).map((t) => {
          const pe = prescanTracker.get(t.symbol);
          return `${t.symbol}(oi=${pe?.lastOi30m?.toFixed(2)}%,x${pe?.oiAccel30m?.toFixed(1)})`;
        }),
      },
      "📈 Layer 5 OI Accel: токены с ускоряющимся OI добавлены в батч",
    );
  }
  lastLayerDebug.l5PassedToBatch = oiAccelTickers.length;

  // ── Layer 8: Steady Climbers — устойчивый рост цены между циклами ────────────
  // Ловит токены которые методично растут +0.8–8% каждые ~10 минут, не попадая
  // в Layer 1-7 (нет объёмного спайка, нет OI-данных или OI слабый).
  // Пример: HOME росло +5-6%/цикл → на момент первого прескана уже +39.9%.
  // Обновляем steadyClimbMap для ВСЕХ ~520 токенов каждый цикл — не только тех,
  // что прошли другие слои. Инжект только если 3+ цикла подряд рост + не перегрет.
  const steadyClimberExcludeSet = new Set([
    ...activeSymbols,
    ...watchlistSymbolsFound,
    ...topByVolumeSet,
    ...oiMoverTickers.map((t) => t.symbol),
    ...volAwakenTickers.map((t) => t.symbol),
    ...oiAccelTickers.map((t) => t.symbol),
  ]);
  const steadyClimberTickers: BingXTicker[] = [];
  const steadyClimberAdded = new Set<string>();

  for (const s of scored) {
    const sym = s.ticker.symbol;
    const curPrice = parseFloat(s.ticker.lastPrice) || 0;
    const price24h = parseFloat(s.ticker.priceChangePercent) || 0;

    const prev = steadyClimbMap.get(sym);
    if (prev && prev.lastPrice > 0 && curPrice > 0) {
      const growthPct = ((curPrice - prev.lastPrice) / prev.lastPrice) * 100;
      if (growthPct >= 0.8 && growthPct <= 8.0) {
        steadyClimbMap.set(sym, {
          growthCycles: prev.growthCycles + 1,
          lastPrice: curPrice,
        });
      } else {
        steadyClimbMap.set(sym, { growthCycles: 0, lastPrice: curPrice });
      }
    } else {
      steadyClimbMap.set(sym, { growthCycles: 0, lastPrice: curPrice });
    }

    const entry = steadyClimbMap.get(sym)!;
    if (
      entry.growthCycles >= 2 && // 3+ точек роста подряд
      price24h >= 0 &&
      price24h < 40 && // не падающий и не перегрет (нижний порог 3%→0%: ранняя детекция при price24h 0-3%)
      !steadyClimberExcludeSet.has(sym)
    ) {
      const ticker = tickerBySymbol.get(sym);
      if (ticker) {
        steadyClimberTickers.push(ticker);
        steadyClimberAdded.add(sym);
      }
    }
  }

  if (steadyClimberTickers.length > 0) {
    logger.info(
      {
        count: steadyClimberTickers.length,
        symbols: steadyClimberTickers.slice(0, 10).map((t) => {
          const e = steadyClimbMap.get(t.symbol);
          return `${t.symbol}(${e?.growthCycles}cyc,p24:${(parseFloat(t.priceChangePercent) || 0).toFixed(1)}%)`;
        }),
      },
      "📈 Layer 8 Steady Climbers: токены с устойчивым ростом добавлены в батч",
    );
  }
  lastLayerDebug.l8SteadyGrowthCycles = [...steadyClimbMap.values()].filter(
    (e) => e.growthCycles >= 2,
  ).length;
  lastLayerDebug.l8PassedToBatch = steadyClimberTickers.length;

  const usdtTickers = [
    ...watchlistTickers,
    ...topByActivity,
    ...topByVolume,
    ...oiMoverTickers,
    ...volAwakenTickers,
    ...oiAccelTickers,
    ...steadyClimberTickers,
  ];
  const scanLimit = activityLimit;

  // ── Quiet Prescan Scan: каждые 3 цикла проверяем паттерны для тихих токенов ──
  // Токены которые давно в prescanTracker (cycleCount > 5) но не попали в активный батч
  // (не прошли Layer 1-4 в этом цикле) никогда не проходят проверку паттернов.
  // Каждые 3 скана добавляем до 50 таких токенов в usdtTickers для полного deep scan.
  // OI данные для них уже свежие (обновлены выше из coinglassOIMap).
  // Сортировка: по lastOi30m desc — самые сильные OI-сигналы первыми.
  if (scanCycleCounter > 1 && scanCycleCounter % 3 === 0) {
    const activeBatchSet = new Set(usdtTickers.map((t) => t.symbol));
    const scoredMap = new Map(scored.map((s) => [s.ticker.symbol, s.ticker]));
    const quietTickers = [...prescanTracker.entries()]
      .filter(
        ([sym, pe]) =>
          !activeBatchSet.has(sym) &&
          Date.now() - (pe.firstSeenAt ?? Date.now()) >= 30 * 60_000,
      )
      .sort(([, a], [, b]) => (b.lastOi30m ?? 0) - (a.lastOi30m ?? 0))
      .slice(0, 50)
      .flatMap(([sym]) => {
        const t = scoredMap.get(sym);
        return t ? [t] : [];
      });
    if (quietTickers.length > 0) {
      usdtTickers.push(...quietTickers);
      logger.info(
        {
          count: quietTickers.length,
          cycle: scanCycleCounter,
          symbols: quietTickers.slice(0, 5).map((t) => t.symbol),
        },
        "🔬 Quiet Prescan: тихие токены добавлены в батч для проверки паттернов",
      );
    }
    lastLayerDebug.quietPrescanAdded = quietTickers.length;
  }

  // ── Layer 7: OI Watch Orphans — cg_building/cg_timeout без prescan ───────────
  // Токены попавшие в OI Watch через cg_building/cg_timeout никогда не проходят
  // prescan → whale_futures условия для них никогда не проверяются.
  // Пример: ROSE (Slow Whale Bleed) — OI накапливается тихо, ни один Layer 1–6
  // не замечает, но cg_building поймал. Инжектируем в батч для полного deep scan.
  {
    const orphanBatchSet = new Set(usdtTickers.map((t) => t.symbol));
    try {
      const orphanRows = await db
        .select({ symbol: oiWatchTable.symbol })
        .from(oiWatchTable)
        .where(
          and(
            inArray(oiWatchTable.triggerTf, [
              "cg_building",
              "cg_timeout",
              "oi24h_accum",
            ]),
            inArray(oiWatchTable.status, ["watching", "confirming"]),
            gt(oiWatchTable.expiresAt, new Date()),
          ),
        )
        .limit(80);
      const scoredBySymbol = new Map(
        scored.map((s) => [s.ticker.symbol, s.ticker]),
      );
      const orphanTickers: BingXTicker[] = [];
      for (const row of orphanRows) {
        if (orphanBatchSet.has(row.symbol)) continue;
        const ticker = scoredBySymbol.get(row.symbol);
        if (!ticker) continue;
        orphanTickers.push(ticker);
        orphanBatchSet.add(row.symbol);
      }
      if (orphanTickers.length > 0) {
        usdtTickers.push(...orphanTickers);
        logger.info(
          {
            count: orphanTickers.length,
            symbols: orphanTickers.map((t) => t.symbol),
          },
          "🔍 Layer 7 OI Watch Orphans: cg_building/cg_timeout/oi24h_accum токены добавлены в батч",
        );
      }
    } catch (err) {
      logger.debug(
        { err },
        "Layer 7 OI Watch Orphans: DB query failed (non-critical)",
      );
    }
  }

  const cgBlindRescueTagSet = new Set<string>(); // заполняется в блоке L6c ниже
  const oiLeaderTagSet = new Set<string>(); // заполняется в блоке L8b ниже

  // ── Layer 6c: Coinalyze Blind OI Rescue ─────────────────────────────────────
  // Когда CG недоступен (timeout) для токена в prescanTracker, но Coinalyze
  // кросс-биржевой агрегат показывает сильный OI (1h ≥ 2%) — инжектируем
  // напрямую в OI Watch (cg_timeout, 3ч) ещё до глубокого скана.
  // Страховка: работает независимо от deep scan — токен в Watch даже если
  // DB упадёт позже в цикле. Layer 7 (следующий цикл) автоматически подхватит.
  // Архетип RE (19.06.2026): CG timeout → SpikeWatcher отклонил → DB error в скане
  // → +17% за 1.5ч без сигнала. Layer 6c добавил бы его в OI Watch заблаговременно.
  {
    const cgBlindRescueSet = new Set(usdtTickers.map((t) => t.symbol));
    const scoredBySymbol6c = new Map(
      scored.map((s) => [s.ticker.symbol, s.ticker]),
    );
    const cgBlindCandidates: Array<{
      symbol: string;
      oiChange30m: number | null;
      price24h: number;
      price: number;
    }> = [];

    for (const [sym, pe] of prescanTracker.entries()) {
      if (pe.cycleCount < 3) continue;
      const cgEntry = coinglassOIMap.get(sym);
      if (cgEntry?.available !== false) continue; // CG работает — rescue не нужен
      const caResult = await getCoinalyzeOI(sym).catch(() => null);
      if (
        !caResult ||
        caResult.oiChange30m === null ||
        caResult.oiChange30m < 1.5
      )
        continue;
      const ticker6c = scoredBySymbol6c.get(sym);
      if (!ticker6c) continue;
      const price24h = parseFloat(ticker6c.priceChangePercent) || 0;
      if (price24h < -5 || price24h > 40) continue;
      if (isExhaustedByTicker(sym, ticker6c.priceChangePercent)) continue;
      const price = parseFloat(ticker6c.lastPrice) || 0;
      if (price <= 0) continue;
      cgBlindCandidates.push({
        symbol: sym,
        oiChange30m: caResult.oiChange30m,
        price24h,
        price,
      });
    }

    if (cgBlindCandidates.length > 0) {
      logger.info(
        {
          count: cgBlindCandidates.length,
          symbols: cgBlindCandidates.map(
            (e) => `${e.symbol}(ca30m:${(e.oiChange30m ?? 0).toFixed(1)}%)`,
          ),
        },
        "🛡 Layer 6c CG Blind Rescue: Coinalyze OI ≥1.5% при CG timeout — проверяем для OI Watch",
      );
      lastLayerDebug.l6cRescuedTotal = cgBlindCandidates.length;
      for (const entry of cgBlindCandidates) {
        try {
          const existing = await db
            .select({ id: oiWatchTable.id })
            .from(oiWatchTable)
            .where(
              and(
                eq(oiWatchTable.symbol, entry.symbol),
                inArray(oiWatchTable.status, ["watching", "confirming"]),
              ),
            )
            .limit(1);
          if (existing.length > 0) continue;

          await dbWriteStrict("oiWatch/L6c-insert", () =>
            db.insert(oiWatchTable).values({
              symbol: entry.symbol,
              triggerTf: "cg_timeout",
              oiChange: entry.oiChange30m ?? 0,
              priceAtEntry: entry.price,
              volumeMultiplier: 1.0,
              sentimentKey: null,
              status: "confirming",
              addedAt: new Date(),
              expiresAt: new Date(Date.now() + 6 * 60 * 60 * 1000), // 6ч (было 3ч)
              avgVolume: 0,
              isVolConfirmed: false,
              oi30mChange: null,
              oi1hChange: entry.oiChange30m,
              oi24hChange: null,
              price1hChange: null,
              price24hChange: entry.price24h,
              volStatusReason: null,
              entryVolMult: 1.0,
              entryCgTurnover: null,
            }),
          );

          // Добавляем в батч текущего цикла для немедленной проверки паттернов
          if (!cgBlindRescueSet.has(entry.symbol)) {
            const ticker6c2 = scoredBySymbol6c.get(entry.symbol);
            if (ticker6c2) {
              usdtTickers.push(ticker6c2);
              cgBlindRescueSet.add(entry.symbol);
              cgBlindRescueTagSet.add(entry.symbol);
            }
          }

          logger.info(
            {
              symbol: entry.symbol,
              caOi30m: (entry.oiChange30m ?? 0).toFixed(1) + "%",
              price24h: entry.price24h.toFixed(1) + "%",
            },
            "🛡 Layer 6c: токен добавлен в OI Watch (cg_timeout, 3ч) + в батч текущего цикла",
          );
          state.oiWatchLastInsertAt = new Date();
          state.oiWatchInsertsLastScan++;
        } catch (err) {
          state.oiWatchInsertErrors++;
          state.oiWatchLastInsertError =
            err instanceof Error ? err.message : String(err);
          logger.warn(
            { err, symbol: entry.symbol },
            "Layer 6c: DB insert failed (non-critical)",
          );
        }
      }
    }
  }

  // ── Layer 8: Proactive OI 24h Leaders → OI Watch ────────────────────────────
  // Берёт топ-100 по OI 24h из CoinGlass coins-markets (данные уже в coinglassOIMap)
  // и немедленно добавляет в OI Watch (status=watching, 12ч). Не ждёт паттерна —
  // это проактивный пул наблюдения. Layer 7 гарантирует инжекцию в батч следующего цикла.
  // Критерии: OI24h ≥ 8%, price24h -5..35%, не перегретые.
  // После вставки — добавляем в usdtTickers текущего цикла для немедленного глубокого скана.
  {
    const layer8Set = new Set(usdtTickers.map((t) => t.symbol));
    const layer8BySymbol = new Map(
      scored.map((s) => [s.ticker.symbol, s.ticker]),
    );
    const oi24hLeaders: Array<{
      symbol: string;
      oi24h: number;
      price: number;
      price24h: number;
      oi30m: number | null;
      oi1h: number | null;
    }> = [];

    for (const [sym, oi] of coinglassOIMap.entries()) {
      if (!oi.available) continue;
      const oi24h = oi.oiChange24h ?? 0;
      if (oi24h < 8) continue;
      const ticker8 = layer8BySymbol.get(sym);
      if (!ticker8) continue;
      const price24h = parseFloat(ticker8.priceChangePercent) || 0;
      if (price24h < -5 || price24h > 40) {
        if (price24h > 40) {
        }
        continue;
      }
      if (isExhaustedByTicker(sym, ticker8.priceChangePercent)) continue;
      const price = parseFloat(ticker8.lastPrice) || 0;
      if (price <= 0) continue;
      oi24hLeaders.push({
        symbol: sym,
        oi24h,
        price,
        price24h,
        oi30m: oi.oiChange30m ?? null,
        oi1h: oi.oiChange1h ?? null,
      });
    }

    oi24hLeaders.sort((a, b) => b.oi24h - a.oi24h);
    const top100Leaders = oi24hLeaders.slice(0, 50);

    if (top100Leaders.length > 0) {
      logger.info(
        {
          total: oi24hLeaders.length,
          taking: top100Leaders.length,
          top5: top100Leaders
            .slice(0, 5)
            .map((e) => `${e.symbol}(oi24h:${e.oi24h.toFixed(1)}%)`),
        },
        "📈 Layer 8: OI 24h лидеры — проверяем для проактивной вставки в OI Watch",
      );

      // Один запрос — все символы уже в вотче (избегаем N запросов в цикле)
      let alreadyWatchingSet = new Set<string>();
      try {
        const watchingRows = await db
          .select({ symbol: oiWatchTable.symbol })
          .from(oiWatchTable)
          .where(inArray(oiWatchTable.status, ["watching", "confirming"]));
        alreadyWatchingSet = new Set(watchingRows.map((r) => r.symbol));
      } catch {
        /* non-critical — если падает, пропускаем цикл */
      }

      let layer8Inserted = 0;
      const layer8NewTickers: BingXTicker[] = [];
      for (const entry of top100Leaders) {
        if (alreadyWatchingSet.has(entry.symbol)) continue;
        try {
          await dbWriteStrict("oiWatch/L8-insert", () =>
            db.insert(oiWatchTable).values({
              symbol: entry.symbol,
              triggerTf: "oi24h_accum",
              oiChange: entry.oi24h,
              priceAtEntry: entry.price,
              volumeMultiplier: 1.0,
              sentimentKey: null,
              status: "watching",
              addedAt: new Date(),
              expiresAt: new Date(Date.now() + 12 * 60 * 60 * 1000), // 12ч
              avgVolume: 0,
              isVolConfirmed: false,
              oi30mChange: entry.oi30m,
              oi1hChange: entry.oi1h,
              oi24hChange: entry.oi24h,
              price1hChange: null,
              price24hChange: entry.price24h,
              volStatusReason: null,
              entryVolMult: 1.0,
              entryCgTurnover: null,
            }),
          );
          alreadyWatchingSet.add(entry.symbol); // дедуп внутри цикла
          layer8Inserted++;
          state.oiWatchLastInsertAt = new Date();
          state.oiWatchInsertsLastScan++;

          // Добавляем в батч текущего цикла для немедленного глубокого скана
          if (!layer8Set.has(entry.symbol)) {
            const t8 = layer8BySymbol.get(entry.symbol);
            if (t8) {
              layer8NewTickers.push(t8);
              layer8Set.add(entry.symbol);
              oiLeaderTagSet.add(entry.symbol);
            }
          }
        } catch (err) {
          state.oiWatchInsertErrors++;
          state.oiWatchLastInsertError =
            err instanceof Error ? err.message : String(err);
          logger.debug(
            { err, symbol: entry.symbol },
            "Layer 8: OI Watch insert failed (non-critical)",
          );
        }
      }
      if (layer8NewTickers.length > 0) usdtTickers.push(...layer8NewTickers);
      if (layer8Inserted > 0) {
        logger.info(
          {
            inserted: layer8Inserted,
            injectedToBatch: layer8NewTickers.length,
          },
          "📈 Layer 8: OI 24h лидеры добавлены в OI Watch (12ч) + в батч текущего цикла",
        );
      }
      lastLayerDebug.l8bOiLeadersTotal = oi24hLeaders.length;
      lastLayerDebug.l8bInsertedToWatch = layer8Inserted;
    }
  }

  // ── Cycle candidates snapshot (for UI tab) ───────────────────────────────────
  {
    const wlSet = new Set(watchlistTickers.map((t) => t.symbol));
    const actSet = new Set(topByActivity.map((t) => t.symbol));
    const volSet = new Set(topByVolume.map((t) => t.symbol));
    const oiSet = new Set(oiMoverTickers.map((t) => t.symbol));
    const vaSet = new Set(volAwakenTickers.map((t) => t.symbol));
    const oacSet = new Set(oiAccelTickers.map((t) => t.symbol));
    const scSet = new Set(steadyClimberTickers.map((t) => t.symbol));
    const scoreMap = new Map(scored.map((s) => [s.ticker.symbol, s.score]));
    const seen = new Set<string>();
    lastCycleCandidates = [];
    lastCycleLayers.clear();
    for (const t of usdtTickers) {
      if (seen.has(t.symbol)) continue;
      seen.add(t.symbol);
      const layers: string[] = [];
      if (wlSet.has(t.symbol)) layers.push("WL");
      if (actSet.has(t.symbol)) layers.push("L1");
      if (volSet.has(t.symbol)) layers.push("L2");
      if (oiSet.has(t.symbol)) layers.push("L3");
      if (vaSet.has(t.symbol)) layers.push("L4");
      if (oacSet.has(t.symbol)) layers.push("L5");
      if (cgBlindRescueTagSet.has(t.symbol)) layers.push("L6c");
      if (oiLeaderTagSet.has(t.symbol)) layers.push("L8b");
      // L8: поведенческий тег — навешивается на любой токен в пуле у которого
      // 3+ цикла устойчивого роста, независимо от того через какой слой он попал.
      // scSet — discovery (не дублирует пул); steadyClimbMap — полная поведенческая картина.
      {
        const sc = steadyClimbMap.get(t.symbol);
        const p24 = parseFloat(t.priceChangePercent) || 0;
        if (sc && sc.growthCycles >= 2 && p24 >= 0 && p24 < 40)
          layers.push("L8");
        else if (scSet.has(t.symbol)) layers.push("L8");
      }
      if (layers.length === 0) layers.push("L7");
      lastCycleLayers.set(t.symbol, layers);
      const _pe = prescanTracker.get(t.symbol);
      if (_pe) _pe.layers = layers;
      lastCycleCandidates.push({
        symbol: t.symbol,
        layers,
        price24h: parseFloat(t.priceChangePercent) || 0,
        price: parseFloat(t.lastPrice) || 0,
        score: scoreMap.get(t.symbol) ?? 0,
        cycledAt: Date.now(),
      });
    }
    lastCycleAt = Date.now();
    lastLayerDebug.cycleNumber = scanCycleCounter;
  }

  // ── Spot Pool: запускаем фоновое обновление кэша (non-blocking) ──────────────
  // Первый цикл — кэш холодный, фильтр пропускает оптимистично.
  // Через 30 мин кэш прогреется и ранний фильтр начнёт отсекать неликвид до klines.
  triggerRefresh(usdtTickers.map((t) => t.symbol));

  const topScore = scored[0]?.score?.toFixed(1) ?? "0";
  logger.info(
    {
      count: usdtTickers.length,
      watchlist: watchlistTickers.length,
      byActivity: topByActivity.length,
      byVolume: topByVolume.length,
      byOI: oiMoverTickers.length,
      bySteadyClimb: steadyClimberTickers.length,
      volSource: useCgVolume
        ? `CoinGlass(cache=${cgVolumeCache.size})`
        : "BingX",
      totalTokens: scored.length,
      topScore,
      top5: scored
        .slice(0, 5)
        .map((s) => `${s.ticker.symbol}(${s.score.toFixed(1)})`),
      watchlistSymbols: watchlistTickers.map((t) => t.symbol),
    },
    "Pre-screened tokens for deep scan",
  );

  // Top-10 pre-screened symbols — любой skip для них логируется на info (не debug)
  const topPrescanSymbols = new Set(
    scored.slice(0, 10).map((s) => s.ticker.symbol),
  );

  // ── Persistent Pre-screen Tracker: обновляем счётчики ───────────────────────
  {
    const nowTs = Date.now();

    // currentTopSymbols включает ВСЕ слои глубокого скана: Layer 1 (activity),
    // Layer 3 (OI movers) и Layer 4 (VolAwaken) + watchlist.
    // Ранее — только Layer 1 → OI-муверы за пределами топ-50 удалялись каждый цикл
    // и никогда не накапливали cycleCount и OI-данные.
    const currentTopSymbols = new Set([
      ...topByActivity.map((t) => t.symbol),
      ...oiMoverTickers.map((t) => t.symbol),
      ...volAwakenTickers.map((t) => t.symbol),
      ...watchlistTickers.map((t) => t.symbol),
      ...oiAccelTickers.map((t) => t.symbol), // Layer 5 — иначе удаляются каждый цикл
    ]);

    // Удаляем токены, которые вышли из пула глубокого скана в этом цикле.
    // Сохраняем cycleCount перед удалением — если токен вернётся в следующем цикле
    // (напр. L2-токен с нестабильной активностью), он продолжит счёт, а не сбросится в 1.
    const savedCycleCounts = new Map<string, number>();
    for (const sym of prescanTracker.keys()) {
      if (!currentTopSymbols.has(sym)) {
        const pe = prescanTracker.get(sym)!;

        // Coverage-фикс: если spot_vol_* ещё не накопил 2 цикла — держим кандидата
        // в пуле ещё немного, вместо немедленного удаления (см. SPOT_VOL_GRACE_CYCLES).
        const needsSpotVolGrace = (pe.spotVolCycles ?? 0) < 2;
        if (needsSpotVolGrace) {
          pe.droppedFromPoolCycles = (pe.droppedFromPoolCycles ?? 0) + 1;
          if (pe.droppedFromPoolCycles <= SPOT_VOL_GRACE_CYCLES) {
            continue; // ещё один льготный цикл — не удаляем
          }
        }

        savedCycleCounts.set(sym, pe.cycleCount);
        prescanTracker.delete(sym);
      } else {
        // Вернулся в пул до истечения льготного периода — сбрасываем счётчик.
        const pe = prescanTracker.get(sym);
        if (pe && pe.droppedFromPoolCycles) pe.droppedFromPoolCycles = 0;
      }
    }

    // Обновляем или добавляем токены из Layer 1 (с трекингом score и ранга)
    for (let rank = 0; rank < scored.slice(0, activityLimit).length; rank++) {
      const s = scored[rank]!;
      const sym = s.ticker.symbol;
      const price24h = parseFloat(s.ticker.priceChangePercent) || 0;

      // Экстремальный памп или дамп: цена улетела >300% или <-300% за 24ч — в prescan не добавляем.
      // Явная знаковая проверка: price24h хранится со знаком (отрицательный = падение).
      if (price24h > 300 || price24h < -300) {
        prescanTracker.delete(sym);
        continue;
      }

      const lastPrice = parseFloat(s.ticker.lastPrice) || 0;
      const rankOneBased = rank + 1;
      const existing = prescanTracker.get(sym);
      if (existing) {
        existing.cycleCount++;
        // Сохраняем последнее ненулевое значение: BingX иногда возвращает "0" для priceChangePercent
        // при мизерном futures-объёме или в момент ресета 24h-окна — перетирать корректные данные нулём не нужно.
        existing.lastPrice24h = price24h || existing.lastPrice24h;
        existing.lastPrice = lastPrice;
        existing.lastScore = s.score;

        if (rankOneBased < existing.bestRank) existing.bestRank = rankOneBased;
      } else {
        const prevCount = savedCycleCounts.get(sym) ?? 0;
        prescanTracker.set(sym, {
          firstPrice24h: price24h,
          lastPrice24h: price24h,
          firstSeenAt: nowTs,
          firstPrice: lastPrice,
          cycleCount: prevCount + 1,
          bestRank: rankOneBased,
          lastScore: s.score,
          firstScore: s.score,
          lastPrice: lastPrice,
          lastFiredAt: 0,
        });
      }
    }

    // Обновляем или добавляем токены из Layer 3 (OI movers), Layer 4 (VolAwaken), Layer 8 (Steady Climbers).
    // Они сканируются глубоко — должны накапливать cycleCount и получать OI-данные.
    for (const ticker of [
      ...oiMoverTickers,
      ...volAwakenTickers,
      ...steadyClimberTickers,
    ]) {
      const sym = ticker.symbol;
      const price24h = parseFloat(ticker.priceChangePercent) || 0;
      // Явная знаковая проверка: price24h хранится со знаком.
      if (price24h > 300 || price24h < -300) {
        prescanTracker.delete(sym);
        continue;
      }
      const lastPrice = parseFloat(ticker.lastPrice) || 0;
      const existing = prescanTracker.get(sym);
      if (existing) {
        existing.cycleCount++;
        existing.lastPrice24h = price24h || existing.lastPrice24h;
        existing.lastPrice = lastPrice;
      } else {
        const prevCount = savedCycleCounts.get(sym) ?? 0;
        prescanTracker.set(sym, {
          firstPrice24h: price24h,
          lastPrice24h: price24h,
          firstSeenAt: nowTs,
          firstPrice: lastPrice,
          cycleCount: prevCount + 1,
          bestRank: activityLimit + 1, // за пределами топ-N activity
          lastScore: 0,
          firstScore: 0,

          lastPrice: lastPrice,
          lastFiredAt: 0,
        });
      }
    }

    // Обновляем или добавляем токены из Layer 0 (watchlist).
    // Они включены в currentTopSymbols (не удаляются из prescanTracker),
    // но без этого блока никогда не получали prescanTracker.set() →
    // inPrescan = false, price = null для watchlist-токенов.
    for (const ticker of watchlistTickers) {
      const sym = (ticker as BingXTicker).symbol;
      const price24h =
        parseFloat((ticker as BingXTicker).priceChangePercent) || 0;
      const lastPrice = parseFloat((ticker as BingXTicker).lastPrice) || 0;
      const existing = prescanTracker.get(sym);
      if (existing) {
        existing.cycleCount++;
        existing.lastPrice24h = price24h || existing.lastPrice24h;
        existing.lastPrice = lastPrice;
      } else {
        const prevCount = savedCycleCounts.get(sym) ?? 0;
        prescanTracker.set(sym, {
          firstPrice24h: price24h,
          lastPrice24h: price24h,
          firstSeenAt: nowTs,
          firstPrice: lastPrice,
          cycleCount: prevCount + 1,
          bestRank: 9999, // watchlist — вне ранжирования по активности
          lastScore: 0,
          firstScore: 0,

          lastPrice: lastPrice,
          lastFiredAt: 0,
        });
      }
    }
  }

  // Persist prescan state to DB after every cycle so cycleCount survives restarts
  void savePrescanToDb();

  // ── Heating Alert: DISABLED — спамит, не несёт ценности в текущем виде ────────
  // {
  //   const HEAT_MIN_CYCLES  = 3;
  //   const HEAT_MIN_P24H    = 3.0;
  //   const HEAT_MAX_P24H    = 20.0;
  //   const HEAT_COOLDOWN_MS = 60 * 60 * 1000;
  //   const nowTs = Date.now();
  //
  //   const heatCandidates: Array<{ sym: string; entry: PrescanEntry }> = [];
  //   for (const [sym, entry] of prescanTracker.entries()) {
  //     if (entry.cycleCount < HEAT_MIN_CYCLES)                                         continue;
  //     if (entry.lastPrice24h < HEAT_MIN_P24H || entry.lastPrice24h > HEAT_MAX_P24H)   continue;
  //     const lastAlert = heatingAlertThrottle.get(sym) ?? 0;
  //     if (nowTs - lastAlert < HEAT_COOLDOWN_MS)                                        continue;
  //     heatCandidates.push({ sym, entry });
  //   }
  //
  //   if (heatCandidates.length > 0) {
  //     let oiWatchSyms = new Set<string>();
  //     let activeSignalSyms = new Set<string>();
  //     try {
  //       const [oiRows, sigRows] = await Promise.all([
  //         db.select({ symbol: oiWatchTable.symbol })
  //           .from(oiWatchTable)
  //           .where(inArray(oiWatchTable.status, ["watching", "confirming"])),
  //         db.select({ symbol: trackedSignalsTable.symbol })
  //           .from(trackedSignalsTable)
  //           .where(inArray(trackedSignalsTable.status, ["active", "in_run", "accumulation", "re_entry"])),
  //       ]);
  //       oiWatchSyms       = new Set(oiRows.map(r => r.symbol));
  //       activeSignalSyms  = new Set(sigRows.map(r => r.symbol));
  //     } catch (err) {
  //       logger.warn({ err }, "HeatingAlert: DB lookup failed — пропускаем цикл");
  //     }
  //
  //     for (const { sym, entry } of heatCandidates) {
  //       if (oiWatchSyms.has(sym) || activeSignalSyms.has(sym)) continue;
  //       if (entry.lastPrice <= entry.firstPrice)                 continue;
  //
  //       heatingAlertThrottle.set(sym, nowTs);
  //
  //       const p24h   = entry.lastPrice24h.toFixed(1);
  //       const cycles = entry.cycleCount;
  //       const cycleWord = cycles >= 5 ? "циклов" : cycles >= 2 ? "цикла" : "цикл";
  //       const cvdLine = entry.lastCvdOk === true
  //         ? "CVD подтверждает ✅"
  //         : entry.lastCvdOk === false
  //           ? "CVD пока не подтверждает"
  //           : "CVD нет данных";
  //
  //       const msg =
  //         `👀 <b>${sym.replace("-USDT", "")}</b> греется: ` +
  //         `в топ пресканера <b>${cycles} ${cycleWord}</b>, ` +
  //         `price24h <b>+${p24h}%</b> — ${cvdLine}`;
  //
  //       try {
  //         await broadcastRawAlert(msg);
  //         logger.info({ sym, cycles, p24h, cvdOk: entry.lastCvdOk }, "HeatingAlert: отправлен");
  //       } catch (err) {
  //         logger.warn({ err, sym }, "HeatingAlert: ошибка отправки");
  //       }
  //     }
  //   }
  // }

  // ── Phase 1: CoinGlass OI universe уже загружен на этапе OI Discovery ────────
  // coinglassOIMap содержит данные для всех ~500 токенов (из кэша или API).
  // Повторного запроса не нужно — данные свежие (только что получены выше).
  const oiMoversCount = oiMoverTickers.length;
  // cgVolumeCache is now populated from runSpotVolBatch (FS volume ratio endpoint: futures_vol_usd 24h).
  // The old cgVolUsd path (from OI snapshot) is always null since OHLC migration — nothing to update here.
  logger.info(
    {
      universe: allBingxSymbols.length,
      oiMovers: oiMoversCount,
      scanPool: usdtTickers.length,
      cgCacheSize: cgVolumeCache.size,
    },
    "CoinGlass OI universe complete",
  );

  // ── Volume Breakout Spot: чистый спот-объём spike ─────────────────────────
  // Fires on pure spot-volume surge ≥2.5x avg — independent of futures score
  // or ranking. Triggers from prescanTracker spot fields (CoinGlass spot vol).
  // Mandatory CVD gate (no graceful fallback). Separate 4h cooldown from VB_futures.
  {
    const VBS_MIN_MULT = 2.5; // spotVolMult ≥ 2.5x (ретроспектива 753 кейсов; 3.0 было слишком строгим)
    // ИСТОРИЯ ПОРОГА: 2.5x → 3.0x по анализу 24 сигналов:
    //   При 2.5–2.9x: 2 hard-стопа (BANANA -14.19%, TAC -10.95%), WR 50%
    //   При ≥3.0x: 0 hard-стопов, все исходы — profit/B/E/cancel, WR 100%
    //   Потери: COOKIE(2.6x ✅) и US(2.7x ✅) — но компенсировано устранением обоих стопов
    const VBS_MIN_CYCLES = 3; // ≥3 cycles with spot data (cold-start guard)
    const VBS_COOLDOWN_MS = 4 * 60 * 60 * 1000; // 4h per symbol
    const VBS_MIN_SPOT_MCAP_PCT = 0.015; // spotVol24h ≥ 1.5% MCap (ретроспектива: 3% отсекало 55% кейсов без улучшения avg peak)
    const VBS_MAX_PER_CYCLE = 4; // не более 4 VBS-сигналов за один скан-цикл
    // ПРИЧИНА ЛИМИТА: 1 июля 2026 — 10 сигналов за один день при рыночном vol-всплеске.
    // Одновременный спот-объём на десятках токенов = рыночное событие, не токен-специфический сигнал.
    const nowTs = Date.now();
    const vbsFired: string[] = [];
    // Build scored lookup for live price/volume (fallback to prescan data if absent)
    const vbsScored = new Map(scored.map((s) => [s.ticker.symbol, s]));
    // Funnel counters: диагностика тихих pre-gate отказов (не видны в PDB)
    let _vbsNoCycles = 0,
      _vbsNoData = 0,
      _vbsMultLow = 0,
      _vbsPdbChecked = 0;

    for (const [sym, entry] of prescanTracker.entries()) {
      // Лимит на цикл — не более VBS_MAX_PER_CYCLE сигналов за один скан
      if (vbsFired.length >= VBS_MAX_PER_CYCLE) break;

      // Gate: нужно ≥3 циклов со спот-данными
      if ((entry.spotVolCycles ?? 0) < VBS_MIN_CYCLES) {
        _vbsNoCycles++;
        continue;
      }
      if ((entry.cycleCount ?? 0) < 10) {
        _vbsNoCycles++;
        continue;
      }
      if (!entry.spotVolAvg1h || !entry.lastSpotVol1h) {
        _vbsNoData++;
        continue;
      }

      // Trigger: spotVolMult ≥ 2.5x
      const spotVolMult = entry.lastSpotVol1h / entry.spotVolAvg1h;
      if (spotVolMult < VBS_MIN_MULT) {
        _vbsMultLow++;
        continue;
      }
      _vbsPdbChecked++;
      _pdbCheck("spot_vol_accumulation");

      // Cooldown (независимый от VB_futures)
      const lastFired = _vbSpotLastFiredAt.get(sym) ?? 0;
      if (lastFired > 0 && nowTs - lastFired < VBS_COOLDOWN_MS) continue;

      // Фильтр перегрева/обвала
      // Верхний порог: +20% (снижен 40→20 по данным 12 SVA-сигналов 27.07.2026:
      //   SOLV p24h=+19.3% → стоп -6.4%; выигрыши ZBT/FHE оба p24h≈0% — никто выше 5% не выиграл).
      // Нижний порог: -10% (история: -40% → -10% после TAC Jul-1 ❌STOP с p24h ≈ -20..−30%).
      const p24h = entry.lastPrice24h;
      if (p24h > 20 || p24h < -10) {
        if (p24h <= -10) {
          logger.info(
            { sym, p24h: p24h.toFixed(1) + "%" },
            "VolBreakoutSpot: p24h < -10% — нисходящий тренд, не breakout",
          );
        } else {
          logger.info(
            { sym, p24h: p24h.toFixed(1) + "%" },
            "VolBreakoutSpot: p24h > 20% — токен уже перегрет (снижено с 40%, данные 27.07.2026)",
          );
        }
        continue;
      }

      // Price-1h gate (добавлен 2026-07-27 по ретроспективе 11 SVA-сигналов):
      // Если цена падала в момент объёмного спайка, спайк = паника продавцов, не накопление.
      // Ретроспектива: BANK(p1h=-2.79%→peak 4%), TAIKO(p1h=-0.07%→1%), OPN(p1h=-0.28%→1.7%) — все стоп/отмены.
      // Успешные: ZBT(p1h=null→+30.7%), FHE(p1h=+0.25%→+10.6%) — null = fail-open, не блокирует.
      // Fail-open: если данные отсутствуют (lastPrice1h=null) — пропускаем проверку.
      {
        const _vbsPrice1h = entry.lastPrice1h ?? null;
        if (_vbsPrice1h !== null && _vbsPrice1h < 0) {
          _pdbReject("spot_vol_accumulation", "price1h_falling");
          _symRej(
            sym,
            "spot_vol_accumulation",
            "price1h_falling",
            entry.lastOi30m ?? null,
            spotVolMult,
            p24h,
            entry.cycleCount ?? null,
          );
          logger.info(
            { sym, price1h: _vbsPrice1h.toFixed(2) + "%" },
            "VolBreakoutSpot: price1h < 0 — цена падает, объём = паника продавцов, skip",
          );
          continue;
        }
      }

      // OI gate (смягчено 2026-07-10): раньше требовался строго положительный OI
      // на ВСЕХ 4 ТФ разом (5m/30m/1h/4h) — это отсекало ~72% отказов из-за
      // естественного шума на коротких ТФ. Теперь допускается ОДИН ТФ в
      // небольшом минусе (> -0.5%), остальные три обязаны быть строго
      // положительными. Отсутствие данных по-прежнему = обязательный отказ.
      {
        const cgOiFloor = coinglassOIMap.get(sym);
        const _vbsPe = prescanTracker.get(sym);
        const _vbsP24h = _vbsPe?.lastPrice24h ?? 0;
        const _vbsCycles = _vbsPe?.cycleCount ?? null;
        // OI gate fail-open: spot_vol_accumulation — спот-driven паттерн; OI вторичен.
        // Ретроспектива: 40% кейсов spot ≥2.5x не имели CG OI данных, но дали avg peak схожий.
        // Жёсткий skip при отсутствии CG убивал все BingX-exclusive токены.
        if (cgOiFloor?.available) {
          const oiTfs = {
            "30m": cgOiFloor.oiChange30m,
            "1h": cgOiFloor.oiChange1h,
            "4h": cgOiFloor.oiChange4h,
          };
          // Только жёсткий сигнал дистрибуции блокирует: OI4h < -3% (монеты сливают лонги на 4ч)
          const oi4hVal = oiTfs["4h"];
          if (oi4hVal !== null && oi4hVal !== undefined && oi4hVal < -3) {
            _pdbReject("spot_vol_accumulation", "oi4h_heavy_unwind");
            _symRej(
              sym,
              "spot_vol_accumulation",
              "oi4h_heavy_unwind",
              cgOiFloor.oiChange30m ?? null,
              null,
              _vbsP24h,
              _vbsCycles,
            );
            logger.info(
              { sym, oi4h: oi4hVal.toFixed(2) },
              "VolBreakoutSpot: skip — OI4h < -3% (дистрибуция на 4ч TF)",
            );
            continue;
          }

          // OI1h declining gate: спот-памп при падающем фьюч OI1h = ложное накопление.
          // ДАННЫЕ (12 SVA-сигналов, 27.07.2026): BANK oi1h=-2.2% → стоп -12.5%;
          // TAIKO oi1h=-2.3% → стоп -6.3%; ZBT oi1h=+2.0% и FHE oi1h=+0.2% — оба выигрыши.
          // Порог -1% (а не 0): небольшой шум на 1h не должен блокировать.
          // Fail-open: только когда CG доступен и значение явно отрицательное.
          const oi1hVal = oiTfs["1h"];
          if (oi1hVal !== null && oi1hVal !== undefined && oi1hVal < -1.0) {
            _pdbReject("spot_vol_accumulation", "oi1h_declining");
            _symRej(
              sym,
              "spot_vol_accumulation",
              "oi1h_declining",
              cgOiFloor.oiChange30m ?? null,
              null,
              _vbsP24h,
              _vbsCycles,
            );
            logger.info(
              { sym, oi1h: oi1hVal.toFixed(2) },
              "VolBreakoutSpot: skip — OI1h < -1% (фьюч OI разворачивается, спот-памп против тренда)",
            );
            continue;
          }
        }
      }

      // CycleCount gates: нижний (листинговый спайк) и верхний (слишком зрелый токен).
      // Нижний: минимум 3 цикла — отсекает листинговые спайки.
      // Верхний (27.07.2026): ДАННЫЕ (10 SVA-сигналов) — победители ZBT(10ц) и FHE(11ц);
      //   стопы/отмены: OPN(458), TAIKO(428), BANK(781), EPIC(401), M(361), SCRT(473) — 6 из 8 плохих.
      //   Порог 25 — с запасом над победителями (10–11); SOLV(6)/ALPINE(4) — исключения, проходят.
      {
        const _vbsCycleCount = prescanTracker.get(sym)?.cycleCount ?? 0;
        if (_vbsCycleCount < 3) {
          _pdbReject("spot_vol_accumulation", "cycles_too_low");
          logger.debug(
            { sym, cycles: _vbsCycleCount },
            "VolBreakoutSpot: skip — cycleCount < 3 (листинговый спайк)",
          );
          continue;
        }
        if (_vbsCycleCount > 25) {
          _pdbReject("spot_vol_accumulation", "cycles_too_high");
          _symRej(
            sym,
            "spot_vol_accumulation",
            "cycles_too_high",
            null,
            spotVolMult,
            p24h,
            _vbsCycleCount,
          );
          logger.info(
            { sym, cycles: _vbsCycleCount },
            "VolBreakoutSpot: skip — cycleCount > 25 (слишком зрелый; медиана стоп/отмен ≥380)",
          );
          continue;
        }
      }

      // Re-entry gate: stop_loss за последние 12ч
      try {
        const recentStop = await db
          .select({ id: trackedSignalsTable.id })
          .from(trackedSignalsTable)
          .where(
            and(
              eq(trackedSignalsTable.symbol, sym),
              eq(trackedSignalsTable.status, "stop_loss"),
              gte(
                trackedSignalsTable.closedAt,
                new Date(Date.now() - 12 * 60 * 60 * 1000),
              ),
            ),
          )
          .limit(1);
        if (recentStop.length > 0) {
          logger.info(
            { sym, spotVolMult: spotVolMult.toFixed(2) + "x" },
            "VolBreakoutSpot: skip — stop_loss за последние 12ч",
          );
          continue;
        }
      } catch {
        /* non-critical */
      }

      // Skip если CoinGlass OI даёт ЭКСТРЕМАЛЬНЫЙ фьюч-сигнал — основной flow справится.
      // Бэктест: volume_breakout_spot (EV +3.6, лучший паттерн) → spot_vol_accumulation 1/60д.
      // Причина: старый порог 8%/6% блокировал большинство реальных spot-breakout кандидатов
      // (pump = spot vol ≥2.5x + OI обычно 6-10%). Поднято до 15%/10% — пропускает умеренный OI.
      const cgOI = coinglassOIMap.get(sym);
      if (cgOI?.available) {
        const hasOISignal =
          Math.abs(cgOI.oiChange30m ?? 0) >= 15.0 ||
          Math.abs(cgOI.oiChange1h ?? 0) >= 10.0;
        if (hasOISignal) continue;
      }

      const vbsScoredEntry = vbsScored.get(sym);
      const currentPrice = vbsScoredEntry
        ? parseFloat(vbsScoredEntry.ticker.lastPrice) || entry.lastPrice
        : entry.lastPrice;
      const quoteVol = vbsScoredEntry
        ? parseFloat(vbsScoredEntry.ticker.quoteVolume) || 0
        : 0;
      const tradingViewUrl = `https://www.tradingview.com/chart/?symbol=BYBIT:${sym.replace("-", "")}`;
      const bingxUrl = `https://bingx.com/en-us/perpetual/${sym}/`;

      // Spot MCap gate: spotVol24h ≥ 3% MCap (VBS-специфичный, выше универсального 1%, не менять)
      // Use FS volume cache (30-min TTL, warmed by runSpotVolBatch) — cache hit path, no extra API call.
      const [fsVol, vbsMcapData] = await Promise.all([
        getFsVolume(sym).catch(() => null),
        fetchMarketCap(sym).catch(() => null),
      ]);
      const spotVol24h = fsVol?.spotVolUsd24h ?? null;
      const vbsMcapUsd = vbsMcapData?.mcap ?? null;
      {
        const poolEntry = getSpotPoolEntry(sym);
        const effectiveSpot = spotVol24h ?? poolEntry?.spotVol24h ?? null;
        const effectiveMcap = vbsMcapUsd ?? poolEntry?.mcapUsd ?? null;
        if (
          effectiveSpot !== null &&
          effectiveMcap !== null &&
          effectiveSpot < effectiveMcap * VBS_MIN_SPOT_MCAP_PCT
        ) {
          const pct = ((effectiveSpot / effectiveMcap) * 100).toFixed(3);
          logger.info(
            { sym, effectiveSpot, effectiveMcap, pct },
            "VolBreakoutSpot: спот-объём < 3% MCap — пропущен",
          );
          continue;
        }
      }

      // CVD Gate — обязательный (нет graceful fallback)
      let _vbsEntryCvd30m: boolean | null = null;
      let _vbsEntryCvd1h: boolean | null = null;
      let _vbsEntryCvd4h: boolean | null = null;
      {
        const [vbsSpotTaker, vbsSpotCvd] = await Promise.all([
          getSpotTakerFlow(sym).catch(() => null),
          getSpotCvdMtf(sym).catch(() => null),
        ]);
        if (vbsSpotCvd?.available) {
          _vbsEntryCvd30m = vbsSpotCvd.cvd30m ?? null;
          _vbsEntryCvd1h = vbsSpotCvd.cvd1h ?? null;
          _vbsEntryCvd4h = vbsSpotCvd.cvd4h ?? null;
        }

        // Нет данных вообще → skip
        if (!vbsSpotTaker?.available && !vbsSpotCvd?.available) {
          logger.info(
            { sym },
            "VolBreakoutSpot: нет CVD данных — skip (обязательный gate)",
          );
          continue;
        }

        // Нужно явное положительное подтверждение
        const vbsCvdPositive =
          (vbsSpotTaker?.available && (vbsSpotTaker.netBuyPct ?? 0) > 0) ||
          (vbsSpotCvd?.available &&
            (vbsSpotCvd.cvd30m === true || vbsSpotCvd.cvd1h === true));
        if (!vbsCvdPositive) {
          logger.info(
            {
              sym,
              spotTakerNetBuy: vbsSpotTaker?.netBuyPct ?? "n/a",
              spotCvd30m: vbsSpotCvd?.cvd30m ?? "n/a",
            },
            "VolBreakoutSpot: нет положительного CVD подтверждения — skip",
          );
          continue;
        }

        // MTF Gate — cvd1h обязателен; cvd4h fail-open (4h может быть neg если был дип).
        // Ретроспектива: 45% кейсов с cvd1h=true но cvd4h=false дали avg peak =+19% vs +21%.
        // cvd4h=false больше не блокирует — только если NO CVD данных вообще → skip.
        if (!vbsSpotCvd?.available || vbsSpotCvd.cvd1h !== true) {
          _pdbReject("spot_vol_accumulation", "cvd_1h_fail");
          _symRej(
            sym,
            "spot_vol_accumulation",
            "cvd_1h_fail",
            null,
            null,
            prescanTracker.get(sym)?.lastPrice24h ?? 0,
            prescanTracker.get(sym)?.cycleCount ?? null,
          );
          logger.info(
            {
              sym,
              cvd30m: vbsSpotCvd?.cvd30m ?? "n/a",
              cvd1h: vbsSpotCvd?.cvd1h ?? "n/a",
              cvd4h: vbsSpotCvd?.cvd4h ?? "n/a",
            },
            "VolBreakoutSpot: cvd1h не true — skip",
          );
          continue;
        }
      }

      // Все gates пройдены — фиксируем cooldown
      _vbSpotLastFiredAt.set(sym, nowTs);
      vbsFired.push(sym);

      // INSERT — только после прохождения всех gate-ов
      _pdbPass("spot_vol_accumulation");
      let vbsInsertedId: number | undefined;
      try {
        const [ins] = await dbWriteStrict("signals/vbs-insert", () =>
          db
            .insert(signalsTable)
            .values({
              symbol: sym,
              type: "alpha",
              value: spotVolMult,
              threshold: VBS_MIN_MULT,
              price: currentPrice,
              priceChangePercent: p24h,
              volume24h: quoteVol,
              avgVolume: 0,
              openInterest: null,
              oiChangePercent: 0,
              fundingRate: null,
              tradingViewUrl,
              sentiment: "Объёмный пробой (спот)",
              sentimentKey: "spot_vol_accumulation" as const,
              alphaScore: 7,
              isContinuing: false,
              cumulativeOiChange: 0,
            })
            .returning({ id: signalsTable.id }),
        );
        vbsInsertedId = ins?.id;
      } catch (err) {
        logger.error(
          { err, sym },
          "VolBreakoutSpot: insert failed after retries — signal dropped",
        );
      }

      if (!vbsInsertedId) continue;

      let vbsTracked: Awaited<ReturnType<typeof trackSignal>> = false;
      try {
        vbsTracked = await trackSignal({
          symbol: sym,
          signalId: vbsInsertedId,
          signalType: "alpha",
          sentiment: "Объёмный пробой (спот)",
          sentimentKey: "spot_vol_accumulation",
          alphaScore: 7,
          entryPrice: await getFreshPrice(sym, currentPrice),
          entryOi: null,
          entryCvd30m: _vbsEntryCvd30m,
          entryCvd1h: _vbsEntryCvd1h,
          entryCvd4h: _vbsEntryCvd4h,
          entryOi30m: entry.lastOi30m ?? null,
          entryOi1h: entry.lastOi1h ?? null,
          entryOi4h: entry.lastOi4h ?? null,
          entrySpotVolMult: spotVolMult,
          entryFutVolMult: null,
        });
      } catch (err) {
        logger.warn(
          { err, sym },
          "VolBreakoutSpot: trackSignal failed — broadcast отменён",
        );
      }
      if (vbsTracked === false || vbsTracked === "skip") {
        logger.info(
          { sym, result: vbsTracked },
          "VolBreakoutSpot: trackSignal вернул skip/false — broadcast пропущен",
        );
        continue;
      }

      // Новый сигнал выдан — обнуляем cycleCount чтобы повторный fire не
      // блокировался гейтом cycleCount > 25 и UI показывал циклы с последнего сигнала.
      resetPrescanCycleCount(sym);

      const vbsResult: AlphaResult = {
        symbol: sym,
        grade: "alpha",
        price: currentPrice,
        priceChange30m: p24h,
        currentVolume: quoteVol,
        avgVolume: 0,
        volumeMultiplier: spotVolMult,
        oiChangePercent: 0,
        openInterest: 0,
        cmcRank: null,
        cmcSource: null,
        cmcAvailable: false,
        liquidationsUsd: null,
        liquidationsMultiple: null,
        coinglassAvailable: false,
        globalOiChange: null,
        globalOiConfirmed: false,
        isNewListing: false,
        isExhaustedSqueeze: false,
        pumpFromOpen: null,
        candleCount: 0,
        sentiment: "Объёмный пробой (спот)",
        sentimentKey: "spot_vol_accumulation",
        traderAction: `LONG (спот-объём ×${spotVolMult.toFixed(1)} от среднего, SpotCVD+, стоп -5%)`,
        alphaScore: 7,
        isContinuing: false,
        cumulativeOiChange: 0,
        tradingViewUrl,
        bingxUrl,
        oiTriggerTf: "prescan",
        oiChange1h: null,
        oiChange4h: null,
        oiChange24h: null,
        spotVol24h,
        marketCapUsd: vbsMcapUsd,
        freshMoverRisk:
          entry.cycleCount < 3 && p24h >= 5
            ? { cycles: entry.cycleCount, price24h: p24h }
            : null,
      };

      try {
        await broadcastBatchAlert([
          { ...vbsResult, entryOb: consumeObAtFire(sym) },
        ]);
        logger.info(
          {
            sym,
            spotVolMult: spotVolMult.toFixed(2) + "x",
            spotVolCycles: entry.spotVolCycles,
            p24h: p24h.toFixed(1) + "%",
            hasCG: cgOI?.available ?? false,
          },
          "📊🌊 VOLUME BREAKOUT SPOT: чистый спот-объём spike — signal fired",
        );
      } catch (err) {
        logger.error({ err, sym }, "VolBreakoutSpot: broadcast failed");
      }
    }

    logger.info(
      {
        noCycles: _vbsNoCycles,
        noData: _vbsNoData,
        multLow: _vbsMultLow,
        pdbChecked: _vbsPdbChecked,
        fired: vbsFired.length,
      },
      "VBS pre-gate funnel",
    );
    if (vbsFired.length > 0) {
      logger.info(
        { count: vbsFired.length, symbols: vbsFired.join(",") },
        "VolBreakoutSpot: цикл завершён",
      );
    }
  }

  // Phase 2: gather alpha candidates (klines + volume + pattern)
  const candidates: {
    symbol: string;
    price: number;
    priceChange30m: number;
    price4hChange: number; // Изменение цены за 4ч (8×30m) — для пост-памп фильтра
    price24hChange: number; // Изменение цены за 24ч — для gate на перегрев
    currentVolume: number;
    avgVolume: number;
    volumeMultiplier: number;
    oiChangePercent: number; // Best (max abs) из 5m/30m/1h OI — для скоринга
    oiChange1h: number | null; // Сырое 1h значение — для отображения в сигнале
    oiChange4h: number | null; // Сырое 4h значение — для отображения в сигнале
    oiChange24h: number | null; // Сырое 24h значение — для отображения в сигнале
    openInterest: number; // CoinGlass global OI in USD (or 0)
    sentiment: SentimentResult;
    coinglassOI: CoinglassOIResult;
    oiTriggerTf: string; // Какой ТФ сработал: "short", "30m", "short+30m", etc.
    isRepeatSignal: boolean; // символ уже был в сигналах за последние 24ч
    isConfirmedFire: boolean; // из confirming-очереди — пропускаем watching, стреляем сразу
    isScalpOnly: boolean; // MTF Spot CVD: старшие ТФ (1h/4h) не подтверждают
    futVolMult: number; // оригинальный фьюч BingX volMult (до замены на спот)
    spotVol24h: number | null; // абсолютный спот-объём $ за 24ч (из SpotPool)
    futVol24hUsd: number; // BingX quoteVolume 24ч $ — для защиты от коллизий тикеров CG
  }[] = [];

  // Track top-performers for debug log (even if they don't pass)
  const debugTop: {
    symbol: string;
    vol: number;
    cgOI: number | null;
    price: number;
  }[] = [];

  // TTL-очистка in-memory confirming fallback (записи старше 90 мин удаляем)
  const nowTtl = Date.now();
  for (const [sym, entry] of confirmingWatchMap) {
    if (nowTtl - entry.addedAt.getTime() > CONFIRMING_WATCH_TTL_MS) {
      confirmingWatchMap.delete(sym);
    }
  }

  // Skip reason counters for INFO-level diagnostics
  const skipCount = {
    noKlines: 0,
    exhaustedPump: 0,
    deepNegative: 0,
    noOiNoVol: 0,
    contraSignal: 0,
    lowVolume: 0,
    repeatSignal: 0,
    stalePump: 0, // exit pump (vol>>OI) / ghost pump guard
    cooldown: 0, // stop-loss / cancelled / chronic token cooldown
    priceGate: 0, // цена не выросла ≥+0.5% от firstPrice за 3+ цикла
    noConfirming: 0, // OI Watch confirming window failed / insert failed
    priceTooHigh: 0, // stale signal (price moved too much) / runaway
    cvdFail: 0, // CVD негативный (MTF spot CVD, main CVD, confirmed fire)
    takerFail: 0, // Taker Flow негативный / funding перегрет
    spotFailNoData: 0, // SpotVol/MCap gate — нет данных в кэше/живом запросе
    spotFailLow: 0, // SpotVol/MCap gate — данные есть, но ниже порога 0.15%
    latePump: 0, // глобальный фильтр поздней записи: price3h > 8%
    wiObBear: 0, // WI < 0 + OB bear — оба медвежьи
    other: 0,
  };
  // gateRejectLog: per-token "почему не дошёл до deepScan" — для диагностики узких мест.
  // Только токены с реальным сигналом: prescan-tracked ИЛИ vol≥1.5x ИЛИ OI≥2%.
  // Группируется по gate и логируется одним entry в конце цикла — grep "GATE REJECT LOG".
  const gateRejectLog: Array<{
    sym: string;
    gate: string;
    oi30m: string;
    vol: string;
    price: string;
    extra: string;
  }> = [];
  const oiPassCount = { t30: 0, t1h: 0, t4h: 0, t24h: 0, anyOiPass: 0 };
  let spotFailLogCount = 0; // лимит диагностических логов на цикл

  const now = Date.now();
  _symRejCycleAt = new Date(now);

  // ── Pre-scan fresh prices для confirming inserts ─────────────────────────────
  // CoinGlass batch уже занял 8+ мин. Kline close = закрытие свечи (0-30 мин назад).
  // Чтобы priceAtEntry в confirming был реальной ценой в момент добавления —
  // берём свежий тикер прямо перед per-symbol loop.
  const confirmPriceMap = new Map<string, number>();
  try {
    const confirmTickers = await getFutureTickers();
    for (const t of confirmTickers) {
      const p = parseFloat((t as any).lastPrice);
      if (p > 0) confirmPriceMap.set((t as any).symbol, p);
    }
  } catch {
    /* non-critical — falls back to kline close */
  }

  // Hard cap: если Neon/CoinGlass лагают и скан затягивается — прерываем через 22 мин.
  // Следующий запланированный скан (через ~5 мин) подберёт оставшиеся символы.
  // 22 мин < WATCHDOG_WARN_MS (35 мин) — watchdog никогда не видит "мёртвый" сканер.
  const MAX_SCAN_CYCLE_MS = 22 * 60_000;
  const cycleStartedAt = Date.now();
  let symbolsProcessed = 0;

  // ── Pre-load OI Watch active entries (одним запросом до loop) ─────────────────
  // Заменяет два per-symbol SELECT внутри loop: cgFallbackConfirmingRows + alreadyQueued.
  // При Neon timeout — fallback false (консервативно: не добавляем дубли в OI Watch).
  const cgFallbackConfirmingSet = new Set<string>();
  const oiWatchActiveSet = new Set<string>();
  try {
    const oiWatchRows = await db
      .select({
        symbol: oiWatchTable.symbol,
        status: oiWatchTable.status,
        triggerTf: oiWatchTable.triggerTf,
      })
      .from(oiWatchTable)
      .where(inArray(oiWatchTable.status, ["watching", "confirming"]));
    for (const r of oiWatchRows) {
      oiWatchActiveSet.add(r.symbol);
      if (
        r.status === "confirming" &&
        ["cg_timeout", "cg_building", "dark_flow"].includes(r.triggerTf)
      ) {
        cgFallbackConfirmingSet.add(r.symbol);
      }
    }
    logger.debug(
      { total: oiWatchRows.length, fallback: cgFallbackConfirmingSet.size },
      "OI Watch pre-load done",
    );
  } catch (err) {
    logger.warn(
      { err },
      "OI Watch pre-load failed — per-symbol DB queries disabled, cgFallback=false",
    );
  }

  // Символы для batch expire после loop (вместо per-symbol await внутри loop)
  const oiWatchToExpire: string[] = [];

  // CVD snapshot по символу — заполняется в главном цикле, читается при signalsToInsert.push
  const _spotCvdMapScan = new Map<
    string,
    Awaited<ReturnType<typeof getSpotCvdMtf>>
  >();
  // symbol → spotVolMult (lastSpotVol1h / spotVolAvg1h), рассчитан в loop1.
  // Мост в loop2/confirmed-fire для универсальной записи entrySpotVolMult:
  // раньше поле заполнялось только на spot_vol_* путях (res._spotVolMult),
  // из-за чего в tracked_signals было 20 non-null строк из сотен сигналов.
  const _spotVolMultMapScan = new Map<string, number>();

  // Патерны, прошедшие свой внутренний гейт в loop1 (по символу) — читается в loop2,
  // когда уже известны bulletScore/finalSentiment.key, чтобы diagPatternPassed мог
  // однозначно показать: срезался ли конкретный проход на alphaScore<5 или на приоритете det.
  const _passedGatePatternsMap = new Map<string, string[]>();
  const _markPassedGate = (symbol: string, pattern: string) => {
    const arr = _passedGatePatternsMap.get(symbol);
    if (arr) arr.push(pattern);
    else _passedGatePatternsMap.set(symbol, [pattern]);
  };

  // ── Parallel pre-fetch: klines + SpotCVD for all scan symbols ──────────────
  // Converts N sequential awaits (~300ms each) into two concurrent batches running
  // in parallel with each other. This is the primary cycle-time improvement.
  //
  // klines: concurrency 10 (BingX allows it; results cached in klinesPrefetch Map).
  // SpotCVD: concurrency 5 (matches CG 5-key rotation). Results go into the module-
  //   level 3-min cache inside getSpotCvdMtf — the loop's getSpotCvdMtf calls return
  //   instantly from cache. No changes needed to the loop CVD logic.
  const klinesPrefetch = new Map<string, BingXKline[]>();
  {
    const _prefetchStart = Date.now();
    // Hard cap: если CoinGlass медленный (SpotTakerFlow 12с/символ × ~72 батча = ~14 мин),
    // pre-warm завершаем принудительно через 3 мин. Незаконченные воркеры продолжают в фоне
    // и прогревают кэш для следующего цикла. Main loop использует то что успело закэшироваться.
    const MAX_PREFETCH_MS = 3 * 60 * 1000;
    let prefetchTimedOut = false;
    const prefetchDeadline = new Promise<void>((resolve) =>
      setTimeout(() => {
        prefetchTimedOut = true;
        resolve();
      }, MAX_PREFETCH_MS),
    );

    await Promise.race([
      Promise.all([
        runConcurrent(usdtTickers, 10, async (ticker) => {
          try {
            const klines = await getKlines(ticker.symbol, "30m", 49);
            if (klines.length >= 10) klinesPrefetch.set(ticker.symbol, klines);
          } catch {
            /* loop falls back to direct await on miss */
          }
        }),
        runConcurrent(usdtTickers, 5, async (ticker) => {
          // Pre-warm the internal 3-min cache; loop call is instant.
          await getSpotCvdMtf(ticker.symbol).catch(() => null);
        }),
        // Pre-warm SpotTakerFlow (2-min internal cache) so loop calls are instant.
        runConcurrent(usdtTickers, 4, async (ticker) => {
          await getSpotTakerFlow(ticker.symbol).catch(() => null);
        }),
        // Pre-warm SpotVolume (5-min internal cache) so loop calls are instant.
        runConcurrent(usdtTickers, 4, async (ticker) => {
          await getSpotVolume(ticker.symbol).catch(() => null);
        }),
      ]),
      prefetchDeadline,
    ]);

    const prefetchMs = Date.now() - _prefetchStart;
    if (prefetchTimedOut) {
      logger.warn(
        {
          klinesCached: klinesPrefetch.size,
          totalSymbols: usdtTickers.length,
          prefetchMs,
        },
        "⚡ Pre-fetch: hard cap hit (CoinGlass slow) — proceeding with partial cache",
      );
    } else {
      logger.info(
        {
          klinesCached: klinesPrefetch.size,
          totalSymbols: usdtTickers.length,
          prefetchMs,
        },
        "⚡ Pre-fetch done: klines + SpotCVD + SpotTakerFlow + SpotVolume parallel",
      );
    }
  }

  // ── Token Unlock filter map (fetched once per scan cycle, 4h cache) ──────────
  // Fail-open: getUpcomingUnlocks() returns empty Map on any CG error.
  const _unlockMap = await getUpcomingUnlocks().catch(
    () =>
      new Map<
        string,
        { daysUntil: number; pctSupply: number; unlockTime: number }
      >(),
  );
  // Per-symbol warn data (daysUntil 4-7): populated in per-symbol block, read at signal creation
  const _unlockWarnMap = new Map<
    string,
    { daysUntil: number; pctSupply: number }
  >();

  const abortFlag = { value: false };
  await runConcurrent(usdtTickers, 4, async (ticker) => {
    if (abortFlag.value) return;
    if (Date.now() - cycleStartedAt > MAX_SCAN_CYCLE_MS) {
      logger.warn(
        {
          symbolsProcessed,
          totalSymbols: usdtTickers.length,
          elapsedMin: Math.round((Date.now() - cycleStartedAt) / 60_000),
        },
        "⏱ Scan cycle hard timeout (22 min) — aborting remaining workers",
      );
      abortFlag.value = true;
      return;
    }
    symbolsProcessed++;
    const symbol = ticker.symbol;
    try {
      symbolBlock: do {
        // ── Spot Liquidity Pre-filter ────────────────────────────────────────────
        // Проверяем кэш спот-ликвидности до дорогого klines-запроса.
        // Порог 1% MCap — универсальный гейт, везде без исключений.
        // Если данных нет в кэше → пропускаем оптимистично (individual gate поймает).
        const preSpotEntry = getSpotPoolEntry(symbol);
        if (
          preSpotEntry &&
          preSpotEntry.spotVol24h !== null &&
          preSpotEntry.mcapUsd !== null
        ) {
          if (preSpotEntry.spotVol24h < preSpotEntry.mcapUsd * 0.01) {
            if (spotFailLogCount < 5) {
              const pct = (
                (preSpotEntry.spotVol24h / preSpotEntry.mcapUsd) *
                100
              ).toFixed(3);
              logger.info(
                {
                  symbol,
                  spotVol24h: preSpotEntry.spotVol24h,
                  mcapUsd: preSpotEntry.mcapUsd,
                  pct,
                },
                "SPOTFAIL_LOW detail",
              );
              spotFailLogCount++;
            }
            skipCount.spotFailLow++;
            break symbolBlock;
          }
        }
        // Нет данных в кэше — пропускаем pre-filter, идём дальше (CONFIRMED FIRE gate проверит живым запросом)

        // ── OI межцикловый gate (1а): оба цикла должны быть положительными ──────────
        // Применяется ТОЛЬКО если CG данные уже накоплены (оба поля не null).
        // Один спайк — шум. Два цикла подряд положительных — накопление.
        // Токены без CG-покрытия (BingX-exclusive, prevOi30m ещё null) проходят без фильтра.
        const _oiGatePe = prescanTracker.get(symbol);
        if (_oiGatePe?.lastOi30m != null && _oiGatePe?.prevOi30m != null) {
          // Байпас для токенов с сильным суточным OI — они накапливаются тихо,
          // краткосрочные TF при этом могут быть нейтральными или слабо отрицательными.
          const has24hStrength = (_oiGatePe.lastOi24h ?? 0) >= 10.0;
          if (
            !has24hStrength &&
            ((_oiGatePe.lastOi30m ?? 0) <= 0 || (_oiGatePe.prevOi30m ?? 0) <= 0)
          ) {
            logger.debug(
              {
                symbol,
                lastOi30m: _oiGatePe.lastOi30m,
                prevOi30m: _oiGatePe.prevOi30m,
                lastOi24h: _oiGatePe.lastOi24h,
              },
              "OI gate: OI не растёт два цикла подряд — пропускаем глубокий скан",
            );
            break symbolBlock;
          }
        }

        // ── Unlock filter (Layer 0 exempt; BTC/ETH exempt) ────────────────────────
        // Block: разлок ≤3 дн + pctSupply ≥1% + не в watchlist → skip символ.
        // Warn:  разлок 4-7 дн + pctSupply ≥1% → предупреждение в Telegram.
        // Fail-open: CoinGlass недоступен → _unlockMap пуст, ничего не блокируем.
        // BTC/ETH: exempt — для ликвидных мейджоров разлоки фондов не меняют картину.
        {
          const _base = symbol.replace("-USDT", "");
          if (_base !== "BTC" && _base !== "ETH") {
            const _uf = _unlockMap.get(_base);
            if (_uf && _uf.pctSupply >= 1) {
              if (_uf.daysUntil <= 3 && !watchlistSet.has(symbol)) {
                logger.info(
                  {
                    symbol,
                    daysUntil: _uf.daysUntil,
                    pctSupply: _uf.pctSupply,
                  },
                  "🔒 UNLOCK_BLOCK: разлок ≤3 дн — пропускаем символ (не watchlist)",
                );
                break symbolBlock;
              }
              if (_uf.daysUntil <= 7) {
                _unlockWarnMap.set(symbol, {
                  daysUntil: _uf.daysUntil,
                  pctSupply: _uf.pctSupply,
                });
              }
            }
          }
        }

        // Use pre-fetched klines if available (parallel pre-fetch above); fall back to
        // a direct await only if the pre-fetch missed (e.g., symbol added mid-cycle).
        const klines =
          klinesPrefetch.get(symbol) ?? (await getKlines(symbol, "30m", 49));

        // Требуем минимум 10 свечей для расчёта среднего объёма
        if (klines.length < 10) break symbolBlock;

        const current = klines[klines.length - 1];
        // v3.0 Step 3: use last 20 candles for average volume (not all 48)
        const historical = klines.slice(-21, -1);

        const close = parseFloat(current.close) || 0;
        const open = parseFloat(current.open) || 0;
        if (!close || !open) break symbolBlock;

        const currentVol = (parseFloat(current.volume) || 0) * close;
        const avgVol =
          historical.length > 0
            ? historical.reduce(
                (s, k) =>
                  s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0),
                0,
              ) / historical.length
            : 0;

        if (!avgVol) break symbolBlock;

        const priceChange = ((close - open) / open) * 100;
        let volMult = currentVol / avgVol;

        // ── Cross-exchange volume confirmation ────────────────────────────────────
        // Guard: only run when BingX volMult ≥ 1.3 — preserves the original trigger.
        //
        // PRIMARY: CoinGlass spot/pairs-markets per-exchange data (already pre-warmed
        //   by the pre-fetch block above; getSpotVolumeExchangeData() is a sync cache hit).
        //   For each of 4 target exchanges (Binance/Bybit/OKX/Bitget) we compute:
        //     exchangeVolMult = exchange_spot_1h_vol / (avgVol × 2)
        //   where avgVol × 2 is BingX's 1h baseline (same denominator as BingX volMult).
        //   Confirmation: CROSS_VOL_SPIKE_THRESHOLD = 1.5, CROSS_VOL_MIN_CONFIRMATIONS = 2.
        //   finalVolMult = avg of confirming exchanges' volMults (identical composition to old).
        //   This replicates "≥2 exchanges show elevated activity" semantics without
        //   4 per-symbol async API calls (getBinanceVolMult/getBybitVolMult/…).
        // FALLBACK: getCrossExchangeVolMult() per-exchange async calls — used only when
        //   the CG pairs-markets cache has no data (BingX-exclusive tokens).
        if (volMult >= 1.3) {
          const _perExData = getSpotVolumeExchangeData(symbol);
          if (_perExData !== null) {
            // Per-exchange spot volume from CG pairs-markets (pre-warmed, sync hit).
            // CG exchange names are lowercased keys; we check substring match for each target.
            const _SPIKE = 1.5;
            const _MIN_CONFIRM = 2;
            const _vol1hBaseline = avgVol * 2; // BingX 1h baseline (30m avgVol × 2)
            const _targetExchanges = [
              "binance",
              "bybit",
              "okx",
              "bitget",
            ] as const;
            const _confirmingMults: number[] = [];

            for (const _target of _targetExchanges) {
              // CG may return e.g. "binance", "bybit", "okx", "bitget" — lowercase match.
              let _exVol = _perExData[_target] ?? 0;
              // Also handle names like "binance futures", "bybit futures", "okex", etc.
              if (_exVol === 0) {
                for (const [_k, _v] of Object.entries(_perExData)) {
                  if (
                    _k.includes(_target) ||
                    (_target === "okx" && _k.includes("okex"))
                  ) {
                    _exVol += _v;
                  }
                }
              }
              if (_exVol > 0 && _vol1hBaseline > 0) {
                const _exMult = _exVol / _vol1hBaseline;
                if (_exMult >= _SPIKE) _confirmingMults.push(_exMult);
              }
            }

            if (_confirmingMults.length >= _MIN_CONFIRM) {
              const _avgMult =
                _confirmingMults.reduce((s, v) => s + v, 0) /
                _confirmingMults.length;
              const _prevVolMult = volMult;
              volMult = Math.max(volMult, _avgMult);
              logger.info(
                {
                  symbol,
                  confirming: _confirmingMults.length,
                  avgMult: _avgMult.toFixed(2),
                  volMult: volMult.toFixed(2),
                  prev: _prevVolMult.toFixed(2),
                },
                "🌐 Cross-vol confirmed (pairs-markets)",
              );
            }
          } else {
            // Fallback: no CG pairs-markets data (BingX-exclusive token or cache miss).
            // Uses original 4 per-symbol async calls with CROSS_VOL_SPIKE_THRESHOLD=1.5,
            // CROSS_VOL_MIN_CONFIRMATIONS=2, finalVolMult = avg of confirming exchanges.
            const _crossResult = await getCrossExchangeVolMult(symbol, volMult);
            if (_crossResult.crossConfirmed) {
              volMult = _crossResult.finalVolMult;
              logger.info(
                {
                  symbol,
                  confirming: _crossResult.confirming.length,
                  finalVolMult: _crossResult.finalVolMult.toFixed(2),
                },
                "🌐 Cross-vol confirmed (per-exchange fallback)",
              );
            }
          }
        }

        // 4h price context: compare current close to close ~8 candles (4h) ago.
        // Используется для пост-памп фильтра в Phase 3.
        const lookback4hIdx = Math.max(0, klines.length - 1 - 8);
        const base4hClose = parseFloat(klines[lookback4hIdx]?.close || "0");
        const price4hChange =
          base4hClose > 0 ? ((close - base4hClose) / base4hClose) * 100 : 0;

        // 1h price context: compare current close to close 2 candles ago (2×30m = 1h).
        // Хранится в prescanTracker для отображения в воронке сканера.
        const lookback1hIdx = Math.max(0, klines.length - 1 - 2);
        const base1hClose = parseFloat(klines[lookback1hIdx]?.close || "0");
        const price1hChange =
          base1hClose > 0 ? ((close - base1hClose) / base1hClose) * 100 : null;

        // 3h price context: compare current close to close 6 candles ago (6×30m = 3h).
        // Глобальный фильтр поздней записи: если цена выросла >8% за последние 3ч — поезд ушёл.
        const lookback3hIdx = Math.max(0, klines.length - 1 - 6);
        const base3hClose = parseFloat(klines[lookback3hIdx]?.close || "0");
        const price3h =
          base3hClose > 0 ? ((close - base3hClose) / base3hClose) * 100 : 0;

        // 4h cumulative volume: средний объём последних 8 свечей (4h) vs базовый avgVol (20 свечей).
        // Используется в 4h Momentum Pattern для обнаружения медленных грайндов.
        const recent8 = klines.slice(-9, -1); // 8×30m = 4h, без текущей свечи
        const vol4hAvg =
          recent8.length >= 4
            ? recent8.reduce(
                (s, k) =>
                  s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0),
                0,
              ) / recent8.length
            : 0;
        const volMult4h = avgVol > 0 && vol4hAvg > 0 ? vol4hAvg / avgVol : 0;

        // Volume trend: объём за последние 2 закрытые свечи (не текущая).
        // Если хотя бы одна из них >= 1.3x нормы — объём нарастает трендом, не одиночный спайк.
        // Используется как фильтр качества для hidden_accumulation.
        const prev1k = klines[klines.length - 2];
        const prev2k = klines[klines.length - 3];
        const prevVol1 = prev1k
          ? (parseFloat(prev1k.volume) || 0) * (parseFloat(prev1k.close) || 0)
          : 0;
        const prevVol2 = prev2k
          ? (parseFloat(prev2k.volume) || 0) * (parseFloat(prev2k.close) || 0)
          : 0;
        const prevVol1Mult = avgVol > 0 ? prevVol1 / avgVol : 0;
        const prevVol2Mult = avgVol > 0 ? prevVol2 / avgVol : 0;
        // Тренд объёма: хотя бы одна из 2 предыдущих закрытых свечей тоже была >= 1.3x.
        // Обновляется позже (после spotVolMult) — спот ≥1.3x тоже считается трендом (1.2).
        let isVolTrend = prevVol1Mult >= 1.3 || prevVol2Mult >= 1.3;

        // ── PRE-FILTER: Exhausted pump — price up >20% in 24h AND volume now cooling off ──
        // We DON'T block early breakouts (PIPPIN: 24h=0.84% at signal time).
        // Блок поздних входов по 24h цене из BingX — независимо от CoinGlass/Coinalyze.
        // BingX priceChangePercent = изменение за последние 24h, всегда актуально.
        const price24hChange = parseFloat(ticker.priceChangePercent) || 0;

        // 1. Памп уже отыгран: цена выросла >25% за 24h И объём остывает (< 2.5x).
        //    Дополнительно: если 4h объём >= 1.3x — монета ещё активна (многодневный тренд), пропускаем.
        if (price24hChange > 40 && volMult < 2.5 && volMult4h < 1.3) {
          logger.info(
            {
              symbol,
              price24hChange: price24hChange.toFixed(1) + "%",
              volMult: volMult.toFixed(2),
            },
            "SKIP: exhausted pump (>25% 24h + vol < 2.5x) — слишком поздно для входа",
          );
          skipCount.exhaustedPump++;
          if (prescanTracker.has(symbol)) {
            const _peEP = prescanTracker.get(symbol)!;
            gateRejectLog.push({
              sym: symbol,
              gate: "exhaustedPump",
              oi30m: _peEP.lastOi30m?.toFixed(2) ?? "n/a",
              vol: volMult.toFixed(2) + "x",
              price: priceChange.toFixed(2) + "%",
              extra: `p24h=${price24hChange.toFixed(1)}%`,
            });
            _symRej(
              symbol,
              "gate",
              "exhaustedPump",
              _peEP.lastOi30m ?? null,
              volMult,
              price24hChange,
              _peEP.cycleCount,
            );
          }
          // Памп уже случился — помечаем для batch expire после loop (не блокируем scan)
          oiWatchToExpire.push(symbol);
          break symbolBlock;
        }

        // 2. Монета в нисходящем тренде 24h → хвост дампа после пампа, лонги ликвидируются.
        //    Памп был вчера — сегодня монета уже -8% или хуже. Входить = ловить падающий нож.
        if (price24hChange < -8) {
          if (topPrescanSymbols.has(symbol)) {
            logger.info(
              {
                symbol,
                price24hChange: price24hChange.toFixed(1) + "%",
                prescanTop10: true,
              },
              "🚫 TOP-10 SKIP [deepNeg]: цена ниже -8% за 24h — post-dump, входить не стоит",
            );
          } else {
            logger.debug(
              { symbol, price24hChange: price24hChange.toFixed(1) + "%" },
              "SKIP: 24h price deeply negative — post-pump dump",
            );
          }
          skipCount.deepNegative++;
          if (prescanTracker.has(symbol)) {
            const _pe = prescanTracker.get(symbol)!;
            gateRejectLog.push({
              sym: symbol,
              gate: "deepNeg",
              oi30m: _pe.lastOi30m?.toFixed(2) ?? "n/a",
              vol: volMult.toFixed(2) + "x",
              price: priceChange.toFixed(2) + "%",
              extra: `p24h=${price24hChange.toFixed(1)}%`,
            });
            _symRej(
              symbol,
              "gate",
              "deepNeg",
              _pe.lastOi30m ?? null,
              volMult,
              price24hChange,
              _pe.cycleCount,
            );
          }
          // Цена упала — сетап сломан, помечаем для batch expire после loop
          oiWatchToExpire.push(symbol);
          break symbolBlock;
        }

        const _accumPrescanEntry = prescanTracker.get(symbol);
        // Тихое/дип/трендовое накопление: cvd30m может быть в минусе по природе паттерна.
        // Глобальный CVD hard gate (cvd30m) убивает такие сигналы — обходим его.
        // Вместо этого накопительные паттерны проверяют cvd1h + cvd4h в своём блоке ниже.
        const isHiddenAccumLikely =
          _accumPrescanEntry != null &&
          ((_accumPrescanEntry.lastOi4h ?? 0) >= 1.5 ||
            (_accumPrescanEntry.lastOi1h ?? 0) >= 2.0) &&
          Math.abs(_accumPrescanEntry.lastPrice1h ?? 0) < 5.0;

        // ── MTF SPOT CVD PRE-FILTER (v9) ─────────────────────────────────────────────
        // Первостепенный фильтр: спот должен подтверждать покупки на 30m (hard gate).
        // Если 1h или 4h в минусе — сигнал помечается как "Scalp Only" (риск разворота).
        // Если CoinGlass недоступен → не блокируем сигнал (graceful fallback).
        let spotCvd: Awaited<ReturnType<typeof getSpotCvdMtf>> | null = null;
        let isScalpOnly = false;
        let _spotCvdHardBlocked = false;
        let _cvdPrevPositiveCycles = 0; // значение cvdPositiveCycles ДО обновления текущего цикла
        {
          spotCvd = await getSpotCvdMtf(symbol);
          _spotCvdMapScan.set(symbol, spotCvd); // сохраняем для signalsToInsert.push (второй цикл)
          if (spotCvd.available && spotCvd.hardBlocked) {
            // Defer continue — _maybeSpotDivergence check needs to happen first
            _spotCvdHardBlocked = true;
          }
          if (spotCvd.available) {
            isScalpOnly = spotCvd.scalpOnly;
            logger.debug(
              {
                symbol,
                cvd30m: spotCvd.cvd30m,
                cvd1h: spotCvd.cvd1h,
                cvd4h: spotCvd.cvd4h,
                scalpOnly: isScalpOnly,
                isGolden: spotCvd.isGolden,
              },
              spotCvd.isGolden
                ? "✅ MTF SPOT CVD: Golden Signal (все 4 ТФ в плюсе)"
                : isScalpOnly
                  ? "⚠️ MTF SPOT CVD: 30m ок, но 1h/4h в минусе → Scalp Only"
                  : "✅ MTF SPOT CVD: подтверждено",
            );
          }
          const _prescanForCvd = prescanTracker.get(symbol);
          // Сохраняем значение ДО обновления текущего цикла — используется в history bypass
          // всё равно должна позволить пройти токену с устойчивой историей.
          _cvdPrevPositiveCycles = _prescanForCvd?.cvdPositiveCycles ?? 0;
          if (_prescanForCvd && spotCvd.available) {
            _prescanForCvd.lastCvdOk = !spotCvd.hardBlocked;
            _prescanForCvd.lastNetBuyPct =
              spotCvd.cvd30m === true ? 50 : spotCvd.cvd30m === false ? -50 : 0;
            _prescanForCvd.lastCvd30m = spotCvd.cvd30m;
            _prescanForCvd.lastCvd1h = spotCvd.cvd1h;
            _prescanForCvd.lastCvd4h = spotCvd.cvd4h;
            // Счётчик spot CVD: сколько циклов подряд spot CVD 30m положительный.
            // Сбрасывается при первом минусе. takerPositiveCycles обновляется ниже,
            // после того как получены реальные данные CoinGlass taker (scanTf).
            const cvd30mPos = spotCvd.cvd30m === true;
            _prescanForCvd.cvdPositiveCycles = cvd30mPos
              ? (_prescanForCvd.cvdPositiveCycles ?? 0) + 1
              : 0;
          }
          // Обновляем постоянный кэш CVD-данных (даже если символ потом выпадет из prescan)
          if (spotCvd.available) {
            const _lk = lastKnownLiveData.get(symbol);
            const _pe2 = prescanTracker.get(symbol);
            lastKnownLiveData.set(symbol, {
              oi30m: _lk?.oi30m ?? null,
              oi1h: _lk?.oi1h ?? null,
              oi4h: _lk?.oi4h ?? null,
              oi24h: _lk?.oi24h ?? null,
              cvd30m: spotCvd.cvd30m ?? null,
              cvd1h: spotCvd.cvd1h ?? null,
              cvd4h: spotCvd.cvd4h ?? null,
              netBuyPct:
                spotCvd.cvd30m === true
                  ? 50
                  : spotCvd.cvd30m === false
                    ? -50
                    : (_lk?.netBuyPct ?? null),
              price1h: _lk?.price1h ?? null,
              spotTakerNetBuy:
                _pe2?.lastSpotTakerNetBuy ?? _lk?.spotTakerNetBuy ?? null,
              spotTakerDominance:
                _pe2?.lastSpotTakerDominance ?? _lk?.spotTakerDominance ?? null,
              whaleIndex: _pe2?.lastWhaleIndex ?? _lk?.whaleIndex ?? null,
              updatedAt: Date.now(),
            });
          }
        }

        // ── STEP 1: PRIMARY FILTER — CoinGlass глобальный OI (агрегат по всем биржам) ──
        // Проверяем 5 таймфреймов: 5m, 30m, 1h, 4h, 24h.
        // Fast Track символы проходят этот блок без проверки OI.
        const cgOI = coinglassOIMap.get(symbol);

        // ── CoinGlass Timeout Fallback: BingX OI прямой запрос ───────────────────
        // Когда CoinGlass таймаутит по символу (малые токены, rate-limit),
        // вычисляем % изменения OI напрямую из BingX: текущий OI vs сохранённый baseline.
        // Baseline обновляется каждые 20-60 мин → получаем аналог oi30m/oi1h.
        let bingxDirectOIChange: number | null = null;
        if (!cgOI?.available) {
          // Уровень 1: BingX прямой запрос vs baseline (без лимитов, мгновенно)
          const baseline = oiBaseline.get(symbol);
          if (baseline && Date.now() - baseline.takenAt < MAX_BASELINE_AGE_MS) {
            const bxOI = await getOpenInterest(symbol);
            if (bxOI) {
              const currentOI = parseFloat(bxOI.openInterest);
              if (currentOI > 0 && baseline.oi > 0) {
                bingxDirectOIChange =
                  ((currentOI - baseline.oi) / baseline.oi) * 100;
                logger.info(
                  {
                    symbol,
                    currentOI: currentOI.toFixed(0),
                    baselineOI: baseline.oi.toFixed(0),
                    changePct: bingxDirectOIChange.toFixed(1) + "%",
                    baselineAgeMin: (
                      (Date.now() - baseline.takenAt) /
                      60000
                    ).toFixed(0),
                  },
                  "🔄 CG FALLBACK L1: BingX OI прямой запрос (CoinGlass таймаут)",
                );
              }
            }
          }
        }

        // BingX Direct OI (абсолютное значение в токенах) для BingX-exclusive токенов
        const _peForDirectOI = prescanTracker.get(symbol);
        const bingxDirectOIAbs = _peForDirectOI?.bingxDirectOI ?? null;
        if (
          !cgOI?.available &&
          bingxDirectOIAbs !== null &&
          bingxDirectOIAbs > 0
        ) {
          logger.debug(
            { symbol, bingxDirectOI: bingxDirectOIAbs },
            "BingX Direct OI доступен — токен частично виден",
          );
        }

        const oi30m =
          cgOI?.oiChange30m ??
          (bingxDirectOIChange !== null ? bingxDirectOIChange : null);
        const oi1h =
          cgOI?.oiChange1h ??
          (bingxDirectOIChange !== null ? bingxDirectOIChange : null);
        const oi4h = cgOI?.oiChange4h ?? null;
        // oi24h: CoinGlass → Coinalyze кэш (без HTTP, батч прогрет выше)
        const oi24h = cgOI?.oiChange24h ?? getCoinalyzeOI24hCached(symbol);

        // Сохраняем live OI TF данные и 1h цену в prescan tracker для отображения в UI
        {
          const _pe = prescanTracker.get(symbol);
          if (_pe) {
            _pe.lastOi30m = oi30m;
            _pe.lastOi1h = oi1h;
            _pe.lastOi4h = oi4h;
            _pe.lastOi24h = oi24h;
            _pe.lastPrice1h = price1hChange;
            _pe.lastPrice3h = price3h;
            _pe.prevVolMult = _pe.lastVolMult; // сохраняем прошлый цикл перед перезаписью
            _pe.lastVolMult = volMult;
            _pe.lastAvgVol = avgVol;
            // volAccelSpike: объём удвоился за один цикл (~10 мин) + токен долго в prescan
            const _volAccel =
              _pe.lastVolMult && _pe.prevVolMult && _pe.prevVolMult > 0
                ? _pe.lastVolMult / _pe.prevVolMult
                : null;
            _pe.volAccelSpike =
              _volAccel !== null &&
              _volAccel >= 2.0 &&
              (_pe.cycleCount ?? 0) >= 5;
            _pe.lastCgTimedOut = cgOI?.timedOut ?? false;
            if (cgOI?.available) _pe.lastOiAt = Date.now();
          }
          // Обновляем постоянный кэш OI-данных (fallback для выпавших из prescan открытых позиций)
          {
            const _lk = lastKnownLiveData.get(symbol);
            const _pe3 = prescanTracker.get(symbol);
            lastKnownLiveData.set(symbol, {
              oi30m,
              oi1h,
              oi4h,
              oi24h,
              cvd30m: _lk?.cvd30m ?? null,
              cvd1h: _lk?.cvd1h ?? null,
              cvd4h: _lk?.cvd4h ?? null,
              netBuyPct: _lk?.netBuyPct ?? null,
              price1h: price1hChange,
              spotTakerNetBuy:
                _pe3?.lastSpotTakerNetBuy ?? _lk?.spotTakerNetBuy ?? null,
              spotTakerDominance:
                _pe3?.lastSpotTakerDominance ?? _lk?.spotTakerDominance ?? null,
              whaleIndex: _pe3?.lastWhaleIndex ?? _lk?.whaleIndex ?? null,
              updatedAt: Date.now(),
            });
          }
        }

        // spot_divergence: специально ищет токены где cvd30m негативен при позитивных 1h/4h
        // — глобальный CVD gate его системно блокирует до проверки паттерна. Исключаем.
        // anyOiPass объявлена позже в цикле — не используем, остальных условий достаточно.
        const _maybeSpotDivergence =
          spotCvd?.available === true &&
          spotCvd.cvd1h === true &&
          spotCvd.cvd4h === true &&
          price24hChange <= 40 &&
          (prescanTracker.get(symbol)?.cycleCount ?? 0) >= 5;

        // Apply deferred MTF CVD hard block (was deferred to allow _maybeSpotDivergence check)
        if (
          _spotCvdHardBlocked &&
          !isHiddenAccumLikely &&
          !_maybeSpotDivergence
        ) {
          // ── History bypass: тот же механизм что ACCUM_PATTERN_KEYS ALLOW[history] ──────
          // Если в предыдущих 3+ циклах CVD 5m был стабильно положительным, один «минусовой»
          // цикл не повод блокировать — это может быть краткосрочный откат при накоплении.
          // Страховочный клапан: тейкер активно продаёт (lastNetBuyPct < -30%) → история
          // не перекрывает, блокируем как обычно.
          //
          // СТАНДАРТ CVD-HISTORY BYPASS (общий фильтр, до паттерна):
          //   cycles >= 3, taker > -30% (мягче по давлению).
          //   Высокая планка по циклам — потому что контекст паттерна ещё не известен,
          //   история CVD — единственный аргумент для bypass.
          //   Мягкий тейкер — потому что до паттерна непонятно, какое давление нормально
          //   для конкретного сетапа; блокировать слишком рано значит не дать шанса pattern-детекции.
          //   Если добавляешь новый bypass-путь на уровне общего фильтра — следуй этому стандарту,
          //   не придумывай третий набор цифр без явной причины. На уровне конкретного паттерна
          //   см. стандарт в quiet_oi_accumulation ниже (cycles >= 2, taker >= -10%).
          const _cvdBypassEntry = prescanTracker.get(symbol);
          const _takerActivelyAgainst =
            (_cvdBypassEntry?.lastNetBuyPct ?? 0) < -30;
          if (_cvdPrevPositiveCycles >= 3 && !_takerActivelyAgainst) {
            logger.info(
              {
                symbol,
                prevCvdCycles: _cvdPrevPositiveCycles,
                lastNetBuyPct:
                  _cvdBypassEntry?.lastNetBuyPct?.toFixed(1) ?? "n/a",
              },
              "ALLOW[history]: MTF CVD gate — 3+ цикла CVD+ в истории, тейкер нейтральный — пропускаем",
            );
            // fallthrough — не continue
          } else {
            const prescanCycles = _cvdBypassEntry?.cycleCount ?? 0;
            if (prescanCycles >= 3 && spotCvd?.cvd30m !== false) {
              // Тёплый токен (3+ цикла) + cvd30m не явно отрицательный: soft pass
              logger.debug(
                { symbol, prescanCycles, cvd30m: spotCvd?.cvd30m },
                "CVD soft pass: тёплый токен, cvd30m не отрицательный",
              );
            } else {
              // Новый токен или cvd30m явно false — spot vol surge bypass или блок
              const _svpe = prescanTracker.get(symbol);
              const _svMult =
                _svpe?.spotVolAvg1h && _svpe?.lastSpotVol1h
                  ? _svpe.lastSpotVol1h / _svpe.spotVolAvg1h
                  : null;
              if (_svMult !== null && _svMult >= 3.0) {
                logger.info(
                  {
                    symbol,
                    spotVolMult: _svMult.toFixed(2) + "x",
                    cycles: prescanCycles,
                    cvd1h: spotCvd?.cvd1h ?? "n/a",
                  },
                  "CVD bypass[hard]: spot vol surge ≥3x → CVD gate пропущен (cvd1h проверит паттерн)",
                );
                // fallthrough — spot vol patterns проверим ниже
              } else {
                logger.info(
                  {
                    symbol,
                    prescanCycles,
                    cvd30m: spotCvd?.cvd30m,
                    oi30m: oi30m?.toFixed(1) ?? "n/a",
                    vol: volMult.toFixed(2) + "x",
                    price: priceChange.toFixed(2) + "%",
                  },
                  "SKIP [MTF SPOT CVD]: спот не подтверждает покупки (30m в минусе)",
                );
                skipCount.cvdFail++;
                gateRejectLog.push({
                  sym: symbol,
                  gate: "cvdFail",
                  oi30m: oi30m?.toFixed(2) ?? "n/a",
                  vol: volMult.toFixed(2) + "x",
                  price: priceChange.toFixed(2) + "%",
                  extra: `cvd30m=${spotCvd?.cvd30m ?? "n/a"},cycles=${prescanCycles}`,
                });
                _symRej(
                  symbol,
                  "gate",
                  "cvdFail",
                  oi30m ?? null,
                  volMult,
                  price24hChange,
                  prescanCycles,
                );
                break symbolBlock;
              }
            }
          }
        }

        // Пороги — дифференцированные по ТФ (минимальный ТФ — 30m):
        const OI_THRESH_30M = 4.0; // снижен с 6% → ловим накопление раньше
        const OI_THRESH_1H = 3.0;
        const OI_THRESH_4H = 5.0; // снижен с 8% → TOP-10 проходит быстрее
        const OI_THRESH_24H = 10.0; // снижен с 20% → стабильный интерес от 10% за сутки
        // Требуем ПОЛОЖИТЕЛЬНЫЙ OI — отрицательный означает закрытие позиций/окончание движения.
        const t30 = oi30m !== null && oi30m >= OI_THRESH_30M;
        const t1h = oi1h !== null && oi1h >= OI_THRESH_1H;
        const t4h = oi4h !== null && oi4h >= OI_THRESH_4H;
        const shortTfNotDumping = oi30m === null || oi30m > -3; // 30m OI не в глубоком минусе
        const t24h =
          oi24h !== null && oi24h >= OI_THRESH_24H && shortTfNotDumping;

        // ── ФИЛЬТР: памп уже был — кросс-биржевой OI (CoinGlass, агрегат всех бирж) ──
        //
        // CoinGlass = агрегат Binance + Bybit + OKX + BingX + др. → это глобальный сигнал,
        // не привязан к одной бирже. Два случая:
        //
        // A) CoinGlass вернул 24h OI < -15% → шорты закрывались весь день → памп отыгран.
        if (oi24h !== null && oi24h < -15) {
          logger.debug(
            { symbol, oi24h: oi24h.toFixed(1) + "%" },
            "SKIP: памп уже был — CoinGlass 24h OI < -15% (глобальный агрегат)",
          );
          skipCount.contraSignal++;
          if (oi30m !== null && oi30m >= 2) {
            gateRejectLog.push({
              sym: symbol,
              gate: "contra",
              oi30m: oi30m.toFixed(2),
              vol: volMult.toFixed(2) + "x",
              price: priceChange.toFixed(2) + "%",
              extra: `oi24h=${oi24h.toFixed(1)}%`,
            });
            _symRej(
              symbol,
              "gate",
              "contra_oi24h",
              oi30m,
              volMult,
              price24hChange,
              prescanTracker.get(symbol)?.cycleCount ?? null,
            );
          }
          break symbolBlock;
        }

        // B) CoinGlass покрывает монету, но 24h поле отсутствует (null) — типично для малых токенов.
        //    В этом случае смотрим краткосрочные TF: если ВСЕ доступные (5m, 30m, 1h) отрицательные
        //    → OI падает по всему фронту → выдавливание лонгов / пост-памп дамп.
        if (cgOI?.available && oi24h === null) {
          const shortTfValues = [oi30m, oi1h].filter(
            (v) => v !== null,
          ) as number[];
          const allNegative =
            shortTfValues.length >= 2 && shortTfValues.every((v) => v < -2);
          if (allNegative) {
            logger.debug(
              { symbol, oi30m: oi30m?.toFixed(1), oi1h: oi1h?.toFixed(1) },
              "SKIP: 24h OI недоступен, но все краткосрочные TF отрицательные — OI падает по всему фронту",
            );
            skipCount.contraSignal++;
            break symbolBlock;
          }
        }

        // "Steady Accumulation": 30m OI умеренный (2–4%) + цена во флэте.
        // Ловит скрытое накопление где 30m OI ниже порога пробоя, но показывает рост.
        const _peTSteady = prescanTracker.get(symbol);
        const _svmTSteady =
          _peTSteady?.spotVolAvg1h && _peTSteady?.lastSpotVol1h
            ? _peTSteady.lastSpotVol1h / _peTSteady.spotVolAvg1h
            : null;
        const tSteady =
          !t30 &&
          !t1h &&
          !t4h &&
          !t24h &&
          oi30m !== null &&
          oi30m >= 2.0 && // 30m OI медленно растёт (2–4%)
          _svmTSteady !== null &&
          _svmTSteady >= 1.2 &&
          Date.now() -
            (prescanTracker.get(symbol)?.firstSeenAt ?? Date.now()) >=
            30 * 60_000; // токен 30+ мин в пресканере

        // Multi-TF confirmation:
        // — 30m — кратчайший ТФ; длинные (1h ≥3%, 4h ≥5%, 24h ≥10%) проходят поодиночке.
        const shortTfsConfirmed = t30;
        const longTfPass = t1h || t4h || t24h;
        // anyOiPass: либо CoinGlass дал данные, либо BingX прямой фолбэк сработал
        const hasFallbackOI = bingxDirectOIChange !== null;
        const anyOiPass =
          (cgOI?.available || hasFallbackOI) &&
          (shortTfsConfirmed || longTfPass || tSteady);
        // spot_absorption исключение (2026-07-08): !anyOiPass слишком широкое для этого
        // паттерна — longTfPass (t1h≥3% / t4h≥5% / t24h≥10%) не противоречит тезису
        // "OI не в свежем спайке" (spot_absorption гейтится только на oi30m<4%), а просто
        // означает что OI медленно строился ЧАСЫ назад — это не то же самое, что "уже
        // поймал стандартный OI-паттерн в ЭТОМ цикле". Используем узкую версию: блокируем
        // только если shortTfsConfirmed (реальный свежий спайк 5m+30m) или tSteady (тот же
        // токен уже получил свою запись в oi_watch через STEADY ACCUM в этом же цикле) —
        // иначе будет дублирование сигнала на один и тот же токен.
        const _spotAbsorptionOiBlock = shortTfsConfirmed || tSteady;
        // spot_vol паттерны: нет OI-спайка подтверждённого CoinGlass.
        // BingX-fallback — долгосрочная дельта, не краткосрочный спайк → игнорируем.
        // Если CG недоступен → разрешаем (нет данных о спайке).
        // Если CG доступен и показывает спайк → блокируем.
        const _noOiSpikeForSpotVol =
          cgOI?.available !== true || (!shortTfsConfirmed && !longTfPass);

        if (t30) oiPassCount.t30++;
        if (t1h) oiPassCount.t1h++;
        if (t4h) oiPassCount.t4h++;
        if (t24h) oiPassCount.t24h++;
        if (anyOiPass) oiPassCount.anyOiPass++;

        // ── Фильтр: короткие ТФ + противоречие длинных ────────────────────────────
        // Если сработали только 5м+30м, но 4h или 24h OI глубоко в минусе —
        // весь день шли продажи/выход из позиций, краткосрочный всплеск ложный.
        if (shortTfsConfirmed && !longTfPass) {
          if (oi24h !== null && oi24h < -10) {
            logger.debug(
              { symbol, oi24h: oi24h.toFixed(1) + "%" },
              "SKIP: 5м+30м ок, но 24ч OI < -10% — дневной слив",
            );
            skipCount.contraSignal++;
            break symbolBlock;
          }
          if (oi4h !== null && oi4h < -5) {
            logger.debug(
              { symbol, oi4h: oi4h.toFixed(1) + "%" },
              "SKIP: 5м+30м ок, но 4ч OI < -5% — последние 4ч продажи",
            );
            skipCount.contraSignal++;
            break symbolBlock;
          }
        }

        // ── Spot Taker Flow ──
        // Кэш 2 мин — повторный вызов дешёвый (cache hit).
        // getSpotTakerFlow: Binance spot → fallback BingX spot.
        const _spotTaker = await getSpotTakerFlow(symbol).catch(() => null);

        // Spot taker consecutive cycles update — обновляем счётчик taker netBuyPct > 0.
        // Сбрасывается при первом цикле с netBuyPct <= 0 или при отсутствии данных.
        {
          const _prescanForTaker = prescanTracker.get(symbol);
          if (_prescanForTaker) {
            if (_spotTaker?.available) {
              _prescanForTaker.takerPositiveCycles =
                (_spotTaker.netBuyPct ?? 0) > 0
                  ? (_prescanForTaker.takerPositiveCycles ?? 0) + 1
                  : 0;
              _prescanForTaker.lastSpotTakerNetBuy =
                _spotTaker.netBuyPct ?? null;
            }
            // Если _spotTaker недоступен — не сбрасываем счётчик, оставляем последнее известное.
          }
        }

        // ── Quiet OI Accumulation (EVAA-тип): микро-OI растёт стабильно, ниже стандартных порогов ──
        // Для микро-токенов где OI 0.2-0.5% за свечу — в 10-30 раз ниже стандартных порогов.
        // Требует cycleCount >= 5: токен давно в пресканере, не одиночный всплеск.
        const prescanAgeMinutes =
          (Date.now() -
            (prescanTracker.get(symbol)?.firstSeenAt ?? Date.now())) /
          60_000;
        const prescanCyclesCurrent = prescanAgeMinutes; // time-based: minutes in prescan
        // Taker gate: текущий цикл спот taker покупает (первичная проверка).
        // Порог тейкера ослаблен 3% → 2% (2026-07-10): одновременное требование низких
        // OI-порогов + Fut Taker было редкой комбинацией — консультант рекомендовал смягчить.
        const _quietTakerOk =
          _spotTaker !== null &&
          _spotTaker.available &&
          (_spotTaker.netBuyPct ?? 0) >= 2;
        // CVD history gate: если taker-данные слабые в ЭТОМ цикле, но spot CVD был
        // положительным 2+ цикла подряд — история накопления достаточна для сигнала.
        // Дополнительное условие: taker не активно отрицательный (>= -10 или нет данных).
        //
        // СТАНДАРТ CVD-HISTORY BYPASS (уровень конкретного паттерна):
        //   cycles >= 2, taker >= -10% (строже по давлению).
        //   Ниже планка по циклам — потому что остальные условия quiet_oi уже жёсткие
        //   (prescanCycles >= 5, oi30m/oi1h/volMult/price-коридор), история CVD добавляет
        //   поверх них, а не заменяет контекст.
        //   Строгий тейкер — потому что паттерн специфически о тихом накоплении:
        //   тейкер -15% при боковой цене прямо противоречит тезису независимо от истории.
        //   Если добавляешь bypass в другой конкретный паттерн — следуй этому стандарту.
        //   На уровне общего фильтра (до паттерна) см. стандарт выше (cycles >= 3, taker > -30%).
        const _quietCvdHistory =
          (prescanTracker.get(symbol)?.cvdPositiveCycles ?? 0) >= 2 &&
          (_spotTaker === null ||
            !_spotTaker.available ||
            (_spotTaker.netBuyPct ?? 0) >= -10);

        // DEBUG: quiet_oi_accumulation near-miss logging
        if (
          !anyOiPass &&
          cgOI?.available === true &&
          prescanCyclesCurrent >= 30
        ) {
          const _qReasons: string[] = [];
          if (oi30m === null || oi30m < 0.2)
            _qReasons.push(`oi30m=${oi30m?.toFixed(2) ?? "null"}<0.2`);
          if (oi1h === null || oi1h < 0.5)
            _qReasons.push(`oi1h=${oi1h?.toFixed(2) ?? "null"}<0.5`);
          if (!_spotTaker?.available || (_spotTaker.netBuyPct ?? 999) < 3)
            _qReasons.push(
              `spottaker=${_spotTaker?.netBuyPct?.toFixed(1) ?? "n/a"}%<3`,
            );
          if (volMult < 0.8 || volMult > 1.8)
            _qReasons.push(`vol=${volMult.toFixed(2)}x`);
          if (prescanCyclesCurrent < 30)
            _qReasons.push(`ageMin=${prescanCyclesCurrent.toFixed(0)}<30`);
          if (!(price24hChange <= 40))
            _qReasons.push(`price24h=${price24hChange.toFixed(1)}%`);
          if (price3h > 6) _qReasons.push(`price3h=${price3h.toFixed(1)}%`);
          if (_qReasons.length > 0 && _qReasons.length <= 3) {
            logger.info(
              {
                symbol,
                reasons: _qReasons,
                cycleCount: prescanCyclesCurrent,
                oi30m: oi30m?.toFixed(2),
                oi1h: oi1h?.toFixed(2),
                vol: volMult.toFixed(2),
                spotNetBuyPct: _spotTaker?.netBuyPct?.toFixed(1),
                price: priceChange.toFixed(2),
                price24h: price24hChange.toFixed(1),
                price3h: price3h.toFixed(1),
              },
              "🔬 QUIET_OI_ACCUM near-miss: 1-3 условия не прошли",
            );
          }
        }

        // ── Spot Volume Multiplier: используется вместо фьюч volMult в паттернах ─
        // lastSpotVol1h / spotVolAvg1h — нормированный спот-объём.
        // null если данные ещё не накоплены (spotVolAvg1h = 0 или отсутствует).
        const _peSvm = prescanTracker.get(symbol);
        {
          const _inMap = prescanTracker.has(symbol);
          const _avg = _peSvm?.spotVolAvg1h ?? null;
          const _last = _peSvm?.lastSpotVol1h ?? null;
          if (!_inMap) _spotVolDiag.notInMap++;
          else if (!_avg) _spotVolDiag.noAvg++;
          else if (!_last) _spotVolDiag.noLast++;
          else _spotVolDiag.hasMult++;
          if (_spotVolDiag.sample.length < 5)
            _spotVolDiag.sample.push({
              sym: symbol,
              inMap: _inMap,
              avg: _avg,
              last: _last,
              cycles: _peSvm?.spotVolCycles ?? null,
            });
        }
        const spotVolMult =
          _peSvm?.spotVolAvg1h && _peSvm?.lastSpotVol1h
            ? _peSvm.lastSpotVol1h / _peSvm.spotVolAvg1h
            : null;
        if (spotVolMult !== null) _spotVolMultMapScan.set(symbol, spotVolMult);
        const _prevSpotVolMult =
          _peSvm?.prevSpotVol1h && _peSvm?.spotVolAvg1h
            ? _peSvm.prevSpotVol1h / _peSvm.spotVolAvg1h
            : null;

        // 1.2: спот ≥1.3x тоже считается "объёмным трендом" — softens gate для токенов,
        // где фьюч-объём тихий но спот уже активен.
        if (spotVolMult !== null && spotVolMult >= 1.3) isVolTrend = true;

        // ── 4H PULLBACK CONTINUATION: коррекция внутри восходящего тренда ──────────
        // Ретроспектива 774 мувёров (2026-07-18): 19% «невидимых» токенов имели
        // p24h +9.2% (суточный тренд) + p4h −1.43% (4h откат) + oi4h −2.40%.
        // Паттерн: OI4h разворачивается из отрицательного → продолжение тренда.
        const _pePullback = prescanTracker.get(symbol);
        // 4H PULLBACK v3 (2026-07-27): калибровка по структурным блокерам.
        // Диагностика: oi4h_not_neg / oi4h_not_improving — OI4h null при CG-таймауте = instant fail.
        // Fixes:
        //   - price4h порог -1.5% → -1.0% (ретро median p4h = -1.43%)
        //   - Путь B: OI4h null (CG-таймаут) → прокси через oi30m ≥ 0.1% (стабилизировался)
        //   - volMult 0.5 → 0.3 (в коррекции объём снижен естественно)
        const _pb4hOi4h = _pePullback?.lastOi4h ?? null;
        const _pb4hPrevOi4h = _pePullback?.prevOi4h ?? null;
        // _pb4hImproving: OI4h должен быть >= prevOi4h (дренаж остановился или улучшается).
        // >= вместо >: стабильный OI4h между циклами (prevOi4h === lastOi4h) тоже считается
        // "improving" — дренаж уже остановился. CoinGlass OI4h — роллинговый 4h показатель,
        // который между смежными 10-мин prescan-циклами может не меняться. Строгий > блокировал
        // паттерн каждый раз когда OI4h стабилен на отрицательном уровне.
        const _pb4hImproving =
          _pb4hOi4h !== null &&
          _pb4hOi4h >= (_pb4hPrevOi4h !== null ? _pb4hPrevOi4h : _pb4hOi4h - 1);
        const is4hPullbackContinuation =
          price24hChange >= 1 &&
          price24hChange <= 25 &&
          price4hChange <= -1.0 && // было -1.5; ретро p4h median −1.43%
          // Путь A: OI4h доступен и отрицательный, но улучшается между циклами
          ((_pb4hOi4h !== null && _pb4hOi4h < 0 && _pb4hImproving) ||
            // Путь B: OI4h нет (CG-таймаут) — OI30m стабилизировался как прокси
            (_pb4hOi4h === null && oi30m !== null && oi30m >= 0.1)) &&
          (oi30m === null || oi30m >= 0) && // OI30m не в минусе (fail-open)
          volMult >= 0.3 && // было 0.5; в коррекции объём снижен
          (_pePullback?.cycleCount ?? 0) >= 3;

        // ── PRICE-LED MOMENTUM (Архетип C): цена бежит, OI не подключился ────────────
        // Ретроспектива 774 мувёров: 11.8% токенов — price3h+price4h оба ≥3%, OI тихий.
        // Отличие от 4h_momentum: не требует vol4h ≥1.2x; явно исключает высокий OI.
        // Выход: прямой сигнал, стоп -6%; pending_confirmation рекомендован.
        // Калибровка 2026-07-27: oi30m_high (≥1.0%) — доминирующий reject; физическое
        // противоречие: когда price3h/4h ≥3%, OI почти всегда ≥1%. Fixes:
        //   - oi30m ceiling 1.0% → 2.5% (цена опережает OI, а не нулевой OI)
        //   - price3h/4h порог 3.0% → 2.5%
        //   - lastOi4h ceiling 4.0% → 3.0%
        const _pePriceLed = prescanTracker.get(symbol);
        const isPriceLedMomentum =
          price3h >= 2.5 && // было 3.0%; цена бежит 3h
          price4hChange >= 2.5 && // было 3.0%; и 4h — синхронный импульс
          (_pePriceLed?.lastOi4h == null || _pePriceLed.lastOi4h < 3.0) && // было 4.0%; OI4h не накоплен (fail-pass если null)
          (oi30m === null || oi30m < 2.5) && // было 1.0%; OI30m тихий относительно ценового движения
          price24hChange <= 35 &&
          (_pePriceLed?.cycleCount ?? 0) >= 2;

        // ── BALANCED GRIND (Архетип F): умеренный рост по всем ТФ ───────────────────
        // Ретроспектива 774 мувёров: 32.3% (самый частый) — OI растёт умеренно на всех
        // трёх ТФ одновременно, цена 0.5–5% за 3h, объём нормальный. «Здоровый» памп.
        // Выход: прямой сигнал; стоп -10% (глобальный).
        // Калибровка 2026-07-27: oi1h_range + oi4h_range — доминирующие реджекты.
        // oi1h = null при CG-таймауте → instant fail; убран из обязательных gates.
        // Fixes:
        //   - oi1h: убран из обязательных (fail-open: null = нет данных = не блокирует)
        //   - lastOi4h floor: 1.0% → 0.3% (ретро median oi4h ~0.7%)
        //   - Путь B: lastOi4h null + cycleCount ≥ 5 = slow-build без CG данных
        const _peBalGrind = prescanTracker.get(symbol);
        // Исправления 28.07.2026:
        // (1) oi30m cap 3.0→3.5: устраняет мёртвую зону 3.0–3.5% (BA/TA требуют ≥3.5)
        // (2) Path B lastOi4h: null→<0.3 — охватывает и null, и реальные 0–0.29% (dead zone OI4h)
        // (3) price24h cap 30→40: согласован с остальными прямыми паттернами
        const isBalancedGrind =
          oi30m !== null &&
          oi30m >= 0.1 &&
          oi30m <= 3.5 && // было 3.0%; мёртвая зона 3.0–3.5% (BA/TA требуют ≥3.5)
          // OI1h: не обязателен (CG-таймаут убивает его); если есть — не аномально высокий
          (oi1h === null || oi1h <= 4.0) &&
          // OI4h: умеренный рост ИЛИ нет данных / tiny (<0.3%) + достаточная история = slow-build
          ((_peBalGrind?.lastOi4h != null &&
            _peBalGrind.lastOi4h >= 0.3 && // было 1.0%; ретро median ~0.7%
            _peBalGrind.lastOi4h <= 8.0) ||
            ((_peBalGrind?.lastOi4h ?? 0) < 0.3 && // null ИЛИ 0–0.29% = slow build без OI4h
              (_peBalGrind?.cycleCount ?? 0) >= 5)) &&
          price3h >= 0.5 &&
          price3h <= 5.0 &&
          (volMult >= 0.8 || _peBalGrind?.lastVolMult == null) &&
          price24hChange <= 30;

        // ── STEALTH BREAKOUT (Архетип E): был тихий, затем резкий OI-пробой ─────────
        // Ретроспектива 774 мувёров: 12.7% — все метрики плоские несколько циклов,
        // затем резкий сдвиг OI4h (Δ >3pp) или ускорение объёма (×1.5).
        // Выход: прямой сигнал, стоп -5%.
        // Калибровка 2026-07-27: prev_oi4h_not_flat — доминирующий reject.
        // prevOi4h = null когда CG тайм-аут прошлого цикла → instant fail.
        // Но null = тишина = именно то состояние, которое ищет паттерн.
        // Fixes:
        //   - prevOi4h null → считать "тихим" (fail-open)
        //   - deltaOi4h порог 3.0 → 1.5pp (OI4h — 4h-метрика, медленно меняется за 10 мин)
        const _peStealthBrk = prescanTracker.get(symbol);
        const _sbPrevOi4h = _peStealthBrk?.prevOi4h ?? null;
        const _sbLastOi4h = _peStealthBrk?.lastOi4h ?? null;
        const _sbLastVol = _peStealthBrk?.lastVolMult ?? null;
        const _sbPrevVol = _peStealthBrk?.prevVolMult ?? null;
        // cgNoDataCount >= 3 = токен без CG покрытия (BingX-exclusive); null prevOi4h для них
        // не означает "был тихий" — означает "никогда не было данных CoinGlass".
        // Анализ prescan_tracker: 190/247 токенов с null prev_oi_4h (77%), из них 164 имеют
        // и null last_oi_4h — нет CG покрытия совсем. Guard: null допустим только при cgNoDataCount < 3.
        const _sbCgNoData = (_peStealthBrk?.cgNoDataCount ?? 0) >= 3;
        // prevOi4h=null означает "предыдущий цикл был тихим" (0% OI4h).
        // Дельта: lastOi4h - 0 = lastOi4h (переход из тишины в активность).
        // Старый код требовал оба non-null → Trigger A был мёртв для тихих токенов — COTI-кейс.
        const _sbDeltaOi4h =
          _sbLastOi4h !== null
            ? _sbLastOi4h - (_sbPrevOi4h ?? 0) // null prev = 0% (был тихим)
            : null;
        const _sbVolAccel =
          _sbLastVol !== null && _sbPrevVol !== null && _sbPrevVol > 0
            ? _sbLastVol / _sbPrevVol
            : null;
        const isStealthBreakout =
          ((_sbPrevOi4h === null && !_sbCgNoData) ||
            (_sbPrevOi4h !== null && _sbPrevOi4h < 2.0)) && // null = тихий только при CG покрытии; иначе требуем явное значение < 2.0
          ((_sbDeltaOi4h !== null && _sbDeltaOi4h > 1.5) || // было 3.0pp; OI4h пробой
            (_sbVolAccel !== null &&
              _sbVolAccel >= 1.5 &&
              _sbLastVol !== null &&
              _sbLastVol >= 1.0)) &&
          price24hChange <= 40 &&
          (_peStealthBrk?.cycleCount ?? 0) >= 2;

        // ── DEMARK: TD Sequential Buy Setup ──────────────────────────────────────────
        // Ключ в ta-cache — cgBase формат без "-USDT" (тот же, что CoinGlass).
        // td1h/td4h = 9 → buy setup завершён (9 последовательных close < close[i-4]).
        // 4h-кулдаун: td=9 сохраняется несколько скан-циклов → блокируем повтор.
        const _dmBase = symbol.replace("-USDT", "");
        const _dmTdEntry = getTdAtrEntry(_dmBase);
        const _dmTd1h = _dmTdEntry?.td1h ?? null;
        const _dmTd4h = _dmTdEntry?.td4h ?? null;
        const _dmAtr1h = _dmTdEntry?.atr1h ?? null;
        const _dmLastFired = _demarkCooldown.get(symbol) ?? 0;
        const _dmCooledDown = Date.now() - _dmLastFired > DEMARK_COOLDOWN_MS;
        const isDemarkCandidate =
          (_dmTd1h === 9 || _dmTd4h === 9) &&
          _dmCooledDown &&
          prescanCyclesCurrent >= 3 &&
          price24hChange <= 40; // не берём уже улетевшие

        // ── Байпас для cg_timeout/cg_building записей в очереди подтверждения ──────
        // Эти символы пропустили OI-фильтр (CG timeout или OI ниже порога), но уже
        // добавлены в confirming-очередь. Позволяем им дойти до confirming-блока (строка ~1426).
        // Обёрнут в try-catch: DB timeout здесь ранее убивал весь скан символа
        // (Error scanning symbol). При ошибке — fallback false, скан продолжается.
        // cgFallbackConfirming: используем pre-loop кэш (один SELECT до loop вместо per-symbol)
        const isCgFallbackConfirming = cgFallbackConfirmingSet.has(symbol);

        // ── pdb-инструментация для 5 inline паттернов (pre-check level) ─────────────
        // Позволяет видеть в pattern_debug/history: сколько раз токен дошёл до
        // pre-check и почему не прошёл. _pdbPass ставится в точке реального срабатывания.
        // _symRej пишет per-symbol reject reason для scan_reject_log (аудит "почему не поймали X").
        {
          // Используем prescanTracker.get() напрямую вместо _pe1 — _pe1 объявлен ниже по коду (TDZ).
          const _prcEntry = prescanTracker.get(symbol);
          const _prcCycles = _prcEntry?.cycleCount ?? null;

          // 4h_pullback_continuation v3 — коррекция в тренде; два пути (A: OI4h; B: OI30m прокси)
          _pdbCheck("4h_pullback_continuation");
          if (is4hPullbackContinuation) {
            _pdbPass("4h_pullback_continuation");
          } else if (price24hChange < 1 || price24hChange > 25) {
            _pdbReject("4h_pullback_continuation", "price24h_range");
            _symRej(
              symbol,
              "4h_pullback_continuation",
              "price24h_range",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else if (price4hChange > -1.0) {
            // было -1.5; снижено по ретро median -1.43%
            _pdbReject("4h_pullback_continuation", "no_pullback");
            _symRej(
              symbol,
              "4h_pullback_continuation",
              "no_pullback",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else if (
            // Path A fail: OI4h есть но не отрицательный
            (_pb4hOi4h !== null && _pb4hOi4h >= 0) ||
            // Path B fail: OI4h нет И OI30m не стабилизировался
            (_pb4hOi4h === null && (oi30m === null || oi30m < 0.1))
          ) {
            _pdbReject("4h_pullback_continuation", "oi4h_not_neg");
            _symRej(
              symbol,
              "4h_pullback_continuation",
              "oi4h_not_neg",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else if (_pb4hOi4h !== null && !_pb4hImproving) {
            _pdbReject("4h_pullback_continuation", "oi4h_not_improving");
            _symRej(
              symbol,
              "4h_pullback_continuation",
              "oi4h_not_improving",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else if (oi30m !== null && oi30m < 0) {
            // OI30m отрицательный — дренаж ещё не остановился; не путать с vol_cycles_low
            _pdbReject("4h_pullback_continuation", "oi30m_negative");
            _symRej(
              symbol,
              "4h_pullback_continuation",
              "oi30m_negative",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else {
            _pdbReject("4h_pullback_continuation", "vol_cycles_low");
            _symRej(
              symbol,
              "4h_pullback_continuation",
              "vol_cycles_low",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          }

          // price_led_momentum — цена бежит, OI тихий (Архетип C)
          _pdbCheck("price_led_momentum");
          if (isPriceLedMomentum) {
            _pdbPass("price_led_momentum");
          } else if (price3h < 2.5 || price4hChange < 2.5) {
            // было 3.0%; снижено по структурному анализу
            _pdbReject("price_led_momentum", "price_low");
            _symRej(
              symbol,
              "price_led_momentum",
              "price_low",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else if (
            _pePriceLed?.lastOi4h != null &&
            _pePriceLed.lastOi4h >= 3.0
          ) {
            // было 4.0%; снижено
            _pdbReject("price_led_momentum", "oi4h_high");
            _symRej(
              symbol,
              "price_led_momentum",
              "oi4h_high",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else if (oi30m !== null && oi30m >= 2.5) {
            // было 1.0%; поднято — цена опережает OI, а не нулевой OI
            _pdbReject("price_led_momentum", "oi30m_high");
            _symRej(
              symbol,
              "price_led_momentum",
              "oi30m_high",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else {
            _pdbReject("price_led_momentum", "p24h_or_cycles");
            _symRej(
              symbol,
              "price_led_momentum",
              "p24h_or_cycles",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          }

          // balanced_grind — умеренный рост по всем ТФ (Архетип F)
          // oi1h убран из обязательных gates; oi4h floor снижен 1.0→0.3%
          _pdbCheck("balanced_grind");
          if (isBalancedGrind) {
            _pdbPass("balanced_grind");
          } else if (oi30m === null || oi30m < 0.1 || oi30m > 3.5) {
            _pdbReject("balanced_grind", "oi30m_range");
            _symRej(
              symbol,
              "balanced_grind",
              "oi30m_range",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else if (
            // OI4h condition fails BOTH paths:
            // Path A fail: есть данные но вне диапазона [0.3, 8.0]
            // Path B fail: null или tiny (<0.3%) И cycleCount < 5
            !(
              (_peBalGrind?.lastOi4h != null &&
                _peBalGrind.lastOi4h >= 0.3 &&
                _peBalGrind.lastOi4h <= 8.0) ||
              ((_peBalGrind?.lastOi4h ?? 0) < 0.3 &&
                (_peBalGrind?.cycleCount ?? 0) >= 5)
            )
          ) {
            _pdbReject("balanced_grind", "oi4h_range");
            _symRej(
              symbol,
              "balanced_grind",
              "oi4h_range",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else {
            _pdbReject("balanced_grind", "price_or_vol");
            _symRej(
              symbol,
              "balanced_grind",
              "price_or_vol",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          }

          // stealth_breakout — был тихий, резкий ΔOI4h или ΔvolMult (Архетип E)
          // null prevOi4h = тихий (fail-open) только при CG покрытии (cgNoDataCount < 3); delta порог 3.0→1.5pp
          _pdbCheck("stealth_breakout");
          if (isStealthBreakout) {
            _pdbPass("stealth_breakout");
          } else if (_sbPrevOi4h === null && _sbCgNoData) {
            // null prevOi4h + нет CG покрытия = токен BingX-exclusive; не считается "тихим"
            _pdbReject("stealth_breakout", "cg_no_data");
            _symRej(
              symbol,
              "stealth_breakout",
              "cg_no_data",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else if (
            (_sbDeltaOi4h === null || _sbDeltaOi4h <= 1.5) && // было 3.0pp
            (_sbVolAccel === null || _sbVolAccel < 1.5)
          ) {
            _pdbReject("stealth_breakout", "no_breakout");
            _symRej(
              symbol,
              "stealth_breakout",
              "no_breakout",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          } else {
            _pdbReject("stealth_breakout", "p24h_or_cycles");
            _symRej(
              symbol,
              "stealth_breakout",
              "p24h_or_cycles",
              oi30m ?? null,
              volMult,
              price24hChange,
              _prcCycles,
            );
          }
        }

        // Demark: TD Sequential Buy — TD9 завершён (trended exhaustion buy)
        _pdbCheck("demark");
        if (isDemarkCandidate) {
          _pdbPass("demark");
        } else if (_dmTd1h !== 9 && _dmTd4h !== 9) {
          _pdbReject(
            "demark",
            `no_td9_td1h=${_dmTd1h ?? "null"}_td4h=${_dmTd4h ?? "null"}`,
          );
        } else if (!_dmCooledDown) {
          _pdbReject("demark", "cooldown_4h");
        } else {
          _pdbReject("demark", "cycles_low_or_overheated");
        }

        if (
          !anyOiPass &&
          !tSteady &&
          !isCgFallbackConfirming &&
          !is4hPullbackContinuation &&
          !isPriceLedMomentum &&
          !isBalancedGrind &&
          !isStealthBreakout &&
          !isDemarkCandidate
        ) {
          // ── FALLBACK: токены с недоступным или строящимся OI → OI Watch ─────────
          // Теперь доступен ВСЕМ токенам в батче (не только topByActivity).
          // A) CG timeout — только Layer 1 (activeSymbols): был весь батч → слишком шумно.
          // B) CG Building (OI строится, но ниже порога) — любой токен, cycleCount ≥ 2.
          // C) Dark Flow (устойчивый объём без OI следа) — любой токен, cycleCount ≥ 3 + vol ≥ 2x.
          {
            const dfEntry = prescanTracker.get(symbol);
            const dfCycles = dfEntry?.cycleCount ?? 0;

            // cgTimeout: только топ-активные (Layer 1) — иначе flood мусорными токенами
            if (!cgOI?.available && activeSymbols.has(symbol))
              state.cgTimeoutsLastScan++;
            const cgTimeoutFallback =
              !cgOI?.available &&
              activeSymbols.has(symbol) && // ограничение остаётся — только Layer 1
              spotVolMult !== null &&
              spotVolMult >= 1.3 &&
              (spotVolMult === null || spotVolMult < 2.5) && // vol ≥ 2.5x уже попадает в spot_vol_accumulation
              priceChange > -5 &&
              priceChange < 25 &&
              dfCycles >= 3;

            const buildingTfCount = cgOI?.available
              ? [oi30m, oi1h].filter((v) => v !== null && v >= 2.0).length
              : 0;
            // cgBuilding: расширено — любой токен в батче с cycleCount ≥ 2
            const cgBuildingFallback =
              cgOI?.available &&
              buildingTfCount >= 2 &&
              !anyOiPass &&
              spotVolMult !== null &&
              spotVolMult >= 1.5 &&
              dfCycles >= 2;

            // ── DARK FLOW: устойчивая аномальная активность без следа в OI ──────────
            // Расширено: ранее только activeSymbols (Layer 1), теперь весь батч.
            // CoinGlass ЕСТЬ данные, но OI не растёт ни на одном ТФ.
            // Монета 3+ сканов в пре-скрине с объёмом ≥ 2x — устойчивая аномалия.
            const darkFlowTrigger =
              cgOI?.available && // CG есть — не timeout
              !cgBuildingFallback && // OI даже слабо не строится
              !anyOiPass && // OI не прошёл ни один порог
              dfCycles >= 3 && // 3+ сканов в пресканере
              volMult >= 2.0 && // объём подтверждён (2x+)
              Math.abs(priceChange) < 25 && // цена в разумном диапазоне
              price24hChange < 40; // унифицированный потолок перегрева

            if (cgTimeoutFallback || cgBuildingFallback || darkFlowTrigger) {
              // Не дублируем если символ уже в очереди (watching или confirming)
              // alreadyQueued: используем pre-loop кэш oiWatchActiveSet
              if (!oiWatchActiveSet.has(symbol)) {
                const watchTf = cgTimeoutFallback
                  ? "cg_timeout"
                  : cgBuildingFallback
                    ? "cg_building"
                    : "dark_flow";
                const watchOi = oi30m ?? oi1h ?? 0;
                try {
                  await dbWriteStrict("oiWatch/darkFlow-insert", async () => {
                    const _freshPrice = await getFreshPrice(symbol, close);
                    return db.insert(oiWatchTable).values({
                      symbol,
                      triggerTf: watchTf,
                      oiChange: watchOi,
                      priceAtEntry: _freshPrice,
                      volumeMultiplier: spotVolMult ?? volMult, // 1.6: спот если есть, иначе фьюч
                      sentimentKey: null,
                      status: "confirming",
                      addedAt: new Date(),
                      // Расширенные окна: dark_flow 6ч, cg_timeout/cg_building 12ч
                      expiresAt: new Date(
                        Date.now() +
                          (watchTf === "dark_flow" ? 6 : 12) * 60 * 60 * 1000,
                      ),
                      avgVolume: avgVol,
                      isVolConfirmed: false,
                      oi30mChange: oi30m,
                      oi1hChange: oi1h,
                      oi24hChange: oi24h ?? null,
                      price1hChange: price1hChange ?? null,
                      price24hChange: price24hChange,
                      volStatusReason: cgVolStatusReason(spotCvd),
                      entryVolMult: volMult,
                      entryCgTurnover:
                        cgOI?.cgVolUsd != null &&
                        cgOI?.oiUsd != null &&
                        cgOI.oiUsd > 0
                          ? cgOI.cgVolUsd / cgOI.oiUsd
                          : null,
                    });
                  });
                  logger.info(
                    {
                      symbol,
                      reason: watchTf,
                      vol: volMult.toFixed(1) + "x",
                      price: priceChange.toFixed(1) + "%",
                      buildingTfs: buildingTfCount,
                      dfCycles,
                      inLayer1: activeSymbols.has(symbol),
                    },
                    watchTf === "dark_flow"
                      ? "🌑 DARK FLOW: устойчивая активность без OI — добавлен в OI Watch (6ч)"
                      : "👁 ACTIVITY WATCH: кандидат добавлен в OI Watch",
                  );
                  state.oiWatchLastInsertAt = new Date();
                  state.oiWatchInsertsLastScan++;
                  oiWatchActiveSet.add(symbol); // обновляем кэш чтобы не дублировать в этом цикле
                } catch (err) {
                  state.oiWatchInsertErrors++;
                  state.oiWatchLastInsertError =
                    err instanceof Error ? err.message : String(err);
                  logger.warn(
                    { err, symbol },
                    "dark_flow/activity_watch OI Watch insert failed",
                  );
                }
              }
            }
          }

          logger.debug(
            {
              symbol,
              vol: volMult.toFixed(2) + "x",
              vol4h: volMult4h.toFixed(2) + "x",
              price: priceChange.toFixed(2) + "%",
              price4h: price4hChange.toFixed(1) + "%",
              oi30m: oi30m?.toFixed(2) ?? "n/a",
              oi1h: oi1h?.toFixed(2) ?? "n/a",
            },
            "SKIP: недостаточно объёма или движения цены (vol < 1.0x или price < 2.5%)",
          );
          skipCount.noOiNoVol++;
          break symbolBlock;
        }

        // Какой ТФ сработал (OI path)
        let oiTriggerTf: string;
        let cgOIChange: number;

        if (tSteady) {
          // Steady Accumulation — 5m + 30m одновременно, цена flat
          oiTriggerTf = "steady";
          cgOIChange = oi30m!; // берём 30m как основное значение для скоринга
          logger.info(
            {
              symbol,
              oi30m: oi30m!.toFixed(1) + "%",
              price: priceChange.toFixed(1) + "%",
            },
            "🔍 STEADY ACCUM: Multi-TF OI convergence + flat price",
          );
        } else {
          // Стандартный CoinGlass OI путь
          const triggeredTfs = [
            t30 && "30m",
            t1h && "1h",
            t4h && "4h",
            t24h && "24h",
          ].filter(Boolean) as string[];
          const fallbackSuffix =
            hasFallbackOI && !cgOI?.available ? "+bingx_direct" : "";
          oiTriggerTf = triggeredTfs.join("+") + fallbackSuffix;

          const cand30m = t30 ? Math.abs(oi30m!) : 0;
          const cand1h = t1h ? Math.abs(oi1h!) : 0;
          const cand4h = t4h ? Math.abs(oi4h!) : 0;
          const cand24h = t24h ? Math.abs(oi24h!) : 0;
          const bestAbs = Math.max(cand30m, cand1h, cand4h, cand24h);
          cgOIChange =
            bestAbs === cand30m && t30
              ? oi30m!
              : bestAbs === cand1h && t1h
                ? oi1h!
                : bestAbs === cand4h && t4h
                  ? oi4h!
                  : (oi24h ?? 0); // fallback может быть null (спот-паттерны / L11 инжект без OI) → toFixed крашил скан символа
        }

        // ── STEP 2: LIQUIDITY FILTER — Global Vol24h / OI USD > 0.1 (не «мёртвые» монеты) ──
        const oiUsd = cgOI?.oiUsd;
        const cgVolUsd = cgOI?.cgVolUsd;
        const vol24hUSD = parseFloat(ticker.quoteVolume) || 0;

        if (oiUsd && oiUsd > 0 && cgVolUsd && cgVolUsd > 0) {
          const turnoverRatio = cgVolUsd / oiUsd;
          if (turnoverRatio < 0.15) {
            logger.debug(
              {
                symbol,
                turnoverRatio: turnoverRatio.toFixed(3),
                cgVol: cgVolUsd,
                oiUsd,
              },
              "SKIP: low global turnover ratio (cgVol/OI < 0.15)",
            );
            skipCount.other++;
            break symbolBlock;
          }
        }

        // ── Ликвидность: относительные фильтры покрывают без абсолютных порогов ───
        // Все фильтры ниже — относительные (volMult, OI%, turnoverRatio, спред).
        // Абсолютных долларовых порогов нет: $15M для BTC — песчинка,
        // $15M для микрокапа — всё что есть. Мёртвые монеты отсеиваются спредом
        // (≥0.5% → пропустить) и volMult (2.5x своей базы).

        // ── FILTER: Exit pump — объём в 4x+ раз больше OI = поздний сброс, не органика ──
        if (oiUsd && oiUsd > 0 && cgVolUsd && cgVolUsd > 0) {
          const volToOi = cgVolUsd / oiUsd;
          if (volToOi > 4.0) {
            logger.debug(
              { symbol, volToOi: volToOi.toFixed(2) },
              "SKIP: exit pump — объём >> OI (4x+)",
            );
            skipCount.stalePump++;
            gateRejectLog.push({
              sym: symbol,
              gate: "stalePump",
              oi30m: oi30m?.toFixed(2) ?? "n/a",
              vol: volMult.toFixed(2) + "x",
              price: priceChange.toFixed(2) + "%",
              extra: `volToOi=${volToOi.toFixed(1)}x`,
            });
            _symRej(
              symbol,
              "gate",
              "stalePump",
              oi30m ?? null,
              volMult,
              price24hChange,
              prescanTracker.get(symbol)?.cycleCount ?? null,
            );
            break symbolBlock;
          }
        }

        // Debug tracking (для лог-сводки по итогам цикла)
        debugTop.push({
          symbol,
          vol: volMult,
          cgOI: cgOIChange || null,
          price: priceChange,
        });

        // ── FILTER: Spread — узкий спред (< 0.5%) если BingX возвращает bid/ask ────
        const bid = parseFloat(ticker.bidPrice ?? "0") || 0;
        const ask = parseFloat(ticker.askPrice ?? "0") || 0;
        if (bid > 0 && ask > 0) {
          const spreadPct = ((ask - bid) / ask) * 100;
          if (spreadPct >= 0.5) {
            logger.debug(
              { symbol, spread: spreadPct.toFixed(3) },
              "SKIP: spread >= 0.5%",
            );
            skipCount.other++;
            break symbolBlock;
          }
        }

        // ── STEP 3: VOLUME FILTER — подтверждение интереса ──────────────────────────
        // Логика порогов объёма:
        //
        // A) "High OI Quiet" — OI ≥ 20% (24h) или ≥ 12% (4h) И цена ≤ 1.5% flat.
        //    Крупный игрок набирает позицию тихо в течение часов/суток.
        //    Порог: 1.8x — минимальное подтверждение объёмом (было 1.0x — слишком много шума).
        //
        // B) "Steady Accum" — 5m+30m одновременно + flat price (мульти-ТФ паттерн).
        //    Порог: 1.8x
        //
        // C) Стандартный путь (импульс, пробой, шорт-сквиз): единый порог 1.0x
        const isHighOiQuiet =
          (t24h && Math.abs(oi24h!) >= 10) || (t4h && Math.abs(oi4h!) >= 12); // 20→10: согласовано с OI_THRESH_24H

        // Экстремальный вариант: OI 4h >= 20% или 24h >= 15% + цена плоская.
        // Китовое накопление — объёмный спайк по определению НЕ придёт в фазе накопления.
        // Снижаем порог до 0.9x — достаточно нормального торгового объёма.
        const isExtremeOiQuiet =
          isHighOiQuiet &&
          ((t4h && Math.abs(oi4h!) >= 20) || (t24h && Math.abs(oi24h!) >= 15)); // 20→15: сильный 24h сигнал, не обязательно экстремальный

        // "Медленное бычье накопление" — цена тихо ползёт вверх (1–8%) при наличии OI.
        // NEAR, GRASS, BLEND/LYN-тип: OI копится несколько часов, объём умеренный (1–2x).
        // Стандартный порог 2.5x их режет. Снижаем до 1.5x при bullish slow accum.
        // Условие: цена 1–8% (есть движение, но не взрыв) + хотя бы один OI ТФ сработал.
        const isBullishSlowAccum = t30 || t1h || t4h || t24h;

        // Порог объёма:
        // - extreme OI quiet (накопление китов): 0.9x
        // - bullish slow accum (медленный бычий): 1.5x
        // - стандарт: 2.5x
        // Победители с НИЗКИМ объёмом: M-USDT(0.80x, +22.1%), PLAYSOUT(1.76x, +21.9%), BNLIFE(0.99x, +3.3%).
        // isOiAccel: OI ускоряется от цикла к циклу — снижаем порог объёма с 2.5 до 1.8x.
        // Позволяет токенам типа ROSE (медленное OI накопление) проходить в deep scan раньше.
        const peAccel = prescanTracker.get(symbol);
        const isOiAccel =
          (peAccel?.oiAccel30m ?? 0) >= 1.8 && (peAccel?.lastOi30m ?? 0) >= 0.3;
        const volThreshold = isExtremeOiQuiet
          ? 0.9
          : isBullishSlowAccum
            ? 1.5
            : isOiAccel
              ? 1.8
              : 2.5;

        // Spot vol для gate'а (mcapPct — для логов/будущих фильтров, в условие не входит).
        const _svmMcapUsd = getSpotPoolEntry(symbol)?.mcapUsd ?? null;
        const _spotMcapPct =
          spotVolMult !== null && _peSvm?.lastSpotVol1h && _svmMcapUsd
            ? (_peSvm.lastSpotVol1h / _svmMcapUsd) * 100
            : null;

        // isCgFallbackConfirming: у символа уже есть запись в confirming-очереди
        // с trigger_tf="cg_building"/"cg_timeout" — даём ей дойти до confirming-блока
        // даже при объёме < 2.5x (без этого bypass символ уходит в OI Watch path
        // и никогда не достигает строки ~1684 с проверкой confirming-записи).
        // Архетипные паттерны имеют собственные низкие порогу объёма (≥0.5x / ≥0.8x / нет требования).
        // Они никогда не дойдут до рядков 4918+ если их не вывести из этого блока.
        const _isArchetypeBypass =
          is4hPullbackContinuation ||
          isPriceLedMomentum ||
          isBalancedGrind ||
          isStealthBreakout ||
          isDemarkCandidate;
        if (
          (spotVolMult === null || spotVolMult < volThreshold) &&
          !isCgFallbackConfirming &&
          !_isArchetypeBypass
        ) {
          // ── OI WATCH: OI сработал, но объём ещё не подтянулся ────────────────────
          // Вместо того чтобы просто пропустить, ставим монету на наблюдение.
          // Критерии добавления в watch:
          //   1. OI уверенно сработал (хоть один ТФ)
          //   2. Объём пока ниже порога (иначе бы уже дали сигнал)
          //   3. Цена ещё не улетела (< 25% на текущей свече) — зарождение, не поздний вход
          //   4. Не новый листинг (у них своя логика Short Sniper)
          // t24h включён: монеты с устойчивым 24h накоплением (RECALL-тип) тоже попадают в OI Watch
          const oiTriggeredStrongly = cgOI?.available && (t30 || t1h || t24h);
          const priceNotYetExploded = Math.abs(priceChange) < 25;
          if (oiTriggeredStrongly && priceNotYetExploded && avgVol > 0) {
            try {
              // Изменение 2: если ВСЕ доступные TF OI положительные — используем
              // пониженный порог объёма в OI Watch (кодируем в triggerTf как "all+{tf}")
              const availableOis = [oi30m, oi1h, oi4h, oi24h].filter(
                (v) => v !== null,
              ) as number[];
              const allAvailablePositive =
                availableOis.length >= 2 && availableOis.every((v) => v > 0);
              const baseTf = t30 ? "30m" : "1h";
              const triggerTf = allAvailablePositive ? `all+${baseTf}` : baseTf;
              const triggerOi = t30 ? oi30m! : oi1h!;
              const expiresAt = new Date(Date.now() + 6 * 3600 * 1000); // +6ч: единое окно OI Watch

              // Upsert: обновляем активные watching ИЛИ confirming записи, иначе вставляем новую.
              // Без проверки confirming: cg_timeout/cg_building могли уже создать confirming-запись,
              // и мы бы вставляли duplicate watching поверх неё (EIGEN-баг).
              const existing = await db
                .select({ id: oiWatchTable.id, status: oiWatchTable.status })
                .from(oiWatchTable)
                .where(
                  and(
                    eq(oiWatchTable.symbol, symbol),
                    inArray(oiWatchTable.status, ["watching", "confirming"]),
                  ),
                )
                .limit(1);

              if (existing.length > 0) {
                // Обновляем OI значение (накапливается)
                // dbWriteStrict: критичный апдейт состояния PATH B — не должен теряться молча
                await dbWriteStrict("oiWatch/pathB-update", () =>
                  db
                    .update(oiWatchTable)
                    .set({
                      oiChange: triggerOi,
                      volumeMultiplier: spotVolMult ?? volMult,
                      expiresAt,
                      volStatusReason: cgVolStatusReason(spotCvd),
                    }) // 1.6
                    .where(eq(oiWatchTable.id, existing[0].id)),
                );
              } else if (existing.length === 0) {
                await dbWriteStrict("oiWatch/pathB-insert", async () => {
                  const _freshPrice = await getFreshPrice(symbol, close);
                  return db.insert(oiWatchTable).values({
                    symbol,
                    triggerTf,
                    oiChange: triggerOi,
                    priceAtEntry: _freshPrice,
                    volumeMultiplier: spotVolMult ?? volMult, // 1.6
                    sentimentKey: null,
                    status: "watching",
                    addedAt: new Date(),
                    expiresAt,
                    avgVolume: avgVol,
                    oi30mChange: oi30m,
                    oi1hChange: oi1h,
                    oi24hChange: oi24h ?? null,
                    price1hChange: price1hChange ?? null,
                    price24hChange: price24hChange,
                    volStatusReason: cgVolStatusReason(spotCvd),
                    entryVolMult: volMult,
                    entryCgTurnover:
                      cgOI?.cgVolUsd != null &&
                      cgOI?.oiUsd != null &&
                      cgOI.oiUsd > 0
                        ? cgOI.cgVolUsd / cgOI.oiUsd
                        : null,
                  });
                });
                logger.info(
                  {
                    symbol,
                    triggerTf,
                    oiChange: triggerOi.toFixed(2) + "%",
                    vol: volMult.toFixed(2) + "x",
                    price: priceChange.toFixed(2) + "%",
                  },
                  "👁 OI WATCH: добавлен кандидат (OI есть, объём ещё не подтянулся)",
                );
                state.oiWatchLastInsertAt = new Date();
                state.oiWatchInsertsLastScan++;
              }
            } catch (err) {
              state.oiWatchInsertErrors++;
              state.oiWatchLastInsertError =
                err instanceof Error ? err.message : String(err);
              logger.warn({ err, symbol }, "OI Watch insert failed");
            }
          }
          logger.debug(
            {
              symbol,
              volMult: volMult.toFixed(2),
              threshold: volThreshold,
              isHighOiQuiet,
              isSteady: tSteady,
            },
            "SKIP: volume below threshold",
          );
          skipCount.lowVolume++;
          break symbolBlock;
        }

        if (isHighOiQuiet) {
          logger.info(
            {
              symbol,
              oi24h: oi24h?.toFixed(1) + "%",
              oi4h: oi4h?.toFixed(1) + "%",
              price: priceChange.toFixed(1) + "%",
              vol: volMult.toFixed(1) + "x",
            },
            "🏦 HIGH OI QUIET: Large OI + flat price — hidden accumulation/distribution",
          );
        }

        // ── STEP 4: ANTI-STALE FILTER ─────────────────────────────────────────────
        // Если CoinGlass batch занял 8+ минут и монета уже двинулась на >= 20%
        // за последние 2 свечи (60 мин) — это запоздалый сигнал, пропускаем.
        // (было 3 свечи / 15% — слишком агрессивно, пропускали вторые волны)
        const STALE_LOOKBACK = 2; // свечи назад (2 × 30m = 60 мин)
        const STALE_THRESHOLD = 45; // % порог "уже поздно" (увеличено для ракет типа SUP/OWL)
        const staleRefIdx = klines.length - 1 - STALE_LOOKBACK;
        if (staleRefIdx >= 0) {
          const staleRefClose = parseFloat(klines[staleRefIdx].close) || 0;
          if (staleRefClose > 0) {
            const staleMove = Math.abs(
              ((close - staleRefClose) / staleRefClose) * 100,
            );
            if (staleMove >= STALE_THRESHOLD) {
              logger.info(
                {
                  symbol,
                  staleMove: staleMove.toFixed(1) + "%",
                  lookbackCandles: STALE_LOOKBACK,
                },
                "SKIP: stale signal — price already moved too much in last 3 candles",
              );
              skipCount.priceTooHigh++;
              break symbolBlock;
            }
          }
        }

        // ── PRICE GROWTH GATE: "присутствие" vs "накопление" ────────────────────────
        // Если токен 3+ циклов в пресканере и цена не выросла ≥ +0.5% от точки первого
        // появления — он не накапливается, а просто присутствует в пуле.
        // Исключения (whitelist): isHiddenAccumLikely — тихое OI-накопление с плоской ценой;
        // _likelyDipAccum: при дипе цена по определению ниже firstPrice — gate убивал бы
        // паттерн структурно до evaluatePattern. det ещё не вычислен, поэтому используем
        // те же условия что detectSentiment: OI ≥4% (снижено с 8% 2026-07-10) + price -0.5..-3% + vol ≥2x.
        const _pe1 = prescanTracker.get(symbol);
        const _likelyDipAccum =
          cgOIChange >= 4 &&
          priceChange >= -3.0 &&
          priceChange < -0.5 &&
          spotVolMult !== null &&
          spotVolMult >= 2.0;
        // Bypass: токен 10+ циклов с устойчивым OI4h ≥2% но ценой в боковике [-5%..+2%]
        // Это классическая тихая аккумуляция без подтверждения цены — не давим gate.
        const _isHighOiLongAccum =
          (_pe1?.lastOi4h ?? 0) >= 2.0 &&
          (_pe1?.cycleCount ?? 0) >= 10 &&
          priceChange >= -5.0 &&
          priceChange <= 2.0;
        {
          const _pgFirst = _pe1?.firstPrice ?? 0;
          const _pgLast = _pe1?.lastPrice ?? 0;
          if (
            (_pe1?.cycleCount ?? 0) >= 3 &&
            _pgFirst > 0 &&
            _pgLast > 0 &&
            _pgLast <= _pgFirst * 1.005 &&
            !isHiddenAccumLikely &&
            !_likelyDipAccum &&
            !_isHighOiLongAccum
          ) {
            const _pgMovePct =
              ((_pgLast / _pgFirst - 1) * 100).toFixed(2) + "%";
            const _pgBlockedPattern: string | undefined = tSteady
              ? "tSteady_pathb"
              : undefined;
            logger.debug(
              {
                symbol,
                cycleCount: _pe1!.cycleCount,
                firstPrice: _pgFirst,
                lastPrice: _pgLast,
                movePct: _pgMovePct,
              },
              "SKIP: price-gate — цена не выросла ≥ +0.5% от firstPrice за 3+ цикла",
            );
            skipCount.priceGate++;
            break symbolBlock;
          }
        }

        // ── PATTERN EVALUATION (CoinGlass OI + Volume + Price) ────────────────────
        // PDB: оба паттерна evaluatePattern проверяются для каждого токена —
        // считаем здесь все evaluations, не только passes.
        _pdbCheck("trend_accumulation");
        _pdbCheck("bullish_accumulation");
        let det = evaluatePattern(
          cgOIChange,
          priceChange,
          spotVolMult !== null ? spotVolMult : volMult,
          null,
          settings,
          oiTriggerTf,
          _pe1?.prevOi30m ?? null,
          price24hChange,
          _pe1?.cycleCount ?? 0,
        );
        // Pattern debug: предусловие выполнено (evaluatePattern вернул совпадение)
        if (det) _pdbPass(det.sentiment.key);

        // T2 (2026-07-19): PDB диагностика trend_accumulation — почему detectSentiment
        // вернул bullish_accumulation (fallback) вместо trend_accumulation.
        // Срабатывает когда det=BA (условия TA не выполнены), логирует ПЕРВЫЙ failed gate.
        // Позволяет увидеть распределение блокировок в реальных scan-циклах.
        if (det?.sentiment.key === "bullish_accumulation") {
          const _taEffVol = spotVolMult !== null ? spotVolMult : volMult;
          const _taCycles = _pe1?.cycleCount ?? 0;
          if (cgOIChange < 3.5) {
            _pdbReject("trend_accumulation", "oi30m_low");
          } else if (_pe1?.prevOi30m !== null && (_pe1?.prevOi30m ?? 0) < 0.3) {
            // prevOi30m null = fail-open: CG-таймаут не логируем как reject
            _pdbReject("trend_accumulation", "prev_oi30m_low");
          } else if (priceChange < 1.0) {
            _pdbReject("trend_accumulation", "price30m_low");
          } else if (price24hChange > 20.0) {
            _pdbReject("trend_accumulation", "price24h_high");
          } else if (_taEffVol < 0.5) {
            _pdbReject("trend_accumulation", "vol_low");
          }
        }

        // 1.1: trend_accumulation — фьюч volMult floor.
        // Порог снижен 1.5x → 0.4x (2026-07-14): исторические прибыльные сигналы
        // (SLX, RPL, RIF, KGEN) имели futures vol 0.5–1.1x — все ниже старого порога 1.5x.
        // Старый порог 1.5x + аналогичный gate в detectSentiment убили все срабатывания.
        // 0.4x — минимальный floor против полного отсутствия активности.
        if (det?.sentiment.key === "trend_accumulation" && volMult < 0.4) {
          _pdbReject("trend_accumulation", "fut_vol_mult_low");
          _symRej(
            symbol,
            "trend_accumulation",
            "fut_vol_mult_low",
            oi30m ?? null,
            volMult,
            price24hChange,
            _pe1?.cycleCount ?? null,
          );
          det = null;
        }

        // ── OI floor для bullish_accumulation ────────────────────────────────────────
        // ПРОБЛЕМА: detectSentiment — безусловный fallback: возвращает BA при ЛЮБОМ OI (даже 0%).
        // Анализ 6 сигналов: победители OI ≥ 10% (OPENEDEN +16.5%); проигравшие OI 4-6%
        // (FIL/LAB/ULTIMA — всё отменено). OPN-USDT 2026-07-16: OI30m = 0.84% → −6.3% PnL.
        // Бэктест 90д (18 сигналов):
        //   cgOI30m null (OI1h/4h fallback): avg_peak 12.8%, 22% SL, avg_pnl +2.2% ← ЛУЧШАЯ группа
        //   cgOI30m 0-3%: avg_peak 6.6%, 50% SL, avg_pnl -6.2%  ← ХУДШАЯ группа
        //   cgOI30m >3%:  avg_peak 5.4%, 50% SL, avg_pnl -6.3%
        // Вывод: снижение cgOI порога с 3.5% до 2.0% открыло 2-3.5% bucket (50% SL!).
        // Реверт: cgOI30m ≥ 3.5%. OI1h/4h fallback — лучшая группа, оставить без изменений.
        if (det?.sentiment.key === "bullish_accumulation") {
          // EPIC-кейс (2026-07-16): OI30m=0.8% но OI4h=5.8% → in_run +15.6%.
          // Накопление может идти на 4h TF без резкого всплеска на 30m.
          // Проверяем любой TF: cgOI 30m ≥ 3.5% ИЛИ OI1h ≥ 2% ИЛИ OI4h ≥ 2.5%.
          // Bucket 2-3.5% cgOI даёт 50% SL по бэктесту — не накопление, уже памп.
          const _baHasStrongOI =
            cgOIChange >= 3.5 ||
            (oi1h !== null && oi1h >= 2.0) ||
            (oi4h !== null && oi4h >= 2.5);
          if (!_baHasStrongOI) {
            _pdbReject("bullish_accumulation", "oi_too_low");
            _symRej(
              symbol,
              "bullish_accumulation",
              "oi_too_low",
              oi30m ?? null,
              volMult,
              price24hChange,
              _pe1?.cycleCount ?? null,
            );
            logger.debug(
              {
                symbol,
                cgOI30m: cgOIChange.toFixed(2) + "%",
                oi1h: oi1h?.toFixed(2) ?? "n/a",
                oi4h: oi4h?.toFixed(2) ?? "n/a",
              },
              "SKIP bullish_accumulation: OI ниже минимума по всем TF (30m<3.5% + 1h<2% + 4h<2.5%)",
            );
            det = null;
          }
        }

        // ── Two-cycle OI gate для bullish_accumulation ───────────────────────────────
        // Разовый OI-спайк ≠ накопление. Настоящее накопление = OI растёт 2+ цикла.
        // trend_accumulation требует prevOI ≥ 1%; BA минимально — prevOi30m > 0.
        // Fail-open: prevOi30m === null (данных нет) → пропускаем, не блокируем.
        if (det?.sentiment.key === "bullish_accumulation") {
          const _baPrevOi = _pe1?.prevOi30m ?? null;
          // Ретроспектива 774 кейсов: p25 prevOI30m = -1.04%, многие реальные пампы
          // имели слегка отрицательный предыдущий цикл. Порог ослаблен 0 → -0.3
          // (отсекает явный слив OI, но пропускает боковик/незначительный минус).
          if (_baPrevOi !== null && _baPrevOi <= -0.3) {
            _pdbReject("bullish_accumulation", "prev_oi_not_building");
            _symRej(
              symbol,
              "bullish_accumulation",
              "prev_oi_not_building",
              oi30m ?? null,
              volMult,
              price24hChange,
              _pe1?.cycleCount ?? null,
            );
            logger.debug(
              { symbol, prevOi30m: _baPrevOi.toFixed(2) + "%" },
              "SKIP bullish_accumulation: OI не накапливалось предыдущий цикл (prevOi30m ≤ -0.3)",
            );
            det = null;
          }
        }

        // ── Vol floor для bullish_accumulation ───────────────────────────────────────
        // ПРОБЛЕМА: detectSentiment возвращает bullish_accumulation как безусловный fallback.
        // Сигналы без OI и с низким vol — чистый шум: BILL (-18%), PARTI (-10%).
        // Правило (анализ 6 сигналов, 2026-07-16):
        //   С CG OI ≥ порога настроек:               требуем vol ≥ 1.8x (было 1.5x, 2026-07-16)
        //   Без OI (cgOI недоступен / ниже порога):  требуем vol ≥ 2.5x (было 2.0x, 2026-07-16)
        // spotVolMult приоритетнее volMult (реальный спотовый интерес).
        // Победители: OPENEDEN (2.1x OI≥10%) — проходит; LAB/FHE с 0.6-0.9x — отсечены.
        if (det?.sentiment.key === "bullish_accumulation") {
          const _baEffVol = spotVolMult !== null ? spotVolMult : volMult;
          // _baCgAbove синхронизирован с OI floor выше: cgOI ≥ 3.5% (после реверта с 2.0%).
          // Бэктест: null-группа (OI1h/4h only) = лучший результат (+2.2% avg pnl) — minVol 1.0x.
          // Группа с cgOI 2-3.5% = 50% SL → уже отсечена _baHasStrongOI выше.
          const _baCgAbove =
            (cgOI?.available === true && cgOIChange >= 3.5) ||
            (oi1h !== null && oi1h >= 2.0) ||
            // Выровнен с _baHasStrongOI: oi4h ≥ 2.5% (было 3.0% — несогласованность)
            (oi4h !== null && oi4h >= 2.5);
          const _baMinVol = _baCgAbove ? 1.0 : 1.8;
          if (_baEffVol < _baMinVol) {
            _pdbReject(
              "bullish_accumulation",
              _baCgAbove ? "vol_low_with_oi" : "vol_low_no_oi",
            );
            _symRej(
              symbol,
              "bullish_accumulation",
              _baCgAbove ? "vol_low_with_oi" : "vol_low_no_oi",
              oi30m ?? null,
              volMult,
              price24hChange,
              _pe1?.cycleCount ?? null,
            );
            logger.debug(
              {
                symbol,
                vol: _baEffVol.toFixed(2),
                minVol: _baMinVol,
                hasCgOi: _baCgAbove,
              },
              "SKIP bullish_accumulation: объём ниже минимального порога",
            );
            det = null;
          }
        }

        if (det && (_pe1?.cycleCount ?? 0) > 25) {
          _pdbReject("bullish_accumulation", "cycles_too_high");
          _symRej(
            symbol,
            "bullish_accumulation",
            "cycles_too_high",
            oi30m ?? null,
            volMult,
            price24hChange,
            _pe1?.cycleCount ?? null,
          );
          det = null;
        }

        // ── OI cross-TF consistency gate ─────────────────────────────────────────────
        // OI1h должен быть неотрицательным если данные есть.
        // KAITO 2026-07-16: OI30m +1.54% но OI1h -0.55%, OI4h -4.39% → OI разворачивается.
        // OI4h < -3%: дистрибуция на старшем ТФ — BA не для этого.
        if (det?.sentiment.key === "bullish_accumulation") {
          if (oi1h !== null && oi1h < 0) {
            _pdbReject("bullish_accumulation", "oi1h_negative");
            _symRej(
              symbol,
              "bullish_accumulation",
              "oi1h_negative",
              oi30m ?? null,
              volMult,
              price24hChange,
              _pe1?.cycleCount ?? null,
            );
            logger.debug(
              { symbol, oi1h: oi1h.toFixed(2) },
              "SKIP bullish_accumulation: OI1h отрицательный — OI разворачивается",
            );
            det = null;
          } else if (oi4h !== null && oi4h < -5) {
            _pdbReject("bullish_accumulation", "oi4h_unwinding");
            _symRej(
              symbol,
              "bullish_accumulation",
              "oi4h_unwinding",
              oi30m ?? null,
              volMult,
              price24hChange,
              _pe1?.cycleCount ?? null,
            );
            logger.debug(
              { symbol, oi4h: oi4h.toFixed(2) },
              "SKIP bullish_accumulation: OI4h < -5% — дистрибуция на старшем ТФ",
            );
            det = null;
          }
        }

        // ── p24h cap для bullish_accumulation ────────────────────────────────────────
        // B2 (2026-07-19): 25% → 20%. Анализ сигналов: FLOCK p24h=27.8% → стоп -10.23%,
        // BANK p24h=26.6% → BU стоп; исторически VANRY (73%) и SYN (92%) тоже прошли.
        // B2b (2026-07-19 бэктест 90д): 20% → 10%.
        // Win avg p24h=0.7%, loss avg p24h=16.4%. Бакеты: 0-5%=1w/1sl, 5-10%=0/1,
        // 10-20%=0/0, >20%=0/2 — ни одного победителя выше 5%, удаляем 10-20%+ зону.
        if (det?.sentiment.key === "bullish_accumulation") {
          if (price24hChange > 10) {
            _pdbReject("bullish_accumulation", "price24h_too_high");
            _symRej(
              symbol,
              "bullish_accumulation",
              "price24h_too_high",
              oi30m ?? null,
              volMult,
              price24hChange,
              _pe1?.cycleCount ?? null,
            );
            logger.debug(
              { symbol, price24h: price24hChange.toFixed(1) },
              "SKIP bullish_accumulation: p24h > 10%",
            );
            det = null;
          }
        }

        // ── B3: futures vol floor для bullish_accumulation ───────────────────────────
        // B3 (2026-07-19): минимальный фьюч-объём ≥0.5x. Ретро OI 2-10% зона:
        // fut ≥0.8x → avg_p3h=7.45%, hit_10%=19; fut <0.8x → avg_p3h=3.64%, hit_10%=0.
        // Порог 0.5x (консервативно): блокирует PARTI (0.2x → стоп -10.89%),
        // сохраняет FHE (0.6x → прибыль +4.98%).
        if (det?.sentiment.key === "bullish_accumulation") {
          if (volMult < 0.5) {
            _pdbReject("bullish_accumulation", "fut_vol_low");
            _symRej(
              symbol,
              "bullish_accumulation",
              "fut_vol_low",
              oi30m ?? null,
              volMult,
              price24hChange,
              _pe1?.cycleCount ?? null,
            );
            logger.debug(
              { symbol, futVol: volMult.toFixed(2) },
              "SKIP bullish_accumulation: futures vol < 0.5x",
            );
            det = null;
          }
        }

        // ── B4: OI30m ceiling для bullish_accumulation ───────────────────────────────
        // B4 (2026-07-19 бэктест 90д): новый гейт. OI30m на входе у стопов avg=4.33%,
        // у победителей avg=0.78%. BA — паттерн тихого накопления; высокий OI30m = уже
        // горячий токен, а не зарождение. Порог 2.5% (консервативно, между 0.78% и 4.33%).
        if (det?.sentiment.key === "bullish_accumulation") {
          if (oi30m !== null && oi30m > 2.5) {
            _pdbReject("bullish_accumulation", "oi30m_too_hot");
            _symRej(
              symbol,
              "bullish_accumulation",
              "oi30m_too_hot",
              oi30m ?? null,
              volMult,
              price24hChange,
              _pe1?.cycleCount ?? null,
            );
            logger.debug(
              { symbol, oi30m: oi30m.toFixed(2) },
              "SKIP bullish_accumulation: OI30m > 2.5% — токен уже горячий при входе (бэктест: стопы avg 4.33%)",
            );
            det = null;
          }
        }

        // ── trend_accumulation: исключить из isExtremeOiQuiet volume bypass ────────────
        // Паттерн предполагает движение цены +2-9%, тихое накопление китов здесь неприменимо.
        // isExtremeOiQuiet снижает порог объёма до 0.9x — для trend_accumulation требуем >= 1.5x.
        if (
          det?.sentiment.key === "trend_accumulation" &&
          isExtremeOiQuiet &&
          volMult < 1.5
        ) {
          logger.debug(
            { symbol, volMult: volMult.toFixed(2) },
            "SKIP: trend_accumulation excluded from isExtremeOiQuiet vol bypass (volMult < 1.5)",
          );
          _pdbReject("trend_accumulation", "extreme_oi_quiet_vol_low");
          skipCount.lowVolume++;
          break symbolBlock;
        }

        // ── ФИЛЬТР: накопительные паттерны — требуем объёмный тренд (не одиночный спайк) ──
        // Одна свеча с высоким объёмом может быть шумом (арбитраж, вынос стопов).
        // Если предыдущие 2 закрытые свечи тоже показывают объём >= 1.3x — это ТРЕНД покупок.
        // Данные: SYN (vol=8x но prevVol была нормальная) — убираем такие сигналы.
        // Исключение: isExtremeOiQuiet — при тихом накоплении китов объёмного тренда
        // по определению нет. Сигнал — сам OI, а не объём. Фильтр неприменим.
        // Альтернативный путь через историю: oi4hConsecGrowth >= 3 (OI4h стабильно растёт
        // 3+ цикла подряд) — прокси на устойчивый тренд накопления, заменяет объёмную проверку.
        const ACCUM_PATTERN_KEYS = ["trend_accumulation"];
        const _accumOi4hHistory = (_pe1?.oi4hConsecGrowth ?? 0) >= 3;
        if (
          det &&
          ACCUM_PATTERN_KEYS.includes(det.sentiment.key) &&
          !isVolTrend &&
          !isExtremeOiQuiet
        ) {
          if (_accumOi4hHistory) {
            logger.debug(
              {
                symbol,
                pattern: det.sentiment.key,
                oi4hConsecGrowth: _pe1?.oi4hConsecGrowth,
                prevVol1: prevVol1Mult.toFixed(2) + "x",
                prevVol2: prevVol2Mult.toFixed(2) + "x",
              },
              "ALLOW[history]: накоп. паттерн — нет объёмного тренда, но oi4hConsecGrowth >= 3 (история OI4h покрывает)",
            );
          } else {
            logger.debug(
              {
                symbol,
                pattern: det.sentiment.key,
                prevVol1: prevVol1Mult.toFixed(2) + "x",
                prevVol2: prevVol2Mult.toFixed(2) + "x",
              },
              "SKIP: накоп. паттерн — нет объёмного тренда (предыдущие свечи < 1.3x нормы)",
            );
            _pdbReject(det.sentiment.key, "vol_trend_fail");
            det = null;
          }
        }

        // ── MTF SPOT CVD: накопительные паттерны требуют подтверждения 1h + 4h ───────
        // Накопление должно быть видно на старших ТФ спота — иначе шум деривативов.
        // Альтернативный путь через историю: cvdPositiveCycles >= 3 (spot CVD был положительным
        // 3+ циклов подряд) И taker не активно против прямо сейчас (netBuyPct >= -10).
        // CG timeout (available=false) — ОСОБЕННО тот случай, где история должна спасать паттерн.
        if (det && ACCUM_PATTERN_KEYS.includes(det.sentiment.key)) {
          const _accumCvdHistory =
            (_pe1?.cvdPositiveCycles ?? 0) >= 3 &&
            (_spotTaker === null ||
              !_spotTaker.available ||
              (_spotTaker.netBuyPct ?? 0) >= -10);

          if (!spotCvd?.available) {
            if (_accumCvdHistory) {
              logger.debug(
                {
                  symbol,
                  pattern: det.sentiment.key,
                  cvdPositiveCycles: _pe1?.cvdPositiveCycles,
                  spotTakerNow: _spotTaker?.netBuyPct?.toFixed(1),
                },
                "ALLOW[history]: накоп. паттерн — CG timeout, но cvdPositiveCycles >= 3 покрывает",
              );
            } else {
              logger.debug(
                {
                  symbol,
                  pattern: det.sentiment.key,
                  cvdPositiveCycles: _pe1?.cvdPositiveCycles,
                },
                "SKIP: накоп. паттерн — нет данных спота (обязательно для паттерна)",
              );
              _pdbReject(det.sentiment.key, "no_spot_cvd_data");
              det = null;
            }
          } else if (spotCvd.cvd1h !== true || spotCvd.cvd4h !== true) {
            if (_accumCvdHistory) {
              logger.debug(
                {
                  symbol,
                  pattern: det.sentiment.key,
                  cvd1h: spotCvd.cvd1h,
                  cvd4h: spotCvd.cvd4h,
                  cvdPositiveCycles: _pe1?.cvdPositiveCycles,
                  spotTakerNow: _spotTaker?.netBuyPct?.toFixed(1),
                },
                "ALLOW[history]: накоп. паттерн — CVD 1h/4h не подтверждает, но cvdPositiveCycles >= 3 (история)",
              );
            } else {
              const _patKey = det.sentiment.key;
              logger.debug(
                {
                  symbol,
                  pattern: _patKey,
                  cvd1h: spotCvd.cvd1h,
                  cvd4h: spotCvd.cvd4h,
                },
                "SKIP: накоп. паттерн — спот CVD 1h и/или 4h не подтверждают накопление (false или нет данных)",
              );
              _pdbReject(_patKey, "cvd_mtf_fail");
              det = null;
            }
          }
        }

        // Override: Steady Accumulation — 5m+30m одновременный рост + цена flat.
        // С новой философией (только подтверждённые покупки) — НЕ стреляем напрямую при flat цене.
        // Вместо этого добавляем в OI Watch: когда цена тронется на 2%+ — PATH B выстрелит.
        // tSteady попадает сюда с volMult >= 2.5 (иначе ушёл бы в OI Watch раньше).
        if (!det && tSteady) {
          try {
            const existingWatch = await db
              .select({ id: oiWatchTable.id })
              .from(oiWatchTable)
              .where(
                and(
                  eq(oiWatchTable.symbol, symbol),
                  inArray(oiWatchTable.status, ["watching", "confirming"]),
                ),
              )
              .limit(1);
            if (existingWatch.length === 0) {
              // dbWriteStrict: критичная запись OI Watch — бросает при неудаче
              await dbWriteStrict("oiWatch/steadyAccum-insert", async () => {
                const _freshPrice = await getFreshPrice(symbol, close);
                return db.insert(oiWatchTable).values({
                  symbol,
                  triggerTf: "30m",
                  oiChange: oi30m!,
                  priceAtEntry: _freshPrice,
                  volumeMultiplier: spotVolMult ?? volMult, // 1.6
                  sentimentKey: null,
                  status: "watching",
                  addedAt: new Date(),
                  expiresAt: new Date(Date.now() + 6 * 3600 * 1000), // +6ч: единое окно OI Watch
                  avgVolume: avgVol,
                  oi30mChange: oi30m,
                  oi1hChange: oi1h,
                  oi24hChange: oi24h ?? null,
                  price1hChange: price1hChange ?? null,
                  price24hChange: price24hChange,
                  volStatusReason: cgVolStatusReason(spotCvd),
                  entryVolMult: volMult,
                  entryCgTurnover:
                    cgOI?.cgVolUsd != null &&
                    cgOI?.oiUsd != null &&
                    cgOI.oiUsd > 0
                      ? cgOI.cgVolUsd / cgOI.oiUsd
                      : null,
                });
              });
              logger.info(
                { symbol, oi30m: oi30m?.toFixed(1), vol: volMult.toFixed(2) },
                "👁 STEADY ACCUM → OI Watch: flat цена, ждём подтверждения движения",
              );
              state.oiWatchLastInsertAt = new Date();
              state.oiWatchInsertsLastScan++;
            }
          } catch (err) {
            state.oiWatchInsertErrors++;
            state.oiWatchLastInsertError =
              err instanceof Error ? err.message : String(err);
            logger.warn({ err, symbol }, "tSteady OI Watch insert failed");
          }
          // Не устанавливаем det — продолжаем без прямого сигнала
        }

        // ── SPOT ABSORPTION: CVD standalone detector (Blend/Beat/Folks-тип) ────────
        // Ловит монеты где шорты закрываются (OI нейтральный или слегка падает),
        // но спот-покупки устойчивые — spot absorption перед потенциальным сквизом.
        // Не пересекается с tSteady (tSteady требует flat цены, здесь цена уже растёт).
        // Не пересекается с anyOiPass (здесь OI NOT в зоне стандартных порогов).
        //
        // Условия входа:
        //   cvd30m = true                       — устойчивые спот-покупки (не разовый всплеск)
        //   priceChange: 1%..15%               — рост допустим до 15% (BSB-тип: +9.22% одна свеча)
        //   oi30m < 4.0%                         — OI не растёт взрывом (иначе уже поймал бы tSteady)
        //   volMult >= 1.3x                    — снижено с 1.5x: SYN-тип (1.43x vol) с сильным SpotCVD
        //   !spotAbsorptionOiBlock              — свежий OI-спайк (5m+30m) или tSteady не обнаружен

        // ── GLOBAL LATE-ENTRY FILTER: price3h > 12% → памп уже произошёл 3ч назад ────
        // Порог поднят с 8% до 12%: OI-накопление может продолжаться пока цена растёт.
        if (
          det &&
          det.sentiment.key !== "spot_vol_accumulation" &&
          price3h > 12
        ) {
          logger.debug(
            {
              symbol,
              price3h: price3h.toFixed(1) + "%",
              pattern: det.sentiment.key,
            },
            "SKIP: late-entry filter — цена выросла >12% за 3ч (поезд ушёл)",
          );
          skipCount.latePump++;
          {
            const _pe = prescanTracker.get(symbol);
            if (_pe) _pe.lastSkipReason = "late_pump";
          }
          _pdbReject(det.sentiment.key, "late_entry_price3h");
          det = null;
        }

        // ── 4H PULLBACK CONTINUATION: коррекция внутри восходящего тренда ─────────
        // Байпас anyOiPass: p24h тренд + p4h откат + OI4h разворачивается из отрицательного.
        // 19% «невидимых» мувёров ретроспективы: p24h +9.2%, p4h −1.43%, oi4h −2.40%.
        // Выход: прямой сигнал, стоп −6%
        if (!det && is4hPullbackContinuation) {
          // Путь A: OI4h доступен; Путь B: OI4h null → OI30m прокси
          const _pbOi4h = _pePullback?.lastOi4h ?? null;
          const _pbPrevOi4h = _pePullback?.prevOi4h ?? null;
          const _pbOiStr =
            _pbOi4h !== null
              ? `OI4h ${(_pbPrevOi4h ?? 0).toFixed(1)}%→${_pbOi4h.toFixed(1)}% улучшается`
              : `OI30m ${(oi30m ?? 0).toFixed(1)}% стабилизируется (CG нет)`;
          det = {
            passes: true,
            oiChangePercent: oi30m ?? 0,
            openInterest: 0,
            sentiment: {
              key: "4h_pullback_continuation",
              label: "4H Pullback Continuation",
              traderAction: `LONG (p24h +${price24hChange.toFixed(1)}% тренд, p4h ${price4hChange.toFixed(1)}% коррекция, ${_pbOiStr}, стоп -6%)`,
              oiFalling: false,
            },
          };
          (det as any).__isConfirmedFire = true;
          logger.info(
            {
              symbol,
              p24h: price24hChange.toFixed(1),
              p4h: price4hChange.toFixed(1),
              prevOi4h: _pbPrevOi4h?.toFixed(1) ?? "null",
              lastOi4h: _pbOi4h?.toFixed(1) ?? "null",
              oi30m: (oi30m ?? 0).toFixed(2),
              vol: volMult.toFixed(2),
            },
            "🔻📈 4H PULLBACK CONTINUATION: коррекция+стабилизация OI — прямой сигнал",
          );
        }

        // ── PRICE-LED MOMENTUM (Архетип C): цена без OI ──────────────────────────────
        // Байпас anyOiPass: оба price3h ≥3% и price4h ≥3%, OI тихий — цена опережает OI.
        // Падает после всех других паттернов — только если ни один из них не сработал.
        // Выход: прямой сигнал, стоп -6%
        if (!det && isPriceLedMomentum) {
          const _plmOi4h = _pePriceLed?.lastOi4h ?? null;
          det = {
            passes: true,
            oiChangePercent: oi30m ?? 0,
            openInterest: 0,
            sentiment: {
              key: "price_led_momentum",
              label: "Price-Led Momentum",
              traderAction: `LONG (price3h +${price3h.toFixed(1)}%, price4h +${price4hChange.toFixed(1)}%, OI4h ${_plmOi4h != null ? _plmOi4h.toFixed(1) + "%" : "—"} — цена опережает OI, стоп -6%)`,
              oiFalling: false,
            },
          };
          (det as any).__isConfirmedFire = true;
          logger.info(
            {
              symbol,
              p3h: price3h.toFixed(1),
              p4h: price4hChange.toFixed(1),
              oi4h: _plmOi4h?.toFixed(1) ?? "null",
              oi30m: (oi30m ?? 0).toFixed(2),
              p24h: price24hChange.toFixed(1),
            },
            "🟡 PRICE-LED MOMENTUM (C): цена бежит, OI тихий — прямой сигнал",
          );
        }

        // ── BALANCED GRIND (Архетип F): умеренный рост по всем ТФ ───────────────────
        // Байпас anyOiPass: OI30m/1h/4h все умеренно положительны, ниже порогов anyOiPass.
        // Самый частый архетип (32.3% пампов) — перехватывает «здоровый» рост.
        // Выход: прямой сигнал, стоп -10% (глобальный)
        if (!det && isBalancedGrind) {
          const _bgOi4h = _peBalGrind?.lastOi4h ?? null;
          det = {
            passes: true,
            oiChangePercent: oi30m ?? 0,
            openInterest: 0,
            sentiment: {
              key: "balanced_grind",
              label: "Balanced Grind",
              traderAction: `LONG (OI: 30m ${(oi30m ?? 0).toFixed(1)}%, 1h ${oi1h != null ? oi1h.toFixed(1) + "%" : "—"}, 4h ${_bgOi4h != null ? _bgOi4h.toFixed(1) + "%" : "—"} — умеренный рост, стоп -10%)`,
              oiFalling: false,
            },
          };
          (det as any).__isConfirmedFire = true;
          logger.info(
            {
              symbol,
              oi30m: (oi30m ?? 0).toFixed(2),
              oi1h: (oi1h ?? 0).toFixed(2),
              oi4h: _bgOi4h?.toFixed(1) ?? "null",
              p3h: price3h.toFixed(1),
              vol: volMult.toFixed(2),
              p24h: price24hChange.toFixed(1),
            },
            "🟢 BALANCED GRIND (F): OI равномерно растёт на всех ТФ — прямой сигнал",
          );
        }

        // ── STEALTH BREAKOUT (Архетип E): был тихий, резкий ΔOI4h ──────────────────
        // Байпас anyOiPass: предыдущий цикл тихий (prevOI4h <2%), резкий пробой OI4h
        // или объём ×1.5 — токен «проснулся».
        // Выход: прямой сигнал, стоп -5%
        if (!det && isStealthBreakout) {
          const _sbOi4hStr =
            _sbLastOi4h != null ? `${_sbLastOi4h.toFixed(1)}%` : "—";
          const _sbDeltaStr =
            _sbDeltaOi4h != null ? `Δ${_sbDeltaOi4h.toFixed(1)}pp` : "";
          det = {
            passes: true,
            oiChangePercent: oi30m ?? 0,
            openInterest: 0,
            sentiment: {
              key: "stealth_breakout",
              label: "Stealth Breakout",
              traderAction: `LONG (prevOI4h ${(_sbPrevOi4h ?? 0).toFixed(1)}% → OI4h ${_sbOi4hStr} ${_sbDeltaStr} — пробой из тихой зоны, стоп -5%)`,
              oiFalling: false,
            },
          };
          (det as any).__isConfirmedFire = true;
          logger.info(
            {
              symbol,
              prevOi4h: (_sbPrevOi4h ?? 0).toFixed(1),
              lastOi4h: _sbLastOi4h?.toFixed(1) ?? "null",
              deltaOi4h: _sbDeltaOi4h?.toFixed(1) ?? "null",
              volAccel: _sbVolAccel?.toFixed(2) ?? "null",
              p24h: price24hChange.toFixed(1),
            },
            "⚪ STEALTH BREAKOUT (E): пробой из тихой зоны — прямой сигнал",
          );
        }

        // ── DEMARK: TD Sequential Buy (TD9) — трендовое истощение, разворот ──────────
        // Байпас anyOiPass: чисто технический паттерн (TD9 не требует OI-сигнала).
        // Условие: 1h или 4h TD9 buy setup завершён, cycles ≥ 3, не перегрет.
        // Стоп: -8% (PATTERN_MAX_STOP) ≈ 2×ATR_1h в среднем.
        // Отмена: demark_counter_td (td1h ≤ -3) в FastCycle + stale_oi_vol наследуется.
        // Таймаут: 2 дня (getMaxWatchDays = 2) — TD9 сетапы быстро устаревают.
        if (!det && isDemarkCandidate) {
          const _dmTfStr = _dmTd4h === 9 ? "4h" : "1h";
          const _dmTdStr = _dmTd4h === 9 ? `TD4h=9` : `TD1h=9`;
          det = {
            passes: true,
            oiChangePercent: oi30m ?? 0,
            openInterest: 0,
            sentiment: {
              key: "demark",
              label: `Demark TD9 Buy (${_dmTfStr})`,
              traderAction: `LONG (${_dmTdStr} — 9 баров истощения завершены, разворот вверх, стоп -8%)`,
              oiFalling: false,
            },
          };
          (det as any).__isConfirmedFire = true;
          _demarkCooldown.set(symbol, Date.now());
          logger.info(
            {
              symbol,
              td1h: _dmTd1h,
              td4h: _dmTd4h,
              atr1h: _dmAtr1h,
              p24h: price24hChange.toFixed(1),
              cycles: prescanCyclesCurrent,
            },
            "🕯 DEMARK TD9: buy setup завершён — прямой сигнал (TA bypass)",
          );
        }

        if (!det) {
          // Записываем причину пропуска в prescan-трекер для отображения в UI
          const _pe = prescanTracker.get(symbol);
          if (_pe && _pe.lastSkipReason !== "late_pump") {
            // late_pump уже записан выше; остальные случаи — OI прошёл, паттерн не сработал
            _pe.lastSkipReason = anyOiPass
              ? "no_pattern"
              : !cgOI?.available
                ? "no_cg_data"
                : "oi_low";
          }
          break symbolBlock;
        }
        // Паттерн найден — сбрасываем причину пропуска
        {
          const _pe = prescanTracker.get(symbol);
          if (_pe) _pe.lastSkipReason = null;
        }

        // Явный лог "паттерн сработал, символ известен" ДО кулдаунов — раньше был
        // виден только агрегированный passed-счётчик без символа, и когда сигнал
        // пропадал в кулдаунах ниже, невозможно было доказать, какой именно кулдаун
        // его срезал (см. кейс quiet_oi_accumulation passed=1 → 0 сигналов).
        logger.info(
          { symbol, pattern: det.sentiment.key, cycle: scanCycleCounter },
          "Pattern matched — det assigned, entering cooldown checks",
        );

        // ── КУЛДАУН по символу после отмены/стоп-лосса ──────────────────────────
        // cancelled: 6ч — сигнал истёк (не стоп), токен может снова накапливаться.
        //   Было 24ч — слишком долго: PLAYSOUT отменился за дип, через 6ч уже памп.
        // stop_loss: 24ч — добавочный кулдаун (плюс отдельный 3-дневный бан ниже).
        // Защита от NULL closed_at (баг в старых записях): используем detectedAt как запасное.
        {
          const recentCancelled = await db
            .select({ id: trackedSignalsTable.id })
            .from(trackedSignalsTable)
            .where(
              and(
                eq(trackedSignalsTable.symbol, symbol),
                eq(trackedSignalsTable.status, "cancelled"),
                or(
                  gte(
                    trackedSignalsTable.closedAt,
                    new Date(Date.now() - 6 * 60 * 60 * 1000),
                  ),
                  and(
                    isNull(trackedSignalsTable.closedAt),
                    gte(
                      trackedSignalsTable.detectedAt,
                      new Date(Date.now() - 6 * 60 * 60 * 1000),
                    ),
                  ),
                ),
              ),
            )
            .limit(1);
          if (recentCancelled.length > 0) {
            logger.info(
              { symbol },
              "SKIP: кулдаун 6ч — недавний cancelled по этому символу",
            );
            skipCount.cooldown++;
            {
              const _pe = prescanTracker.get(symbol);
              if (_pe) _pe.lastSkipReason = "cooldown";
            }
            break symbolBlock;
          }

          const recentStopLoss = await db
            .select({ id: trackedSignalsTable.id })
            .from(trackedSignalsTable)
            .where(
              and(
                eq(trackedSignalsTable.symbol, symbol),
                eq(trackedSignalsTable.status, "stop_loss"),
                or(
                  gte(
                    trackedSignalsTable.closedAt,
                    new Date(Date.now() - 24 * 60 * 60 * 1000),
                  ),
                  and(
                    isNull(trackedSignalsTable.closedAt),
                    gte(
                      trackedSignalsTable.detectedAt,
                      new Date(Date.now() - 24 * 60 * 60 * 1000),
                    ),
                  ),
                ),
              ),
            )
            .limit(1);
          if (recentStopLoss.length > 0) {
            logger.info(
              { symbol },
              "SKIP: кулдаун 24ч — недавний stop_loss по этому символу",
            );
            skipCount.cooldown++;
            {
              const _pe = prescanTracker.get(symbol);
              if (_pe) _pe.lastSkipReason = "cooldown";
            }
            break symbolBlock;
          }
        }

        // ── ХРОНИЧЕСКИЙ ТОКЕН: накопление без результата 4 дня → 72ч блок ─────────
        // WAVES: 2 недели повторяющихся накопительных паттернов без движения цены.
        // Если за последние 4 дня было 2+ отмены накопительного паттерна — токен мёртв.
        // Не давать ему снова заходить в систему раньше чем через 72ч.
        {
          const since4d = new Date(Date.now() - 4 * 24 * 60 * 60 * 1000);
          const since72h = new Date(Date.now() - 72 * 60 * 60 * 1000);
          const chronicCancels = await db
            .select({ id: trackedSignalsTable.id })
            .from(trackedSignalsTable)
            .innerJoin(
              signalsTable,
              eq(signalsTable.id, trackedSignalsTable.signalId),
            )
            .where(
              and(
                eq(trackedSignalsTable.symbol, symbol),
                eq(trackedSignalsTable.status, "cancelled"),
                inArray(signalsTable.sentimentKey, [
                  "dip_accumulation",
                  "trend_accumulation",
                ]),
                gte(trackedSignalsTable.closedAt, since4d),
              ),
            );
          if (chronicCancels.length >= 2) {
            // Проверяем, не было ли профита за последние 72ч (если был — не блокируем)
            const recentProfit = await db
              .select({ id: trackedSignalsTable.id })
              .from(trackedSignalsTable)
              .where(
                and(
                  eq(trackedSignalsTable.symbol, symbol),
                  eq(trackedSignalsTable.status, "profit"),
                  gte(trackedSignalsTable.closedAt, since72h),
                ),
              )
              .limit(1);
            if (recentProfit.length === 0) {
              logger.info(
                { symbol, chronicCancels: chronicCancels.length },
                "SKIP: хронический токен — 2+ отмены накопительных паттернов за 4 дня без профита (блок 72ч)",
              );
              skipCount.cooldown++;
              break symbolBlock;
            }
          }
        }

        // ── ПОВТОРНЫЙ СИГНАЛ / ГЛОБАЛЬНЫЙ COOLDOWN 24ч ──────────────────────────
        // Если символ уже получил сигнал за последние 24ч — блокируем повтор,
        // КРОМЕ случая когда по нему уже открыта позиция (active/in_run/accumulation/re_entry):
        // там сопровождение уже идёт и повторный сигнал не нужен, но и блокировать его бессмысленно.
        let isRepeatSignal = false;
        {
          const since24h = new Date(Date.now() - 24 * 60 * 60 * 1000);
          const prev = await db
            .select({ id: trackedSignalsTable.id })
            .from(trackedSignalsTable)
            .where(
              and(
                eq(trackedSignalsTable.symbol, symbol),
                gte(trackedSignalsTable.detectedAt, since24h),
              ),
            )
            .limit(1);
          isRepeatSignal = prev.length > 0;
          if (isRepeatSignal) {
            // Проверяем: есть ли активная позиция — тогда не блокируем
            const activePos = await db
              .select({ id: trackedSignalsTable.id })
              .from(trackedSignalsTable)
              .where(
                and(
                  eq(trackedSignalsTable.symbol, symbol),
                  inArray(trackedSignalsTable.status, [
                    "active",
                    "in_run",
                    "accumulation",
                    "re_entry",
                  ]),
                ),
              )
              .limit(1);
            if (activePos.length === 0) {
              logger.info(
                { symbol },
                "SKIP: cooldown 24ч — символ уже получил сигнал, активной позиции нет",
              );
              skipCount.cooldown++;
              break symbolBlock;
            }
            logger.debug(
              { symbol },
              "REPEAT: активная позиция есть — cooldown не применяем, помечаем повтор",
            );
          }
        }

        // OI теперь бонус, а не ворота — отрицательный OI на отдельных ТФ не блокирует сигнал.
        // Исключение 1: если CoinGlass покрывает монету И все краткосрочные ТФ глубоко отрицательные
        // — это явный пост-памп дамп, входить опасно.
        if (cgOI?.available) {
          const shortTfValues = [oi30m, oi1h].filter(
            (v) => v !== null,
          ) as number[];
          const allDeeplyNegative =
            shortTfValues.length >= 2 && shortTfValues.every((v) => v < -3);
          if (allDeeplyNegative) {
            logger.debug(
              { symbol, oi30m: oi30m?.toFixed(1), oi1h: oi1h?.toFixed(1) },
              "SKIP: все краткосрочные OI глубоко отрицательные (< -3%) — пост-памп дамп",
            );
            skipCount.contraSignal++;
            break symbolBlock;
          }
        }

        // ── ОКНО ПОДТВЕРЖДЕНИЯ: 60 минут для всех паттернов ──────────────────────
        // Идея: засёк рост OI → подожди 1 час → проверь что OI всё ещё растёт → сигнал.
        // Это отсекает flash-пампы (OI резко растёт и тут же падает за 10-15 минут).
        // Настоящее накопление держит OI положительным часами.
        //
        // Проверки на 60-й минуте:
        //   • свежий OI (cgOIChange) < -3%   → OI иссяк, накопление закончилось → отмена
        //   • цена откатилась > 5% от точки   → ложный сигнал → отмена
        //   • цена улетела > 20% вверх         → вход слишком дорогой → отмена
        //   • всё остальное                    → СИГНАЛ
        //
        {
          // Время ожидания зависит от ТФ: 4h/24h уже подтверждают многочасовое накопление,
          // долго ждать смысла нет. 30m спайки требуют полного часа проверки.
          // Увеличено с 4ч до 6ч: теперь окно подтверждения 2ч + запас ещё 4ч наблюдения.
          const CONFIRM_EXPIRE_MS = 6 * 60 * 60 * 1000;
          // MAX_RETRACE_PCT определяется ниже — после того как известен тип паттерна (entryTf / sentimentKey).
          const OI_DRAIN_PCT = -3.0;

          const dbConfirmingRows = await db
            .select()
            .from(oiWatchTable)
            .where(
              and(
                eq(oiWatchTable.symbol, symbol),
                eq(oiWatchTable.status, "confirming"),
              ),
            )
            .limit(1);

          // Мержим DB + in-memory fallback (DB приоритет при дубликатах)
          let confirmingEntry: typeof dbConfirmingRows = dbConfirmingRows;
          if (confirmingEntry.length === 0) {
            const memEntry = confirmingWatchMap.get(symbol);
            if (memEntry && memEntry.expiresAt > new Date()) {
              confirmingEntry = [
                {
                  id: -1,
                  symbol: memEntry.symbol,
                  triggerTf: memEntry.triggerTf,
                  oiChange: memEntry.oiChange,
                  priceAtEntry: memEntry.priceAtEntry,
                  volumeMultiplier: memEntry.volumeMultiplier,
                  sentimentKey: memEntry.sentimentKey,
                  status: "confirming",
                  addedAt: memEntry.addedAt,
                  expiresAt: memEntry.expiresAt,
                  avgVolume: memEntry.avgVolume,
                  oi30mChange: memEntry.oi30mChange,
                  oi1hChange: memEntry.oi1hChange,
                  oi24hChange: memEntry.oi24hChange,
                  firedAt: null,
                } as (typeof dbConfirmingRows)[0],
              ];
            }
          }

          if (confirmingEntry.length > 0) {
            const entry = confirmingEntry[0];
            const ageMs = Date.now() - new Date(entry.addedAt).getTime();
            const priceFromDetection =
              ((close - entry.priceAtEntry) / entry.priceAtEntry) * 100;
            // Сохраняем последнюю цену для display в UI — символ может выпасть из prescanTracker
            if (close > 0) oiWatchPriceCache.set(symbol, close);

            // drift4h: изменение цены за последние 4 часа (скользящее окно).
            // Используется вместо priceFromDetection для CONFIRM WAIT — чтобы старые
            // записи (7+ дней в очереди) не блокировались устаревшей точкой входа.
            // 30m свечи → 4h = 8 свечей назад. Берём close той свечи как базу.
            const kline4hAgo =
              klines.length >= 9 ? klines[klines.length - 9] : klines[0];
            const price4hAgo =
              parseFloat(kline4hAgo?.close ?? "0") || entry.priceAtEntry;
            const drift4h =
              price4hAgo > 0
                ? ((close - price4hAgo) / price4hAgo) * 100
                : priceFromDetection;

            // Время ожидания определяется по ТФ сохранённому в записи очереди.
            // "4h", "5m+4h" — реальные 4h OI → 30 мин достаточно.
            const entryTf = entry.triggerTf ?? "30m";
            const is4hOI = /\b4h\b/.test(entryTf);
            const is24hOI = /\b24h\b/.test(entryTf);
            const is1hOI = /\b1h\b/.test(entryTf);
            const isSlowPattern = [
              "dip_accumulation",
              "trend_accumulation",
              "spot_divergence",
              "bullish_accumulation",
            ].includes(entry.sentimentKey ?? "");
            const MAX_RUNAWAY_PCT = 10.0;
            // MAX_RETRACE_PCT: Медленные (накопление): -25% — перед памп нормальны глубокие шейк-ауты.
            // OPENEDEN: дал -18-20% откат перед памп +52%. PLAYSOUT: -16% перед +20%.
            const MAX_RETRACE_PCT = isSlowPattern || is24hOI ? -25.0 : -10.0;
            // Окна подтверждения: монета должна удержать накопление перед сигналом.
            const CONFIRM_WINDOW_MS =
              is4hOI || is24hOI
                ? 30 * 60 * 1000 // 30 мин: 4h/24h OI — уже подтверждены долгим накоплением
                : is1hOI
                  ? 60 * 60 * 1000 // 60 мин: 1h OI
                  : 2 * 60 * 60 * 1000; // 2 часа: 30m/5m/steady — накопление требует времени
            const waitMin = Math.round(CONFIRM_WINDOW_MS / 60000);

            if (isSlowPattern) {
              // Триггер для медленных паттернов: пробой локального хая ИЛИ всплеск объема
              const recentHighs = klines
                .slice(-9, -1)
                .map((k) => parseFloat(k.high) || 0);
              const recentHigh = Math.max(...recentHighs);
              const breakout = recentHigh > 0 && close > recentHigh * 1.005; // Пробой на 0.5% выше хая

              // Дополнительный триггер: всплеск объема на текущей свече (> 3x от avgVolume)
              const currentVolume = parseFloat(
                klines[klines.length - 1].volume,
              );
              const avgVol = entry.avgVolume; // Используем avgVolume из oiWatchTable
              const volumeSpike =
                (avgVol ?? 0) > 0 && currentVolume > (avgVol ?? 0) * 3.0;

              if (!breakout && !volumeSpike) {
                logger.debug(
                  {
                    symbol,
                    close,
                    recentHigh,
                    gap: ((close / recentHigh - 1) * 100).toFixed(2) + "%",
                    currentVolume,
                    avgVol,
                  },
                  "⏳ SLOW PATTERN: ждём пробоя локального хая ИЛИ всплеска объема",
                );
                break symbolBlock;
              }

              logger.info(
                {
                  symbol,
                  close,
                  recentHigh,
                  currentVolume,
                  avgVol,
                  trigger: breakout ? "breakout" : "volume_spike",
                },
                "✅ SLOW PATTERN: пробой локального хая ИЛИ всплеск объема — сигнал разрешён",
              );
              // Триггер сработал — проверяем OI и даём сигнал через стандартные проверки ниже
            }

            // ── OI Watch: накопительные паттерны — те же гейты что и в основном скан-цикле ──
            // Когда det=null (символ не поймали заново) фильтры выше не применяются.
            // Дублируем их здесь чтобы OI Watch путь не был лазейкой.
            const OI_WATCH_ACCUM_KEYS = [
              "dip_accumulation",
              "trend_accumulation",
            ];
            if (OI_WATCH_ACCUM_KEYS.includes(entry.sentimentKey ?? "")) {
              // Vol Trend: предыдущие свечи тоже должны показывать объём
              if (!isVolTrend && !isExtremeOiQuiet) {
                logger.debug(
                  {
                    symbol,
                    pattern: entry.sentimentKey,
                    prevVol1: prevVol1Mult.toFixed(2) + "x",
                    prevVol2: prevVol2Mult.toFixed(2) + "x",
                  },
                  "SKIP: OI Watch накоп. паттерн — нет объёмного тренда (предыдущие свечи < 1.3x нормы)",
                );
                break symbolBlock;
              }
              // Spot CVD: данные обязательны; CVD 1h+4h должны подтверждать накопление
              if (!spotCvd?.available) {
                logger.debug(
                  { symbol, pattern: entry.sentimentKey },
                  "SKIP: OI Watch накоп. паттерн — нет данных спота (обязательно для паттерна)",
                );
                break symbolBlock;
              }
              if (spotCvd.cvd1h !== true || spotCvd.cvd4h !== true) {
                logger.debug(
                  {
                    symbol,
                    pattern: entry.sentimentKey,
                    cvd1h: spotCvd.cvd1h,
                    cvd4h: spotCvd.cvd4h,
                  },
                  "SKIP: OI Watch накоп. паттерн — спот CVD 1h и/или 4h не подтверждают накопление (false или нет данных)",
                );
                break symbolBlock;
              }
            }

            if (!isSlowPattern && ageMs < CONFIRM_WINDOW_MS) {
              // Ещё в окне наблюдения. Ранняя отмена если OI уже иссяк или цена рухнула.
              const earlyOIDrain = cgOI?.available && cgOIChange < OI_DRAIN_PCT;
              const earlyRetrace = priceFromDetection < MAX_RETRACE_PCT;
              // OI перестал строиться: был >= 5%, упал ниже 2% — накопление завершилось
              const earlyOIFaded =
                cgOI?.available &&
                cgOIChange < 2.0 &&
                (entry.oiChange ?? 0) >= 5.0;
              if (earlyOIDrain || earlyRetrace || earlyOIFaded) {
                await dbWriteStrict("oiWatch/confirm-earlyCancel", () =>
                  db
                    .update(oiWatchTable)
                    .set({ status: "expired", firedAt: new Date() })
                    .where(eq(oiWatchTable.id, entry.id)),
                );
                logger.info(
                  {
                    symbol,
                    tf: entryTf,
                    ageMin: (ageMs / 60000).toFixed(1),
                    oi: cgOIChange.toFixed(1) + "%",
                    drift: priceFromDetection.toFixed(1) + "%",
                  },
                  earlyOIDrain
                    ? "❌ CONFIRM EARLY CANCEL: OI иссяк до окончания ожидания"
                    : earlyOIFaded
                      ? "❌ CONFIRM EARLY CANCEL: OI перестал строиться (< 2%) — накопление завершилось"
                      : "❌ CONFIRM EARLY CANCEL: цена откатилась > 5% — ложный сигнал",
                );
                skipCount.noConfirming++;
                break symbolBlock;
              }
              logger.debug(
                {
                  symbol,
                  tf: entryTf,
                  waitMin,
                  ageMin: (ageMs / 60000).toFixed(1),
                  drift: priceFromDetection.toFixed(1) + "%",
                  freshOI: cgOIChange.toFixed(1) + "%",
                },
                `⏳ CONFIRMING: ждём ${waitMin} мин. OI держится.`,
              );
              // Обновляем volStatusReason каждый цикл пока токен в confirming — чтобы
              // фронтенд показывал актуальный статус CVD, а не null (fallback "нет данных CG").
              if (entry.id > 0) {
                void db
                  .update(oiWatchTable)
                  .set({ volStatusReason: cgVolStatusReason(spotCvd) })
                  .where(eq(oiWatchTable.id, entry.id))
                  .catch(() => {});
              }
              break symbolBlock;
            }

            // Окно закрылось — финальные проверки

            if (cgOI?.available && cgOIChange < OI_DRAIN_PCT) {
              await dbWriteStrict("oiWatch/confirm-oiDrain", () =>
                db
                  .update(oiWatchTable)
                  .set({ status: "expired", firedAt: new Date() })
                  .where(eq(oiWatchTable.id, entry.id)),
              );
              logger.info(
                { symbol, tf: entryTf, freshOI: cgOIChange.toFixed(1) + "%" },
                `❌ CONFIRM FAILED: ${waitMin} мин прошло, но OI упал — накопление закончилось`,
              );
              skipCount.noConfirming++;
              break symbolBlock;
            }

            // OI перестал строиться: был >= 5% при добавлении, теперь ниже 2% — накопление завершилось
            if (
              cgOI?.available &&
              cgOIChange < 2.0 &&
              (entry.oiChange ?? 0) >= 5.0
            ) {
              await dbWriteStrict("oiWatch/confirm-oiFaded", () =>
                db
                  .update(oiWatchTable)
                  .set({ status: "expired", firedAt: new Date() })
                  .where(eq(oiWatchTable.id, entry.id)),
              );
              logger.info(
                {
                  symbol,
                  tf: entryTf,
                  currentOI: cgOIChange.toFixed(1) + "%",
                  entryOI: (entry.oiChange ?? 0).toFixed(1) + "%",
                },
                "❌ CONFIRM EXPIRED: OI перестал строиться — накопление завершилось",
              );
              skipCount.noConfirming++;
              break symbolBlock;
            }

            if (priceFromDetection < MAX_RETRACE_PCT) {
              await dbWriteStrict("oiWatch/confirm-priceRetrace", () =>
                db
                  .update(oiWatchTable)
                  .set({ status: "expired", firedAt: new Date() })
                  .where(eq(oiWatchTable.id, entry.id)),
              );
              logger.info(
                {
                  symbol,
                  tf: entryTf,
                  drift: priceFromDetection.toFixed(1) + "%",
                },
                `❌ CONFIRM FAILED: цена откатилась > 5% за ${waitMin} мин — ложный сигнал`,
              );
              skipCount.noConfirming++;
              break symbolBlock;
            }

            if (priceFromDetection > MAX_RUNAWAY_PCT) {
              await dbWriteStrict("oiWatch/confirm-priceRunaway", () =>
                db
                  .update(oiWatchTable)
                  .set({ status: "expired", firedAt: new Date() })
                  .where(eq(oiWatchTable.id, entry.id)),
              );
              logger.info(
                {
                  symbol,
                  tf: entryTf,
                  drift: priceFromDetection.toFixed(1) + "%",
                },
                `❌ CONFIRM SKIP: цена ушла > ${MAX_RUNAWAY_PCT}% вверх — вход слишком поздний`,
              );
              skipCount.priceTooHigh++;
              break symbolBlock;
            }

            // Ждём реального начала роста — не входим если цена ещё в минусе или флэте.
            // ZBT-кейс: цена -2.5% → в допуске [-5%..+10%] → сигнал стрелял → вход на дне.
            // ZETA/ATOM/CRV-кейс: цена +0.5% → signal fire → сразу разворот → peak=0% → stale cancel.
            // Исключение: 24h OI — долгосрочное накопление, достаточно любого начала роста.
            // Исключение: dark_flow — активность без OI, сигнал основан на объёме/пре-скрине.
            //   Для него достаточно что цена не рухнула > -5% от точки входа.
            const MIN_POSITIVE_DRIFT = is24hOI
              ? 0.5
              : entryTf === "dark_flow"
                ? -5.0
                : isSlowPattern
                  ? 1.0 // dip_accum/trend_accum/hidden_accum: цена должна стоять — 2% drift противоречит паттерну
                  : 2.0;
            // Двойной ценовой гейт:
            // 1. drift4h < MIN_POSITIVE_DRIFT — 4h скользящее окно ещё не показало движение.
            // 2. priceFromDetection < priceConfirmFloor — цена ещё не выросла достаточно от точки входа.
            // VVV/AIXBT/PYTH-кейс: drift4h мог быть +2.5% (общий 4h импульс), но
            // priceFromDetection=+0.2% — сигнал стрелял в TG без реального роста.
            const priceConfirmFloor = 1.0;
            if (
              drift4h < MIN_POSITIVE_DRIFT ||
              priceFromDetection < priceConfirmFloor
            ) {
              // ── PRE-BREAKOUT: OI + объём подтверждены, но цена ещё не двинулась ─────
              // Используем drift4h (скользящее окно 4h) вместо priceFromDetection,
              // чтобы старые записи (7+ дней) не блокировались устаревшей ценой входа.
              // GENIUS: oi4h=82%, drift=-6%, 30ч ожидания → памп без сигнала.
              // IN:     oi4h=52%, drift=-12%, 8.5ч ожидания → то же.
              // Условия: 2+ ч в очереди, OI или объём подтверждены, не рухнула, не стрелял раньше.
              // dark_flow: используем volMult >= 2.0 вместо cgOIChange (OI в CG не видно),
              //            порог краша шире (-10% вместо -5%, т.к. MAX_RETRACE у dark_flow = -10%).
              const isDarkFlow = entryTf === "dark_flow";
              const alreadyPreFired = !!(entry.signalPayload as any)
                ?.preBreakoutFiredAt;
              const preBreakoutOiOk = isDarkFlow
                ? volMult >= 2.0 // dark_flow: объём вместо OI
                : cgOIChange >= 10.0; // нормальный: CG OI >= 10%
              const preBreakoutMaxCrash = isDarkFlow ? -10.0 : -5.0;
              if (
                !alreadyPreFired &&
                ageMs >= 2 * 60 * 60 * 1000 && // 2+ часа ожидания
                preBreakoutOiOk && // OI или объём подтверждён
                volMult >= 1.5 && // объём подтверждён в любом случае
                priceFromDetection > preBreakoutMaxCrash // цена не рухнула
              ) {
                // Помечаем запись — больше не стреляем pre_breakout из этого entry
                // dbWriteBestEffort: защита от зависания при нагрузке на Neon pool
                await dbWriteStrict("oiWatch/preBreakoutFired-mark", () =>
                  db
                    .update(oiWatchTable)
                    .set({
                      signalPayload: {
                        ...((entry.signalPayload as any) ?? {}),
                        preBreakoutFiredAt: new Date().toISOString(),
                      },
                    })
                    .where(eq(oiWatchTable.id, entry.id)),
                );

                const base = symbol.replace("-USDT", "");
                const oi4hStr =
                  cgOI?.oiChange4h != null
                    ? `  • OI 4h: <b>+${cgOI.oiChange4h.toFixed(1)}%</b>`
                    : "";
                const _preMsg = isDarkFlow
                  ? [
                      `🌑 <b>DARK FLOW: ${base}/USDT</b>`,
                      ``,
                      `Устойчивая активность без следа в OI — цена <b>не двинулась</b>`,
                      ``,
                      `  • Объём: <b>${volMult.toFixed(1)}x</b>`,
                      `  • OI CoinGlass: <b>${cgOIChange > 0 ? "+" : ""}${cgOIChange.toFixed(1)}%</b> (ниже порога)`,
                      `  • Дрейф от входа: <b>${priceFromDetection.toFixed(1)}%</b>`,
                      `  • В confirming-очереди: <b>${Math.round(ageMs / 60000)} мин</b>`,
                      ``,
                      `💡 Умные деньги вне OI-радара — жди пробой или объёмный всплеск`,
                      ``,
                      `🔗 <a href="https://www.tradingview.com/chart/?symbol=BYBIT:${base}USDT.P">TradingView</a>`,
                      ``,
                      `#${base} #dark_flow`,
                    ].join("\n")
                  : [
                      `🔍 <b>PRE-BREAKOUT: ${base}/USDT</b>`,
                      ``,
                      `OI и объём подтверждены — цена ещё <b>не двинулась</b>`,
                      ``,
                      `  • OI (global): <b>+${cgOIChange.toFixed(1)}%</b>`,
                      oi4hStr || null,
                      `  • Объём: <b>${volMult.toFixed(1)}x</b>`,
                      `  • Дрейф от входа: <b>${priceFromDetection.toFixed(1)}%</b>`,
                      `  • В очереди: <b>${Math.round(ageMs / 60000)} мин</b>`,
                      ``,
                      `💡 Накопление без старта — жди пробой или объёмный всплеск`,
                      ``,
                      `🔗 <a href="https://www.tradingview.com/chart/?symbol=BYBIT:${base}USDT.P">TradingView</a>`,
                      ``,
                      `#${base} #pre_breakout`,
                    ]
                      .filter((l) => l !== null)
                      .join("\n");

                // ── Spot volume gate (Pre-Breakout / Dark Flow) ─────────────────────────
                const [pbFsVol, pbMcapRaw] = await Promise.all([
                  getFsVolume(symbol).catch(() => null),
                  fetchMarketCap(symbol).catch(() => null),
                ]);
                const pbSpotVol24h = pbFsVol?.spotVolUsd24h ?? null;
                const pbMcapUsd = pbMcapRaw?.mcap ?? null;
                const tag = isDarkFlow ? "DARK FLOW" : "PRE-BREAKOUT";
                // Нет спота или нет MCap → блок.
                const pbSpotOk =
                  pbSpotVol24h !== null &&
                  pbMcapUsd !== null &&
                  pbSpotVol24h >= pbMcapUsd * 0.01;
                if (!pbSpotOk) {
                  const pct =
                    pbSpotVol24h !== null && pbMcapUsd
                      ? ((pbSpotVol24h / pbMcapUsd) * 100).toFixed(3)
                      : "нет данных";
                  logger.info(
                    { symbol, pbSpotVol24h, pbMcapUsd, pct },
                    pbSpotVol24h === null
                      ? `${tag}: нет данных спота — сигнал отменён`
                      : pbMcapUsd === null
                        ? `${tag}: MCap недоступен — сигнал отменён`
                        : `${tag}: спот-объём < 1% MCap — сигнал отменён`,
                  );
                } else {
                  try {
                    // Telegram не шлём — ждём полного подтверждения тихо (без спама отменами)
                    logger.info(
                      {
                        symbol,
                        tf: entryTf,
                        oi: cgOIChange.toFixed(1) + "%",
                        vol: volMult.toFixed(1) + "x",
                        drift: priceFromDetection.toFixed(1) + "%",
                        ageMin: Math.round(ageMs / 60000),
                      },
                      isDarkFlow
                        ? "🌑 DARK FLOW: устойчивая активность → в трекер (без TG, ждём подтверждение)"
                        : "🔍 PRE-BREAKOUT: OI+объём подтверждены → в трекер (без TG, ждём движение цены)",
                    );
                    // Сигнал ещё не подтверждён — ждём движение цены (не создаём запись в трекере)
                  } catch (err) {
                    logger.warn(
                      { err, symbol },
                      "PRE-BREAKOUT: ошибка отправки алерта",
                    );
                  }
                } // end spot ok else
              }

              logger.info(
                {
                  symbol,
                  tf: entryTf,
                  drift4h: drift4h.toFixed(1) + "%",
                  driftFromEntry: priceFromDetection.toFixed(1) + "%",
                  ageMin: (ageMs / 60000).toFixed(0),
                },
                "⏳ CONFIRM WAIT: цена ещё не в росте — ждём старта движения",
              );
              break symbolBlock; // не отменяем, просто ждём — expire случится через 6ч если роста не будет
            }

            // Ghost pump guard: 24h памп >30% с остывающим объёмом (< 2.5x) =
            // торговая возможность уже случилась ДО нашего сигнала.
            // Глобальный exhausted pump check ловит >40%, но для confirming-блока строже:
            // токен мог попасть в очередь на старте памп (price ~0%), к моменту подтверждения
            // уже +35% → priceFromDetection всё ещё мал (считается от priceAtEntry, не от дня),
            // поэтому MAX_RUNAWAY_PCT не срабатывает. Ghost pump guard закрывает этот зазор.
            if (
              price24hChange > 40 &&
              (spotVolMult === null || spotVolMult < 2.5)
            ) {
              await dbWriteStrict("oiWatch/confirm-ghostPump", () =>
                db
                  .update(oiWatchTable)
                  .set({ status: "expired", firedAt: new Date() })
                  .where(eq(oiWatchTable.id, entry.id)),
              );
              confirmingWatchMap.delete(symbol); // убираем из памяти при истечении
              logger.info(
                {
                  symbol,
                  tf: entryTf,
                  price24hChange: price24hChange.toFixed(1) + "%",
                  volMult: volMult.toFixed(2),
                  drift: priceFromDetection.toFixed(1) + "%",
                },
                "❌ GHOST PUMP: 24h рост >30% + объём остыл — памп случился до сигнала, пропускаем",
              );
              skipCount.stalePump++;
              break symbolBlock;
            }

            // ✅ OI держится, цена пошла вверх — сигнал подтверждён
            // КРИТИЧНО: 3 попытки / 5s — статус "fired" предотвращает двойной выстрел;
            // если UPDATE потерян, следующий цикл может повторно запустить этот entry.
            // Broadcast-dedup в broadcastBatchAlert (атомарный UPDATE+RETURNING) служит
            // финальным барьером от дублированных Telegram-алертов.
            await dbWriteStrict(
              "oiWatch/confirm-setFired",
              () =>
                db
                  .update(oiWatchTable)
                  .set({ status: "fired", firedAt: new Date() })
                  .where(eq(oiWatchTable.id, entry.id)),
              { attempts: 3, perAttemptTimeoutMs: 5000, retryDelayMs: 500 },
            );
            confirmingWatchMap.delete(symbol); // убираем из памяти при выстреле
            // Supersede: гасим другие активные записи того же символа (watching/confirming).
            // Статус fired уже проставлен → они не попадут в WHERE.
            const _supersededRows =
              (await dbWriteBestEffort("oiWatch/supersede", () =>
                db
                  .update(oiWatchTable)
                  .set({ status: "expired", volStatusReason: "superseded" })
                  .where(
                    and(
                      eq(oiWatchTable.symbol, symbol),
                      inArray(oiWatchTable.status, ["watching", "confirming"]),
                    ),
                  )
                  .returning({
                    id: oiWatchTable.id,
                    oi30m: oiWatchTable.oi30mChange,
                    oi1h: oiWatchTable.oi1hChange,
                    oi24h: oiWatchTable.oi24hChange,
                    volMult: oiWatchTable.volumeMultiplier,
                  }),
              )) ?? [];
            logger.info(
              {
                symbol,
                tf: entryTf,
                waitMin,
                ageMin: (ageMs / 60000).toFixed(1),
                drift: priceFromDetection.toFixed(1) + "%",
                freshOI: cgOIChange.toFixed(1) + "%",
              },
              `✅ CONFIRMED: OI держится ${waitMin} мин, цена стабильна — сигнал разрешён`,
            );
            // Помечаем что кандидат пришёл из confirming-очереди — финальный цикл
            // пропустит watching-очередь и выстрелит напрямую (без PATH A задержки).
            (det as any).__isConfirmedFire = true;
          } else if ((det as any).__isConfirmedFire === true) {
            // ── АРХЕТИПНЫЙ ПРЯМОЙ СИГНАЛ: байпас 2-часовой очереди OI Watch ──────
            // Паттерны 4h_pullback_continuation / price_led_momentum / balanced_grind /
            // stealth_breakout устанавливают __isConfirmedFire прямо при детекции.
            // Путь через OI Watch confirming (2ч ожидания) убивал эти сигналы:
            //   • price_led_momentum:  цена уже бежит 3h/4h → за 2ч откат → early cancel
            //   • stealth_breakout:    пробой случился → за 2ч остыл → сигнал пропущен
            //   • balanced_grind:      умеренный рост не держит OI drain условие 2ч
            // Нормальные паттерны НЕ устанавливают __isConfirmedFire при детекции —
            // он выставляется только в строке 5708 по итогам confirming-окна.
            // Поэтому флаг корректно разделяет прямые и косвенные сигналы.
            logger.info(
              { symbol, pattern: det.sentiment.key },
              "🎯 ARCHETYPE DIRECT FIRE: пропуск 2h очереди OI Watch — прямой сигнал",
            );
            // No break — falls through to signal assembly below
          } else {
            // Первый раз видим — сохраняем реальный ТФ, чтобы знать сколько ждать
            const confirmAddedAt = new Date();
            const confirmExpiresAt = new Date(Date.now() + CONFIRM_EXPIRE_MS);
            // Получаем свежую цену заранее — нужна и для DB, и для in-memory fallback
            let confirmPrice = close;
            try {
              confirmPrice = await getFreshPrice(symbol, close);
            } catch {
              /* use close */
            }

            try {
              // Guard: если уже есть watching-запись — не создаём параллельный confirming (EIGEN-баг).
              // confirmingWatchMap защищает от duplicate confirming, но не от watching→confirming коллизии.
              const alreadyWatching = await db
                .select({ id: oiWatchTable.id })
                .from(oiWatchTable)
                .where(
                  and(
                    eq(oiWatchTable.symbol, symbol),
                    inArray(oiWatchTable.status, ["watching", "confirming"]),
                  ),
                )
                .limit(1);
              if (alreadyWatching.length > 0) {
                logger.debug(
                  { symbol, tf: oiTriggerTf },
                  "PATH A confirming skip: уже есть watching-запись — дублирование предотвращено",
                );
              } else {
                // dbWriteStrict: критичная запись PATH A — бросает при неудаче
                await dbWriteStrict("oiWatch/pathA-insert", () =>
                  db.insert(oiWatchTable).values({
                    symbol,
                    triggerTf: oiTriggerTf,
                    oiChange: cgOIChange,
                    priceAtEntry: confirmPrice,
                    volumeMultiplier: spotVolMult ?? volMult, // 1.6
                    sentimentKey: det.sentiment.key,
                    status: "confirming",
                    addedAt: confirmAddedAt,
                    expiresAt: confirmExpiresAt,
                    avgVolume: avgVol,
                    oi30mChange: oi30m,
                    oi1hChange: oi1h,
                    oi24hChange: oi24h ?? null,
                    price1hChange: price1hChange ?? null,
                    price24hChange: price24hChange,
                    entryVolMult: volMult,
                    entryCgTurnover:
                      cgOI?.cgVolUsd != null &&
                      cgOI?.oiUsd != null &&
                      cgOI.oiUsd > 0
                        ? cgOI.cgVolUsd / cgOI.oiUsd
                        : null,
                  }),
                );
                // DB INSERT удался — убираем из памяти если там был стейл
                confirmingWatchMap.delete(symbol);
                const waitMin =
                  oiTriggerTf.includes("24h") || oiTriggerTf.includes("4h")
                    ? 15
                    : oiTriggerTf.includes("1h")
                      ? 30
                      : 60;
                logger.info(
                  {
                    symbol,
                    tf: oiTriggerTf,
                    waitMin,
                    price: priceChange.toFixed(1) + "%",
                    oi: cgOIChange.toFixed(1) + "%",
                    pattern: det.sentiment.key,
                  },
                  `🕐 QUEUED: первое обнаружение — ждём ${waitMin} мин подтверждения OI`,
                );
              } // end else: нет watching-записи, INSERT выполнен
            } catch (err) {
              logger.warn(
                { err, symbol },
                "confirming OI Watch insert failed — saving to in-memory fallback",
              );
              // Сохраняем в памяти — следующий скан найдёт запись и продолжит окно подтверждения
              confirmingWatchMap.set(symbol, {
                symbol,
                triggerTf: oiTriggerTf,
                oiChange: cgOIChange,
                priceAtEntry: confirmPrice,
                volumeMultiplier: spotVolMult ?? volMult, // 1.6
                sentimentKey: det.sentiment.key,
                addedAt: confirmAddedAt,
                expiresAt: confirmExpiresAt,
                avgVolume: avgVol,
                oi30mChange: oi30m,
                oi1hChange: oi1h,
                oi24hChange: oi24h ?? null,
              });
              skipCount.other++;
            }
            break symbolBlock;
          }
        }

        logger.info(
          {
            symbol,
            globalOI: cgOIChange.toFixed(1) + "%",
            bingxOI:
              cgOI?.bingxOiChange30m != null
                ? cgOI.bingxOiChange30m.toFixed(1) + "%"
                : "n/a",
            vol: volMult.toFixed(1) + "x",
            price: priceChange.toFixed(1) + "%",
            pattern: det.sentiment.key,
          },
          "CoinGlass OI + Volume PASSED → candidate",
        );

        const safeOI: CoinglassOIResult = cgOI ?? {
          available: false,
          timedOut: false,
          source: "coinglass",
          oiUsd: 0,
          oiChange30m: null,
          prevOi30m: null,
          oiChange1h: null,
          oiChange4h: null,
          oiChange24h: null,
          bingxOiChange30m: null,
          cgVolUsd: null,
          positiveCandles6h: null,
          oiConsecutiveUp: null,
          oi4hConsecFromOhlc: null,
        };

        candidates.push({
          symbol,
          price: close,
          priceChange30m: priceChange,
          price4hChange,
          price24hChange,
          currentVolume: currentVol,
          avgVolume: avgVol,
          volumeMultiplier: spotVolMult ?? volMult, // 1.6
          oiChangePercent: cgOIChange,
          oiChange1h: oi1h,
          oiChange4h: oi4h,
          oiChange24h: oi24h,
          openInterest: safeOI.oiUsd ?? 0,
          sentiment: det.sentiment,
          coinglassOI: safeOI,
          oiTriggerTf,
          isRepeatSignal,
          isConfirmedFire: (det as any).__isConfirmedFire === true,
          isScalpOnly,
          futVolMult: volMult, // фьюч BingX klines (Phase 2)
          spotVol24h: getSpotPoolEntry(symbol)?.spotVol24h ?? null, // из SpotPool (глобальный)
          futVol24hUsd: vol24hUSD, // для collision-check ликвидаций
        });
        // no-match: прошёл все гейты, но ни один паттерн не сработал (det===null)
        if (det === null) {
          _symRej(
            symbol,
            "no_match",
            "no_pattern_fired",
            oi30m ?? null,
            volMult,
            price24hChange,
            _pe1?.cycleCount ?? null,
          );
        }
      } while (false);
    } catch (err) {
      logger.warn({ symbol, err }, "Error scanning symbol");
    }
    await new Promise((r) => setTimeout(r, 10));
  });

  // Log top-5 by volume among those that passed CoinGlass OI filter
  const top5 = [...debugTop].sort((a, b) => b.vol - a.vol).slice(0, 5);
  if (top5.length > 0) {
    logger.info(
      {
        top5: top5.map((d) => ({
          symbol: d.symbol,
          vol: d.vol.toFixed(1) + "x",
          globalOI: d.cgOI != null ? d.cgOI.toFixed(1) + "%" : "n/a",
          price: d.price.toFixed(2) + "%",
        })),
      },
      "Top-5 (CoinGlass OI passed) by volume this cycle",
    );
  }

  logger.info(
    {
      oi: {
        t30: oiPassCount.t30,
        t1h: oiPassCount.t1h,
        t4h: oiPassCount.t4h,
        t24h: oiPassCount.t24h,
        anyPass: oiPassCount.anyOiPass,
      },
      skip: {
        exhaustedByTicker: lastLayerDebug.exhaustedByTicker,
        exhaustedPump: skipCount.exhaustedPump,
        deepNeg: skipCount.deepNegative,
        noOiNoVol: skipCount.noOiNoVol,
        lowVol: skipCount.lowVolume,
        stalePump: skipCount.stalePump,
        cooldown: skipCount.cooldown,
        noConfirming: skipCount.noConfirming,
        priceTooHigh: skipCount.priceTooHigh,
        cvdFail: skipCount.cvdFail,
        takerFail: skipCount.takerFail,
        spotFail: skipCount.spotFailLow + skipCount.spotFailNoData,
        contra: skipCount.contraSignal,
        wiObBear: skipCount.wiObBear,
        other: skipCount.other,
      },
      candidates: candidates.length,
    },
    "📊 SCAN SUMMARY: OI пороги + причины пропуска",
  );

  if (gateRejectLog.length > 0) {
    // Сортировка: cvdFail (прошли OI+vol, заблокированы CVD) → contra → stalePump → deepNeg
    const gateOrder: Record<string, number> = {
      cvdFail: 0,
      contra: 1,
      stalePump: 2,
      deepNeg: 3,
    };
    gateRejectLog.sort(
      (a, b) => (gateOrder[a.gate] ?? 9) - (gateOrder[b.gate] ?? 9),
    );
    // Группируем по gate для удобного чтения
    const byGate: Record<string, typeof gateRejectLog> = {};
    for (const e of gateRejectLog) {
      (byGate[e.gate] ??= []).push(e);
    }
    const summary = Object.fromEntries(
      Object.entries(byGate).map(([g, arr]) => [
        g,
        arr.map((e) => `${e.sym}(${e.oi30m},${e.vol},${e.extra})`),
      ]),
    );
    logger.info(
      { count: gateRejectLog.length, byGate: summary },
      "📋 GATE REJECT LOG: токены с сигналом заблокированные гейтом",
    );
  }

  logger.info(
    {
      confirmingMapSize: confirmingWatchMap.size,
      confirmingMapSymbols: [...confirmingWatchMap.keys()],
      candidatesCount: candidates.length,
      skipped: skipCount,
    },
    "DEBUG: scan cycle snapshot",
  );

  // Prescan history snapshot (все scored токены) — пишем после deep scan loop когда OI/CVD свежие.
  // fire-and-forget: не блокируем основной поток, ошибки логируются внутри функции.
  void savePrescanHistory(scored);
  // Growth leader log — ОТКЛЮЧЁН (2026-07-18): запись лидеров роста остановлена.

  // Сохраняем prescan tracker в DB после Phase 2 чтобы lastOi* (обновлённые в Phase 2)
  // попали в базу. Первый savePrescanToDb() в Phase 1 (строка ~772) сохраняет данные
  // прошлого цикла — этот вызов перезаписывает свежими OI значениями.
  void savePrescanToDb();
  // Whale Index: батч-фетч per-token WI для OI Watch + топ prescan + активных сигналов
  void batchUpdateWhaleIndex();

  if (candidates.length === 0) {
    const nowNoCandidates = new Date();
    state.lastScanAt = nowNoCandidates;
    state.marketsScanned = usdtTickers.length;
    state.isScanning = false;
    state.lastScanDurationMs = Date.now() - startTime;
    logger.info(
      {
        marketsScanned: usdtTickers.length,
        oiMovers: oiMoversCount,
        topActive: scanLimit,
        skipped: {
          exhaustedByTicker: lastLayerDebug.exhaustedByTicker,
          exhaustedPump: skipCount.exhaustedPump,
          deepNeg: skipCount.deepNegative,
          noOiNoVol: skipCount.noOiNoVol,
          lowVolume: skipCount.lowVolume,
          stalePump: skipCount.stalePump,
          cooldown: skipCount.cooldown,
          noConfirming: skipCount.noConfirming,
          priceTooHigh: skipCount.priceTooHigh,
          cvdFail: skipCount.cvdFail,
          takerFail: skipCount.takerFail,
          spotFailNoData: skipCount.spotFailNoData,
          spotFailLow: skipCount.spotFailLow,
          contra: skipCount.contraSignal,
          other: skipCount.other,
        },
      },
      "No candidates this cycle (CoinGlass OI + Volume filters)",
    );
    // Log pattern debug counters (no-candidates path)
    logger.info(
      { patternDebug: lastPatternDebug },
      "Pattern debug: end-of-scan counters",
    );
    await persistBaselinesToDb();
    // Persist lastScanAt for cross-process status (fire-and-forget, fast-fail)
    void dbWriteBestEffort(
      "scannerLastScanAt (no-candidates)",
      () =>
        db.update(settingsTable).set({ scannerLastScanAt: nowNoCandidates }),
      { attempts: 1 },
    );
    return {
      signalsFound: 0,
      marketsScanned: usdtTickers.length,
      durationMs: Date.now() - startTime,
    };
  }

  // ── FRESH PRICE FETCH ───────────────────────────────────────────────────────
  // CoinGlass batch занял 8+ мин. Klines были взяты в начале скана, поэтому
  // base.price = закрытие свечи из прошлого. Перечитываем текущую цену для
  // каждого кандидата, чтобы трекер и Telegram показывали реальную точку входа.
  const freshPriceMap = new Map<string, number>();
  try {
    const freshTickers = await getFutureTickers();
    for (const t of freshTickers) {
      const p = parseFloat((t as any).lastPrice);
      if (p > 0) freshPriceMap.set((t as any).symbol, p);
    }
    logger.info(
      { fetched: freshPriceMap.size },
      "Fresh ticker prices fetched for candidate entry pricing",
    );
  } catch (err) {
    logger.warn(
      { err },
      "Failed to fetch fresh ticker prices — using kline close as fallback",
    );
  }

  logger.info(
    { count: candidates.length },
    "Phase 3: grade + score for CoinGlass OI candidates...",
  );

  // Phase 3: grade + score (CoinGlass OI already confirmed in Phase 1)
  const alphaResults: AlphaResult[] = [];
  const signalsToInsert: InsertSignal[] = [];

  for (const base of candidates) {
    const { symbol } = base;

    // CoinGlass OI data already fetched in batch — use directly
    const coinglassOI = base.coinglassOI;
    const globalOiChange = coinglassOI.oiChange30m; // global aggregate
    const globalOiConfirmed = true; // all candidates already passed CoinGlass OI filter

    const [trending, liquidations, fundingRate] = await Promise.all([
      getTrendingRank(symbol),
      getLiquidations(symbol, base.futVol24hUsd), // vol24h — collision-check тикеров CG
      getCoinglassAggregateFunding(symbol), // агрегат Binance+Bybit+OKX+BingX
    ]);
    const markPrice = null; // markPrice/indexPrice были только из BingX — больше не нужны
    const indexPrice = null;

    if (fundingRate != null) {
      logger.info(
        { symbol, fundingRate7d: fundingRate.toFixed(4) + "%" },
        fundingRate <= -0.15
          ? "💰 7d фандинг глубоко отрицательный — шорты в ловушке"
          : fundingRate <= -0.05
            ? "💰 7d фандинг отрицательный — шорты платят"
            : fundingRate >= 0.3
              ? "⚠️ 7d фандинг сильно положительный — лонги перегреты"
              : "⚖️ 7d фандинг нейтральный",
      );
    }

    // Re-detect sentiment now that we have liquidation data.
    // IMPORTANT: archetype direct-fire patterns (price_led_momentum, balanced_grind,
    // stealth_breakout, 4h_pullback_continuation, demark) have their sentiment locked
    // in Loop 1 via __isConfirmedFire. detectSentiment() is an unconditional fallback
    // that returns bullish_accumulation for any OI level — calling it again here would
    // overwrite the correct pattern key with BA. Use base.sentiment for confirmed-fire.
    const _pe3 = prescanTracker.get(symbol);
    const finalSentiment = base.isConfirmedFire
      ? base.sentiment
      : detectSentiment(
          base.priceChange30m,
          base.oiChangePercent,
          base.volumeMultiplier,
          liquidations.multiple ?? null,
          base.oiTriggerTf,
          _pe3?.prevOi30m ?? null,
          base.price24hChange,
          _pe3?.cycleCount ?? 0,
        );
    if (finalSentiment.key === "trend_accumulation") {
      logger.info(
        {
          symbol,
          oi30m: base.oiChangePercent,
          prevOi30m: _pe3?.prevOi30m ?? null,
          priceChange: base.priceChange30m,
          price24hChange: base.price24hChange,
          cycleCount: _pe3?.cycleCount ?? 0,
        },
        "📈 TREND_ACCUM: двухцикловое OI накопление на не перегретом токене",
      );
    }

    // ── FUNDING RATE GATE: trend_accumulation — лонги перегреты → skip ──────────
    // 7d кумулятивный фандинг > 0.20% = устойчивый лонг-перевес за неделю (~0.01%/период).
    // При тренд-накоплении ищем РАННИЙ вход, а не позднюю перегретость.
    // Эквивалент старого порога 0.01%/период × ~21 период = ~0.21%.
    if (
      finalSentiment.key === "trend_accumulation" &&
      fundingRate !== null &&
      fundingRate > 0.2
    ) {
      logger.info(
        {
          symbol,
          fundingRate7d: fundingRate.toFixed(4) + "%",
          pattern: "trend_accumulation",
        },
        "SKIP trend_accumulation: 7d фандинг > 0.20% — устойчивый лонг-перевес, не ранний вход",
      );
      skipCount.takerFail++;
      continue;
    }

    // ── STEP 5: Pre-fetch enrichment for Bullet Score v3 ──────────────────────
    // SNF и CVD — in-memory (sync). Taker поднимаем здесь — фильтр ниже тоже использует.
    const _snfEntry = getSpotNetflowEntry(symbol); // sync in-memory
    const spotTfP2 = await getSpotTakerFlow(symbol).catch(() => null);
    const _spotCvdScore = _spotCvdMapScan.get(symbol);

    // ── STEP 5: Bullet Score v3 (base=1 + confirmations) ─────────────────────
    let alphaScore = calcBulletScore({
      sentimentKey: finalSentiment.key,
      oi30m: base.oiChangePercent,
      oi1h: base.oiChange1h ?? null,
      oi4h: _pe3?.lastOi4h ?? null,
      prevOi30m: _pe3?.prevOi30m ?? null,
      spotVolMult: base.volumeMultiplier,
      spotCvd1h: _spotCvdScore?.cvd1h ?? null,
      spotCvd4h: _pe3?.lastCvd4h ?? null,
      takerNetBuyPct: spotTfP2?.netBuyPct ?? null,
      takerAvailable: spotTfP2?.available ?? false,
      snfNetPct1h: _snfEntry?.netPct1h ?? null,
      snfNetPct4h: _snfEntry?.netPct4h ?? null,
      fundingRate,
      p24h: base.price24hChange ?? null,
      cycleCount: _pe3?.cycleCount ?? null,
      growthCycles: steadyClimbMap.get(symbol)?.growthCycles ?? null,
    });

    logger.debug(
      {
        symbol,
        alphaScore,
        oi30m: base.oiChangePercent.toFixed(1),
        oi1h: base.oiChange1h?.toFixed(1) ?? null,
        oi4h: _pe3?.lastOi4h?.toFixed(1) ?? null,
        prevOi30m: _pe3?.prevOi30m?.toFixed(1) ?? null,
        spotVolMult: base.volumeMultiplier.toFixed(2),
        spotCvd1h: _spotCvdScore?.cvd1h ?? null,
        spotCvd4h: _pe3?.lastCvd4h ?? null,
        taker: spotTfP2?.netBuyPct?.toFixed(1) ?? null,
        snf1h: _snfEntry?.netPct1h?.toFixed(1) ?? null,
        funding: fundingRate?.toFixed(3) ?? null,
        p24h: base.price24hChange?.toFixed(1) ?? null,
        cycleCount: _pe3?.cycleCount ?? null,
        growthCycles: steadyClimbMap.get(symbol)?.growthCycles ?? null,
      },
      "Bullet Score v3",
    );

    // ── Net Position V2 penalty для bullish_accumulation ─────────────────────────
    // netShortChangePct ≥ 0.65 = 65%+ от прироста OI приходится на шорты (медведи накапливают).
    // OI-спайк при шортовом доминировании → вероятный deadcat/сжатие, а не лонг-накопление.
    // Не блокирует сигнал, только снижает качество. Fail-open: нет данных → без изменений.
    if (finalSentiment.key === "bullish_accumulation") {
      const _npBa = await getNetPosition(symbol).catch(() => null);
      if (_npBa !== null && _npBa.netShortChangePct >= 0.65) {
        alphaScore = Math.max(0, alphaScore - 1);
        logger.debug(
          { symbol, netShortChangePct: _npBa.netShortChangePct.toFixed(2) },
          "bullish_accumulation: Net Position — шорты ≥65% прироста OI → alphaScore -1",
        );
      }
    }

    // ── Score breakdown для Telegram (компактная расшифровка по компонентам) ───
    const _bkParts: string[] = [];
    {
      const _bkOi = base.oiChangePercent;
      const _bkOi1h = base.oiChange1h ?? null;
      const _bkOi4h = _pe3?.lastOi4h ?? null;
      const _bkPrevOi30m = _pe3?.prevOi30m ?? null;
      const _bkOiParts: string[] = [
        `30m${_bkOi >= 0 ? "+" : ""}${_bkOi.toFixed(1)}%`,
      ];
      if (_bkOi1h != null)
        _bkOiParts.push(`1h${_bkOi1h >= 0 ? "+" : ""}${_bkOi1h.toFixed(1)}%`);
      if (_bkOi4h != null)
        _bkOiParts.push(`4h${_bkOi4h >= 0 ? "+" : ""}${_bkOi4h.toFixed(1)}%`);
      const _bkAccel =
        _bkPrevOi30m != null &&
        _bkPrevOi30m >= 0.3 &&
        _bkOi > _bkPrevOi30m * 1.3;
      _bkParts.push(`OI ${_bkOiParts.join("/")}${_bkAccel ? " ⚡" : ""}`);
      if (base.volumeMultiplier >= 0.5)
        _bkParts.push(`Vol ×${base.volumeMultiplier.toFixed(1)}`);
      const _bkCvd1h = _spotCvdScore?.cvd1h ?? null;
      if (_bkCvd1h === true) _bkParts.push("CVD ✅");
      else if (_bkCvd1h === false) _bkParts.push("CVD ⚠️");
      const _bkTaker = spotTfP2?.available
        ? (spotTfP2.netBuyPct ?? null)
        : null;
      if (_bkTaker != null)
        _bkParts.push(
          `Taker ${_bkTaker.toFixed(0)}%${_bkTaker >= 60 ? "✅" : _bkTaker < 45 ? "⚠️" : ""}`,
        );
      if (fundingRate != null) {
        const _frS = fundingRate >= 0 ? "+" : "";
        _bkParts.push(
          `FR ${_frS}${fundingRate.toFixed(3)}%${fundingRate <= -0.03 ? "💰" : fundingRate >= 0.05 ? "⚠️" : ""}`,
        );
      }
      const _bkCyc = _pe3?.cycleCount ?? null;
      if (_bkCyc != null && _bkCyc >= 5) _bkParts.push(`${_bkCyc}cyc`);
      const _bkGc = steadyClimbMap.get(symbol)?.growthCycles ?? null;
      if (_bkGc != null && _bkGc >= 3) _bkParts.push(`L8×${_bkGc}`);
    }
    let _scoreBreakdown = _bkParts.join(" · ");

    // ── STEP 5b: Archetype bonus (архетип детектора → alphaScore) ──────────────
    // Портированная логика оркестратора архетипов (orchestrator.py).
    // Бонусы: B_silent_accumulation +2, F_balanced_grind +3,
    //         C_price_led_momentum +1, D_pullback_continuation +1, E_stealth +1.
    // Fail-open: нет данных → бонус 0, alphaScore не меняется.
    let _archetypeLabel = "";
    {
      const _aOi30m = base.oiChangePercent; // CG OI 30m %
      const _aOi1h = base.oiChange1h ?? null; // CG OI 1h % (из candidates)
      const _aOi4h = _pe3?.lastOi4h ?? null; // OI 4h % из prescanTracker
      const _aPrevOi4h = _pe3?.prevOi4h ?? null; // OI 4h % предыдущего цикла
      const _aP24h = base.price24hChange; // price 24h %
      const _aP4h = base.price4hChange; // price 4h %
      const _aP3h = _pe3?.lastPrice3h ?? null; // price 3h % (prescanTracker)
      const _aVol = base.volumeMultiplier; // spotVolMult ?? volMult

      let _archetype = "no_signal";

      // Приоритет 1: B_silent_accumulation — тихая 4h-аккумуляция
      if (
        _aOi4h !== null &&
        _aOi4h >= 4.0 &&
        _aOi30m < 1.0 &&
        _aOi1h !== null &&
        _aOi1h < 2.0 &&
        _aP24h >= 3 &&
        _aP24h <= 25 &&
        _aVol >= 0.5
      ) {
        _archetype = "B_silent_accumulation";

        // Приоритет 2: C_price_led_momentum — цена идёт без OI
      } else if (
        _aP3h !== null &&
        _aP3h >= 3.0 &&
        _aP4h >= 3.0 &&
        (_aOi4h === null || _aOi4h < 4.0) &&
        _aOi30m < 1.0
      ) {
        _archetype = "C_price_led_momentum";

        // Приоритет 3: D_pullback_continuation — откат в тренде
      } else if (
        _aP24h >= 5 &&
        _aP24h <= 25 &&
        _aP4h < -1.5 &&
        (_aOi4h === null || _aOi4h > -3.0)
      ) {
        _archetype = "D_pullback_continuation";

        // Приоритет 4: F_balanced_grind — умеренный широкий рост по всем TF
      } else if (
        _aOi30m >= 0.3 &&
        _aOi30m <= 3.0 &&
        _aOi1h !== null &&
        _aOi1h >= 0.5 &&
        _aOi1h <= 4.0 &&
        _aOi4h !== null &&
        _aOi4h >= 2.0 &&
        _aOi4h <= 8.0 &&
        _aP3h !== null &&
        _aP3h >= 0.5 &&
        _aP3h <= 5.0 &&
        _aVol >= 0.8
      ) {
        _archetype = "F_balanced_grind";

        // Приоритет 5: E_stealth — всё плоское; breakout = резкий сдвиг OI4h
      } else {
        const _isFlat =
          (_aOi4h === null || _aOi4h < 2.0) &&
          _aOi30m < 0.5 &&
          (_aP3h === null || _aP3h < 2.0) &&
          _aVol < 1.2;
        if (_isFlat) {
          const _dOi4h =
            _aOi4h !== null && _aPrevOi4h !== null ? _aOi4h - _aPrevOi4h : null;
          _archetype =
            _dOi4h !== null && _dOi4h > 3.0
              ? "E_stealth_breakout"
              : "watchlist_stealth";
        }
      }

      const _archetypeBonuses: Record<string, number> = {
        B_silent_accumulation: 2,
        C_price_led_momentum: 1,
        D_pullback_continuation: 1,
        E_stealth_breakout: 1,
        watchlist_stealth: 1,
        F_balanced_grind: 3,
      };
      const _archetypeBonus = _archetypeBonuses[_archetype] ?? 0;
      if (_archetypeBonus > 0) {
        alphaScore = Math.min(10, alphaScore + _archetypeBonus);
        _archetypeLabel = _archetype;
        logger.info(
          {
            symbol,
            archetype: _archetype,
            bonus: `+${_archetypeBonus}`,
            alphaScoreAfter: alphaScore,
          },
          `🔬 Archetype bonus: ${_archetype} → alphaScore +${_archetypeBonus}`,
        );
      }
    }
    if (_archetypeLabel) _scoreBreakdown += ` · 🔬${_archetypeLabel}`;

    // ── STEP 5: Grading ──────────────────────────────────────────────────────────
    // super_alpha — Score ≥ 8 И OI подтвердили 2+ таймфрейма, OR глобальный OI ≥ 15%
    // alpha       — стандартный сигнал (OI сработал на 1+ ТФ)

    // Считаем количество OI таймфреймов которые сработали для этого кандидата
    const oiTfCount =
      base.oiTriggerTf === "steady" ? 2 : base.oiTriggerTf.split("+").length;

    // Grade будет обновлён после OB анализа (bulletScore) — здесь предварительное значение
    let grade: "alpha" | "super_alpha" =
      (alphaScore >= 8 && oiTfCount >= 2) ||
      Math.abs(base.oiChangePercent) >= 15
        ? "super_alpha"
        : "alpha";

    // ── SPOT TAKER FLOW FILTER: спот buy/sell баланс (Binance / BingX spot) ──────
    // Паттерны: любое buy доминирование (> 0%).
    // spotTfP2 уже поднят в блоке "Pre-fetch enrichment for Bullet Score v2" выше.
    {
      if (spotTfP2?.available) {
        const key = finalSentiment.key;

        // trend_accumulation: использует отдельный futures taker gate ниже (TREND_ACCUM GATE).
        if (key === "trend_accumulation") {
          // пропускаем здесь — специальная логика fut5m+fut15m+spot5m+spot15m ниже
        }
        // остальные long-паттерны: любое spot net buy (доминирование покупателей)
        else if (spotTfP2.dominance === "sell") {
          logger.info(
            {
              symbol,
              key,
              spotNetBuyPct: spotTfP2.netBuyPct?.toFixed(1) + "%",
              exchange: spotTfP2.exchange,
            },
            "SKIP: Spot Taker Flow — продавцы доминируют на споте",
          );
          skipCount.takerFail++;
          continue;
        }
      } else {
        logger.debug(
          { symbol },
          "Spot Taker Flow: данные недоступны — фильтр пропущен",
        );
      }
    }

    // ── TREND_ACCUM GATE: Futures Trend Accumulation — futures taker + spot CVD ──
    // Паттерн использует ФЬЮЧ тейкер (Binance+Bybit) — намеренно, это Futures Trend Accum.
    // Требуем подтверждения притока: fut30m, fut15m (фьюч тейкер) + spot30m, spot15m (spot CVD).
    // Если данные недоступны (API timeout) → условие не проверяется (graceful fallback).
    if (finalSentiment.key === "trend_accumulation") {
      // 3.2: soft gate — только лог, не блокируем. Даёт данные для анализа:
      // когда trend_accumulation стреляет с фьюч-объёмом без спот-поддержки.
      const _taPrescan = prescanTracker.get(symbol);
      const _taSpotVolMult =
        _taPrescan?.spotVolAvg1h && _taPrescan?.lastSpotVol1h
          ? _taPrescan.lastSpotVol1h / _taPrescan.spotVolAvg1h
          : null;
      if (_taSpotVolMult !== null && _taSpotVolMult < 0.5) {
        logger.info(
          { symbol, spotVolMult: _taSpotVolMult.toFixed(2) },
          "trend_accumulation: спот объём слабее 0.5x — возможна только фьюч активность, продолжаем",
        );
      }
      const futTfTrend = await getTakerFlowCached(symbol).catch(() => null);
      const spotCvdP3 = _spotCvdMapScan.get(symbol);
      const futLast =
        (futTfTrend?.cycles.length ?? 0) > 0
          ? futTfTrend!.cycles[futTfTrend!.cycles.length - 1]
          : null;
      const futNegNow =
        futTfTrend?.available && futTfTrend.dominance === "sell";
      const futNegLast =
        futTfTrend?.available && futLast !== null && futLast.delta < 0;
      const spotNeg30m =
        spotCvdP3?.available === true && spotCvdP3.cvd30m === false;
      if (futNegNow || futNegLast || spotNeg30m) {
        logger.info(
          {
            symbol,
            futDominance: futTfTrend?.available ? futTfTrend.dominance : "n/a",
            futLast: futTfTrend?.available
              ? futLast
                ? futLast.netBuyPct.toFixed(1) + "%"
                : "n/a"
              : "n/a",
            spotCvd30m: spotCvdP3?.available ? spotCvdP3.cvd30m : "n/a",
          },
          "SKIP trend_accumulation: не все TF положительны (futSell+spot30m)",
        );
        skipCount.takerFail++;
        continue;
      }
    }

    // ── STEP 6: Order Book Imbalance (CoinGlass агрегированный стакан Binance) ──
    // Запрашиваем только для финальных кандидатов (прошли CVD и все фильтры).
    // Буллиш стакан → бонус до +2 к alpha score.
    // Медвежий стакан → hard gate для volume_breakout.
    const obImbalance = await getCgAskBids(symbol);
    let bulletScore = alphaScore;

    if (obImbalance) {
      bulletScore = Math.min(10, alphaScore + obImbalance.scoreBonus);

      const biasLabel =
        obImbalance.bias === "strong_bull"
          ? "🟢🟢 STRONG BULL"
          : obImbalance.bias === "bull"
            ? "🟢 BULL"
            : obImbalance.bias === "bear"
              ? "🔴 BEAR"
              : "⚪ NEUTRAL";

      logger.info(
        {
          symbol,
          bidAskRatio: obImbalance.bidAskRatio.toFixed(2),
          bidsUsd: obImbalance.bidsUsd.toFixed(0),
          asksUsd: obImbalance.asksUsd.toFixed(0),
          bias: biasLabel,
          scoreBonus:
            obImbalance.scoreBonus > 0 ? `+${obImbalance.scoreBonus}` : "0",
        },
        "📚 Order book (CoinGlass/Binance)",
      );
    } else {
      logger.warn({ symbol }, "📚 Order book: данные недоступны");
    }

    // Диагностика: паттерны, прошедшие свой гейт в loop1 для этого символа — теперь
    // известны bulletScore и итоговый det.key, пишем оба в pattern_debug_log,
    // чтобы точно отличить "срезан на alphaScore<5" от "перехвачен другим паттерном".
    {
      const _passedGate = _passedGatePatternsMap.get(symbol);
      if (_passedGate?.length) {
        for (const _pat of _passedGate) {
          void diagPatternPassed(_pat, symbol, bulletScore, finalSentiment.key);
        }
      }
    }

    // Пересчёт grade с учётом OB бонуса
    if (obImbalance && obImbalance.scoreBonus > 0) {
      if (
        (bulletScore >= 8 && oiTfCount >= 2) ||
        Math.abs(base.oiChangePercent) >= 15
      ) {
        grade = "super_alpha";
      }
    }

    // WI + OB двойной медвежий фильтр удалён по решению пользователя (2026-07-28).
    // OB и WI по-прежнему пишутся в сигнал и видны в UI — но больше не блокируют.

    // ── Bullet Score: информационное поле, НЕ блокирующий гейт (2026-07-10) ──
    // Раньше здесь был `if (bulletScore < 5) continue;` — резал сигналы по низкому
    // score. Убрано по решению пользователя: score считается и сохраняется в сигнале
    // (виден в Telegram/БД), но больше не мешает сигналу дойти до signals/Telegram.
    // Паттерн-гейты (условия входа), кулдауны и dedup не изменились.
    if (bulletScore < 5) {
      logger.info(
        { symbol, bulletScore, pattern: finalSentiment.key },
        "INFO: bulletScore < 5 — сигнал всё равно создан (гейт снят)",
      );
    }

    // State tracking
    const prevState = signalHistory.get(symbol);
    const isContinuing = !!prevState;
    const cumulativeOiChange = prevState
      ? prevState.cumulativeOiChange + base.oiChangePercent
      : base.oiChangePercent;

    signalHistory.set(symbol, {
      firstSignalAt: prevState?.firstSignalAt ?? new Date(),
      signalCount: (prevState?.signalCount ?? 0) + 1,
      cumulativeOiChange,
    });

    const tradingViewUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${symbol.replace("-", "")}`;
    const bingxUrl = `https://bingx.com/en/trade/${symbol.replace("-", "")}/`;

    // Используем свежую цену (текущий рынок), а не закрытие kline 8 мин назад.
    // Это предотвращает ситуацию когда трекер видит "вход" по старой цене
    // и сразу стреляет milestone 25%/50% потому что рынок уже ушёл.
    const freshPrice = freshPriceMap.get(symbol) ?? base.price;
    const klineSlippage =
      base.price > 0 ? ((freshPrice - base.price) / base.price) * 100 : 0;

    // ── HighRisk «свежий мувер» (2026-07-15, growth-leader анализ) ─────────────
    // Токен <3 циклов в прескане (нет истории накопления) + цена уже ≥5% за 24ч.
    // Статистика 30д: в этом сегменте 43% отмен (пик <2% за 3ч); growth-leader
    // данные: муверы без futures-подтверждения дампят в 46% при p24h 10–20%.
    // Информационная пометка в алерте — сигнал НЕ блокируется.
    const _fmCycles = prescanTracker.get(symbol)?.cycleCount ?? 0;
    const freshMoverRisk =
      _fmCycles < 3 && base.price24hChange >= 5
        ? { cycles: _fmCycles, price24h: base.price24hChange }
        : null;
    if (freshMoverRisk) {
      logger.info(
        {
          symbol,
          pattern: finalSentiment.key,
          cycles: _fmCycles,
          price24h: base.price24hChange.toFixed(1) + "%",
        },
        "⚠️ HighRisk fresh mover: <3 циклов в прескане + p24h ≥5% — пометка в алерте",
      );
    }
    if (Math.abs(klineSlippage) >= 3) {
      logger.info(
        {
          symbol,
          klineClose: base.price,
          freshPrice,
          slippage: klineSlippage.toFixed(1) + "%",
        },
        "⚠️ Entry price slippage since kline fetch — using fresh price",
      );
    }

    alphaResults.push({
      symbol,
      grade,
      price: freshPrice,
      priceChange30m: base.priceChange30m,
      currentVolume: base.currentVolume,
      avgVolume: base.avgVolume,
      volumeMultiplier: base.volumeMultiplier,
      oiChangePercent: base.oiChangePercent,
      openInterest: base.openInterest,
      cmcRank: trending.rank,
      cmcSource: trending.source,
      cmcAvailable: trending.available,
      liquidationsUsd: liquidations.liquidationsUsd,
      liquidationsMultiple: liquidations.multiple,
      coinglassAvailable: liquidations.available,
      globalOiChange,
      globalOiConfirmed,
      isNewListing: false,
      isExhaustedSqueeze: false,
      pumpFromOpen: null,
      candleCount: 48,
      sentiment: finalSentiment.label,
      sentimentKey: finalSentiment.key,
      traderAction: finalSentiment.traderAction,
      isContinuing,
      cumulativeOiChange,
      tradingViewUrl,
      bingxUrl,
      oiTriggerTf: base.oiTriggerTf,
      oiChange1h: base.oiChange1h,
      oiChange4h: base.oiChange4h,
      oiChange24h: base.oiChange24h,
      klineSlippage,
      isRepeatSignal: base.isRepeatSignal,
      fundingRate,
      markPrice,
      indexPrice,
      obImbalance,
      cvdDivergence: false,
      isScalpOnly: base.isScalpOnly,
      alphaScore: bulletScore,
      upcomingUnlock: _unlockWarnMap.get(symbol) ?? null,
      freshMoverRisk,
      scoreBreakdown: _scoreBreakdown,
    });

    _pdbPass(finalSentiment.key);
    signalsToInsert.push({
      symbol,
      type: grade,
      value: base.volumeMultiplier,
      threshold: settings.volumeMultiplier,
      price: freshPrice,
      priceChangePercent: base.priceChange30m,
      volume24h: base.currentVolume,
      avgVolume: base.avgVolume,
      openInterest: base.openInterest,
      oiChangePercent: base.oiChangePercent,
      fundingRate: fundingRate ?? null,
      tradingViewUrl,
      cmcRank: trending.rank ?? null,
      cmcSource: trending.source ?? null,
      liquidationsUsd: liquidations.liquidationsUsd ?? null,
      liquidationsMultiple: liquidations.multiple ?? null,
      sentiment: finalSentiment.label,
      sentimentKey: finalSentiment.key,
      alphaScore,
      isContinuing,
      cumulativeOiChange,
      entryCvd30m: _spotCvdMapScan.get(base.symbol)?.cvd30m ?? null,
      entryCvd1h: _spotCvdMapScan.get(base.symbol)?.cvd1h ?? null,
      entryCvd4h: _spotCvdMapScan.get(base.symbol)?.cvd4h ?? null,
      detectedAt: new Date(),
    });

    logger.info(
      { symbol, grade, alphaScore, pattern: finalSentiment.key },
      `✅ ${grade.toUpperCase()} score=${alphaScore}`,
    );
  }

  // ── Символы из confirming-очереди — стреляем немедленно без watching ────────
  // Они уже провели 30-120 мин в confirming. Putting them back in watching
  // creates a second 90-min window with a strict price gate that often kills them.
  const confirmedFireSet = new Set(
    candidates.filter((c) => c.isConfirmedFire).map((c) => c.symbol),
  );

  // ── Route signals through OI Watch (two-stage confirmation) ─────────────────
  // alpha/super_alpha: isVolConfirmed=true, 30-90 min window — fire as soon as conditions hold
  // confirmed_fire:    already in confirming queue → insert + track + broadcast immediately

  for (let i = 0; i < alphaResults.length; i++) {
    const res = alphaResults[i];
    const sig = signalsToInsert[i];
    try {
      // ── DIRECT FIRE: кандидат из confirming-очереди ────────────────────────
      // Пропускаем watching-очередь — сигнал уже подтверждён confirming-циклом.
      // Раньше: confirming → candidates → watching → PATH A (90мин + price gate) → пропуск.
      // Теперь: confirming → candidates → СРАЗУ insert + trackSignal + broadcast.
      if (confirmedFireSet.has(res.symbol)) {
        try {
          // ── Spot volume gate ─────────────────────────────────────────────────
          // Основной: спот-объём >= 1% MCap (универсальный гейт, везде без исключений).
          // Fallback при MCap = null: токен должен быть в prescanTracker с cycleCount >= 2.
          const ALPHA_MIN_SPOT_MCAP_PCT = 0.01; // 1%
          const [vbsFsVol, mcapData] = await Promise.all([
            getFsVolume(res.symbol).catch(() => null),
            fetchMarketCap(res.symbol).catch(() => null),
          ]);
          let spotVol24h = vbsFsVol?.spotVolUsd24h ?? null;
          // Fallback: getSpotVolume (pairs-markets, ВСЕ биржи) когда getFsVolume не нашёл спот
          // на Binance/OKX/Bybit. Покрывает Gate.io, KuCoin и др.
          if (spotVol24h === null) {
            const svFb = await getSpotVolume(res.symbol).catch(() => null);
            if ((svFb?.volumeUsd24h ?? 0) > 0) spotVol24h = svFb!.volumeUsd24h!;
          }
          // MCap: сначала живые данные, потом SpotPool кэш (обновляется каждые 30 мин).
          const marketCapUsd =
            mcapData?.mcap ?? getSpotPoolEntry(res.symbol)?.mcapUsd ?? null;
          if (spotVol24h === null) {
            // volume_breakout — BingX-exclusive токены, спот-данных нет по определению, gate пропущен.
            // whale_alert — своё подтверждение (кит $500K+ + OI/CVD гейт), спот-данные не обязательны.
            const isBingXExclusivePattern =
              res.sentimentKey === "spot_vol_accumulation" ||
              res.sentimentKey === "whale_alert";
            if (!isBingXExclusivePattern) {
              logger.info(
                {
                  symbol: res.symbol,
                  sentimentKey: res.sentimentKey,
                  coinglassAvailable: res.coinglassAvailable,
                },
                "CONFIRMED FIRE: нет данных спота — сигнал отменён",
              );
              skipCount.spotFailNoData++;
              continue;
            }
            logger.info(
              { symbol: res.symbol, sentimentKey: res.sentimentKey },
              "CONFIRMED FIRE: спот null — BingX-exclusive паттерн, spot gate пропущен",
            );
          }
          if (spotVol24h !== null) {
            if (marketCapUsd === null) {
              // MCap недоступен — fallback: проверяем prescanTracker.
              // Если токен уже ≥2 циклов в пресканере — он живой и торгуемый, пропускаем оптимистично.
              const _cfPrescanEntry = prescanTracker.get(res.symbol);
              const _cfCycleCount = _cfPrescanEntry?.cycleCount ?? 0;
              if (_cfCycleCount < 2) {
                logger.info(
                  { symbol: res.symbol, spotVol24h, cycleCount: _cfCycleCount },
                  "CONFIRMED FIRE: MCap недоступен, не в prescanTracker (cycleCount < 2) — сигнал отменён",
                );
                skipCount.spotFailLow++;
                continue;
              }
              logger.info(
                { symbol: res.symbol, spotVol24h, cycleCount: _cfCycleCount },
                "CONFIRMED FIRE: MCap недоступен, prescanTracker cycleCount >= 2 — оптимистично пропущен",
              );
            } else if (spotVol24h < marketCapUsd * ALPHA_MIN_SPOT_MCAP_PCT) {
              const pct = ((spotVol24h / marketCapUsd) * 100).toFixed(3);
              logger.info(
                { symbol: res.symbol, spotVol24h, marketCapUsd, pct },
                "CONFIRMED FIRE: спот-объём < 1% MCap — сигнал отменён",
              );
              skipCount.spotFailLow++;
              continue;
            }
          }

          // ── Spot Taker Flow Gate (confirmed fire) ────────────────────────────
          // Спот тейкер Binance/BingX — продавцы доминируют → OI от шортов.
          // Данные недоступны → не блокируем.
          {
            const cfSpotTf = await getSpotTakerFlow(res.symbol).catch(
              () => null,
            );
            if (cfSpotTf?.available) {
              if (cfSpotTf.dominance === "sell") {
                logger.info(
                  {
                    symbol: res.symbol,
                    spotNetBuyPct: cfSpotTf.netBuyPct?.toFixed(1) + "%",
                    exchange: cfSpotTf.exchange,
                  },
                  "CONFIRMED FIRE: Spot Taker Flow — продавцы доминируют на споте → сигнал пропущен",
                );
                skipCount.takerFail++;
                continue;
              }
            }
          }

          // ── Spot vol mult: EMA prescan → real-time 24h fallback ───────────────
          // getSpotVolume() уже кэширован 5 мин — 0 лишних API-вызовов для свежих токенов.
          // vol1h / (vol24h/24) = текущий часовой объём vs среднечасовой за сутки.
          {
            const _cfPe = prescanTracker.get(res.symbol);
            const _emaSpot =
              _cfPe?.spotVolAvg1h && _cfPe?.lastSpotVol1h
                ? _cfPe.lastSpotVol1h / _cfPe.spotVolAvg1h
                : null;
            let _spotMult: number | null = _emaSpot;
            if (_spotMult === null) {
              const _svFb = await getSpotVolume(res.symbol).catch(() => null);
              if (_svFb?.volumeUsd1h && _svFb?.volumeUsd24h) {
                _spotMult = _svFb.volumeUsd1h / (_svFb.volumeUsd24h / 24);
              }
            }
            (
              res as typeof res & { _spotVolMult?: number | null }
            )._spotVolMult = _spotMult;

            // bullish_accumulation: спот-активность должна быть живой.
            // Если spot vol < 0.8× его 24h-среднего → фьюч без спота → риск медвежьего OI.
            // Fail-open: нет данных → не блокируем.
            if (
              res.sentimentKey === "bullish_accumulation" &&
              _spotMult !== null &&
              _spotMult < 0.8
            ) {
              logger.info(
                { symbol: res.symbol, spotVolMult: _spotMult.toFixed(2) },
                "CONFIRMED FIRE: bullish_accumulation — спот тихий (< 0.8× среднего) → сигнал отменён",
              );
              skipCount.spotFailLow++;
              continue;
            }
          }

          {
            const signalLayers =
              lastCycleCandidates.find((c) => c.symbol === res.symbol)
                ?.layers ?? [];
            logger.info(
              {
                symbol: res.symbol,
                pattern: res.sentimentKey ?? sig.sentimentKey,
                layers: signalLayers,
              },
              `🎯 SIGNAL [${signalLayers.join("+")}] → ${res.sentimentKey ?? sig.sentimentKey}`,
            );
          }
          let inserted: typeof signalsTable.$inferSelect | undefined;
          try {
            const [ins] = await dbWriteStrict(
              "signals/confirmed-fire-insert",
              () =>
                db
                  .insert(signalsTable)
                  .values({
                    ...sig,
                    detectedAt: new Date(),
                  })
                  .returning(),
            );
            inserted = ins;
          } catch (err) {
            logger.error(
              { err, symbol: res.symbol },
              "CONFIRMED FIRE: signal insert failed after retries — signal dropped",
            );
          }
          if (!inserted) {
            skipCount.noConfirming++;
            continue;
          }
          const _peFire = prescanTracker.get(res.symbol);
          const tracked = await trackSignal({
            symbol: res.symbol,
            signalId: inserted.id,
            signalType: res.grade ?? "alpha",
            sentiment: res.sentiment,
            sentimentKey: res.sentimentKey,
            alphaScore: res.alphaScore,
            entryPrice: await getFreshPrice(res.symbol, res.price),
            entryOi: res.openInterest > 0 ? res.openInterest : null,
            entryCvd30m: inserted.entryCvd30m ?? null,
            entryCvd1h: inserted.entryCvd1h ?? null,
            entryCvd4h: inserted.entryCvd4h ?? null,
            marketCapUsd: marketCapUsd ?? null,
            entryOi30m: _peFire?.lastOi30m ?? res.globalOiChange ?? null,
            entryOi1h: _peFire?.lastOi1h ?? res.oiChange1h ?? null,
            entryOi4h: _peFire?.lastOi4h ?? res.oiChange4h ?? null,
            entryFutVolMult:
              res.volumeMultiplier > 0 ? res.volumeMultiplier : null,
            entrySpotVolMult:
              (res as typeof res & { _spotVolMult?: number | null })
                ._spotVolMult ??
              _spotVolMultMapScan.get(res.symbol) ??
              null,
            entrySpotVol24h: spotVol24h ?? null,
            entrySpotMcapPct:
              spotVol24h !== null && marketCapUsd
                ? (spotVol24h / marketCapUsd) * 100
                : null,
          });
          if (tracked === false) {
            logger.error(
              { symbol: res.symbol },
              "CONFIRMED FIRE: trackSignal упал — broadcast отменён",
            );
            continue;
          }
          if (tracked === "skip") {
            // Монета уже в трекере (active/in_run) с другим паттерном — НЕ дублируем алерт.
            // Атомарный claim broadcastBatchAlert защищает от двух процессов на одном сигнале,
            // но не от двух РАЗНЫХ сигналов (разные signal.id) на одну монету.
            // "reentry" (accumulation→active) → всё равно отправляем (статус обновлён, новый вход).
            logger.info(
              { symbol: res.symbol, sentimentKey: res.sentimentKey },
              "CONFIRMED FIRE: монета уже активна — broadcast пропущен (duplicate guard)",
            );
            continue;
          }
          if (tracked !== "reentry") {
            // Свежий сигнал — обнуляем cycleCount для корректного отображения в UI
            // и чтобы не блокировать повторный выстрел гейтом cycleCount > 25.
            resetPrescanCycleCount(res.symbol);
          }
          await broadcastBatchAlert([
            {
              ...res,
              spotVol24h,
              marketCapUsd,
              entryOb: consumeObAtFire(res.symbol),
            },
          ]);
          // whale_alert: алерт отправлен → запись пула Layer 11 → fired (одноразовый паттерн).
          // Помечаем именно здесь (а не при создании alphaResult), чтобы отмена
          // спот-гейтами выше не сжигала запись пула без отправленного алерта.
          logger.info(
            { symbol: res.symbol, grade: res.grade, pattern: res.sentimentKey },
            "✅ CONFIRMED FIRE: сигнал выдан напрямую (без watching-очереди)",
          );
        } catch (err) {
          logger.error(
            { err, symbol: res.symbol },
            "CONFIRMED FIRE: ошибка при выстреле",
          );
        }
        continue; // не создаём watching entry для этого символа
      }

      const payload = { alphaResult: res, signalRow: sig };

      const watchWindowMin = 360; // 6ч для всех паттернов
      const expiresAt = new Date(Date.now() + watchWindowMin * 60 * 1000);
      const triggerTf = res.oiTriggerTf;
      const isVolConfirmed = true;

      const existing = await db
        .select({ id: oiWatchTable.id, status: oiWatchTable.status })
        .from(oiWatchTable)
        .where(
          and(
            eq(oiWatchTable.symbol, res.symbol),
            inArray(oiWatchTable.status, ["watching", "confirming"]),
          ),
        )
        .limit(1);

      if (existing.length > 0) {
        // dbWriteStrict: критичный апдейт OI Watch — бросает при неудаче
        await dbWriteStrict("oiWatch/loop2-update", () =>
          db
            .update(oiWatchTable)
            .set({
              oiChange: res.oiChangePercent,
              volumeMultiplier: res.volumeMultiplier,
              priceAtEntry: res.price,
              expiresAt,
              isVolConfirmed,
              signalPayload: payload as any,
            })
            .where(eq(oiWatchTable.id, existing[0].id)),
        );
        logger.info(
          {
            symbol: res.symbol,
            grade: res.grade,
            vol: res.volumeMultiplier.toFixed(1) + "x",
          },
          "👁 OI Watch: обновлён свежими данными",
        );
      } else {
        await dbWriteStrict("oiWatch/loop2-insert", async () => {
          const _freshPrice = await getFreshPrice(res.symbol, res.price);
          return db.insert(oiWatchTable).values({
            symbol: res.symbol,
            triggerTf,
            oiChange: res.oiChangePercent,
            priceAtEntry: _freshPrice,
            volumeMultiplier: res.volumeMultiplier,
            sentimentKey: res.sentimentKey,
            status: "watching",
            addedAt: new Date(),
            expiresAt,
            avgVolume: res.avgVolume,
            isVolConfirmed,
            signalPayload: payload as any,
            price1hChange: null,
            price24hChange: null,
            // Кандидаты прошли все CVD гейты → объём подтверждён.
            volStatusReason: "confirmed",
            entryVolMult: res.volumeMultiplier,
          });
        });
        logger.info(
          {
            symbol: res.symbol,
            grade: res.grade,
            alphaScore: res.alphaScore,
            vol: res.volumeMultiplier.toFixed(1) + "x",
          },
          "👁 OI Watch: сигнал в очереди — сработает через 2 мин если условия сохранятся",
        );
        state.oiWatchLastInsertAt = new Date();
        state.oiWatchInsertsLastScan++;
      }
    } catch (err) {
      state.oiWatchInsertErrors++;
      state.oiWatchLastInsertError =
        err instanceof Error ? err.message : String(err);
      logger.warn(
        { err, symbol: res.symbol },
        "Ошибка при постановке сигнала в OI Watch",
      );
    }
  }

  // ── Batch expire OI Watch confirming (exhausted pump + deep negative) ─────────
  // Собирались в loop в oiWatchToExpire — теперь один UPDATE вместо N per-symbol await.
  if (oiWatchToExpire.length > 0) {
    void db
      .update(oiWatchTable)
      .set({ status: "expired", firedAt: new Date() })
      .where(
        and(
          inArray(oiWatchTable.symbol, oiWatchToExpire),
          eq(oiWatchTable.status, "confirming"),
        ),
      )
      .catch((err: unknown) =>
        logger.warn(
          { err, count: oiWatchToExpire.length },
          "OI Watch batch expire failed",
        ),
      );
  }

  const totalSignals = alphaResults.length;
  const scanAt = new Date();
  state.lastScanAt = scanAt;
  state.marketsScanned = usdtTickers.length;

  const durationMs = Date.now() - startTime;
  state.isScanning = false;
  state.lastScanDurationMs = durationMs;
  const durationMin = +(durationMs / 60000).toFixed(2);
  const _nfTelemetry = getNetflowTelemetry();
  // Латентность CoinGlass + лаг event loop за окно с прошлого скана:
  // отличаем «CoinGlass медленный» (высокий cgP95 при низком elLag) от
  // «инстанс захлебнулся» (высокий elLagP95 → таймауты внешних API вторичны).
  const _cgTel = snapshotCgTelemetry();
  state.lastCgTelemetry = _cgTel;
  logger.info(
    {
      signalsFound: totalSignals,
      alphaCount: alphaResults.filter((r) => r.grade === "alpha").length,
      superAlphaCount: alphaResults.filter((r) => r.grade === "super_alpha")
        .length,
      marketsScanned: usdtTickers.length,
      durationMs,
      durationMin,
      takerBatchHits: _nfTelemetry.hits,
      takerBatchMisses: _nfTelemetry.misses,
      takerBatchSize: _nfTelemetry.batchSize,
      takerBatchHitRate:
        _nfTelemetry.hits + _nfTelemetry.misses > 0
          ? Math.round(
              (_nfTelemetry.hits / (_nfTelemetry.hits + _nfTelemetry.misses)) *
                100,
            ) + "%"
          : "n/a",
      cgReq: _cgTel.cgReq,
      cgReqPerMin: _cgTel.cgReqPerMin,
      cgTimeoutPct: _cgTel.cgTimeoutPct + "%",
      cgErrors: _cgTel.cgErrors,
      cgP50Ms: _cgTel.cgP50Ms,
      cgP95Ms: _cgTel.cgP95Ms,
      cgMaxMs: _cgTel.cgMaxMs,
      elLagP50Ms: _cgTel.elLagP50Ms,
      elLagP95Ms: _cgTel.elLagP95Ms,
      elLagMaxMs: _cgTel.elLagMaxMs,
      cgWindowMin: _cgTel.windowMin,
    },
    "Scan complete",
  );

  // Persist lastScanAt cross-process: both workers can read current scan time from DB
  void dbWriteBestEffort(
    "scannerLastScanAt",
    () => db.update(settingsTable).set({ scannerLastScanAt: scanAt }),
    { attempts: 1 },
  );

  // ── Ghost Pump: ОТКЛЮЧЁН ─────────────────────────────────────────────────────
  // Паттерн убран из ростера: слишком поздний вход, движение уже случилось к моменту сигнала.
  // prescanTracker.clear() также убран — он мешал Volume Breakout накапливать cycleCount между циклами.

  // Persist OI baselines to DB every 5 min so restarts don't lose context
  await persistBaselinesToDb();

  // Batch spot taker update for dashboard display (fire-and-forget, не блокирует return)
  void (async () => {
    const symbols = Array.from(prescanTracker.keys());
    const results = await Promise.allSettled(
      symbols.map((sym) => getSpotTakerFlow(sym)),
    );
    for (let i = 0; i < symbols.length; i++) {
      const r = results[i];
      if (r.status === "fulfilled" && r.value.available) {
        const pe = prescanTracker.get(symbols[i]);
        if (pe) {
          pe.lastSpotTakerNetBuy = r.value.netBuyPct;
          pe.lastSpotTakerDominance = r.value.dominance;
          pe.lastSpotTakerExchange = r.value.exchange;
        }
      }
    }
  })();

  // Log pattern debug counters at end of scan (persists in logs regardless of HTTP process)
  logger.info(
    {
      patternDebug: lastPatternDebug,
      spotVolDiag: {
        notInMap: _spotVolDiag.notInMap,
        noAvg: _spotVolDiag.noAvg,
        noLast: _spotVolDiag.noLast,
        hasMult: _spotVolDiag.hasMult,
        total:
          _spotVolDiag.notInMap +
          _spotVolDiag.noAvg +
          _spotVolDiag.noLast +
          _spotVolDiag.hasMult,
        sample: _spotVolDiag.sample,
      },
    },
    "Pattern debug: end-of-scan counters",
  );

  // Batch spot volume update (fire-and-forget, для дашборда, не блокирует также return)
  void runSpotVolBatch();

  // Growth leader log: топ-100 BingX gainers (price24h > 3%) — fire-and-forget.
  void saveGrowthLeadersToLog(tickers);

  // Архетипные паттерны — отдельный лог для видимости даже при сбое DB-записи
  const ARCHETYPE_PATTERNS = [
    "4h_pullback_continuation",
    "price_led_momentum",
    "balanced_grind",
    "stealth_breakout",
  ];
  const archetypeStats = Object.fromEntries(
    ARCHETYPE_PATTERNS.map((p) => [
      p,
      lastPatternDebug[p] ?? { checked: 0, passed: 0, rejectedAt: {} },
    ]),
  );
  logger.info({ archetypeStats }, "Archetype pattern stats this cycle");

  // PDB snapshot + flushPendingDiagRows + persistSymRejectLog перенесены в НАЧАЛО следующего скана.
  // Причина: Neon pool перегружен в конце 24-мин скана → attempt падают по таймауту 8s.
  // В начале следующего скана pool простоял ~10 мин и принимает INSERT мгновенно.

  return {
    signalsFound: totalSignals,
    marketsScanned: usdtTickers.length,
    durationMs,
  };
}

/**
 * Вычисляет задержку до следующего выровненного интервала скана.
 * Например, при интервале 30 мин и текущем времени HH:17:xx →
 * следующий скан будет ровно в HH:30:00 (+ 2с), а не HH:17+30=HH:47.
 * Это устраняет drift: каждый скан попадает в начало 30-минутной свечи.
 */
function msUntilNextBoundary(intervalMs: number): number {
  const now = Date.now();
  const msSinceEpoch = now % intervalMs;
  const msToNext = intervalMs - msSinceEpoch;
  // Добавляем 2 секунды, чтобы гарантированно попасть в новую свечу
  return msToNext + 2000;
}

async function scheduledScan() {
  if (!state.running) return;
  let coinglassOutage = false;
  try {
    await performScan();
  } catch (err) {
    if (err instanceof CoinglassOutageError) {
      coinglassOutage = true;
      logger.warn(
        { skipped: err.skipped },
        "Скан отменён: CoinGlass недоступен — повтор через 5 мин",
      );
      try {
        const outageCooldown = new Date(Date.now() - 10 * 60 * 1000);
        const claimed = await dbWriteBestEffort(
          "cgOutage-settingsUpdate",
          () =>
            db
              .update(settingsTable)
              .set({ lastCoinglassOutageAt: new Date() })
              .where(
                sql`id = (SELECT id FROM settings LIMIT 1) AND (last_coinglass_outage_at IS NULL OR last_coinglass_outage_at < ${outageCooldown})`,
              )
              .returning({ id: settingsTable.id }),
          { perAttemptTimeoutMs: 4000, attempts: 1 },
        );
        if (claimed && claimed.length > 0) {
          await broadcastRawAlert(
            `⚠️ CoinGlass API недоступен — скан отменён, повтор через 5 мин`,
          );
        }
      } catch {
        /* Telegram сбой не критичен */
      }
    } else {
      logger.error({ err }, "Scheduled scan error");
    }
  } finally {
    // Safety net: если performScan кинул необработанный exception, isScanning
    // могло остаться true — watchdog через 70 мин бил бы тревогу вечно.
    if (state.isScanning) {
      state.isScanning = false;
      state.lastScanAt = new Date();
      logger.warn(
        "scheduledScan: isScanning stuck after performScan — force-reset",
      );
    }
  }
  // Reschedule ALWAYS — even if getSettings() fails (DB hiccup).
  // Without this guard the scan loop dies silently on any transient DB error.
  if (state.running) {
    if (coinglassOutage) {
      // CoinGlass down: retry in 5 min instead of normal interval
      const retryMs = 5 * 60 * 1000;
      state.nextScanAt = new Date(Date.now() + retryMs);
      scanTimer = setTimeout(scheduledScan, retryMs);
      logger.info(
        { nextScanIn: "5m", nextScanAt: state.nextScanAt },
        "Retry scan scheduled (CoinGlass outage)",
      );
    } else {
      try {
        const settings = await getSettings();
        state.scanIntervalMs = settings.scanIntervalMs;
      } catch (err) {
        logger.warn(
          { err },
          "Failed to load settings for reschedule — keeping current interval",
        );
      }
      const delay = msUntilNextBoundary(state.scanIntervalMs);
      state.nextScanAt = new Date(Date.now() + delay);
      scanTimer = setTimeout(scheduledScan, delay);
      logger.info(
        {
          nextScanIn: `${Math.round(delay / 1000)}s`,
          nextScanAt: state.nextScanAt,
        },
        "Next scan scheduled",
      );
    }
  }
}

export async function startScanner(): Promise<void> {
  if (state.running) return;
  state.running = true;
  logger.info("AltBullet Scanner started (15m TF, 30m OI, multi-pattern)");

  state.bingxConnected = await testBingX();
  state.telegramConnected = await testTelegram();

  // Restore OI baselines from DB so restarts don't cause a blind period
  await loadBaselinesFromDb();
  // Restore Whale Watch stages so real-time accumulation survives restarts
  await loadWhaleWatchStagesFromDb();
  // Schema guard: add ALL known prescan_tracker columns before loadPrescanFromDb.
  // Runs in EVERY worker process — eliminates the race condition where one worker
  // calls loadPrescanFromDb before runStartupMigration (index.ts) completes in
  // the other worker. Each ALTER is idempotent (IF NOT EXISTS).
  for (const _alter of [
    sql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS layers text[] NOT NULL DEFAULT '{}'`,
    sql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_price_24h real`,
    sql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_net_buy_pct real`,
    sql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_spot_taker_net_buy real`,
    sql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_spot_taker_dominance text`,
    sql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_cvd_30m boolean`,
    sql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_cvd_1h boolean`,
    sql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_cvd_4h boolean`,
  ]) {
    try {
      await db.execute(_alter);
    } catch (_e) {
      /* non-fatal: IF NOT EXISTS should prevent errors; swallow anything unexpected */
    }
  }
  // Restore prescan tracker so cycleCount / firstSeenAt survive rebuilds
  await loadPrescanFromDb();
  const settings = await getSettings();
  state.scanIntervalMs = settings.scanIntervalMs;

  let firstScanDelay: number;
  try {
    await performScan();
    firstScanDelay = msUntilNextBoundary(settings.scanIntervalMs);
  } catch (err) {
    if (err instanceof CoinglassOutageError) {
      logger.warn(
        { skipped: err.skipped },
        "Первый скан отменён: CoinGlass недоступен — повтор через 5 мин",
      );
      try {
        const outageCooldown = new Date(Date.now() - 10 * 60 * 1000);
        const claimed = await dbWriteBestEffort(
          "cgOutage-settingsUpdate-first",
          () =>
            db
              .update(settingsTable)
              .set({ lastCoinglassOutageAt: new Date() })
              .where(
                sql`id = (SELECT id FROM settings LIMIT 1) AND (last_coinglass_outage_at IS NULL OR last_coinglass_outage_at < ${outageCooldown})`,
              )
              .returning({ id: settingsTable.id }),
          { perAttemptTimeoutMs: 4000, attempts: 1 },
        );
        if (claimed && claimed.length > 0) {
          await broadcastRawAlert(
            `⚠️ CoinGlass API недоступен — скан отменён, повтор через 5 мин`,
          );
        }
      } catch {
        /* Telegram сбой не критичен */
      }
      firstScanDelay = 5 * 60 * 1000;
    } else {
      throw err;
    }
  }

  state.nextScanAt = new Date(Date.now() + firstScanDelay);
  scanTimer = setTimeout(scheduledScan, firstScanDelay);
  logger.info(
    {
      nextScanIn: `${Math.round(firstScanDelay / 1000)}s`,
      nextScanAt: state.nextScanAt,
    },
    "Next scan scheduled",
  );

  // ── SpotVol periodic timer: 3 быстрых прогрева (t=2/5/8 мин), затем каждые 60 мин ──
  // Прогрев нужен чтобы spotVolCycles≥3 (VBS_MIN_CYCLES) набралось до первого скана
  // (~10-14 мин). После 3 запусков большинство токенов переходят порог и VBS начинает работать.
  // prescanTracker уже загружен из DB к этому моменту.
  void (async () => {
    for (const delayMs of [2 * 60_000, 3 * 60_000, 3 * 60_000]) {
      await new Promise((r) => setTimeout(r, delayMs));
      if (!state.running) return;
      try {
        if (prescanTracker.size > 0) await runSpotVolBatch();
      } catch (err) {
        logger.warn({ err }, "SpotVol warmup: ошибка");
      }
    }
    while (state.running) {
      await new Promise((r) => setTimeout(r, 60 * 60 * 1000));
      try {
        if (prescanTracker.size > 0) await runSpotVolBatch();
      } catch (err) {
        logger.warn({ err }, "SpotVol periodic: ошибка");
      }
    }
  })();

  // ── SpotVol DB resync timer: каждые 5 мин, независимо от батча выше ──
  // Fix для split-brain между инстансами (autoscale — 1-N процессов одновременно,
  // каждый со своей копией prescanTracker в памяти). Подтягивает уже накопленные
  // другими инстансами spotVolAvg1h/spotVolCycles, не трогая своё более свежее состояние.
  void (async () => {
    await new Promise((r) => setTimeout(r, 60 * 1000));
    while (state.running) {
      try {
        if (prescanTracker.size > 0) await refreshSpotVolFromDb();
      } catch (err) {
        logger.warn({ err }, "SpotVol DB resync periodic: ошибка");
      }
      await new Promise((r) => setTimeout(r, 5 * 60 * 1000));
    }
  })();

  // ── lastScanAt heartbeat: записывает in-memory state в DB каждые 3 мин ───
  // Основная запись fire-and-forget внутри скана падает при Neon pool saturation.
  // Этот таймер работает независимо — status endpoint на Worker B видит свежее время.
  // Также пишет scannerScanStartedAt чтобы Worker B мог вывести isScanning кросс-процессно.
  if (lastScanHeartbeatTimer) clearInterval(lastScanHeartbeatTimer);
  lastScanHeartbeatTimer = setInterval(
    () => {
      if (!state.lastScanAt) return;
      if (state.isScanning) {
        // During scan: refresh both fields so Worker B sees isScanning=true (startedAt > lastScanAt)
        const startedAt = state.lastScanAt;
        void dbWriteBestEffort(
          "lastScanAt heartbeat (scanning)",
          () =>
            db.update(settingsTable).set({
              scannerLastScanAt: startedAt,
              scannerScanStartedAt: startedAt,
            }),
          { attempts: 1 },
        );
      } else {
        // Not scanning: only refresh lastScanAt (completion time); scannerScanStartedAt stays older)
        const completedAt = state.lastScanAt;
        void dbWriteBestEffort(
          "lastScanAt heartbeat (idle)",
          () =>
            db.update(settingsTable).set({ scannerLastScanAt: completedAt }),
          { attempts: 1 },
        );
      }
    },
    3 * 60 * 1000,
  );
}

export async function stopScanner(): Promise<void> {
  state.running = false;
  state.nextScanAt = null;
  if (scanTimer) {
    clearTimeout(scanTimer);
    scanTimer = null;
  }
  if (lastScanHeartbeatTimer) {
    clearInterval(lastScanHeartbeatTimer);
    lastScanHeartbeatTimer = null;
  }
  logger.info("Scanner stopped");
}

/** Синхронная проверка — идёт ли скан прямо сейчас. Используется для паузы фоновых джобов. */
export function isScannerActive(): boolean {
  return state.isScanning;
}

export async function getScannerState(): Promise<
  ScannerState & { totalSignals: number; signalsToday: number }
> {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const [totalResult, todayResult, settingsRow] = await Promise.all([
    db
      .select({ count: sql<number>`count(*)` })
      .from(signalsTable)
      .then((r) => r[0]),
    db
      .select({ count: sql<number>`count(*)` })
      .from(signalsTable)
      .where(gte(signalsTable.detectedAt, today))
      .then((r) => r[0]),
    db
      .select({
        scannerLastScanAt: settingsTable.scannerLastScanAt,
        scannerScanStartedAt: settingsTable.scannerScanStartedAt,
        scanIntervalMs: settingsTable.scanIntervalMs,
      })
      .from(settingsTable)
      .limit(1)
      .then((r) => r[0] ?? null),
  ]);

  // Cross-process fallback: if this worker has no scanner, read state from DB
  let effectiveLastScanAt = state.lastScanAt;
  let effectiveRunning = state.running;
  let effectiveIsScanning = state.isScanning;
  const intervalMs = settingsRow?.scanIntervalMs ?? state.scanIntervalMs;

  if (!effectiveLastScanAt && settingsRow?.scannerLastScanAt) {
    effectiveLastScanAt = settingsRow.scannerLastScanAt;
    // Infer running: scanner is alive if last scan was within 2.5× the interval
    const ageMs = Date.now() - settingsRow.scannerLastScanAt.getTime();
    effectiveRunning = ageMs < intervalMs * 2.5;
    // Infer isScanning: startedAt > lastScanAt means scan is in progress
    if (settingsRow.scannerScanStartedAt) {
      effectiveIsScanning =
        settingsRow.scannerScanStartedAt > settingsRow.scannerLastScanAt;
      // Also use startedAt as the elapsed-time anchor for the UI spinner
      if (effectiveIsScanning) {
        effectiveLastScanAt = settingsRow.scannerScanStartedAt;
      }
    }
  }

  return {
    ...state,
    lastScanAt: effectiveLastScanAt,
    running: effectiveRunning,
    isScanning: effectiveIsScanning,
    scanIntervalMs: intervalMs,
    totalSignals: Number(totalResult?.count ?? 0),
    signalsToday: Number(todayResult?.count ?? 0),
  };
}

/** Synchronous getter — safe to pass as a callback without circular import issues */
export function getLastScanAt(): Date | null {
  return state.lastScanAt;
}

/** Returns true while performScan() is running. Used by watchdog to avoid false alerts. */
export function getIsScanning(): boolean {
  return state.isScanning;
}

export function getLastCycleCandidates() {
  return lastCycleCandidates;
}
export function getLastCycleAt(): number | null {
  return lastCycleAt;
}

/** Возвращает последнюю известную цену символа (prescanTracker → oiWatchPriceCache). */
export function getCachedPrice(symbol: string): number | null {
  return (
    prescanTracker.get(symbol)?.lastPrice ??
    oiWatchPriceCache.get(symbol) ??
    null
  );
}

/** Возвращает true если символ есть в BingX фьючерсах (из последнего скан-цикла). */
export function isBingXFutures(symbol: string): boolean {
  return bingxFuturesSymbols.has(symbol);
}

export interface LiveMarketData {
  oi30m: number | null;
  oi1h: number | null;
  oi4h: number | null;
  oi24h: number | null;
  cvd30m: boolean | null;
  cvd1h: boolean | null;
  cvd4h: boolean | null;
  netBuyPct: number | null;
  price1h: number | null;
  spotTakerNetBuy: number | null;
  spotTakerDominance: string | null;
  // Дополнительные live-метрики из prescanTracker (обновляются каждый скан-цикл).
  // whaleIndex доступен для токенов в OI Watch + топ prescan.
  whaleIndex: number | null;
  // obRatio не хранится в prescanTracker — всегда null в live.
  // Появится через backfill job (refreshNullEntryMetrics) в течение 30 мин.
  obRatio: number | null;
}

/**
 * Returns last-known OI and CVD data from the prescan tracker for the given symbols.
 * Data is refreshed every scan cycle (~10 min). Returns only symbols that are currently
 * in the prescan tracker (i.e. were recently in the top-500 by activity score).
 */
export function getPrescanEntry(symbol: string): PrescanEntry | undefined {
  return prescanTracker.get(symbol);
}

/**
 * Сбросить cycleCount токена в prescanTracker до 0 после выстрела сигнала.
 * Без сброса максимальные гейты (cycleCount > 25) навсегда блокируют повторные выстрелы,
 * а колонка «Циклы» в UI показывает время с первого попадания в пул, а не с последнего сигнала.
 */
export function resetPrescanCycleCount(symbol: string): void {
  const pe = prescanTracker.get(symbol);
  if (pe) pe.cycleCount = 0;
}

export function getLiveMarketData(
  symbols: string[],
): Record<string, LiveMarketData> {
  const result: Record<string, LiveMarketData> = {};
  for (const sym of symbols) {
    const e = prescanTracker.get(sym);
    const lk = lastKnownLiveData.get(sym);
    // Приоритет: prescanTracker (свежие данные) → lastKnownLiveData (последние известные)
    if (e) {
      result[sym] = {
        oi30m: e.lastOi30m ?? null,
        oi1h: e.lastOi1h ?? null,
        oi4h: e.lastOi4h ?? null,
        oi24h: e.lastOi24h ?? null,
        cvd30m: e.lastCvd30m ?? null,
        cvd1h: e.lastCvd1h ?? null,
        cvd4h: e.lastCvd4h ?? null,
        netBuyPct: e.lastNetBuyPct ?? null,
        price1h: e.lastPrice1h ?? null,
        spotTakerNetBuy: e.lastSpotTakerNetBuy ?? null,
        spotTakerDominance: e.lastSpotTakerDominance ?? null,
        whaleIndex: e.lastWhaleIndex ?? null,
        obRatio: null,
      };
    } else if (lk) {
      // Символ выпал из prescan (монета остыла), но данные с последнего скана сохранены
      result[sym] = {
        oi30m: lk.oi30m,
        oi1h: lk.oi1h,
        oi4h: lk.oi4h,
        oi24h: lk.oi24h,
        cvd30m: lk.cvd30m,
        cvd1h: lk.cvd1h,
        cvd4h: lk.cvd4h,
        netBuyPct: lk.netBuyPct,
        price1h: lk.price1h,
        spotTakerNetBuy: lk.spotTakerNetBuy,
        spotTakerDominance: lk.spotTakerDominance,
        whaleIndex: lk.whaleIndex,
        obRatio: null,
      };
    }
  }
  return result;
}

/**
 * Обновляет spot taker данные в live-кэше для конкретного символа.
 * Вызывается из watcher.ts каждый раз когда уже был сделан getSpotTakerFlow запрос,
 * чтобы не делать лишний API-вызов и при этом держать данные свежими для dashboard.
 */
export function updateLiveSpotTaker(
  symbol: string,
  netBuyPct: number | null,
  dominance: "buy" | "sell" | "neutral" | null,
): void {
  const pe = prescanTracker.get(symbol);
  if (pe) {
    pe.lastSpotTakerNetBuy = netBuyPct;
    pe.lastSpotTakerDominance = dominance;
    return;
  }
  const lk = lastKnownLiveData.get(symbol);
  if (lk) {
    lk.spotTakerNetBuy = netBuyPct;
    lk.spotTakerDominance = dominance;
    lk.updatedAt = Date.now();
  } else {
    lastKnownLiveData.set(symbol, {
      oi30m: null,
      oi1h: null,
      oi4h: null,
      oi24h: null,
      cvd30m: null,
      cvd1h: null,
      cvd4h: null,
      netBuyPct: null,
      price1h: null,
      spotTakerNetBuy: netBuyPct,
      spotTakerDominance: dominance,
      whaleIndex: prescanTracker.get(symbol)?.lastWhaleIndex ?? null,
      updatedAt: Date.now(),
    });
  }
}

/**
 * Inject OI/CVD data for a symbol into lastKnownLiveData.
 * Called from background fire cycles (liq_cascade, whale_alert, ob_patterns)
 * so that open positions table shows live-equivalent data even for tokens
 * that are not part of the main prescan batch.
 * Only overwrites fields that are provided (non-undefined); preserves existing values otherwise.
 */
export function injectLiveMarketData(
  symbol: string,
  data: Partial<LiveMarketData>,
): void {
  const ex = lastKnownLiveData.get(symbol);
  lastKnownLiveData.set(symbol, {
    oi30m: data.oi30m !== undefined ? data.oi30m : (ex?.oi30m ?? null),
    oi1h: data.oi1h !== undefined ? data.oi1h : (ex?.oi1h ?? null),
    oi4h: data.oi4h !== undefined ? data.oi4h : (ex?.oi4h ?? null),
    oi24h: data.oi24h !== undefined ? data.oi24h : (ex?.oi24h ?? null),
    cvd30m: data.cvd30m !== undefined ? data.cvd30m : (ex?.cvd30m ?? null),
    cvd1h: data.cvd1h !== undefined ? data.cvd1h : (ex?.cvd1h ?? null),
    cvd4h: data.cvd4h !== undefined ? data.cvd4h : (ex?.cvd4h ?? null),
    netBuyPct:
      data.netBuyPct !== undefined ? data.netBuyPct : (ex?.netBuyPct ?? null),
    price1h: data.price1h !== undefined ? data.price1h : (ex?.price1h ?? null),
    whaleIndex:
      data.whaleIndex !== undefined
        ? data.whaleIndex
        : (ex?.whaleIndex ?? null),
    spotTakerNetBuy:
      data.spotTakerNetBuy !== undefined
        ? data.spotTakerNetBuy
        : (ex?.spotTakerNetBuy ?? null),
    spotTakerDominance:
      data.spotTakerDominance !== undefined
        ? data.spotTakerDominance
        : (ex?.spotTakerDominance ?? null),
    updatedAt: Date.now(),
  });
}

/** Returns current scanner candidates: prescan hot list + OI watch queue */
export async function getScannerCandidates(): Promise<{
  prescan: Array<{
    symbol: string;
    cycleCount: number;
    bestRank: number;
    lastPrice24h: number;
    lastPrice: number;
    lastScore: number;
    firstSeenAt: number;
    layers: string[];
    lastCvdOk?: boolean | null;
    lastNetBuyPct?: number | null;
    lastOi30m?: number | null;
    lastOi1h?: number | null;
    lastOi4h?: number | null;
    lastOi24h?: number | null;
    lastPrice1h?: number | null;
    priceMovePct?: number | null;
    lastCvd30m?: boolean | null;
    lastCvd1h?: boolean | null;
    lastCvd4h?: boolean | null;
    cgTimedOut?: boolean | null;
    firstPrice?: number | null;
    lastVolMult?: number | null;
    lastSkipReason?: string | null;
    spotVol24h?: number | null;
    spotTakerNetBuy?: number | null;
    spotTakerDominance?: string | null;
    spotTakerExchange?: string | null;
    mcapUsd?: number | null;
    lastAvgVol?: number | null;
    futVolUsd24h?: number | null;
    spotVolUsd24h?: number | null;
    futSpotRatio?: number | null;
    futVolPctMcap?: number | null;
    spotVolPctMcap?: number | null;
    whaleIndex?: number | null;
  }>;
  oiWatch: Array<{
    id: number;
    symbol: string;
    status: string;
    triggerTf: string;
    oiChange: number;
    priceAtEntry: number;
    currentPrice: number | null;
    volumeMultiplier: number;
    sentimentKey: string | null;
    addedAt: string;
    expiresAt: string;
    oi30m: number | null;
    oi1h: number | null;
    oi24h: number | null;
    price1hChange: number | null;
    price24hChange: number | null;
    currentVolMult: number | null;
    volStatusReason: string | null;
    hasActiveSignal: boolean;
    entryCgTurnover: number | null;
    spotVol24h: number | null;
    spotTakerNetBuy: number | null;
    spotTakerDominance: string | null;
    spotTakerExchange: string | null;
    mcapUsd: number | null;
    entryAvgVol: number | null;
    futureTakerNetBuy: number | null;
    cvd30m: boolean | null;
    cvd1h: boolean | null;
    cvd4h: boolean | null;
    oi4h: number | null;
    whaleIndex: number | null;
  }>;
  cycleCandidates: Array<{
    symbol: string;
    layers: string[];
    price24h: number;
    price: number;
    score: number;
    cycledAt: number;
    lastOi30m?: number | null;
    lastOi1h?: number | null;
    lastOi4h?: number | null;
    lastOi24h?: number | null;
    lastPrice1h?: number | null;
    lastNetBuyPct?: number | null;
    lastSpotTakerNetBuy?: number | null;
    lastSpotTakerDominance?: string | null;
    lastCvd1h?: boolean | null;
    lastSpotVol1h?: number | null;
    spotVolMult?: number | null;
    whaleIndex?: number | null;
  }>;
  cycleAt: number | null;
}> {
  // Dual-process resilience: prescanTracker is in-memory per-worker.
  // If this worker hasn't scanned yet, fall back to persisted DB rows.
  let prescan: Array<{
    symbol: string;
    cycleCount: number;
    bestRank: number;
    lastPrice24h: number;
    lastPrice: number;
    lastScore: number;
    firstSeenAt: number;
    layers: string[];
    lastCvdOk?: boolean | null;
    lastNetBuyPct?: number | null;
    lastOi4h?: number | null;
    lastOi24h?: number | null;
    lastPrice1h?: number | null;
    priceMovePct?: number | null;
    cgTimedOut?: boolean | null;
    firstPrice?: number | null;
  }>;

  // Fetch active tracked symbols to exclude from prescan display
  const activeTrackedRows = await db
    .select({ symbol: trackedSignalsTable.symbol })
    .from(trackedSignalsTable)
    .where(
      inArray(trackedSignalsTable.status, [
        "active",
        "accumulation",
        "in_run",
        "re_entry",
      ]),
    );
  const activeTrackedSet = new Set(activeTrackedRows.map((r) => r.symbol));

  // ── mcapUsd fallback ────────────────────────────────────────────────────────
  // spotPool (in-memory) обновляется каждые 30 мин, поэтому после рестарта до
  // первого обновления mcapUsd = null. market_cap_cache хранит данные 7 дней —
  // используем как fallback чтобы Спот/MCap% не пропадал после каждого деплоя.
  // Ключ в market_cap_cache — базовый символ без "-USDT" (например, "BTC").
  // Module-level кэш (_mcapDbCache) обновляется раз в 5 мин, не per-request.
  const _mcapNow = Date.now();
  if (_mcapNow - _mcapDbCacheAt > MCAP_DB_CACHE_TTL_MS) {
    const rows = await db
      .select({
        symbol: marketCapCacheTable.symbol,
        mcapUsd: marketCapCacheTable.mcapUsd,
      })
      .from(marketCapCacheTable)
      .where(
        gte(
          marketCapCacheTable.updatedAt,
          new Date(_mcapNow - 7 * 24 * 3600_000),
        ),
      )
      .catch(() => [] as { symbol: string; mcapUsd: number | null }[]);
    if (rows.length > 0) {
      _mcapDbCache = new Map(rows.map((r) => [r.symbol, r.mcapUsd]));
      _mcapDbCacheAt = _mcapNow;
    }
  }

  const getMcapUsd = (symbol: string): number | null => {
    const fromPool = getSpotPoolEntry(symbol)?.mcapUsd;
    if (fromPool != null) return fromPool;
    return _mcapDbCache.get(symbol.replace(/-USDT$/, "")) ?? null;
  };

  if (prescanTracker.size > 0) {
    prescan = Array.from(prescanTracker.entries())
      .filter(([symbol]) => !activeTrackedSet.has(symbol))
      .map(([symbol, e]) => ({
        symbol,
        cycleCount: e.cycleCount,
        bestRank: e.bestRank,
        lastPrice24h: e.lastPrice24h,
        lastPrice: e.lastPrice,
        lastScore: e.lastScore,
        firstSeenAt: e.firstSeenAt,
        lastCvdOk: e.lastCvdOk,
        lastNetBuyPct: e.lastNetBuyPct,
        lastOi30m: e.lastOi30m ?? null,
        lastOi1h: e.lastOi1h ?? null,
        lastOi4h: e.lastOi4h ?? null,
        lastOi24h: e.lastOi24h ?? null,
        lastPrice1h: e.lastPrice1h ?? null,
        priceMovePct:
          e.firstPrice > 0
            ? ((e.lastPrice - e.firstPrice) / e.firstPrice) * 100
            : null,
        lastCvd30m: e.lastCvd30m ?? null,
        lastCvd1h: e.lastCvd1h ?? null,
        lastCvd4h: e.lastCvd4h ?? null,
        cgTimedOut: e.lastCgTimedOut ?? null,
        firstPrice: e.firstPrice > 0 ? e.firstPrice : null,
        lastVolMult: e.lastVolMult ?? null,
        lastSkipReason: e.lastSkipReason ?? null,
        lastOiAt: e.lastOiAt ?? null,
        spotVol24h: getSpotPoolEntry(symbol)?.spotVol24h ?? null,
        spotTakerNetBuy: e.lastSpotTakerNetBuy ?? null,
        spotTakerDominance: e.lastSpotTakerDominance ?? null,
        spotTakerExchange: e.lastSpotTakerExchange ?? null,
        mcapUsd: getMcapUsd(symbol),
        lastAvgVol: e.lastAvgVol ?? null,
        spotVolMult:
          e.spotVolAvg1h && e.lastSpotVol1h
            ? e.lastSpotVol1h / e.spotVolAvg1h
            : null,
        prevSpotVolMult:
          e.spotVolAvg1h && e.prevSpotVol1h
            ? e.prevSpotVol1h / e.spotVolAvg1h
            : null,
        spotVolCycles: e.spotVolCycles ?? 0,
        lastSpotNetBuy1h: e.lastSpotNetBuy1h ?? null,
        lastSpotVol1h: e.lastSpotVol1h ?? null,
        lastSpotVol4h: e.lastSpotVol4h ?? null,
        cvd1h: e.lastCvd1h ?? null,
        cvd4h: e.lastCvd4h ?? null,
        layers: e.layers ?? [],
        futVolUsd24h: e.futVolUsd24h ?? null,
        spotVolUsd24h: e.spotVolUsd24h ?? null,
        futSpotRatio: e.futSpotRatio ?? null,
        futVolPctMcap: e.futVolPctMcap ?? null,
        spotVolPctMcap: e.spotVolPctMcap ?? null,
        whaleIndex: e.lastWhaleIndex ?? null,
      }))
      .sort((a, b) => b.lastScore - a.lastScore);
  } else {
    // Fallback: prescanTracker is empty (e.g. loadPrescanFromDb failed).
    // Read directly from DB — persisted CVD/taker fields are available here.
    const dbRows = await db
      .select()
      .from(prescanTrackerTable)
      .orderBy(sql`first_score DESC`)
      .limit(200);
    prescan = dbRows
      .filter((r) => !activeTrackedSet.has(r.symbol))
      .map((r) => {
        const lp = r.lastPrice ?? r.firstPrice;
        return {
          symbol: r.symbol,
          cycleCount: r.cycleCount,
          bestRank: r.bestRank,
          lastPrice24h: r.lastPrice24h ?? r.firstPrice24h,
          lastPrice: lp,
          lastScore: r.firstScore,
          firstSeenAt: r.firstSeenAt,
          lastCvdOk: null, // derived value, not stored in DB
          lastNetBuyPct: r.lastNetBuyPct ?? null,
          lastOi30m: r.lastOi30m ?? null,
          lastOi1h: r.lastOi1h ?? null,
          lastOi4h: r.lastOi4h ?? null,
          lastOi24h: r.lastOi24h ?? null,
          lastPrice1h: r.lastPrice1h ?? null,
          priceMovePct:
            r.firstPrice > 0 && lp > 0
              ? ((lp - r.firstPrice) / r.firstPrice) * 100
              : null,
          lastCvd30m: r.lastCvd30m ?? null,
          lastCvd1h: r.lastCvd1h ?? null,
          lastCvd4h: r.lastCvd4h ?? null,
          firstPrice: r.firstPrice > 0 ? r.firstPrice : null,
          lastVolMult: null,
          lastSkipReason: null,
          spotVol24h: getSpotPoolEntry(r.symbol)?.spotVol24h ?? null,
          spotTakerNetBuy: r.lastSpotTakerNetBuy ?? null,
          spotTakerDominance:
            (r.lastSpotTakerDominance as "buy" | "sell" | "neutral" | null) ??
            null,
          spotTakerExchange: null, // not persisted in DB
          mcapUsd: getMcapUsd(r.symbol),
          lastAvgVol: null,
          spotVolMult:
            r.spotVolAvg1h && r.lastSpotVol1h
              ? r.lastSpotVol1h / r.spotVolAvg1h
              : null,
          prevSpotVolMult:
            r.spotVolAvg1h && r.prevSpotVol1h
              ? r.prevSpotVol1h / r.spotVolAvg1h
              : null,
          spotVolCycles: r.spotVolCycles ?? 0,
          lastSpotNetBuy1h: r.lastSpotNetBuy1h ?? null,
          lastSpotVol1h: r.lastSpotVol1h ?? null,
          lastSpotVol4h: r.lastSpotVol4h ?? null,
          cvd1h: r.lastCvd1h ?? null,
          cvd4h: r.lastCvd4h ?? null,
          layers: r.layers ?? [],
          futVolUsd24h: r.futVolUsd24h ?? null,
          spotVolUsd24h: r.spotVolUsd24h ?? null,
          futSpotRatio: r.futSpotRatio ?? null,
          futVolPctMcap: r.futVolPctMcap ?? null,
          spotVolPctMcap: r.spotVolPctMcap ?? null,
          whaleIndex: r.lastWhaleIndex ?? null,
        };
      });
  }

  const watching = await db
    .select({
      id: oiWatchTable.id,
      symbol: oiWatchTable.symbol,
      status: oiWatchTable.status,
      triggerTf: oiWatchTable.triggerTf,
      oiChange: oiWatchTable.oiChange,
      priceAtEntry: oiWatchTable.priceAtEntry,
      volumeMultiplier: oiWatchTable.volumeMultiplier,
      sentimentKey: oiWatchTable.sentimentKey,
      addedAt: oiWatchTable.addedAt,
      expiresAt: oiWatchTable.expiresAt,
      oi30mChange: oiWatchTable.oi30mChange,
      oi1hChange: oiWatchTable.oi1hChange,
      oi24hChange: oiWatchTable.oi24hChange,
      price1hChange: oiWatchTable.price1hChange,
      price24hChange: oiWatchTable.price24hChange,
      currentVolMult: oiWatchTable.currentVolMult,
      volStatusReason: oiWatchTable.volStatusReason,
      entryCgTurnover: oiWatchTable.entryCgTurnover,
      signalPayload: oiWatchTable.signalPayload,
    })
    .from(oiWatchTable)
    .where(
      and(
        inArray(oiWatchTable.status, ["watching", "confirming"]),
        gt(oiWatchTable.expiresAt, new Date()),
      ),
    )
    .orderBy(oiWatchTable.addedAt);

  const oiWatch = watching.map((r) => ({
    id: r.id,
    symbol: r.symbol,
    status: r.status,
    triggerTf: r.triggerTf,
    oiChange: r.oiChange,
    priceAtEntry: r.priceAtEntry,
    currentPrice:
      prescanTracker.get(r.symbol)?.lastPrice ??
      oiWatchPriceCache.get(r.symbol) ??
      null,
    volumeMultiplier: r.volumeMultiplier,
    sentimentKey: r.sentimentKey ?? null,
    addedAt: r.addedAt.toISOString(),
    expiresAt: r.expiresAt.toISOString(),
    oi30m: r.oi30mChange ?? null,
    oi1h: r.oi1hChange ?? null,
    oi24h: r.oi24hChange ?? null,
    price1hChange: r.price1hChange ?? null,
    price24hChange: r.price24hChange ?? null,
    currentVolMult: r.currentVolMult ?? null,
    volStatusReason: r.volStatusReason ?? null,
    hasActiveSignal: activeTrackedSet.has(r.symbol),
    entryCgTurnover: r.entryCgTurnover ?? null,
    spotVol24h: getSpotPoolEntry(r.symbol)?.spotVol24h ?? null,
    spotTakerNetBuy: prescanTracker.get(r.symbol)?.lastSpotTakerNetBuy ?? null,
    spotTakerDominance:
      prescanTracker.get(r.symbol)?.lastSpotTakerDominance ?? null,
    spotTakerExchange:
      prescanTracker.get(r.symbol)?.lastSpotTakerExchange ?? null,
    mcapUsd: getMcapUsd(r.symbol),
    entryAvgVol: prescanTracker.get(r.symbol)?.lastAvgVol ?? null,
    futureTakerNetBuy: prescanTracker.get(r.symbol)?.lastNetBuyPct ?? null,
    cvd30m: prescanTracker.get(r.symbol)?.lastCvd30m ?? null,
    cvd1h: prescanTracker.get(r.symbol)?.lastCvd1h ?? null,
    cvd4h: prescanTracker.get(r.symbol)?.lastCvd4h ?? null,
    oi4h: prescanTracker.get(r.symbol)?.lastOi4h ?? null,
    upcomingUnlock: (() => {
      // signalPayload is stored as { alphaResult: AlphaResult, signalRow: ... }
      const payload = r.signalPayload as {
        alphaResult?: {
          upcomingUnlock?: { daysUntil: number; pctSupply: number } | null;
        };
      } | null;
      return payload?.alphaResult?.upcomingUnlock ?? null;
    })(),
    whaleIndex: prescanTracker.get(r.symbol)?.lastWhaleIndex ?? null,
  }));
  return {
    prescan,
    oiWatch,
    cycleCandidates: lastCycleCandidates.map((e) => {
      const pe = prescanTracker.get(e.symbol);
      const spotVolMult =
        pe?.lastSpotVol1h != null &&
        pe?.spotVolAvg1h != null &&
        pe.spotVolAvg1h > 0
          ? pe.lastSpotVol1h / pe.spotVolAvg1h
          : null;
      return {
        ...e,
        lastOi30m: pe?.lastOi30m ?? null,
        lastOi1h: pe?.lastOi1h ?? null,
        lastOi4h: pe?.lastOi4h ?? null,
        lastOi24h: pe?.lastOi24h ?? null,
        lastPrice1h: pe?.lastPrice1h ?? null,
        lastNetBuyPct: pe?.lastNetBuyPct ?? null,
        lastSpotTakerNetBuy: pe?.lastSpotTakerNetBuy ?? null,
        lastSpotTakerDominance: pe?.lastSpotTakerDominance ?? null,
        lastCvd1h: pe?.lastCvd1h ?? null,
        lastSpotVol1h: pe?.lastSpotVol1h ?? null,
        spotVolMult,
        whaleIndex: pe?.lastWhaleIndex ?? null,
      };
    }),
    cycleAt: lastCycleAt,
  };
}

/**
 * Пересчитывает price24h для всех токенов в prescanTracker через 1h klines BingX.
 * BingX ticker priceChangePercent считается от открытия СУТОЧНОЙ свечи (UTC midnight),
 * а не от реального момента 24h назад — поэтому токены, выросшие вчера, показывают ~0%.
 * Этот job запускается каждые 20 мин и исправляет lastPrice24h на скользящее значение.
 */
export async function runPrice24hRefreshCycle(): Promise<void> {
  const symbols = Array.from(prescanTracker.keys());
  if (symbols.length === 0) return;

  let updated = 0;
  let failed = 0;

  const CONCURRENCY = 8;
  for (let i = 0; i < symbols.length; i += CONCURRENCY) {
    const batch = symbols.slice(i, i + CONCURRENCY);
    await Promise.allSettled(
      batch.map(async (symbol) => {
        try {
          const klines = await getKlines(symbol, "1h", 25);
          if (klines.length < 2) return;

          const price24hAgo = parseFloat(klines[0].open);
          const currentPrice = parseFloat(klines[klines.length - 1].close);

          if (!price24hAgo || !currentPrice || price24hAgo <= 0) return;

          const trueP24h = ((currentPrice - price24hAgo) / price24hAgo) * 100;

          const entry = prescanTracker.get(symbol);
          if (entry) {
            entry.lastPrice24h = trueP24h;
            updated++;
          }
        } catch {
          failed++;
        }
      }),
    );
  }

  logger.info(
    { updated, failed, total: symbols.length },
    "Price24h refresh complete (klines rolling 24h)",
  );
}
