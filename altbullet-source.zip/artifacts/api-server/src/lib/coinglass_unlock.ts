/**
 * CoinGlass — Token Unlock Calendar.
 *
 * Fetches upcoming token unlock events from CoinGlass /api/coin-unlock-list.
 * Used to block or warn signals when a large unlock is imminent.
 *
 * Block logic (called from performScan):
 *   daysUntil ≤ 3 AND pctSupply ≥ 1% → block signal (log to missed_signals_log)
 *   daysUntil 4–7 AND pctSupply ≥ 1% → warn in Telegram alert
 *   Watchlist exempt from block (Layer 0) but still gets warning.
 *
 * Cache: 4h (unlock dates change infrequently).
 * Fail-open: returns empty Map on any API error or missing key.
 */

import { logger } from "./logger.js";
import { getNextCgKey } from "./coinglass_keys.js";

export interface UnlockInfo {
  daysUntil: number; // calendar days until unlock (0 = today / imminent)
  pctSupply: number; // % of circulating supply being unlocked
  unlockTime: number; // Unix timestamp (ms)
}

const CACHE_TTL_MS = 4 * 3600_000; // 4h

let _cache: Map<string, UnlockInfo> | null = null;
let _cacheAt = 0;

// CoinGlass unlock row — field names may vary between API versions
interface CgUnlockRow {
  token?: string;
  symbol?: string;
  tokenSymbol?: string;
  unlockTime?: number;
  unlockTimestamp?: number;
  unlockDate?: string;
  percentage?: number;
  unlockPercent?: number;
  ratio?: number;
  supplyRatio?: number;
  amount?: number;
  unlockAmount?: number;
  type?: string;
  name?: string;
}

function parseRow(
  row: CgUnlockRow,
  now: number,
): { baseSymbol: string; info: UnlockInfo } | null {
  const rawSym = row.token ?? row.symbol ?? row.tokenSymbol;
  if (!rawSym || typeof rawSym !== "string") return null;
  // CoinGlass unlock API returns base symbols (e.g. "SUI", "OP", "ARB").
  // BingX symbols are "SUI-USDT" — we strip the suffix to get the base.
  // This is identical to toCgSymbol() in coinglass_spot_cvd.ts.
  // No separate alias table exists in the codebase; if a non-standard
  // CG ticker is discovered, add the token to watchlist (Layer 0 exempt) as a workaround.
  const baseSymbol = rawSym
    .toUpperCase()
    .trim()
    .replace(/USDT$/, "")
    .replace(/-$/, "");
  if (!baseSymbol) return null;

  // Parse unlock timestamp (CoinGlass may return seconds or ms)
  let tsMs: number | null = null;
  if (row.unlockTime != null && typeof row.unlockTime === "number") {
    tsMs = row.unlockTime > 1e12 ? row.unlockTime : row.unlockTime * 1000;
  } else if (
    row.unlockTimestamp != null &&
    typeof row.unlockTimestamp === "number"
  ) {
    tsMs =
      row.unlockTimestamp > 1e12
        ? row.unlockTimestamp
        : row.unlockTimestamp * 1000;
  } else if (row.unlockDate && typeof row.unlockDate === "string") {
    const d = Date.parse(row.unlockDate);
    if (!isNaN(d)) tsMs = d;
  }
  if (tsMs == null) return null;

  // Skip already-passed events (allow up to 1h grace)
  if (tsMs < now - 3_600_000) return null;

  // Parse percentage of supply
  const pct =
    row.percentage ?? row.unlockPercent ?? row.ratio ?? row.supplyRatio;
  if (pct == null || typeof pct !== "number" || pct <= 0) return null;

  const daysUntil = Math.max(0, Math.floor((tsMs - now) / 86_400_000));

  return {
    baseSymbol,
    info: { daysUntil, pctSupply: pct, unlockTime: tsMs },
  };
}

/**
 * Returns a Map<baseSymbol, UnlockInfo> for all tokens with upcoming unlocks.
 * baseSymbol matches BingX symbol without the "-USDT" suffix (e.g. "SUI", "OP").
 * Cached for 4h. Returns empty Map (or stale cache) on error (fail-open).
 */
export async function getUpcomingUnlocks(): Promise<Map<string, UnlockInfo>> {
  const now = Date.now();
  if (_cache !== null && now - _cacheAt < CACHE_TTL_MS) return _cache;

  // Strict fail-open: if the cache is expired and the fetch fails for any reason,
  // return an EMPTY Map so no tokens are blocked. Stale cache is only safe to return
  // while it is still within TTL (handled by the early-return above).
  const emptyOnError = new Map<string, UnlockInfo>();

  const key = getNextCgKey();
  if (!key) {
    logger.warn(
      "CoinGlass coin-unlock-list: no API key available — fail-open (empty map)",
    );
    return emptyOnError;
  }

  try {
    const url = "https://open-api-v4.coinglass.com/api/coin-unlock-list";
    const resp = await fetch(url, {
      headers: { "CG-API-KEY": key },
      signal: AbortSignal.timeout(8_000),
    });

    if (!resp.ok) {
      logger.warn(
        { status: resp.status },
        "CoinGlass coin-unlock-list: non-2xx — fail-open (empty map)",
      );
      return emptyOnError;
    }

    const json = (await resp.json()) as {
      code?: string;
      msg?: string;
      data?: CgUnlockRow[] | { list?: CgUnlockRow[] };
    };

    // Handle both flat array and nested {list: [...]} structures
    let rows: CgUnlockRow[] | undefined;
    if (Array.isArray(json.data)) {
      rows = json.data;
    } else if (
      json.data &&
      typeof json.data === "object" &&
      Array.isArray((json.data as { list?: CgUnlockRow[] }).list)
    ) {
      rows = (json.data as { list: CgUnlockRow[] }).list;
    }

    if (!rows) {
      logger.warn(
        { code: json.code },
        "CoinGlass coin-unlock-list: unexpected structure — fail-open (empty map)",
      );
      return emptyOnError;
    }

    const result = new Map<string, UnlockInfo>();
    for (const row of rows) {
      const parsed = parseRow(row, now);
      if (!parsed) continue;
      // Keep the soonest upcoming unlock if multiple events exist for one token
      const existing = result.get(parsed.baseSymbol);
      if (!existing || parsed.info.daysUntil < existing.daysUntil) {
        result.set(parsed.baseSymbol, parsed.info);
      }
    }

    _cache = result;
    _cacheAt = now;
    logger.info(
      { total: rows.length, withUnlock: result.size },
      "CoinGlass coin-unlock-list: fetched OK",
    );
    return result;
  } catch (err) {
    logger.warn(
      { err },
      "CoinGlass coin-unlock-list: fetch error — fail-open (empty map)",
    );
    return emptyOnError;
  }
}

/** Force-clears the cache (for admin refresh). */
export function clearUnlockCache(): void {
  _cache = null;
  _cacheAt = 0;
}
