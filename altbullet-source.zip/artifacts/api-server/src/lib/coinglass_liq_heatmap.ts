/**
 * CoinGlass — Liquidation Heatmap (Professional plan).
 *
 * Источник: /api/futures/liquidation/aggregated-heatmap/model2?symbol=BASE&range=3d
 * Fallback: /api/futures/liquidation/heatmap/model2?symbol=BASEUSDT&exchange=Binance
 *
 * Назначение: умные стопы и тейки для сигналов.
 *  - Стоп: ближайший значимый кластер лонг-ликвидаций НИЖЕ цены входа минус 2%
 *    (цена часто прокалывает кластер и разворачивается — стоп не должен стоять внутри).
 *  - Тейки: значимые кластеры шорт-ликвидаций ВЫШЕ цены входа (до 3 уровней).
 *
 * Ответ API: { y_axis: number[], liquidation_leverage_data: [x, y, value][], price_candlesticks }
 *  - y_axis — ценовые бины; x — временной индекс; текущий срез = столбец с max(x).
 *
 * Конвенции модулей CoinGlass: fail-open (null при любой ошибке), TTL-кэш,
 * negative caching (токен не покрыт), circuit breaker, 429 → logCg429.
 *
 * Защита от коллизий тикеров: если цена входа не попадает в диапазон y_axis
 * (±20% допуска) — данные принадлежат другому инструменту → null.
 */

import { logger } from "./logger.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";

export interface LiqTakeTarget {
  price: number;
  pctFromEntry: number; // +% от входа
  liqUsd: number; // сумма ликвидаций в кластере
}

export interface LiqLevels {
  stopPrice: number; // кластер * 0.98
  stopPct: number; // глубина стопа в % от входа (положительное число)
  clusterPrice: number; // цена самого кластера
  clusterLiqUsd: number;
  takes: LiqTakeTarget[]; // до 3 целей выше входа (ближняя первой)
}

/** BingX "BTC-USDT" → базовый символ CoinGlass "BTC". */
function toBase(bingxSymbol: string): string {
  return bingxSymbol.replace(/-USDT$/, "").replace(/USDT$/, "");
}

// ── Кэш распарсенных уровней (per-symbol) ─────────────────────────────────────
interface ParsedLevels {
  prices: number[];
  values: number[];
}
const LEVELS_TTL = 10 * 60 * 1000; // 10 мин — heatmap обновляется медленно
const NEGATIVE_TTL = 30 * 60 * 1000; // 30 мин — токен не покрыт CoinGlass
const _cache = new Map<string, { levels: ParsedLevels | null; ts: number }>();

// Circuit breaker: 3 подряд неудачи → пауза 10 мин
let _consecFails = 0;
let _breakerUntil = 0;

function _fail(): void {
  _consecFails++;
  if (_consecFails >= 3) {
    _breakerUntil = Date.now() + 10 * 60 * 1000;
    _consecFails = 0;
    logger.warn("liqHeatmap: 3 подряд неудачи — circuit breaker на 10 мин");
  }
}

interface HeatmapResponse {
  code: string;
  data?: {
    y_axis?: number[];
    liquidation_leverage_data?: [number, number, number][];
  };
}

async function fetchHeatmapRaw(
  url: string,
  apiKey: string,
): Promise<ParsedLevels | null> {
  const res = await fetch(url, {
    headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
    signal: AbortSignal.timeout(8000),
  });

  if (res.status === 429) {
    logCg429(apiKey, { endpoint: "liquidation/heatmap" });
    return null;
  }
  if (!res.ok) return null;

  const json = (await res.json()) as HeatmapResponse;
  const yAxis = json.data?.y_axis;
  const cells = json.data?.liquidation_leverage_data;
  if (
    json.code !== "0" ||
    !Array.isArray(yAxis) ||
    yAxis.length === 0 ||
    !Array.isArray(cells) ||
    cells.length === 0
  ) {
    return null;
  }

  // Текущий срез — столбец с максимальным временным индексом x
  let maxX = -1;
  for (const c of cells) if (c[0] > maxX) maxX = c[0];
  const byBin = new Map<number, number>();
  for (const c of cells) {
    if (c[0] !== maxX) continue;
    const y = c[1];
    const v = Number(c[2]) || 0;
    if (v > 0) byBin.set(y, (byBin.get(y) ?? 0) + v);
  }
  if (byBin.size === 0) return null;

  const prices: number[] = [];
  const values: number[] = [];
  for (const [y, v] of [...byBin.entries()].sort((a, b) => a[0] - b[0])) {
    const p = yAxis[y];
    if (p === undefined || p <= 0) continue;
    prices.push(p);
    values.push(v);
  }
  return prices.length > 0 ? { prices, values } : null;
}

/** Загружает и парсит heatmap-уровни символа (кэш 10 мин, negative 30 мин). */
async function getLevels(bingxSymbol: string): Promise<ParsedLevels | null> {
  const base = toBase(bingxSymbol).toUpperCase();
  const cached = _cache.get(base);
  if (cached) {
    const ttl = cached.levels ? LEVELS_TTL : NEGATIVE_TTL;
    if (Date.now() - cached.ts < ttl) return cached.levels;
  }

  if (Date.now() < _breakerUntil) return null;

  const apiKey = getNextCgKey();
  if (!apiKey) return null;

  try {
    // 1. Агрегированный heatmap (все биржи)
    let levels = await fetchHeatmapRaw(
      `https://open-api-v4.coinglass.com/api/futures/liquidation/aggregated-heatmap/model2?symbol=${base}&range=3d`,
      apiKey,
    );

    // 2. Fallback — pair heatmap Binance
    if (!levels) {
      levels = await fetchHeatmapRaw(
        `https://open-api-v4.coinglass.com/api/futures/liquidation/heatmap/model2?symbol=${base}USDT&exchange=Binance&range=3d`,
        apiKey,
      ).catch(() => null);
    }

    _consecFails = 0;
    _cache.set(base, { levels, ts: Date.now() });
    if (!levels) {
      logger.debug(
        { symbol: base },
        "liqHeatmap: нет данных heatmap (negative cache 30 мин)",
      );
    }
    return levels;
  } catch (err) {
    _fail();
    logger.debug(
      { err: String(err), symbol: base },
      "liqHeatmap: fetch error — fail-open",
    );
    return null;
  }
}

// ── Извлечение кластеров и расчёт уровней ─────────────────────────────────────

/** Мин. дистанция кластера от входа: бины вплотную к цене — шум, не уровень. */
const MIN_CLUSTER_DIST_PCT = 1.0;
/** Значимость: бин ≥ 1.5× среднего значения по всем бинам. */
const SIGNIFICANCE_MULT = 1.5;
/** Отступ стопа под кластер. */
const STOP_OFFSET_PCT = 2.0;
/** Максимум целей. */
const MAX_TAKES = 3;

interface Cluster {
  price: number;
  liqUsd: number;
}

/** Склеивает соседние значимые бины в кластеры (цена = бин с max значением). */
function extractClusters(levels: ParsedLevels): Cluster[] {
  const { prices, values } = levels;
  const total = values.reduce((s, v) => s + v, 0);
  if (total <= 0) return [];
  const avg = total / values.length;
  const threshold = avg * SIGNIFICANCE_MULT;

  const clusters: Cluster[] = [];
  let cur: { bestPrice: number; bestVal: number; sum: number } | null = null;
  for (let i = 0; i < prices.length; i++) {
    if (values[i] >= threshold) {
      if (!cur) cur = { bestPrice: prices[i], bestVal: values[i], sum: 0 };
      cur.sum += values[i];
      if (values[i] > cur.bestVal) {
        cur.bestVal = values[i];
        cur.bestPrice = prices[i];
      }
    } else if (cur) {
      clusters.push({ price: cur.bestPrice, liqUsd: cur.sum });
      cur = null;
    }
  }
  if (cur) clusters.push({ price: cur.bestPrice, liqUsd: cur.sum });
  return clusters;
}

/**
 * Индивидуальные стоп/тейки по liquidation heatmap для точки входа.
 * Fail-open: null → вызывающий код использует стандартный стоп -10%.
 */
export async function getLiqLevels(
  bingxSymbol: string,
  entryPrice: number,
): Promise<LiqLevels | null> {
  if (!(entryPrice > 0)) return null;
  const levels = await getLevels(bingxSymbol);
  if (!levels) return null;

  // Sanity check коллизий тикеров: вход должен попадать в диапазон heatmap ±20%
  const minP = levels.prices[0];
  const maxP = levels.prices[levels.prices.length - 1];
  if (entryPrice < minP * 0.8 || entryPrice > maxP * 1.2) {
    logger.warn(
      { symbol: bingxSymbol, entryPrice, heatmapRange: [minP, maxP] },
      "liqHeatmap: цена входа вне диапазона heatmap — подозрение на коллизию тикера, данные отброшены",
    );
    return null;
  }

  const clusters = extractClusters(levels);
  if (clusters.length === 0) return null;

  // Стоп: ближайший значимый кластер ниже входа (минимум 1% ниже) минус 2%
  const below = clusters.filter(
    (c) => c.price <= entryPrice * (1 - MIN_CLUSTER_DIST_PCT / 100),
  );
  const stopCluster = below.length > 0 ? below[below.length - 1] : null;
  if (!stopCluster) return null; // ниже входа кластеров нет → fallback -10%

  const stopPrice = stopCluster.price * (1 - STOP_OFFSET_PCT / 100);
  const stopPct = ((entryPrice - stopPrice) / entryPrice) * 100;
  if (!(stopPct > 0)) return null;

  // Тейки: значимые кластеры выше входа (минимум 1% выше), ближние первыми
  const takes: LiqTakeTarget[] = clusters
    .filter((c) => c.price >= entryPrice * (1 + MIN_CLUSTER_DIST_PCT / 100))
    .slice(0, MAX_TAKES)
    .map((c) => ({
      price: c.price,
      pctFromEntry: ((c.price - entryPrice) / entryPrice) * 100,
      liqUsd: c.liqUsd,
    }));

  return {
    stopPrice,
    stopPct,
    clusterPrice: stopCluster.price,
    clusterLiqUsd: stopCluster.liqUsd,
    takes,
  };
}

// ── Liq Map Clusters — /api/futures/liquidation/map (liq_magnet_squeeze) ─────
// Отдельный кэш (15 мин) — независимо от heatmap/model2 (10 мин).
// Endpoint: /api/futures/liquidation/map?symbol=BASE&exchange=Binance
// Парсим тем же extractClusters что и для heatmap; выбираем шорт-кластеры (+4%..+12%).
// Fail-open: null при ошибке. Пустой массив — данные есть, кластеров в диапазоне нет.

export interface ShortLiqCluster {
  price: number;
  liqUsd: number;
  /** % выше текущей цены (положительный) */
  pctAbove: number;
}

const _liqMapCache = new Map<
  string,
  { clusters: ShortLiqCluster[] | null; ts: number }
>();
const LIQ_MAP_TTL = 15 * 60 * 1000; // 15 мин — отдельный TTL от heatmap
const LIQ_MAP_NEG_TTL = 30 * 60 * 1000;

/**
 * Возвращает кластеры шорт-ликвидаций в диапазоне +4%..+12% над текущей ценой.
 * Использует /api/futures/liquidation/map (15 мин кэш), отдельный от aggregated-heatmap/model2.
 * Fail-open: null при ошибке. Пустой массив — кластеров в диапазоне нет.
 */
export async function getLiqMapClusters(
  bingxSymbol: string,
  currentPrice: number,
): Promise<ShortLiqCluster[] | null> {
  if (!(currentPrice > 0)) return null;

  const base = toBase(bingxSymbol).toUpperCase();
  const cached = _liqMapCache.get(base);
  if (cached) {
    const ttl = cached.clusters !== null ? LIQ_MAP_TTL : LIQ_MAP_NEG_TTL;
    if (Date.now() - cached.ts < ttl) return cached.clusters;
  }

  const apiKey = getNextCgKey();
  if (!apiKey) return null;

  const LOW = 0.04; // +4% от текущей цены
  const HIGH = 0.12; // +12% от текущей цены

  try {
    const url = `https://open-api-v4.coinglass.com/api/futures/liquidation/map?symbol=${base}&exchange=Binance`;
    const res = await fetch(url, {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(6000),
    });

    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "liquidation/map" });
      return null;
    }
    if (!res.ok) {
      _liqMapCache.set(base, { clusters: null, ts: Date.now() });
      return null;
    }

    const json = (await res.json()) as HeatmapResponse;
    if (json.code !== "0") {
      _liqMapCache.set(base, { clusters: null, ts: Date.now() });
      return null;
    }

    // Парсим так же как heatmap/model2 (CoinGlass реализует map в том же формате)
    const yAxis = json.data?.y_axis;
    const cells = json.data?.liquidation_leverage_data;
    if (
      !Array.isArray(yAxis) ||
      yAxis.length === 0 ||
      !Array.isArray(cells) ||
      cells.length === 0
    ) {
      _liqMapCache.set(base, { clusters: [], ts: Date.now() });
      return [];
    }

    // Санити-проверка: коллизия тикеров
    const minP = Math.min(...yAxis.filter((p) => p > 0));
    const maxP = Math.max(...yAxis.filter((p) => p > 0));
    if (currentPrice < minP * 0.8 || currentPrice > maxP * 1.2) {
      _liqMapCache.set(base, { clusters: null, ts: Date.now() });
      return null;
    }

    // Берём текущий временной срез (max x)
    let maxX = -1;
    for (const c of cells) if (c[0] > maxX) maxX = c[0];
    const byBin = new Map<number, number>();
    for (const c of cells) {
      if (c[0] !== maxX) continue;
      const y = c[1];
      const v = Number(c[2]) || 0;
      if (v > 0) byBin.set(y, (byBin.get(y) ?? 0) + v);
    }

    const parsedLevels: ParsedLevels = {
      prices: [],
      values: [],
    };
    for (const [y, v] of [...byBin.entries()].sort((a, b) => a[0] - b[0])) {
      const p = yAxis[y];
      if (p === undefined || p <= 0) continue;
      parsedLevels.prices.push(p);
      parsedLevels.values.push(v);
    }

    const allClusters = extractClusters(parsedLevels);
    const shortClusters = allClusters
      .filter(
        (c) =>
          c.price >= currentPrice * (1 + LOW) &&
          c.price <= currentPrice * (1 + HIGH),
      )
      .map((c) => ({
        price: c.price,
        liqUsd: c.liqUsd,
        pctAbove: ((c.price - currentPrice) / currentPrice) * 100,
      }))
      .sort((a, b) => a.pctAbove - b.pctAbove);

    _liqMapCache.set(base, { clusters: shortClusters, ts: Date.now() });
    return shortClusters;
  } catch (err) {
    logger.debug(
      { err: String(err), symbol: base },
      "getLiqMapClusters: fetch error — fail-open",
    );
    return null;
  }
}

// ── Liquidation Max Pain ───────────────────────────────────────────────────────
// Batch endpoint: /api/futures/liquidation/max-pain?range=24h
// Один запрос = данные по всем крупным монетам (BTC, ETH, SOL…).
// Семантика (подтверждена по структуре ответа):
//  - longMaxPainPrice  = цена, куда рынок может сдвинуться чтобы задеть максимум лонг-позиций
//  - shortMaxPainPrice = цена, куда рынок может сдвинуться чтобы задеть максимум шорт-позиций
// Fail-open: null если монета не покрыта (большинство альткоинов BingX).

export interface MaxPainData {
  longMaxPainPrice: number; // max pain price for long positions
  shortMaxPainPrice: number; // max pain price for short positions
  longMaxPainLevel: number; // USD объём лонг-ликвидаций на этой цене
  shortMaxPainLevel: number; // USD объём шорт-ликвидаций на этой цене
}

const _maxPainBatch = new Map<string, MaxPainData>();
let _maxPainFetchedAt = 0;
const MAX_PAIN_TTL = 5 * 60 * 1000; // 5 мин — real-time API, но нам не нужно чаще

interface _MaxPainRaw {
  symbol: string;
  price: number;
  long_max_pain_liq_level: number;
  long_max_pain_liq_price: number;
  short_max_pain_liq_level: number;
  short_max_pain_liq_price: number;
}

async function _fetchMaxPainBatch(): Promise<void> {
  const apiKey = getNextCgKey();
  if (!apiKey) return;
  try {
    const res = await fetch(
      "https://open-api-v4.coinglass.com/api/futures/liquidation/max-pain?range=24h",
      {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(8000),
      },
    );
    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "liquidation/max-pain" });
      return;
    }
    if (!res.ok) return;
    const json = (await res.json()) as { code: string; data?: _MaxPainRaw[] };
    if (json.code !== "0" || !Array.isArray(json.data)) return;
    _maxPainBatch.clear();
    for (const row of json.data) {
      if (
        !row.symbol ||
        !(row.long_max_pain_liq_price > 0) ||
        !(row.short_max_pain_liq_price > 0)
      )
        continue;
      _maxPainBatch.set(row.symbol.toUpperCase(), {
        longMaxPainPrice: row.long_max_pain_liq_price,
        shortMaxPainPrice: row.short_max_pain_liq_price,
        longMaxPainLevel: row.long_max_pain_liq_level,
        shortMaxPainLevel: row.short_max_pain_liq_level,
      });
    }
    _maxPainFetchedAt = Date.now();
    logger.debug({ count: _maxPainBatch.size }, "MaxPain batch fetched");
  } catch (err) {
    logger.debug({ err: String(err) }, "MaxPain batch fetch error — fail-open");
  }
}

/**
 * Получить Max Pain для BingX-символа.
 * Автоматически обновляет батч если TTL истёк (5 мин).
 * Fail-open: null для монет без покрытия CoinGlass (большинство альтов).
 */
export async function getMaxPain(
  bingxSymbol: string,
): Promise<MaxPainData | null> {
  if (Date.now() - _maxPainFetchedAt > MAX_PAIN_TTL) {
    await _fetchMaxPainBatch().catch(() => null);
  }
  const raw = toBase(bingxSymbol).toUpperCase();
  const base = /^1000/.test(raw) ? raw.slice(4) : raw; // 1000PEPE → PEPE
  return _maxPainBatch.get(base) ?? null;
}

// ── Short Liq Clusters above price (getShortLiqClusters, legacy) ─────────────
// Используется другими частями кодовой базы. liq_magnet_squeeze перешёл на getLiqMapClusters.

/**
 * Возвращает кластеры шорт-ликвидаций в диапазоне +4%..+12% над текущей ценой.
 * Источник: aggregated-heatmap/model2 (10 мин кэш).
 * Для liq_magnet_squeeze используйте getLiqMapClusters (/api/futures/liquidation/map, 15 мин).
 * Fail-open: null при отсутствии heatmap-данных или ошибке.
 */
export async function getShortLiqClusters(
  bingxSymbol: string,
  currentPrice: number,
): Promise<ShortLiqCluster[] | null> {
  if (!(currentPrice > 0)) return null;
  const levels = await getLevels(bingxSymbol);
  if (!levels) return null;

  // Санити-проверка: коллизия тикеров — цена должна попадать в ±20% диапазона heatmap
  const minP = levels.prices[0];
  const maxP = levels.prices[levels.prices.length - 1];
  if (currentPrice < minP * 0.8 || currentPrice > maxP * 1.2) return null;

  const clusters = extractClusters(levels);
  const LOW = 0.04; // +4% от текущей цены
  const HIGH = 0.12; // +12% от текущей цены

  return clusters
    .filter(
      (c) =>
        c.price >= currentPrice * (1 + LOW) &&
        c.price <= currentPrice * (1 + HIGH),
    )
    .map((c) => ({
      price: c.price,
      liqUsd: c.liqUsd,
      pctAbove: ((c.price - currentPrice) / currentPrice) * 100,
    }))
    .sort((a, b) => a.pctAbove - b.pctAbove); // ближняя к цене — первая
}
