// ── Fast-fail DB write helpers ────────────────────────────────────────────────
// Two helpers with different failure semantics:
//
// dbWriteBestEffort — для некритичных путей (cleanup, debug-лог, heartbeat):
//   при неудаче логирует warn и возвращает null — не бросает.
//   Цель — НЕ ждать полный connectionTimeoutMillis пула (15с) на каждую попытку,
//   а сдаться быстро, чтобы не занимать слот пула и не растягивать цикл скана.
//
// dbWriteStrict — для критичных бизнес-записей (oi_watch, tracked_signals):
//   при неудаче бросает исключение — вызывающий код должен обработать failure.
//   Гарантирует, что in-memory стейт и DB остаются консистентными: если запись
//   не прошла, исключение поднимается в per-symbol catch и символ пропускается.
//
// Важно: Promise.race не отменяет сам DB-запрос (pg-pool не поддерживает
// cancel на connect), но вызывающий код перестаёт ждать и освобождается —
// именно это и растягивало циклы при деградации Neon.
//
// См. .agents/memory/db-read-retry-helper.md для истории соседней проблемы.
import { logger } from "./logger.js";

export interface DbWriteFastOptions {
  /** Сколько попыток всего (включая первую). По умолчанию 2. */
  attempts?: number;
  /** Максимум ожидания на одну попытку, мс. По умолчанию 2500. */
  perAttemptTimeoutMs?: number;
  /** Пауза между попытками, мс. По умолчанию 400. */
  retryDelayMs?: number;
}

/**
 * Выполняет fn() с коротким таймаутом на попытку и малым числом ретраев.
 * Best-effort: при неудаче логирует warn и возвращает null — не бросает.
 * Только для некритичных путей (cleanup, debug-лог, heartbeat).
 */
export async function dbWriteBestEffort<T>(
  label: string,
  fn: () => Promise<T>,
  opts: DbWriteFastOptions = {},
): Promise<T | null> {
  const attempts = opts.attempts ?? 2;
  const perAttemptTimeoutMs = opts.perAttemptTimeoutMs ?? 2500;
  const retryDelayMs = opts.retryDelayMs ?? 400;

  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await Promise.race([
        fn(),
        new Promise<never>((_, reject) => {
          setTimeout(
            () =>
              reject(
                new Error(`${label}: timed out after ${perAttemptTimeoutMs}ms`),
              ),
            perAttemptTimeoutMs,
          );
        }),
      ]);
    } catch (err) {
      if (attempt < attempts) {
        logger.warn(
          { err, attempt, attempts },
          `${label}: write attempt ${attempt}/${attempts} failed — retrying fast`,
        );
        await new Promise((r) => setTimeout(r, retryDelayMs));
      } else {
        logger.warn(
          { err, attempt, attempts },
          `${label}: write failed after ${attempts} attempt(s) — skipping (non-critical)`,
        );
      }
    }
  }
  return null;
}

/**
 * Выполняет fn() с коротким таймаутом на попытку и малым числом ретраев.
 * Strict: при неудаче после всех попыток бросает исключение — не возвращает null.
 * Использовать для критичных бизнес-записей (oi_watch, tracked_signals), где
 * молчаливый провал рассинхронизирует in-memory и DB стейт.
 */
export async function dbWriteStrict<T>(
  label: string,
  fn: () => Promise<T>,
  opts: DbWriteFastOptions = {},
): Promise<T> {
  const attempts = opts.attempts ?? 2;
  const perAttemptTimeoutMs = opts.perAttemptTimeoutMs ?? 2500;
  const retryDelayMs = opts.retryDelayMs ?? 400;
  let lastErr: unknown;

  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      return await Promise.race([
        fn(),
        new Promise<never>((_, reject) => {
          setTimeout(
            () =>
              reject(
                new Error(`${label}: timed out after ${perAttemptTimeoutMs}ms`),
              ),
            perAttemptTimeoutMs,
          );
        }),
      ]);
    } catch (err) {
      lastErr = err;
      if (attempt < attempts) {
        logger.warn(
          { err, attempt, attempts },
          `${label}: write attempt ${attempt}/${attempts} failed — retrying`,
        );
        await new Promise((r) => setTimeout(r, retryDelayMs));
      } else {
        logger.error(
          { err, attempt, attempts },
          `${label}: write failed after ${attempts} attempt(s) — throwing (critical)`,
        );
      }
    }
  }
  throw lastErr;
}
