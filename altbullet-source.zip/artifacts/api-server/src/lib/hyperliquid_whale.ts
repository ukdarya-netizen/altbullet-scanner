/**
 * CoinGlass — Hyperliquid Whale Alerts / Positions.
 *
 * Киты открывающие крупные позиции ($1M+) на Hyperliquid DEX.
 *
 * Endpoints:
 *   GET /api/hyperliquid/whale-alert     — лента алертов (открытия/закрытия)
 *   GET /api/hyperliquid/whale-position  — текущие открытые позиции китов
 *
 * Семантика полей (доки CoinGlass не рендерятся, проверено по живым данным):
 *   position_size   — размер в токенах, знак = сторона (отриц. = шорт)
 *   position_action — 1 = открытие, 2 = закрытие (действуем только на 1)
 *   create_time     — unix ms
 *
 * Fail-open: null при любой ошибке. Кэш 60с (job опрашивает каждые ~3 мин).
 */

import { logger } from "./logger.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";

export interface HlWhaleAlert {
  /** адрес кита */
  user: string;
  /** HL base symbol, напр. "BTC", "HYPE", "kPEPE" */
  symbol: string;
  /** размер в токенах; отрицательный = шорт */
  positionSize: number;
  /** цена входа кита */
  entryPrice: number | null;
  /** цена ликвидации кита */
  liqPrice: number | null;
  /** размер позиции в USD */
  positionValueUsd: number;
  /** 1 = открытие, 2 = закрытие */
  positionAction: number;
  /** unix ms */
  createTime: number;
}

interface RawAlert {
  user?: string;
  symbol?: string;
  position_size?: number;
  entry_price?: number;
  liq_price?: number;
  position_value_usd?: number;
  position_action?: number;
  create_time?: number;
}

const CACHE_TTL = 60 * 1000;
let _cache: { data: HlWhaleAlert[] | null; ts: number } | null = null;

/**
 * Лента whale-алертов Hyperliquid (все стороны/действия — фильтрация на вызывающей стороне).
 * Fail-open: null при любой ошибке.
 */
export async function fetchHyperliquidWhaleAlerts(): Promise<
  HlWhaleAlert[] | null
> {
  if (_cache && Date.now() - _cache.ts < CACHE_TTL) return _cache.data;

  const apiKey = getNextCgKey();
  if (!apiKey) return null;

  try {
    const res = await fetch(
      "https://open-api-v4.coinglass.com/api/hyperliquid/whale-alert",
      {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(5000),
      },
    );

    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "hyperliquid/whale-alert" });
      return null;
    }
    if (!res.ok) {
      logger.debug(
        { status: res.status },
        "fetchHyperliquidWhaleAlerts: HTTP error — fail-open",
      );
      return null;
    }

    const json = (await res.json()) as { code: string; data?: RawAlert[] };
    if (json.code !== "0" || !Array.isArray(json.data)) return null;

    const alerts: HlWhaleAlert[] = [];
    for (const r of json.data) {
      if (!r.user || !r.symbol) continue;
      const size = Number(r.position_size);
      const usd = Number(r.position_value_usd);
      const action = Number(r.position_action);
      const ct = Number(r.create_time);
      if (
        !Number.isFinite(size) ||
        !Number.isFinite(usd) ||
        !Number.isFinite(ct)
      )
        continue;
      alerts.push({
        user: r.user,
        symbol: r.symbol,
        positionSize: size,
        entryPrice: Number.isFinite(Number(r.entry_price))
          ? Number(r.entry_price)
          : null,
        liqPrice: Number.isFinite(Number(r.liq_price))
          ? Number(r.liq_price)
          : null,
        positionValueUsd: usd,
        positionAction: action,
        createTime: ct,
      });
    }

    _cache = { data: alerts, ts: Date.now() };
    return alerts;
  } catch (err) {
    logger.debug(
      { err: String(err) },
      "fetchHyperliquidWhaleAlerts: fetch error — fail-open",
    );
    return null;
  }
}

/**
 * Маппинг HL base symbol → BingX pair.
 * HL использует k-префикс для 1000-контрактов (kPEPE = 1000 PEPE),
 * BingX — префикс "1000" (1000PEPE-USDT).
 * Возвращает BingX pair если торгуется, иначе null.
 *
 * @param hlBase        HL base symbol, напр. "HYPE" / "kPEPE"
 * @param bingxSymbols  Set всех BingX пар вида "XXX-USDT"
 */
export function mapHlSymbolToBingx(
  hlBase: string,
  bingxSymbols: Set<string>,
): string | null {
  const base = hlBase.trim();
  if (!base) return null;

  // k-префикс: kPEPE → 1000PEPE-USDT (fallback: PEPE-USDT)
  if (/^k[A-Z0-9]+$/.test(base)) {
    const rest = base.slice(1);
    const k1000 = `1000${rest}-USDT`;
    if (bingxSymbols.has(k1000)) return k1000;
    const plain = `${rest}-USDT`;
    if (bingxSymbols.has(plain)) return plain;
    return null;
  }

  const direct = `${base.toUpperCase()}-USDT`;
  if (bingxSymbols.has(direct)) return direct;
  return null;
}
