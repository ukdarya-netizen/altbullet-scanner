// ── Watcher message formatters & P&L helpers ─────────────────────────────────
// Pure functions: string formatting, P&L math, Telegram message builders.
// No side effects, no DB calls, no in-memory state.

import type { TrackedSignal } from "@workspace/db";
import {
  MILESTONES,
  getExitProfile,
  getMaxWatchDays,
  getBuStopMilestone,
} from "./watcher-config.js";
import { getPatternTgLabel } from "./pattern-labels.js";

// ── Liquidation cluster context (for follow-up messages) ─────────────────────

/** Ближайшие кластеры ликвидаций относительно текущей цены.
 *  Вычисляется из getLiqLevels(symbol, currentPrice) в момент отправки follow-up. */
export interface LiqContext {
  /** Ближайший кластер ЛОНГ-ликвидаций ниже текущей цены (поддержка/стоп). */
  below?: { pct: number; usd: number };
  /** Ближайший кластер ШОРТ-ликвидаций выше текущей цены (сопротивление/цель). */
  above?: { pct: number; usd: number };
}

/** Форматирует строку кластеров ликвидаций для follow-up сообщений.
 *  Возвращает пустую строку если данных нет. */
export function fmtLiqContextLine(ctx: LiqContext | null | undefined): string {
  if (!ctx) return "";
  const parts: string[] = [];
  if (ctx.below) {
    const usdStr = ctx.below.usd > 0 ? ` (${fmtVolM(ctx.below.usd)})` : "";
    parts.push(`▼ −${ctx.below.pct.toFixed(1)}% лонги${usdStr}`);
  }
  if (ctx.above) {
    const usdStr = ctx.above.usd > 0 ? ` (${fmtVolM(ctx.above.usd)})` : "";
    parts.push(`▲ +${ctx.above.pct.toFixed(1)}% шорты${usdStr}`);
  }
  return parts.length > 0 ? `📍 Кластеры: ${parts.join(" | ")}` : "";
}

/** OB стакан при входе — для отображения в сопроводительных сообщениях.
 *  Возвращает пустую строку если entryObRatio = null (не удалось получить). */
function fmtObLine(t: TrackedSignal): string {
  if (t.entryObRatio == null) return "";
  const emoji =
    t.entryObRatio >= 1.5 ? "🟢" : t.entryObRatio <= 0.7 ? "🔴" : "⚪";
  return `📊 OB стакан: ${t.entryObRatio.toFixed(2)}x${emoji}`;
}

// ── Price / number formatters ─────────────────────────────────────────────────

export function fmtP(p: number) {
  return p < 1
    ? `$${p.toFixed(6)}`
    : p < 100
      ? `$${p.toFixed(4)}`
      : `$${p.toFixed(2)}`;
}
export function fmtPct(n: number) {
  return `${n >= 0 ? "+" : ""}${n.toFixed(2)}%`;
}
export function fmtVolM(v: number): string {
  if (v >= 1_000_000) return `$${(v / 1_000_000).toFixed(1)}M`;
  if (v >= 1_000) return `$${(v / 1_000).toFixed(0)}K`;
  return `$${v.toFixed(0)}`;
}
export function scoreBar(s: number) {
  const f = Math.round(s);
  return "█".repeat(f) + "░".repeat(10 - f);
}

export function hoursAndDays(from: Date): {
  h: number;
  d: number;
  str: string;
} {
  const ms = Date.now() - from.getTime();
  const h = ms / 3_600_000;
  const d = Math.floor(h / 24);
  const rem = Math.round(h % 24);
  return { h, d, str: d > 0 ? `${d}д ${rem}ч` : `${Math.round(h)}ч` };
}

// ── Hashtag helpers ───────────────────────────────────────────────────────────
/** "BTC-USDT" → "#BTC" */
export function tickerTag(symbol: string): string {
  return `#${symbol.replace("-USDT", "").replace(/[^A-Za-z0-9]/g, "")}`;
}

/** "hidden_accumulation" → "#hidden_accumulation" */
export function patternTag(sentimentKey: string | null | undefined): string {
  if (!sentimentKey) return "";
  return `#${sentimentKey}`;
}

/** Returns "🏷 {patternLabel}" line for follow-up messages, or empty string if unknown. */
export function fmtPattern(t: TrackedSignal): string {
  const label = t.sentimentKey
    ? getPatternTgLabel(t.sentimentKey)
    : (t.sentiment ?? null);
  if (!label) return "";
  return `🏷 ${label}`;
}

// ── P&L math ──────────────────────────────────────────────────────────────────

export function computePnl(t: TrackedSignal, price: number): number {
  return ((price - t.entryPrice) / t.entryPrice) * 100;
}

export function computePeakPnl(t: TrackedSignal): number {
  if (!t.peakPrice) return 0;
  return ((t.peakPrice - t.entryPrice) / t.entryPrice) * 100;
}

export function nextMilestone(
  lastMilestone: number | null,
  currentPnl: number,
): number | null {
  // Возвращаем НАИВЫСШИЙ достигнутый milestone выше lastMilestone.
  // Старая логика возвращала наименьший → слала "+20%" когда сигнал уже на +42%,
  // потом "+25%", "+30%" тремя отдельными сообщениями. Теперь одно сообщение
  // за скачок, показывающее самый высокий пройденный порог.
  const last = lastMilestone ?? 0;
  let highest: number | null = null;
  for (const m of MILESTONES) {
    if (m > last && currentPnl >= m) highest = m;
  }
  return highest;
}

// ── Telegram message builders ─────────────────────────────────────────────────

export function msgFirstTarget(
  t: TrackedSignal,
  currentPrice: number,
  liqCtx?: LiqContext | null,
): string {
  const pnl = computePnl(t, currentPrice);
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const liqLine = fmtLiqContextLine(liqCtx);
  const obLine = fmtObLine(t);
  return [
    `🟣🎯 <b>TARGET HIT — ${sym} +${getExitProfile(t.sentimentKey).firstTarget}%</b>`,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)}) | ${dur.str}`,
    ``,
    `✂️ Фиксируй 25-50%`,
    `🛡 Стоп в БУ → ${fmtP(t.entryPrice)}`,
    `⏳ Следующий уровень: +${getExitProfile(t.sentimentKey).trailingActivation}% (трейлинг)`,
    obLine,
    liqLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #in_run`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgTrailingActivated(
  t: TrackedSignal,
  currentPrice: number,
  trailingStopLevel: number,
  liqCtx?: LiqContext | null,
): string {
  const pnl = computePnl(t, currentPrice);
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const liqLine = fmtLiqContextLine(liqCtx);
  const obLine = fmtObLine(t);
  return [
    `🟣🎯 <b>TARGET HIT — ${sym} +${getExitProfile(t.sentimentKey).trailingActivation}%</b>`,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)}) | ${dur.str}`,
    ``,
    `🛡 Трейлинг-стоп: ${fmtP(trailingStopLevel)} (гарантия +${(((1 + getExitProfile(t.sentimentKey).trailingActivation / 100) * (1 - getExitProfile(t.sentimentKey).trailingGap / 100) - 1) * 100).toFixed(1)}%)`,
    `Стоп тянется вверх автоматически`,
    obLine,
    liqLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #in_run #trailing`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgMilestone(
  t: TrackedSignal,
  milestone: number,
  currentPrice: number,
  trailingStopLevel: number,
  liqCtx?: LiqContext | null,
): string {
  const pnl = computePnl(t, currentPrice);
  const stopPnl = ((trailingStopLevel - t.entryPrice) / t.entryPrice) * 100;
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const liqLine = fmtLiqContextLine(liqCtx);
  const obLine = fmtObLine(t);
  // Заголовок показывает реальный текущий PnL, не порог milestone.
  // Milestone определяет когда отправить сообщение и какую картинку выбрать,
  // но пользователю важно видеть фактический рост, а не пороговое значение.
  return [
    `🟣🚀 <b>MOONSHOT — ${sym} ${fmtPct(pnl)}</b>`,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} | ${dur.str}`,
    ``,
    `🛡 Трейлинг-стоп: ${fmtP(trailingStopLevel)} (${fmtPct(stopPnl)} от входа)`,
    `Держим до срабатывания стопа`,
    obLine,
    liqLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #moonshot`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgTrailingStopHit(
  t: TrackedSignal,
  currentPrice: number,
  peakPnl: number,
  finalPnl: number,
): string {
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const alphaScoreLine = t.alphaScore
    ? `🎯 Bullet Score был: ${t.alphaScore}/10  <code>${scoreBar(t.alphaScore)}</code>`
    : "";
  const obLine = fmtObLine(t);
  return [
    `🟣🏁 <b>POSITION CLOSED — ${sym} — PROFIT (трейлинг)</b>`,
    `Пик ${fmtPct(peakPnl)} → зафиксировано ${fmtPct(finalPnl)} | ${dur.str}`,
    alphaScoreLine,
    obLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #profit`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgStopLoss(
  t: TrackedSignal,
  currentPrice: number,
  pnl: number,
): string {
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const obLine = fmtObLine(t);
  return [
    `🟣🏁 <b>POSITION CLOSED — ${sym} — STOP LOSS</b>`,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)}) | ${dur.str}`,
    obLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #stop_loss`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgBUStop(
  t: TrackedSignal,
  currentPrice: number,
  pnl: number,
): string {
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const obLine = fmtObLine(t);
  return [
    `🟣🏁 <b>POSITION CLOSED — ${sym} — BREAKEVEN (БУ)</b>`,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)}) | ${dur.str}`,
    obLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #bu_stop`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgPartialTakeProfit(
  t: TrackedSignal,
  currentPrice: number,
  pnl: number,
): string {
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const obLine = fmtObLine(t);
  const milestone = getBuStopMilestone(t.sentimentKey);
  return [
    `🟣🎯 <b>TARGET HIT — ${sym} +${milestone}%</b>`,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)}) | ${dur.str}`,
    ``,
    `🛡 Стоп в БУ → ${fmtP(t.entryPrice)}`,
    `✂️ Фиксируй 20-25%`,
    obLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #partial`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msg8PercentHit(
  t: TrackedSignal,
  currentPrice: number,
  liqCtx?: LiqContext | null,
): string {
  const pnl = computePnl(t, currentPrice);
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const liqLine = fmtLiqContextLine(liqCtx);
  const obLine = fmtObLine(t);
  return [
    `🟣🎯 <b>TARGET HIT — ${sym} +8%</b>`,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)}) | ${dur.str}`,
    ``,
    `Новая цель достигнута. Каждый процент — шаг к свободе.`,
    ``,
    `✂️ Фиксируй 20-25%`,
    `🛡 Стоп в БУ → ${fmtP(t.entryPrice)}`,
    `⏳ Следующие цели: +10% → +15% → +20%+`,
    obLine,
    liqLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #target_8`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgAccumVolumeBuilding(
  t: TrackedSignal,
  currentPrice: number,
  pnl: number,
  volMult: number,
  spotVol24h: number | null,
  spotVolMult?: number | null,
): string {
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const displayMult = (spotVolMult ?? volMult).toFixed(1);
  const obLine = fmtObLine(t);
  return [
    `🟣📊 <b>POSITION UPDATE — ${sym}</b>`,
    `🔄 В накоплении ${dur.str} | ${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    `📡 Спот-активность ${displayMult}x нормы — первый признак пробуждения`,
    obLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #accumulation`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgAccumOiBuilding(
  t: TrackedSignal,
  currentPrice: number,
  pnl: number,
  oiChange: number,
): string {
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const obLine = fmtObLine(t);
  return [
    `🟣📊 <b>POSITION UPDATE — ${sym}</b>`,
    `🔄 В накоплении ${dur.str} | ${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    `📈 OI +${oiChange.toFixed(1)}% за 30м — крупный игрок набирает`,
    obLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #accumulation`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgAccumulationReminder(
  t: TrackedSignal,
  currentPrice: number,
  pnl: number,
): string {
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  return [
    `🟣📊 <b>POSITION UPDATE — ${sym}</b>`,
    `🔄 В накоплении ${dur.str} | ${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    `👁 Без изменений, наблюдаю до ${getMaxWatchDays(t.sentimentKey)} дней`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #accumulation`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgAccumulation(
  t: TrackedSignal,
  currentPrice: number,
  pnl: number,
): string {
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  return [
    `🟣📊 <b>POSITION UPDATE — ${sym}</b>`,
    `🔄 В накоплении ${dur.str} | ${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #accumulation`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgReEntry(
  t: TrackedSignal,
  currentPrice: number,
  volMult: number,
  _spotVol24h: number | null,
): string {
  const { str } = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const pnl = computePnl(t, currentPrice);
  return [
    `🟣📊 <b>POSITION UPDATE — ${sym}</b>`,
    `🔁 RE-ENTRY — объём вернулся спустя ${str}`,
    ``,
    `Спот-активность ${volMult.toFixed(1)}x нормы, накопление завершено — ожидается импульс`,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)})`,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #re_entry`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgLateSignal(
  t: TrackedSignal,
  currentPrice: number,
  pnl: number,
): string {
  const sym = t.symbol.replace("-USDT", "");
  const obLine = fmtObLine(t);
  return [
    `🟣📊 <b>POSITION UPDATE — ${sym}</b>`,
    `⚠️ ЗАПОЗДАЛЫЙ СИГНАЛ — цена уже ${fmtPct(pnl)} к моменту обнаружения`,
    ``,
    `Входить не рекомендуется, момент пропущен. Трейлинг-стоп ${getExitProfile(t.sentimentKey).trailingGap}% включён.`,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)}`,
    obLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #late_signal #in_run`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgBreakeven(
  t: TrackedSignal,
  currentPrice: number,
  pnl: number,
): string {
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const obLine = fmtObLine(t);
  return [
    `🟣🏁 <b>POSITION CLOSED — ${sym} — BREAKEVEN</b>`,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)}) | ${dur.str}`,
    obLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #breakeven`,
  ]
    .filter(Boolean)
    .join("\n");
}

/** Таймаут 4д, цена НИЖЕ точки входа → засчитывается как стоп лосс */
export function msgBreakevenAsStopLoss(
  t: TrackedSignal,
  currentPrice: number,
  pnl: number,
): string {
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");
  const obLine = fmtObLine(t);
  return [
    `🔴🏁 <b>POSITION CLOSED — ${sym} — STOP LOSS (таймаут ${getMaxWatchDays(t.sentimentKey)}д)</b>`,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)}) | ${dur.str}`,
    ``,
    `⚠️ Сигнал закрыт по таймауту без прибыли — засчитан как стоп лосс`,
    obLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #stop_loss`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function msgInvalidated(
  t: TrackedSignal,
  currentPrice: number,
  pnl: number,
  reason: "oi_drop" | "vol_drop",
  oiDrop?: number,
  _volMult?: number,
): string {
  const dur = hoursAndDays(t.detectedAt);
  const sym = t.symbol.replace("-USDT", "");

  const reasonText =
    reason === "oi_drop"
      ? `📉 OI ${oiDrop?.toFixed(1)}% за 30м, крупный игрок закрыл позиции`
      : `📭 Спот-объём упал, катализатор не подтвердился`;

  const hint =
    t.sentimentKey === "trend_accumulation"
      ? `Возможен повторный вход при новом OI-спайке`
      : `Импульс выдохся, закрываем`;

  const obLine = fmtObLine(t);
  return [
    `🟣🚫 <b>SIGNAL CANCELLED — ${sym}</b>`,
    ``,
    reasonText,
    `${fmtP(t.entryPrice)} → ${fmtP(currentPrice)} (${fmtPct(pnl)}) | ${dur.str}`,
    ``,
    hint,
    obLine,
    ``,
    fmtPattern(t),
    `${tickerTag(t.symbol)} ${patternTag(t.sentimentKey)} #cancelled`,
  ]
    .filter(Boolean)
    .join("\n");
}
