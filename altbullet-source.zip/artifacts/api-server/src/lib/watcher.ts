import { logger } from "./logger.js";
import {
  db,
  trackedSignalsTable,
  settingsTable,
  oiWatchTable,
  signalsTable,
  oiDailySnapshotsTable,
  marketCapCacheTable,
  whaleAlertPoolTable,
  taScannerCacheTable,
} from "@workspace/db";
import type {
  TrackedSignal,
  InsertTrackedSignal,
  InsertSignal,
} from "@workspace/db";
import {
  eq,
  and,
  inArray,
  sql,
  lt,
  gte,
  desc,
  gt,
  isNull,
  or,
} from "drizzle-orm";
import { dbWriteBestEffort, dbWriteStrict } from "./dbWriteFast.js";
import { DEAD_PATTERN_KEYS } from "./dead-patterns.js";
import {
  getFutureTickers,
  getFutureTicker,
  getKlines,
  fetchCVD,
  getFundingRate,
  getOrderBookAnalysis,
  type BingXKline,
  type OrderBookAnalysis,
} from "./bingx.js";
import {
  loadMaBulkMap,
  loadEmaBulkMap,
  loadMacdBulkMap,
  loadTdBulkMap,
  loadAtrBulkMap,
  type MaListEntry,
  type EmaListEntry,
  type MacdListEntry,
  type TdListEntry,
  type AtrListEntry,
} from "./coinglass_ta.js";
import { setTdAtrEntry, getTdAtrEntry } from "./ta-cache.js";
import { getCrossExchangeOrderBook } from "./orderbook_external.js";
import {
  sendMessage,
  sendPhotoCaption,
  broadcastBatchAlert,
  getTargets,
  type AlphaResult,
} from "./telegram.js";
import { getCoinglassOI } from "./coinglass_oi.js";
import { getCoinglassTakerFlow } from "./coinglass_taker.js";
import { getSpotTakerFlow } from "./coinglass_spot_taker.js";
import {
  registerSnfSymbol,
  getSpotNetflowEntry,
} from "./spot-netflow-cache.js";
import {
  getSpotCvdMtf,
  getCoinglassAggregateFunding,
} from "./coinglass_spot_cvd.js";
import { getFsVolume } from "./coinglass_fs_volume.js";
import { getSpotVolume } from "./coinglass_spot_volume.js";
import {
  buildPositionsStatusText,
  formatOpenPositionLines,
  POSITIONS_IMG,
} from "./positionsReport.js";
import { getSpotPoolEntry } from "./spotPool.js";
import {
  getPrescanEntry,
  updateLiveSpotTaker,
  injectLiveMarketData,
  _pdbCheck,
  _pdbPass,
  _pdbReject,
  _pdbEnsure,
  isScannerActive,
  runPrice24hRefreshCycle,
  resetPrescanCycleCount,
} from "./scanner.js";
import { getPatternTgLabel } from "./pattern-labels.js";
import { backfillOiHistoryAfterCollisionCleanup } from "./oiHistoryBackfill.js";
import {
  runLiqCascadeWatcherJob,
  getLiqCascadeLayer10Candidates,
} from "./liq-cascade-watcher.js";
import { collectSingleSignalPreGrowth } from "./growthLeaderPreGrowth.js";
import { fetchArchetype } from "./archetypeClient.js";
import {
  runWhaleAlertJob,
  loadWhaleAlertPoolFromDb,
  getWhaleAlertPoolEntry,
  getActiveWhaleAlertPoolEntries,
  markWhaleAlertFired,
  incrementWhalePoolCycleCount,
} from "./whale-alert-job.js";
import { isWhaleOnCooldown } from "./hl-position-tracker.js";
import { startWhaleIndexUpdater, getTokenWhaleIndex } from "./whale_index.js";
import { claimSettingsBroadcast } from "./broadcast-guard.js";
import { getLiqLevels } from "./coinglass_liq_heatmap.js";
import { fetchMarketCap } from "./whale_watch_v2.js";

import {
  STOP_LOSS,
  CANCEL_STOP_LOSS_PCT,
  ACCUMULATION_REENTRY_H,
  ACCUM_SCOUT_COOLDOWN_MS,
  ACCUM_OI_COOLDOWN_MS,
  RE_ENTRY_VOL_MULT,
  FAST_CYCLE_MS,
  getExitProfile,
  getPatternMaxStop,
  getPatternMinStop,
  getMaxWatchDays,
  getNoTouchStopMs,
  getBuStopMilestone,
  SMART_CANCEL_MIN_AGE_MS,
} from "./watcher-config.js";

// Момент старта процесса — используется для grace period после рестарта.
// В течение RESTART_GRACE_MS stale-cancel (72ч hard max + OI check) не срабатывает:
// FastCycle должен успеть оценить и перевести сигналы в in_run прежде чем их отменять.
const SERVER_STARTED_AT = Date.now();
const RESTART_GRACE_MS = 30 * 60_000; // 30 минут

// ── OB snapshot cache — trackSignal сохраняет orderbook при выстреле, fire path читает consumeObAtFire ──
// Consume-once: вызов удаляет запись (избегаем stalе данных если сигналы быстро идут подряд).
const _obAtFire = new Map<string, OrderBookAnalysis | null>();
export function consumeObAtFire(symbol: string): OrderBookAnalysis | null {
  const v = _obAtFire.get(symbol) ?? null;
  _obAtFire.delete(symbol);
  return v;
}

// ── Stale-cancel in-memory extension state (сбрасывается при рестарте) ────────
// _vbStaleHoldUntil  : spot_vol_accumulation / volume_breakout* OI Watch — id → hold-until ms
// _haStaleHoldUntil  : hidden_accumulation OI Watch — id → hold-until ms (0 = проверено, не продлено)
// _staleOi4hExtCount : Глобальный OI4h guard — id → число использованных продлений (макс 2)
const _vbStaleHoldUntil = new Map<number, number>();
const _haStaleHoldUntil = new Map<number, number>();
const _staleOi4hExtCount = new Map<number, number>();
const _staleTakerSellCycles = new Map<number, number>(); // счётчик sell циклов для Шаг 1f

const _staleTakerFlipped = new Set<number>(); // флаг: тейкер перевернулся (Шаг 1f)
// Быстрые паттерны: стейл-чек жёсткий, OI4h guard не применяется
const FAST_STALE_PATTERNS = new Set<string>();
/** Минимальный % притока в OI за 4ч относительно mCap токена — считается значительным */
const NETCHANGE_MCAP_THRESHOLD = 0.5;

// ── Whale Watch Spot: умная отмена — in-memory state ─────────────────────────
// cvdNegCycles: счётчик подряд-отрицательных CVD циклов для каждого символа.
// Сбрасывается при восстановлении CVD. Сбрасывается на рестарте — допустимо
// для advisory-уведомления (не финансовое действие).

// ── Telegram helpers ──────────────────────────────────────────────────────────
// getTargets() импортирован из telegram.ts — содержит DB fallback + in-memory кэш channelId.
// Локальная копия удалена во избежание расхождений.

export async function broadcast(text: string) {
  let targets: (number | string)[] = [];
  try {
    targets = await getTargets();
  } catch (err) {
    logger.error({ err }, "broadcast: не удалось получить список получателей");
    return;
  }
  if (targets.length === 0) {
    logger.warn(
      "broadcast: нет получателей — сообщение не отправлено (subscribers пуст, channel_id не задан, TELEGRAM_CHAT_ID не настроен)",
    );
    return;
  }
  for (const t of targets) {
    try {
      await sendMessage(t, text);
    } catch (err) {
      // Ошибка Telegram (таймаут, rate limit и т.д.) не должна ломать весь цикл.
      // Логируем и продолжаем — остальные получатели получат сообщение.
      logger.error(
        { err, target: t },
        "broadcast: не удалось отправить сообщение",
      );
    }
  }
}

const _MOONSHOT_IMG = new URL("../assets/moonshot.png", import.meta.url)
  .pathname;
const STOPLOSS_IMG = new URL("../assets/stoploss.png", import.meta.url)
  .pathname;
const MILESTONE8_IMG = new URL("../assets/milestone8.png", import.meta.url)
  .pathname;

const FIRST_TARGET_IMG = new URL("../assets/first_target.png", import.meta.url)
  .pathname;
const MILESTONE10_IMG = new URL("../assets/milestone10.png", import.meta.url)
  .pathname;
const MILESTONE15_IMG = new URL("../assets/milestone15.png", import.meta.url)
  .pathname;
const MILESTONE20_IMG = new URL("../assets/milestone20.png", import.meta.url)
  .pathname;
const MILESTONE25_IMG = new URL("../assets/milestone25.png", import.meta.url)
  .pathname;
const MILESTONE30_IMG = new URL("../assets/milestone30.png", import.meta.url)
  .pathname;
const MILESTONE50_IMG = new URL("../assets/milestone50.png", import.meta.url)
  .pathname;
const MILESTONE55_IMG = new URL("../assets/milestone55.png", import.meta.url)
  .pathname;
const MILESTONE60_IMG = new URL("../assets/milestone60.png", import.meta.url)
  .pathname;
const MILESTONE65_IMG = new URL("../assets/milestone65.png", import.meta.url)
  .pathname;
const MILESTONE70_IMG = new URL("../assets/milestone70.png", import.meta.url)
  .pathname;
const MILESTONE75_IMG = new URL("../assets/milestone75.png", import.meta.url)
  .pathname;
const MILESTONE80_IMG = new URL("../assets/milestone80.png", import.meta.url)
  .pathname;
const MILESTONE85_IMG = new URL("../assets/milestone85.png", import.meta.url)
  .pathname;
const MILESTONE90_IMG = new URL("../assets/milestone90.png", import.meta.url)
  .pathname;
const MILESTONE95_IMG = new URL("../assets/milestone95.png", import.meta.url)
  .pathname;
const MILESTONE100_IMG = new URL("../assets/milestone100.png", import.meta.url)
  .pathname;
const CANCEL_IMG = new URL("../assets/cancel.png", import.meta.url).pathname;
const POSITION_UPDATE_IMG = new URL(
  "../assets/position_update.png",
  import.meta.url,
).pathname;
const POSITION_HOLD_IMG = new URL(
  "../assets/position_hold.png",
  import.meta.url,
).pathname;
const POSITION_FOLLOW_IMG = new URL(
  "../assets/position_follow.png",
  import.meta.url,
).pathname;
const POSITION_EXIT_IMG = new URL(
  "../assets/position_exit.png",
  import.meta.url,
).pathname;
const TRAILING_STOP_IMG = new URL(
  "../assets/trailing_stop.png",
  import.meta.url,
).pathname;
const BU_STOP_IMG = new URL("../assets/bu_stop.png", import.meta.url).pathname;
const BREAKEVEN_STOP_IMG = new URL(
  "../assets/breakeven_locked.png",
  import.meta.url,
).pathname;
const WEEKLY_REPORT_IMG = new URL(
  "../assets/weekly_report.png",
  import.meta.url,
).pathname;
const DAILY_REPORT_IMG = new URL("../assets/daily_report.png", import.meta.url)
  .pathname;
const MONTHLY_REPORT_IMG = new URL(
  "../assets/monthly_report.png",
  import.meta.url,
).pathname;
const WATCHDOG_IMG = new URL("../assets/watchdog.png", import.meta.url)
  .pathname;
const RESTART_IMG = new URL("../assets/system_restarted.png", import.meta.url)
  .pathname;
const MANUAL_CHECK_IMG = new URL("../assets/manual_check.png", import.meta.url)
  .pathname;

export async function broadcastPhoto(photoPath: string, caption: string) {
  let targets: (number | string)[] = [];
  try {
    targets = await getTargets();
  } catch (err) {
    logger.error(
      { err },
      "broadcastPhoto: не удалось получить список получателей",
    );
    return;
  }
  if (targets.length === 0) return;
  for (const t of targets) {
    try {
      const sent = await sendPhotoCaption(t, photoPath, caption);
      if (!sent) await sendMessage(t, caption); // fallback to text if photo fails
    } catch (err) {
      logger.error({ err, target: t }, "broadcastPhoto: ошибка отправки");
    }
  }
}

/**
 * Отправляет фото + один или несколько текстовых чанков КАЖДОМУ получателю подряд,
 * прежде чем переходить к следующему. В отличие от отдельных вызовов broadcastPhoto()
 * и broadcast()/adminBroadcast(), это не даёт фото "убежать" вперёд текста на N-1
 * итераций цикла (при большом числе подписчиков разрыв между фото и текстом рос
 * пропорционально их числу — ранние получатели видели фото на десятки секунд/минуту
 * раньше текста).
 */
// Telegram caption limit = 1024 символов. Режем по границе строки с запасом на HTML-теги.
const CAPTION_MAX_LEN = 1000;

/** Делит текст на { caption, rest }: caption <= maxLen символов (по границе строки), rest — остаток. */
function splitCaptionAndRest(
  text: string,
  maxLen = CAPTION_MAX_LEN,
): { caption: string; rest: string } {
  const lines = text.split("\n");
  let caption = "";
  let i = 0;
  for (; i < lines.length; i++) {
    const candidate = caption ? caption + "\n" + lines[i] : lines[i];
    if (candidate.length > maxLen && caption) break;
    caption = candidate;
  }
  const rest = lines.slice(i).join("\n");
  return { caption, rest };
}

/**
 * Отправляет фото с текстом, ПРИКРЕПЛЁННЫМ как caption к самому фото (единое сообщение
 * в Telegram), каждому получателю подряд. Если текст длиннее лимита caption (1024 симв.),
 * остаток отправляется следом отдельными сообщениями сразу после фото — так фото и текст
 * не расходятся по времени и основной текст виден прямо на фото.
 */
export async function broadcastPhotoWithText(
  photoPath: string,
  text: string,
): Promise<void> {
  let targets: (number | string)[] = [];
  try {
    targets = await getTargets();
  } catch (err) {
    logger.error(
      { err },
      "broadcastPhotoWithText: не удалось получить список получателей",
    );
    return;
  }
  if (targets.length === 0) {
    logger.warn("broadcastPhotoWithText: нет получателей");
    return;
  }
  const { caption, rest } = splitCaptionAndRest(text);
  const restChunks = rest ? splitMessageChunks(rest) : [];
  for (const t of targets) {
    try {
      const sent = await sendPhotoCaption(t, photoPath, caption);
      if (!sent) {
        logger.debug(
          { target: t },
          "broadcastPhotoWithText: фото не отправлено, отправляем весь текст сообщением",
        );
        await sendMessage(t, text);
        continue;
      }
    } catch (err) {
      logger.error(
        { err, target: t },
        "broadcastPhotoWithText: ошибка отправки фото",
      );
    }
    for (let i = 0; i < restChunks.length; i++) {
      const part =
        i === 0
          ? restChunks[i]!
          : `📊 <b>Продолжение (${i + 2}/${restChunks.length + 1}):</b>\n\n${restChunks[i]}`;
      try {
        await sendMessage(t, part);
      } catch (err) {
        logger.error(
          { err, target: t },
          "broadcastPhotoWithText: ошибка отправки текста",
        );
      }
      if (i < restChunks.length - 1)
        await new Promise((r) => setTimeout(r, 500));
    }
  }
}

// Разбивает длинный текст на чанки <= maxLen символов по границам строк.
// Telegram лимит = 4096 символов; используем 4000 с запасом на HTML-теги.
export function splitMessageChunks(text: string, maxLen = 4000): string[] {
  const lines = text.split("\n");
  const chunks: string[] = [];
  let current = "";
  for (const line of lines) {
    const candidate = current ? current + "\n" + line : line;
    if (candidate.length > maxLen && current) {
      chunks.push(current);
      current = line;
    } else {
      current = candidate;
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

/** Admin broadcast — отправляет произвольный текст всем подписчикам (для уведомлений об обновлениях) */
export async function adminBroadcast(text: string): Promise<void> {
  await broadcast(text);
}

// Отправляет текст одному получателю или всем, разбивая на чанки ≤4000 символов.
async function sendTo(
  text: string,
  targetChatId?: number | string,
): Promise<void> {
  const chunks = splitMessageChunks(text, 4000);
  if (targetChatId !== undefined) {
    for (let i = 0; i < chunks.length; i++) {
      await sendMessage(targetChatId, chunks[i]!);
      if (i < chunks.length - 1) await new Promise((r) => setTimeout(r, 300));
    }
  } else {
    for (let i = 0; i < chunks.length; i++) {
      await broadcast(chunks[i]!);
      if (i < chunks.length - 1) await new Promise((r) => setTimeout(r, 300));
    }
  }
}

// Отправляет фото с текстом: caption ≤1024 символов (лимит Telegram),
// остаток — отдельными сообщениями ≤4000 символов каждое.
// При сбое фото — fallback: весь текст отдельными сообщениями.
async function sendPhotoTo(
  photoPath: string,
  text: string,
  targetChatId?: number | string,
): Promise<void> {
  if (targetChatId !== undefined) {
    const { caption, rest } = splitCaptionAndRest(text);
    const restChunks = rest ? splitMessageChunks(rest, 4000) : [];
    const sent = await sendPhotoCaption(targetChatId, photoPath, caption).catch(
      () => false,
    );
    if (!sent) {
      // фото не отправилось — шлём весь текст текстовыми сообщениями
      await sendTo(text, targetChatId);
      return;
    }
    for (let i = 0; i < restChunks.length; i++) {
      await sendMessage(targetChatId, restChunks[i]!).catch(() => {});
      if (i < restChunks.length - 1)
        await new Promise((r) => setTimeout(r, 300));
    }
  } else {
    // broadcast: broadcastPhotoWithText уже корректно обрабатывает caption overflow
    await broadcastPhotoWithText(photoPath, text);
  }
}

import {
  fmtP,
  fmtPct,
  hoursAndDays,
  tickerTag,
  patternTag,
  fmtPattern,
  computePnl,
  computePeakPnl,
  nextMilestone,
  msgFirstTarget,
  msgTrailingActivated,
  msgMilestone,
  msgTrailingStopHit,
  msgStopLoss,
  msgBUStop,
  msg8PercentHit,
  msgPartialTakeProfit,
  msgAccumVolumeBuilding,
  msgAccumOiBuilding,
  msgReEntry,
  msgLateSignal,
  msgBreakeven,
  msgBreakevenAsStopLoss,
  type LiqContext,
} from "./watcher-formatters.js";

// ── Add signal to tracker ─────────────────────────────────────────────────────
// ── Индивидуальный стоп-лосс по Liquidation Heatmap ──────────────────────────
// Эффективная глубина стопа сигнала: персональная (liq heatmap) или стандартная -10%.
// Положительное число — глубина в % от входа.
export function effStopPct(t: { stopLossPct?: number | null }): number {
  return t.stopLossPct != null && t.stopLossPct > 0 ? t.stopLossPct : STOP_LOSS;
}

interface LiqStopFields {
  stopLossPrice: number | null;
  stopLossPct: number | null;
  stopSource: "liq_heatmap" | "pattern" | "standard";
  takeTargets: { price: number; pctFromEntry: number; liqUsd: number }[] | null;
}

/**
 * Расчёт персонального стопа/тейков по CoinGlass Liquidation Heatmap.
 * 2026-07-15: liq-стоп клампится сверху паттерн-лимитом (PATTERN_MAX_STOP) —
 * раньше кластер на −13…−15% сохранялся как есть и переопределял глобальный −10%
 * (avgLoss −15.45% на проде). Если heatmap недоступен, а у паттерна есть
 * документированный стоп (−5…−8%) — персистим его напрямую (stopSource="pattern"),
 * чтобы effStopPct не падал в глобальный −10%.
 */
async function computeLiqStopFields(
  symbol: string,
  entryPrice: number,
  sentimentKey?: string | null,
): Promise<LiqStopFields> {
  const patternMax = getPatternMaxStop(sentimentKey);

  // liquidation_cascade: heatmap кластеры часто дают -7...-8% стоп, который
  // выносится волатильностью самого каскада (45% стопов = ложные, цена отскочила
  // 10-33% после выхода). Всегда используем паттерн-стоп (-10%).
  // Тейки из heatmap сохраняем если доступны.
  if (sentimentKey === "liquidation_cascade") {
    const fixedStopPrice =
      entryPrice > 0 ? entryPrice * (1 - patternMax / 100) : null;
    try {
      const liqForTakes = await getLiqLevels(symbol, entryPrice);
      return {
        stopLossPrice: fixedStopPrice,
        stopLossPct: patternMax,
        stopSource: "pattern",
        takeTargets: liqForTakes?.takes?.length ? liqForTakes.takes : null,
      };
    } catch {
      /* heatmap недоступен — паттерн-стоп без тейков */
    }
    return {
      stopLossPrice: fixedStopPrice,
      stopLossPct: patternMax,
      stopSource: "pattern",
      takeTargets: null,
    };
  }

  try {
    const liq = await getLiqLevels(symbol, entryPrice);
    if (liq) {
      const patternMin = getPatternMinStop(sentimentKey);
      const clampedMax = liq.stopPct > patternMax;
      const clampedMin = patternMin > 0 && liq.stopPct < patternMin;
      const stopPct = clampedMax
        ? patternMax
        : clampedMin
          ? patternMin
          : liq.stopPct;
      const stopPrice =
        clampedMax || clampedMin
          ? entryPrice * (1 - stopPct / 100)
          : liq.stopPrice;
      if (clampedMax) {
        logger.info(
          {
            symbol,
            sentimentKey,
            liqStopPct: liq.stopPct.toFixed(1),
            patternMax,
          },
          "🛡 liq-стоп глубже паттерн-лимита — клампим",
        );
      }
      if (clampedMin) {
        logger.info(
          {
            symbol,
            sentimentKey,
            liqStopPct: liq.stopPct.toFixed(1),
            patternMin,
          },
          "🛡 liq-стоп мельче паттерн-минимума — подтягиваем",
        );
      }
      return {
        stopLossPrice: stopPrice,
        stopLossPct: stopPct,
        stopSource: clampedMax || clampedMin ? "pattern" : "liq_heatmap",
        takeTargets: liq.takes.length > 0 ? liq.takes : null,
      };
    }
  } catch (err) {
    logger.debug(
      { err, symbol },
      "computeLiqStopFields: fail-open → паттерн/стандартный стоп",
    );
  }
  // Heatmap недоступен: паттерн с документированным стопом → персистим его.
  if (patternMax < STOP_LOSS) {
    return {
      stopLossPrice:
        entryPrice > 0 ? entryPrice * (1 - patternMax / 100) : null,
      stopLossPct: patternMax,
      stopSource: "pattern",
      takeTargets: null,
    };
  }
  return {
    stopLossPrice: null,
    stopLossPct: null,
    stopSource: "standard",
    takeTargets: null,
  };
}

/**
 * Получает ближайшие кластеры ликвидаций относительно ТЕКУЩЕЙ цены для follow-up сообщений.
 * Использует тот же getLiqLevels (кэш 10 мин) — повторный вызов бесплатен.
 * Fail-open: null если heatmap недоступен.
 */
async function _buildLiqCtx(
  symbol: string,
  currentPrice: number,
): Promise<LiqContext | null> {
  try {
    const liq = await getLiqLevels(symbol, currentPrice);
    if (!liq) return null;
    const ctx: LiqContext = {};
    // Кластер ЛОНГ-ликвидаций ниже текущей цены (поддержка)
    if (liq.clusterPrice > 0 && currentPrice > 0) {
      ctx.below = {
        pct: Math.abs(((liq.clusterPrice - currentPrice) / currentPrice) * 100),
        usd: liq.clusterLiqUsd,
      };
    }
    // Ближайший кластер ШОРТ-ликвидаций выше текущей цены (сопротивление)
    if (liq.takes.length > 0) {
      ctx.above = {
        pct: liq.takes[0].pctFromEntry, // % от currentPrice (т.к. мы передали currentPrice в getLiqLevels)
        usd: liq.takes[0].liqUsd,
      };
    }
    return ctx.below !== undefined || ctx.above !== undefined ? ctx : null;
  } catch {
    return null;
  }
}

export async function trackSignal(params: {
  symbol: string;
  signalId: number | null;
  signalType: string;
  sentiment?: string | null;
  sentimentKey?: string | null;
  alphaScore?: number | null;
  entryPrice: number;
  /** Явный override prescanCycles — используется для whale_alert и других фоновых паттернов,
   *  чьи символы отсутствуют в prescanTracker. Если не передан, берётся из getPrescanEntry. */
  prescanCycles?: number | null;
  entryOi?: number | null;
  initialStatus?: "active";
  entryCvd30m?: boolean | null;
  entryCvd1h?: boolean | null;
  entryCvd4h?: boolean | null;
  marketCapUsd?: number | null;
  // Entry metrics snapshot — для анализа качества сигналов post-factum
  entryOi30m?: number | null;
  entryOi1h?: number | null;
  entryOi4h?: number | null;
  entryOi24h?: number | null;
  entryFutTakerNetBuy?: number | null;
  entrySpotVolMult?: number | null;
  entryFutVolMult?: number | null;
  entrySpotVol24h?: number | null;
  entrySpotMcapPct?: number | null;
  entrySpotTakerNetBuy?: number | null;
  entrySpotNetBuy1h?: number | null;
  entrySpotNetBuy4h?: number | null;
  entrySpotNetBuy24h?: number | null;
  entrySource?: string | null;
  // liq_cascade specific trigger params — для ретроспективного анализа
  entryLiqLong1h?: number | null;
  entryLiqLong24h?: number | null;
  entryLiqRatio?: number | null;
  entryLiqReason?: string | null;
}): Promise<"new" | "reentry" | "skip" | false> {
  try {
    const existing = await db
      .select({
        id: trackedSignalsTable.id,
        status: trackedSignalsTable.status,
        entryPrice: trackedSignalsTable.entryPrice,
        signalType: trackedSignalsTable.signalType,
      })
      .from(trackedSignalsTable)
      .where(
        and(
          eq(trackedSignalsTable.symbol, params.symbol),
          inArray(trackedSignalsTable.status, [
            "active",
            "accumulation",
            "in_run",
            "re_entry",
          ]),
        ),
      )
      .limit(1);

    // Является ли новый сигнал апгрейдом относительно текущего?
    // ghost_pump/ghost_pump_early → alpha/super_alpha: более строгая подтверждённая система
    // Апгрейд: НЕ сбрасываем цену входа и статус — позиция продолжается,
    // но обновляем метаданные (тип, сентимент) чтобы трекер отображал актуальный паттерн.
    const GHOST_TYPES = new Set(["ghost_pump", "ghost_pump_early"]);
    const ALPHA_TYPES = new Set(["alpha", "super_alpha"]);

    if (existing.length > 0) {
      const rec = existing[0];
      const isGhostToAlpha =
        GHOST_TYPES.has(rec.signalType ?? "") &&
        ALPHA_TYPES.has(params.signalType);

      // in_run: монета уже летит — обновляем метаданные если это апгрейд, иначе пропускаем.
      // В любом случае НЕ посылаем повторный алерт (return "skip").
      if (rec.status === "in_run") {
        if (isGhostToAlpha) {
          await dbWriteStrict("trackedSignal/ghost-inRun-upgrade", () =>
            db
              .update(trackedSignalsTable)
              .set({
                signalId: params.signalId,
                signalType: params.signalType,
                sentiment: params.sentiment ?? null,
                sentimentKey: params.sentimentKey ?? null,
                alphaScore: params.alphaScore ?? null,
                updatedAt: new Date(),
              })
              .where(eq(trackedSignalsTable.id, rec.id)),
          );
          logger.info(
            {
              symbol: params.symbol,
              from: rec.signalType,
              to: params.signalType,
            },
            "📈 trackSignal: ghost_pump in_run → alpha (метаданные обновлены, алерт не дублируем)",
          );
        } else {
          logger.info(
            { symbol: params.symbol, status: rec.status, type: rec.signalType },
            "Already in_run — skipping duplicate alert",
          );
        }
        return "skip"; // позиция уже летит — не дублируем алерт
      }

      // active: позиция уже открыта — НЕ перезаписываем цену входа и НЕ дублируем алерт.
      // Исключение: ghost_pump → alpha апгрейд: обновляем тип и сентимент тихо.
      if (rec.status === "active") {
        if (isGhostToAlpha) {
          await dbWriteStrict("trackedSignal/ghost-active-upgrade", () =>
            db
              .update(trackedSignalsTable)
              .set({
                signalId: params.signalId,
                signalType: params.signalType,
                sentiment: params.sentiment ?? null,
                sentimentKey: params.sentimentKey ?? null,
                alphaScore: params.alphaScore ?? null,
                updatedAt: new Date(),
              })
              .where(eq(trackedSignalsTable.id, rec.id)),
          );
          logger.info(
            {
              symbol: params.symbol,
              from: rec.signalType,
              to: params.signalType,
            },
            "📈 trackSignal: ghost_pump active → alpha (метаданные обновлены, алерт не дублируем)",
          );
        } else {
          logger.info(
            {
              symbol: params.symbol,
              existingEntry: rec.entryPrice,
              newPrice: params.entryPrice,
            },
            "Already active — skipping duplicate alert (entry price protected)",
          );
        }
        return "skip"; // позиция уже активна — не дублируем алерт
      }

      // accumulation: монета накапливается давно — новый сигнал означает возобновление
      // импульса, сбрасываем вход на актуальную цену.
      const oldEntry = rec.entryPrice;
      const liqReset = await computeLiqStopFields(
        params.symbol,
        params.entryPrice,
        params.sentimentKey,
      );
      await dbWriteStrict("trackedSignal/accum-reentry-reset", () =>
        db
          .update(trackedSignalsTable)
          .set({
            signalId: params.signalId,
            signalType: params.signalType,
            sentiment: params.sentiment ?? null,
            sentimentKey: params.sentimentKey ?? null,
            alphaScore: params.alphaScore ?? null,
            isShort: false,
            entryPrice: params.entryPrice,
            entryOi: params.entryOi ?? null,
            peakPrice: params.entryPrice,
            trailingStopLevel: null,
            lastMilestone: null,
            stopLossPrice: liqReset.stopLossPrice,
            stopLossPct: liqReset.stopLossPct,
            stopSource: liqReset.stopSource,
            takeTargets: liqReset.takeTargets,
            status: "active",
            reEntryCount: 0,
            detectedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(eq(trackedSignalsTable.id, rec.id)),
      );

      logger.info(
        { symbol: params.symbol, oldEntry, newEntry: params.entryPrice },
        "📍 Signal tracker reset (accumulation → active) — fresh entry price",
      );
      return "reentry";
    }

    // ── Пост-памп фильтр: остаточные индикаторы после отработки сигнала ──────
    // После памп OI/объём/тейкер остаются "задранными" ещё несколько часов.
    // Если монета недавно закрылась, а цена ещё не вернулась к уровню предыдущего входа —
    // это остатки старого памп, не новый сетап → пропускаем.
    // Разрешаем новый сигнал когда цена вернётся в пределы 8% от старого входа.
    if (!params.initialStatus) {
      const postPumpWindow = new Date(Date.now() - 48 * 60 * 60 * 1000);
      const recentlyClosed = await db
        .select({
          id: trackedSignalsTable.id,
          status: trackedSignalsTable.status,
          entryPrice: trackedSignalsTable.entryPrice,
        })
        .from(trackedSignalsTable)
        .where(
          and(
            eq(trackedSignalsTable.symbol, params.symbol),
            inArray(trackedSignalsTable.status, ["profit", "stop_loss"]),
            gte(trackedSignalsTable.updatedAt, postPumpWindow),
          ),
        )
        .limit(1);

      if (recentlyClosed.length > 0) {
        const prevEntry = Number(recentlyClosed[0].entryPrice);
        const elevationPct =
          prevEntry > 0
            ? ((params.entryPrice - prevEntry) / prevEntry) * 100
            : 0;
        if (elevationPct > 8) {
          logger.info(
            {
              symbol: params.symbol,
              closedStatus: recentlyClosed[0].status,
              prevEntry,
              currentEntry: params.entryPrice,
              elevationPct: elevationPct.toFixed(1) + "%",
            },
            "🔇 trackSignal: пост-памп — цена ещё задрана выше предыдущего входа, сигнал пропущен",
          );
          return "skip";
        }
      }
    }

    // ── Prescan context at fire time ─────────────────────────────────────────
    const prescanE = getPrescanEntry(params.symbol);
    let price24hAtFire = prescanE?.lastPrice24h ?? null;
    const prescanCycles = params.prescanCycles ?? prescanE?.cycleCount ?? null;

    // ── Универсальное обогащение метрик входа (2026-07-15) ──────────────────
    // Анализ прода показал 87–98% NULL в entry-метриках: паттерны передавали
    // только «свои» поля. Общий знаменатель нужен для сравнения победителей и
    // проигравших. Приоритет: params → prescanTracker (fail-open, null если нет).
    let entryOi30m = params.entryOi30m ?? prescanE?.lastOi30m ?? null;
    let entryOi1h = params.entryOi1h ?? prescanE?.lastOi1h ?? null;
    let entryOi4h = params.entryOi4h ?? prescanE?.lastOi4h ?? null;
    let entryOi24h = params.entryOi24h ?? prescanE?.lastOi24h ?? null;
    let entryPrice1h: number | null = prescanE?.lastPrice1h ?? null;
    if (entryPrice1h === null) {
      // background job сигнал (liq_cascade/whale_alert/etc.) — prescan не имеет lastPrice1h
      // для этого символа. Вычисляем из 3 × 30m klines (fail-open, timeout 3s).
      const _kl = await Promise.race([
        getKlines(params.symbol, "30m", 4),
        new Promise<BingXKline[]>((_, r) =>
          setTimeout(() => r(new Error("price1h klines timeout")), 3_000),
        ),
      ]).catch(() => [] as BingXKline[]);
      if (_kl.length >= 3) {
        const _c = parseFloat(_kl[_kl.length - 1].close);
        const _b = parseFloat(_kl[_kl.length - 3].close);
        entryPrice1h = _b > 0 ? ((_c - _b) / _b) * 100 : null;
      }
    }
    let entryCvd30m = params.entryCvd30m ?? prescanE?.lastCvd30m ?? null;
    let entryCvd1h = params.entryCvd1h ?? prescanE?.lastCvd1h ?? null;
    let entryCvd4h = params.entryCvd4h ?? prescanE?.lastCvd4h ?? null;
    const entryFutVolMult =
      params.entryFutVolMult ?? prescanE?.lastVolMult ?? null;
    let entrySpotTakerNetBuy =
      params.entrySpotTakerNetBuy ?? prescanE?.lastSpotTakerNetBuy ?? null;
    let entrySpotNetBuy1h =
      params.entrySpotNetBuy1h ?? prescanE?.lastSpotNetBuy1h ?? null;
    let entrySpotNetBuy4h = params.entrySpotNetBuy4h ?? null;
    let entrySpotNetBuy24h = params.entrySpotNetBuy24h ?? null;
    // spotVolMult: prescan fallback (lastSpotVol1h / spotVolAvg1h)
    const entrySpotVolMult =
      params.entrySpotVolMult ??
      (prescanE?.spotVolAvg1h &&
      prescanE.lastSpotVol1h &&
      prescanE.spotVolAvg1h > 0
        ? prescanE.lastSpotVol1h / prescanE.spotVolAvg1h
        : null);

    // Funding (BingX) + BTC 24h (рыночный режим) + SpotVol 24h (CoinGlass, кэш 30 мин)
    // — универсально для ВСЕХ сигналов. Никогда не блокируют INSERT: таймаут 4с, любая ошибка → null.
    let entryFundingRate: number | null = null;
    let entryBtc24h: number | null = null;
    let entryWhaleIndex: number | null = null;
    let entryObBids: number | null = null;
    let entryObAsks: number | null = null;
    let entryObRatio: number | null = null;
    let entryFutTakerNetBuy: number | null = params.entryFutTakerNetBuy ?? null;
    let entrySpotVol24h: number | null = params.entrySpotVol24h ?? null;
    let entrySpotMcapPct: number | null = params.entrySpotMcapPct ?? null;
    try {
      const withTimeout = <T>(p: Promise<T>): Promise<T | null> =>
        Promise.race([
          p.catch(() => null),
          new Promise<null>((res) => setTimeout(() => res(null), 4000)),
        ]);
      // WI (getTokenWhaleIndex) обращается к CoinGlass,
      // который под нагрузкой отвечает за 5–8с → даём 8с как OB, иначе таймаут = null при записи.
      const withTimeout8s = <T>(p: Promise<T>): Promise<T | null> =>
        Promise.race([
          p.catch(() => null),
          new Promise<null>((res) => setTimeout(() => res(null), 8000)),
        ]);
      // OB: запускаем независимо с таймаутом 8s (вместо 4s) — BingX быстрый, но под нагрузкой
      // event loop может тормозить. Параллельно с основным Promise.all, не блокирует его.
      const _obRace = Promise.race([
        getOrderBookAnalysis(params.symbol, 20).catch(() => null),
        new Promise<null>((res) => setTimeout(() => res(null), 8000)),
      ]);
      const [
        funding,
        btcTicker,
        tokenWi,
        spotVol24hRaw,
        symbolTicker,
        liveCvd,
        liveTaker,
        liveSpotTaker,
        liveOI,
      ] = await Promise.all([
        withTimeout(getFundingRate(params.symbol)),
        withTimeout(getFutureTicker("BTC-USDT")),
        withTimeout8s(getTokenWhaleIndex(params.symbol)),
        entrySpotVol24h === null
          ? withTimeout(
              getFsVolume(params.symbol).then((r) => r.spotVolUsd24h ?? null),
            )
          : Promise.resolve(null),
        // live fallback: тикер символа для price24hAtFire (если prescanE не дал — background job сигнал)
        price24hAtFire === null
          ? withTimeout(getFutureTicker(params.symbol))
          : Promise.resolve(null),
        // live fallback: SpotCVD для background job сигналов (liq_cascade, whale_alert, spot_ob) где prescanE = null
        entryCvd30m === null && entryCvd1h === null && entryCvd4h === null
          ? withTimeout(getSpotCvdMtf(params.symbol))
          : Promise.resolve(null),
        // Futures taker net buy % (CoinGlass) — universal fallback для background job сигналов
        // где prescanE = null и params не передал значение (whale_alert без таймфрейма и т.п.)
        entryFutTakerNetBuy === null
          ? withTimeout(getCoinglassTakerFlow(params.symbol).catch(() => null))
          : Promise.resolve(null),
        // Spot taker net buy % — universal live fallback: prescanTracker.lastSpotTakerNetBuy
        // обновляется batch-ом в конце скана, поэтому для main-scan сигналов может быть null.
        // limit=96 даёт 24h свечей → таже функция возвращает 1h/4h/24h агрегаты за 1 CG-запрос.
        // scanner.ts продолжает использовать limit=4 (только дашборд, не DB-хранилище).
        entrySpotTakerNetBuy === null ||
        entrySpotNetBuy4h === null ||
        entrySpotNetBuy24h === null
          ? withTimeout(getSpotTakerFlow(params.symbol, 96))
          : Promise.resolve(null),
        // OI live fallback: для background job сигналов (liq_cascade, whale_alert) prescanE = null
        // → все OI-поля null. Добираем OI из CoinGlass напрямую с тем же 8с таймаутом.
        entryOi30m === null && entryOi1h === null && entryOi4h === null
          ? withTimeout8s(
              getCoinglassOI(params.symbol, params.entryPrice).catch(
                () => null,
              ),
            )
          : Promise.resolve(null),
      ]);
      // OB: ждём результат (уже работает ~4s параллельно с Promise.all, максимум ещё 4s)
      const obResult = await _obRace;
      if (funding?.lastFundingRate != null) {
        const fr = parseFloat(funding.lastFundingRate); // raw decimal: 0.0001 = 0.01%
        if (Number.isFinite(fr)) entryFundingRate = fr;
      }
      if (btcTicker?.priceChangePercent != null) {
        const b = parseFloat(String(btcTicker.priceChangePercent));
        if (Number.isFinite(b)) entryBtc24h = b;
      }
      if (tokenWi != null && Number.isFinite(tokenWi))
        entryWhaleIndex = tokenWi;
      if (spotVol24hRaw != null) entrySpotVol24h = spotVol24hRaw;
      // price24hAtFire: live fallback через тикер символа
      if (price24hAtFire === null && symbolTicker?.priceChangePercent != null) {
        const p = parseFloat(String(symbolTicker.priceChangePercent));
        if (Number.isFinite(p)) price24hAtFire = p;
      }
      // CVD: live fallback для background job сигналов (prescanE = null → все CVD поля были null)
      if (liveCvd?.available) {
        if (entryCvd30m === null) entryCvd30m = liveCvd.cvd30m ?? null;
        if (entryCvd1h === null) entryCvd1h = liveCvd.cvd1h ?? null;
        if (entryCvd4h === null) entryCvd4h = liveCvd.cvd4h ?? null;
      }
      // OI: live fallback для background job сигналов (prescanE = null → все OI поля null).
      // Если liveOI пришёл (не null), но поля всё ещё null — применяем.
      if (liveOI) {
        if (entryOi30m === null) entryOi30m = liveOI.oiChange30m ?? null;
        if (entryOi1h === null) entryOi1h = liveOI.oiChange1h ?? null;
        if (entryOi4h === null) entryOi4h = liveOI.oiChange4h ?? null;
        if (entryOi24h === null) entryOi24h = liveOI.oiChange24h ?? null;
      }
      // OB snapshot: кэш для fire path + DB-значения
      _obAtFire.set(params.symbol, obResult ?? null);
      if (obResult) {
        entryObBids = obResult.bidVolumeUsd;
        entryObAsks = obResult.askVolumeUsd;
        entryObRatio = obResult.bidAskRatio;
      }
      // Futures taker net buy %: universal fallback (background job сигналы где prescanE = null)
      if (liveTaker?.available && entryFutTakerNetBuy === null) {
        entryFutTakerNetBuy = liveTaker.netBuyPct ?? null;
      }
      // Spot taker net buy %: universal live fallback (main-scan сигналы: batch-обновление
      // prescanTracker запускается ПОСЛЕ скана, поэтому lastSpotTakerNetBuy = null в момент fire)
      if (liveSpotTaker?.available && entrySpotTakerNetBuy === null) {
        entrySpotTakerNetBuy = liveSpotTaker.netBuyPct ?? null;
      }
      // SNF 1h/4h/24h: PRIMARY — fresh limit=96 запрос (liveSpotTaker, Binance→BingX fallback).
      // Все 3 TF вычислены из одного batch свечей, нет доп. CG-запросов.
      if (liveSpotTaker?.available) {
        if (entrySpotNetBuy1h === null)
          entrySpotNetBuy1h = liveSpotTaker.takerNetBuy1h ?? null;
        if (entrySpotNetBuy4h === null)
          entrySpotNetBuy4h = liveSpotTaker.takerNetBuy4h ?? null;
        if (entrySpotNetBuy24h === null)
          entrySpotNetBuy24h = liveSpotTaker.takerNetBuy24h ?? null;
      }
      // SNF 4h/24h: FALLBACK — batch-кэш CoinGlass spot netflow (каждые 5 мин).
      // Покрывает случай когда liveSpotTaker unavailable (CG timeout / 429).
      if (entrySpotNetBuy4h === null || entrySpotNetBuy24h === null) {
        const _snfEntry = getSpotNetflowEntry(params.symbol);
        if (_snfEntry) {
          if (entrySpotNetBuy4h === null)
            entrySpotNetBuy4h = _snfEntry.netPct4h ?? null;
          if (entrySpotNetBuy24h === null)
            entrySpotNetBuy24h = _snfEntry.netPct24h ?? null;
        }
      }
    } catch {
      /* fail-open — метрики не критичны для трекинга */
    }
    // Регистрируем символ для per-symbol SNF supplement (заполнит map для UI)
    registerSnfSymbol(params.symbol);
    // mcapUsd: params → spotPool → market_cap_cache DB (persistent 7-day fallback)
    // spotPool пуст ~30 мин после рестарта; market_cap_cache заполнен startMarketCapPreloader
    const _mcapPool =
      params.marketCapUsd ?? getSpotPoolEntry(params.symbol)?.mcapUsd ?? null;
    const mcapUsd: number | null =
      _mcapPool ??
      (await db
        .select({ mcapUsd: marketCapCacheTable.mcapUsd })
        .from(marketCapCacheTable)
        .where(
          eq(marketCapCacheTable.symbol, params.symbol.replace(/-USDT$/, "")),
        )
        .limit(1)
        .then((r) => r[0]?.mcapUsd ?? null)
        .catch(() => null));
    if (
      entrySpotMcapPct === null &&
      entrySpotVol24h !== null &&
      mcapUsd &&
      mcapUsd > 0
    ) {
      entrySpotMcapPct = (entrySpotVol24h / mcapUsd) * 100;
    }

    // OI Watch entry price — если сигнал пришёл из очереди OI Watch
    let oiWatchEntryPrice: number | null = null;
    try {
      const oiWatchRows = await db
        .select({ priceAtEntry: oiWatchTable.priceAtEntry })
        .from(oiWatchTable)
        .where(
          and(
            eq(oiWatchTable.symbol, params.symbol),
            inArray(oiWatchTable.status, ["watching", "confirming"]),
          ),
        )
        .orderBy(desc(oiWatchTable.addedAt))
        .limit(1);
      oiWatchEntryPrice = oiWatchRows[0]?.priceAtEntry ?? null;
    } catch {
      /* non-critical */
    }

    // Персональный стоп/тейки по Liquidation Heatmap (fail-open → паттерн-стоп или -10%)
    const liqFields = await computeLiqStopFields(
      params.symbol,
      params.entryPrice,
      params.sentimentKey,
    );

    // Promise.race с таймаутом 10s: самый критичный INSERT — потеря означает
    // потерю всего трекинга позиции. Timeout бросает, outer catch возвращает false
    // → caller не делает Telegram broadcast (безопасный fail-fast).
    // 10s (не dbWriteBestEffort) — нужен throw при failure, а не silent null.
    await Promise.race([
      db.insert(trackedSignalsTable).values({
        symbol: params.symbol,
        signalId: params.signalId,
        signalType: params.signalType,
        sentiment: params.sentiment ?? null,
        sentimentKey: params.sentimentKey ?? null,
        alphaScore: params.alphaScore ?? null,
        isShort: false,
        entryPrice: params.entryPrice,
        entryOi: params.entryOi ?? null,
        peakPrice: params.entryPrice,
        trailingStopLevel: null,
        lastMilestone: null,
        stopLossPrice: liqFields.stopLossPrice,
        stopLossPct: liqFields.stopLossPct,
        stopSource: liqFields.stopSource,
        takeTargets: liqFields.takeTargets,
        price24hAtFire,
        prescanCycles,
        oiWatchEntryPrice,
        entryCvd30m,
        entryCvd1h,
        entryCvd4h,
        marketCapUsd: mcapUsd,
        entryOi30m,
        entryOi1h,
        entryOi4h,
        entryOi24h,
        entryPrice1h,
        entryFutTakerNetBuy,
        entrySpotVolMult,
        entryFutVolMult,
        entrySpotVol24h,
        entrySpotMcapPct,
        entrySpotTakerNetBuy,
        entrySpotNetBuy1h,
        entrySpotNetBuy4h,
        entrySpotNetBuy24h,
        entrySource: params.entrySource ?? null,
        entryLiqLong1h: params.entryLiqLong1h ?? null,
        entryLiqLong24h: params.entryLiqLong24h ?? null,
        entryLiqRatio: params.entryLiqRatio ?? null,
        entryLiqReason: params.entryLiqReason ?? null,
        entryFundingRate,
        entryBtc24h,
        entryWhaleIndex,
        entryObBids,
        entryObAsks,
        entryObRatio,
        status: params.initialStatus ?? "active",
        reEntryCount: 0,
        detectedAt: new Date(),
        updatedAt: new Date(),
      } as InsertTrackedSignal),
      new Promise<never>((_, reject) =>
        setTimeout(
          () => reject(new Error("trackSignal INSERT timeout (10s)")),
          10_000,
        ),
      ),
    ]);

    // T002+T003: автосбор ретроданных (T-1/2/4/12h) + архетип при каждом выстреле (fire-and-forget, fail-open)
    {
      const _fireMs = Date.now();
      const _archM = {
        oi_30m: entryOi30m,
        oi_1h: entryOi1h,
        oi_4h: entryOi4h,
        vol_mult: entryFutVolMult,
        spot_vol_mult: entrySpotVolMult,
        cvd_1h: entryCvd1h ?? null,
        cvd_30m: entryCvd30m ?? null,
        price_24h: price24hAtFire ?? null,
        funding: entryFundingRate,
        net_buy_pct: entrySpotTakerNetBuy,
      };
      fetchArchetype(params.symbol, _archM)
        .then((arch) =>
          collectSingleSignalPreGrowth(
            params.symbol,
            _fireMs,
            arch?.archetype ?? null,
            arch?.confidence_score ?? null,
            params.sentimentKey,
          ),
        )
        .catch((err: unknown) =>
          logger.debug(
            { err, symbol: params.symbol },
            "signalPreGrowth: фоновый сбор не удался (fail-open)",
          ),
        );
    }

    logger.info(
      { symbol: params.symbol, price: params.entryPrice },
      "📍 Signal added to tracker",
    );
    return "new";
  } catch (err) {
    logger.error(
      { err, symbol: params.symbol },
      "Failed to add signal to tracker",
    );
    return false; // сигнализируем вызывающему — broadcast нельзя делать
  }
}

// ── Startup reset: normalize stale active signals after server restart ─────────
// Если сервер перезагрузился пока монета двигалась — entry price устарел.
// Вместо молчаливого сброса — отправляем уведомление «Пропущено движение»,
// затем сбрасываем entry до текущей цены чтобы сопровождение продолжалось корректно.
async function sendBotRestartNotification(): Promise<void> {
  // ── Шаг 1: атомарный guard с собственным retry (до 5 попыток, 60с) ──────────
  // Guard UPDATE вынесен в отдельный цикл потому что DB connection pool
  // перегружен пока сканер гоняет первую партию (~10 мин). 5×60с = 5 мин окно,
  // но поскольку watcher стартует в t=14мин (после первого скана), в норме
  // первая же попытка должна проходить. Retry — страховка на случай задержки скана.
  const claimed = await claimSettingsBroadcast({
    column: "lastRestartNotifiedAt",
    windowMs: 5 * 60_000,
    label: "Restart notification",
    retries: 4,
    retryDelayMs: 60_000,
  });
  if (!claimed) {
    return;
  }

  // ── Шаг 2: отправка с retry ───────────────────────────────────────────────
  // Retry loop: 3 попытки с задержкой 60с.
  // ВАЖНО: buildPositionsStatusText() и getTargets() вызываются ВНУТРИ цикла —
  // при старте DB бывает временно недоступна (connection timeout). Если первая
  // попытка упала из-за DB, вторая через 60с сделает свежий запрос к уже
  // восстановившейся БД. Вынос buildPositionsStatusText() за цикл = тихий провал.
  // Рестарт-уведомление идёт только лично @darshakl (7818695412) — не в канал/подписчикам.
  const RESTART_PERSONAL_ID = 7818695412;

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const text = `🔄 <b>Бот перезапущен. Мониторинг возобновлён.</b>`;

      let sent = 0;
      try {
        const ok = await sendPhotoCaption(
          RESTART_PERSONAL_ID,
          RESTART_IMG,
          text,
        ).catch(() => false);
        if (!ok) await sendMessage(RESTART_PERSONAL_ID, text);
        sent++;
      } catch (err) {
        logger.warn({ err, attempt }, "Restart notification: send failed");
      }

      if (sent > 0) {
        logger.info(
          { attempt },
          "🔄 Bot restart notification sent → @darshakl",
        );
        return;
      }
      logger.warn(
        { attempt },
        "Restart notification: отправка упала, retry через 60с",
      );
    } catch (err) {
      logger.warn(
        { err, attempt },
        "Restart notification: ошибка (DB/Telegram/getTargets), retry через 60с",
      );
    }

    if (attempt < 3) await new Promise((r) => setTimeout(r, 60_000));
  }
  logger.error(
    "🔄 Restart notification: все 3 попытки провалились — уведомление не отправлено",
  );
}

// ── После рестарта: предупреждение о позициях близко к стопу ─────────────────
// «Близко» = использовано ≥50% буфера стопа (PnL отрицательный, прошло половину пути к стопу).
// Пример: стоп −8%, текущий PnL −4% → предупреждение.
// Отправляется отдельным сообщением с картинкой manual_check.png — независимо от restartNotif.
async function sendNearStopWarning(): Promise<void> {
  try {
    // Atomic dedup: только один из двух воркеров отправит сообщение.
    // Окно 10 мин — оба воркера стартуют почти одновременно, второй увидит 0 rows и выйдет.
    const claimed = await claimSettingsBroadcast({
      column: "lastManualCheckSentAt",
      windowMs: 10 * 60_000,
      label: "Manual Check near-stop",
      retries: 2,
      retryDelayMs: 15_000,
    });
    if (!claimed) return;

    const openPositions = await db
      .select()
      .from(trackedSignalsTable)
      .where(
        inArray(trackedSignalsTable.status, [
          "active",
          "in_run",
          "accumulation",
          "re_entry",
        ]),
      );

    if (openPositions.length === 0) return;

    let tickers: { symbol: string; lastPrice: string }[] = [];
    try {
      tickers = (await getFutureTickers()) as {
        symbol: string;
        lastPrice: string;
      }[];
    } catch {
      return;
    }

    const priceMap = new Map<string, number>();
    for (const t of tickers)
      priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

    const nearStop: Array<{
      symbol: string;
      pnl: number;
      stopPct: number;
      remaining: number;
    }> = [];
    for (const pos of openPositions) {
      if (!pos.entryPrice || pos.entryPrice === 0) continue;
      const curPrice = priceMap.get(pos.symbol);
      if (!curPrice) continue;
      const pnl = computePnl(pos, curPrice);
      const stopPct = effStopPct(pos);
      if (pnl < 0 && Math.abs(pnl) >= stopPct * 0.5) {
        nearStop.push({
          symbol: pos.symbol,
          pnl,
          stopPct,
          remaining: stopPct - Math.abs(pnl),
        });
      }
    }

    if (nearStop.length === 0) return;

    const lines = [
      `⚠️ <b>MANUAL CHECK — позиции близко к стопу</b>`,
      ``,
      `Бот перезапустился. Следующие позиции требуют проверки:`,
      ``,
      ...nearStop.map((p) => {
        const base = p.symbol.replace("-USDT", "");
        const remainStr =
          p.remaining > 0
            ? `до стопа: <b>${p.remaining.toFixed(1)}%</b>`
            : `⛔ стоп пробит`;
        return `• <b>${base}</b> ${tickerTag(p.symbol)} | PnL: <b>${p.pnl.toFixed(1)}%</b> | Стоп: −${p.stopPct.toFixed(0)}% | ${remainStr}`;
      }),
      ``,
      `🔄 Бот перезапустился — <b>проверьте позиции вручную</b>`,
    ];
    const text = lines.join("\n");

    let targets: (number | string)[] = [];
    try {
      targets = await getTargets();
    } catch {
      return;
    }

    for (const target of targets) {
      try {
        const ok = await sendPhotoCaption(target, MANUAL_CHECK_IMG, text).catch(
          () => false,
        );
        if (!ok) await sendMessage(target, text).catch(() => {});
      } catch {
        /* non-critical */
      }
    }
    logger.warn(
      {
        nearStopCount: nearStop.length,
        symbols: nearStop.map((p) => p.symbol),
      },
      "⚠️ Near-stop positions detected after restart — manual check alert sent",
    );
  } catch (err) {
    logger.warn({ err }, "sendNearStopWarning: non-critical error, skipping");
  }
}

// ── One-time cleanup: закрываем все открытые ghost_pump позиции ──────────────
// Запускается один раз при старте сервера после отключения паттернов.
// После того как все позиции закрыты, функция молчит (нет open ghost_pump → exit).
export async function runGhostPumpCleanup(): Promise<void> {
  const openGhost = await db
    .select({
      id: trackedSignalsTable.id,
      symbol: trackedSignalsTable.symbol,
      status: trackedSignalsTable.status,
      entryPrice: trackedSignalsTable.entryPrice,
    })
    .from(trackedSignalsTable)
    .where(
      and(
        inArray(trackedSignalsTable.status, [
          "active",
          "in_run",
          "accumulation",
          "re_entry",
        ]),
        inArray(trackedSignalsTable.signalType, [
          "ghost_pump",
          "ghost_pump_early",
        ]),
      ),
    );

  if (openGhost.length === 0) return;

  logger.info(
    { count: openGhost.length },
    "🧹 Ghost pump cleanup: закрываем открытые позиции",
  );

  const symbols: string[] = [];
  for (const pos of openGhost) {
    try {
      await dbWriteStrict("trackedSignal/ghost-cleanup-cancel", () =>
        db
          .update(trackedSignalsTable)
          .set({
            status: "cancelled",
            exitPrice: pos.entryPrice,
            pnlPercent: 0,
            cancelReason: "ghost_pump_cleanup",
            closedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(
            and(
              eq(trackedSignalsTable.id, pos.id),
              inArray(trackedSignalsTable.status, [
                "active",
                "in_run",
                "accumulation",
              ]),
            ),
          ),
      );
      symbols.push(pos.symbol.replace("-USDT", ""));
    } catch (err) {
      logger.warn(
        { err, symbol: pos.symbol },
        "Ghost pump cleanup: ошибка закрытия",
      );
    }
  }

  if (symbols.length > 0) {
    try {
      const targets = await getTargets();
      const msg = [
        `🧹 <b>Сброс Ghost Pump позиций</b>`,
        ``,
        `Паттерны <b>Ghost Pump</b> и <b>Anomaly</b> отключены — слишком поздний вход, высокий риск.`,
        ``,
        `Закрыты позиции (${symbols.length}):`,
        symbols.map((s) => `  • #${s}`).join("\n"),
        ``,
        `Бот продолжает работу по оставшимся паттернам.`,
      ].join("\n");
      for (const chatId of targets) {
        try {
          await sendMessage(chatId, msg);
        } catch {
          /* non-critical */
        }
      }
    } catch (err) {
      logger.warn(
        { err },
        "Ghost pump cleanup: не удалось отправить уведомление",
      );
    }
  }
}

// ── Одноразовая чистка POWER-USDT ticker-collision (2026-07-10) ─────────────
// Баг: getBingxOiUsdCached() до фикса умножал уже-USD значение BingX OI ещё
// раз на цену — кросс-валидация занижала эталон в ~1/price раз и почти
// всегда либо ложно молчала, либо (для POWER) сама коллизия была реальной
// (CoinGlass отдавал ~$204-240M против настоящих ~$1.8-17M), но live-чек
// имел fail-open дыру: available:false трактовался как "нет данных, не
// блокируем" вместо "обнаружена подозрительная магнитуда, блокируем".
// В итоге oi24h_accumulation сигнал (signal id 716 / tracked id 725) выстрелил
// на day3-снимке $240M, посчитанном ИЗ ТОЙ ЖЕ испорченной коллизии.
// Идемпотентно: отменяет только active/in_run записи POWER-USDT
// oi24h_accumulation и помечает старые corrupted-снимки NULL (>$50M —
// заведомо выше реального OI POWER), чтобы кандидат-запрос их больше не видел.
export async function cleanupPowerCollisionArtifacts(): Promise<void> {
  try {
    const cancelled = await dbWriteStrict("trackedSignal/power-cancel", () =>
      db
        .update(trackedSignalsTable)
        .set({
          status: "cancelled",
          cancelReason: "coinglass_collision_cleanup",
          closedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(trackedSignalsTable.symbol, "POWER-USDT"),
            eq(trackedSignalsTable.sentimentKey, "oi24h_accumulation"),
            inArray(trackedSignalsTable.status, [
              "active",
              "in_run",
              "accumulation",
              "re_entry",
            ] as any[]),
          ),
        )
        .returning({ id: trackedSignalsTable.id }),
    );

    const snapshots = await dbWriteStrict("oiDailySnapshots/power-clear", () =>
      db
        .update(oiDailySnapshotsTable)
        .set({ oiUsd: null, oiChange24h: null })
        .where(
          and(
            eq(oiDailySnapshotsTable.symbol, "POWER-USDT"),
            gt(oiDailySnapshotsTable.oiUsd, 50_000_000),
          ),
        )
        .returning({
          id: oiDailySnapshotsTable.id,
          date: oiDailySnapshotsTable.date,
        }),
    );

    if (cancelled.length > 0 || snapshots.length > 0) {
      logger.info(
        {
          cancelledTracked: cancelled.length,
          clearedSnapshots: snapshots.length,
          dates: snapshots.map((s) => s.date),
        },
        "POWER-USDT collision cleanup: отменён сигнал и очищены испорченные дневные снимки OI",
      );
    }
  } catch (err) {
    logger.error({ err }, "POWER-USDT collision cleanup error");
  }
}

// ── ОТКЛЮЧЕНО (2026-07-10, тот же день что и написана) ────────────────────────
// Первый прогон на проде массово поломал данные: сравнение "CoinGlass oiUsd
// (это АГРЕГАТ по ВСЕМ биржам, см. totalOI в coinglass_oi.ts) vs прямой OI
// ТОЛЬКО на BingX" при ratio>30x некорректно для ликвидных токенов — у BTC,
// ADA, XRP, DOGE, TRX, ARB, APE и ещё ~290 символов доля BingX в глобальном OI
// естественно и легитимно меньше 1/30, это НЕ признак коллизии тикера, а
// нормальная структура рынка (основной объём на Binance/OKX/Bybit).
// Функция ошибочно обнулила 10-дневную историю oi_daily_snapshots для ~300
// символов и ложно отменила рабочий сигнал APE-USDT (id 716/tracked 716,
// cancel_reason=coinglass_collision_cleanup) — единственная НЕ подтверждённая
// вручную отмена среди четырёх (LDO/RSR/AKE — подтверждены ручным сравнением
// заранее, см. память bingx-oi-usd-unit-bug.md, ratio там был 1600x-38000x,
// на порядки выше шума соотношения "агрегат/одна биржа").
// Настоящий признак коллизии — не ratio к BingX, а то, что абсолютная
// величина oiUsd не совместима с ЛЮБОЙ разумной биржевой структурой (см.
// SATS ratio=19486x в живых логах — вот это коллизия). Безопасный
// автоматический вариант этой проверки пока не реализован — ниже узкий,
// вручную проверенный список символов вместо общего скана всех тикеров.
export async function cleanupOiCollisionArtifacts(): Promise<void> {
  // Список пополняется ТОЛЬКО после ручной сверки abs(oi_usd) со здравым
  // смыслом (рыночная капа/объём токена), не одним лишь ratio к BingX-OI.
  const MANUALLY_VERIFIED_COLLISION_SYMBOLS = [
    "POWER-USDT",
    "RSR-USDT",
    "AKE-USDT",
    "TAC-USDT",
    "LDO-USDT",
  ];
  try {
    const cutoff = new Date(Date.now() - 10 * 24 * 60 * 60 * 1000)
      .toISOString()
      .slice(0, 10);

    const clearedSnapshots = await dbWriteStrict(
      "oiDailySnapshots/collision-clear",
      () =>
        db
          .update(oiDailySnapshotsTable)
          .set({ oiUsd: null, oiChange24h: null })
          .where(
            and(
              inArray(
                oiDailySnapshotsTable.symbol,
                MANUALLY_VERIFIED_COLLISION_SYMBOLS,
              ),
              gte(oiDailySnapshotsTable.date, cutoff),
            ),
          )
          .returning({
            id: oiDailySnapshotsTable.id,
            symbol: oiDailySnapshotsTable.symbol,
          }),
    );

    const cancelledTracked = await dbWriteStrict(
      "trackedSignal/collision-cancel",
      () =>
        db
          .update(trackedSignalsTable)
          .set({
            status: "cancelled",
            cancelReason: "coinglass_collision_cleanup",
            closedAt: new Date(),
            updatedAt: new Date(),
          })
          .where(
            and(
              inArray(
                trackedSignalsTable.symbol,
                MANUALLY_VERIFIED_COLLISION_SYMBOLS,
              ),
              eq(trackedSignalsTable.sentimentKey, "oi24h_accumulation"),
              inArray(trackedSignalsTable.status, [
                "active",
                "in_run",
                "accumulation",
                "re_entry",
              ] as any[]),
            ),
          )
          .returning({
            id: trackedSignalsTable.id,
            symbol: trackedSignalsTable.symbol,
          }),
    );

    if (clearedSnapshots.length > 0 || cancelledTracked.length > 0) {
      logger.info(
        {
          clearedSnapshots: clearedSnapshots.length,
          cancelledTracked: cancelledTracked.map((t) => `${t.symbol}#${t.id}`),
        },
        "OI collision cleanup (ручной whitelist): очищены подтверждённые артефакты",
      );
    }
  } catch (err) {
    logger.error({ err }, "OI collision cleanup error");
  }
}

// ── Разовое восстановление ложной отмены APE-USDT (2026-07-10) ───────────────
// Сломанная версия cleanupOiCollisionArtifacts (см. выше) отменила APE-USDT
// без ручной проверки — единственная неподтверждённая отмена среди четырёх.
// Возвращаем сигнал в активное состояние. Идемпотентно: условие WHERE ловит
// только конкретную запись с этой cancel_reason, повторный запуск — no-op.
export async function restoreFalseApeCancellation(): Promise<void> {
  try {
    const restored = await dbWriteStrict("trackedSignal/ape-restore", () =>
      db
        .update(trackedSignalsTable)
        .set({
          status: "active",
          cancelReason: null,
          closedAt: null,
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(trackedSignalsTable.symbol, "APE-USDT"),
            eq(trackedSignalsTable.id, 716),
            eq(trackedSignalsTable.cancelReason, "coinglass_collision_cleanup"),
          ),
        )
        .returning({ id: trackedSignalsTable.id }),
    );

    if (restored.length > 0) {
      logger.info(
        { restored: restored.length },
        "APE-USDT: отменена ложная отмена coinglass_collision_cleanup, сигнал восстановлен",
      );
    }
  } catch (err) {
    logger.error({ err }, "APE-USDT restore error");
  }
}

// ── Одноразовая очистка сигналов удалённых паттернов (2026-07-15) ─────────────
// В таблице signals накопился шум от паттернов, удалённых из кода (особенно
// oi24h_accumulation — 21 из 60 последних записей). Журнал сделок читает
// tracked_signals — его НЕ трогаем (там живые позиции PUMP/BTC/XAUT и история
// для аналитики). Удаляем только из signals (лента сигналов в UI).
// Идемпотентно: паттерны из списка больше не стреляют, повторный прогон — no-op.
// Dev shell не имеет write-доступа к проду, поэтому фикс едет кодом при деплое
// (см. prod-data-fix-as-code). Можно удалить функцию после подтверждения на проде.
// DEAD_PATTERN_KEYS imported from dead-patterns.ts

export async function cleanupDeadPatternSignals(): Promise<void> {
  try {
    // FK-защита: строки signals, на которые ссылаются tracked_signals.signal_id, не удаляем.
    const deleted = await dbWriteStrict("signals/dead-pattern-delete", () =>
      db
        .delete(signalsTable)
        .where(
          and(
            inArray(signalsTable.sentimentKey, DEAD_PATTERN_KEYS),
            sql`${signalsTable.id} NOT IN (SELECT signal_id FROM tracked_signals WHERE signal_id IS NOT NULL)`,
          ),
        )
        .returning({ id: signalsTable.id }),
    );
    if (deleted.length > 0) {
      logger.info(
        { deleted: deleted.length, keys: DEAD_PATTERN_KEYS.length },
        "🧹 Очистка signals: удалены записи мёртвых паттернов",
      );
    }
  } catch (err) {
    logger.error({ err }, "cleanupDeadPatternSignals error");
  }
}

/** Отменяет открытые позиции (active/in_run/accumulation/re_entry) с мёртвыми паттернами.
 *  Идемпотентно: повторный вызов — no-op (строки уже cancelled). */
export async function cancelDeadPatternTrackedSignals(): Promise<void> {
  try {
    const cancelled = await dbWriteStrict(
      "trackedSignal/dead-pattern-cancel",
      () =>
        db
          .update(trackedSignalsTable)
          .set({
            status: "cancelled",
            cancelReason: "dead_pattern",
            updatedAt: new Date(),
          })
          .where(
            and(
              inArray(trackedSignalsTable.status, [
                "active",
                "accumulation",
                "re_entry",
                "in_run",
              ]),
              inArray(trackedSignalsTable.sentimentKey!, DEAD_PATTERN_KEYS),
            ),
          )
          .returning({
            id: trackedSignalsTable.id,
            symbol: trackedSignalsTable.symbol,
            sentimentKey: trackedSignalsTable.sentimentKey,
          }),
    );
    if (cancelled.length > 0) {
      logger.info(
        {
          cancelled: cancelled.length,
          detail: cancelled
            .map((r) => `${r.symbol}(${r.sentimentKey})`)
            .join(", "),
        },
        "🧹 Отменены открытые позиции с мёртвыми паттернами",
      );
    }
  } catch (err) {
    logger.error({ err }, "cancelDeadPatternTrackedSignals error");
  }
}

export async function runStartupReset(): Promise<void> {
  // Проверяем active/accumulation/re_entry (стоп-лосс персональный или -10%)
  // и in_run (трейлинг стоп / бу-стоп)
  const openSignals = await db
    .select()
    .from(trackedSignalsTable)
    .where(
      inArray(trackedSignalsTable.status, [
        "active",
        "accumulation",
        "re_entry",
        "in_run",
      ]),
    );

  if (openSignals.length === 0) return;

  // ── Retry: BingX API нестабилен при холодном старте (таймауты, DNS) ──────
  // 3 попытки с экспоненциальной задержкой. Если все упали — логируем и выходим.
  // НЕ молчим: раньше был просто return, что скрывало пропуск стоп-лоссов.
  let tickers: { symbol: string; lastPrice: string }[] = [];
  let fetchOk = false;
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      tickers = (await getFutureTickers()) as any[];
      fetchOk = true;
      break;
    } catch (err) {
      logger.warn(
        { err, attempt },
        `Startup reset: BingX fetch attempt ${attempt}/3 failed`,
      );
      if (attempt < 3) await new Promise((r) => setTimeout(r, 3000 * attempt));
    }
  }
  if (!fetchOk) {
    logger.error(
      "Startup reset: все попытки получить цены провалились — стоп-лоссы не проверены",
    );
    return;
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  let targets: (number | string)[] = [];
  try {
    targets = await getTargets();
  } catch {
    /* non-critical */
  }

  let resetCount = 0;
  for (const tracked of openSignals) {
    const currentPrice = priceMap.get(tracked.symbol);
    if (!currentPrice) continue;

    const pnl = computePnl(tracked, currentPrice);
    const base = tracked.symbol.replace("-USDT", "");
    const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT.P`;

    // ── active / accumulation / re_entry: стоп-лосс (персональный или -10%) ──
    // accumulation = active > 24ч без первой цели. Стоп-лосс применяется ко всем.
    // NO-TOUCH PERIOD: при рестарте сервера в первые 2ч/4ч — стоп не срабатывает
    // (тот же guard что и в fast cycle). Сигнал был открыт недавно — рынку нужно время.
    const _startupAgeMs = Date.now() - tracked.detectedAt.getTime();
    if (
      (tracked.status === "active" ||
        tracked.status === "accumulation" ||
        tracked.status === "re_entry") &&
      _startupAgeMs >= getNoTouchStopMs(tracked.sentimentKey) &&
      pnl <= -effStopPct(tracked)
    ) {
      // UPDATE первым — RETURNING гарантирует что только один процесс отправит
      const claimedSL = await dbWriteStrict(
        "trackedSignal/startup-stop-loss",
        () =>
          db
            .update(trackedSignalsTable)
            .set({
              status: "stop_loss",
              exitPrice: currentPrice,
              pnlPercent: pnl,
              closedAt: new Date(),
              updatedAt: new Date(),
            })
            .where(
              sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('active','accumulation','re_entry')`,
            )
            .returning({ id: trackedSignalsTable.id }),
      );
      if (claimedSL.length === 0) {
        resetCount++;
        continue;
      } // другой процесс уже закрыл
      const msg =
        `🛑 <b>Пропущен стоп-лосс (сервер перезапускался)</b>\n\n` +
        `<b>${tracked.symbol}</b>\n` +
        `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Текущая: <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `Убыток: <b>${pnl.toFixed(1)}%</b>\n\n` +
        `Позиция закрыта по стоп-лоссу.\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `${tickerTag(tracked.symbol)} ${patternTag(tracked.sentimentKey)} #stop_loss`;

      for (const chatId of targets) {
        try {
          await sendMessage(chatId, msg);
        } catch {
          /* non-critical */
        }
      }
      logger.warn(
        {
          symbol: tracked.symbol,
          status: tracked.status,
          entry: tracked.entryPrice,
          currentPrice,
          pnl: pnl.toFixed(1) + "%",
        },
        "🛑 Startup reset: missed stop-loss (active/accumulation) — signal closed",
      );
      resetCount++;

      // ── in_run: проверка трейлинг-стопа ────────────────────────────────────
      // После первой цели (+10%) стоп переносится в БУ (entry). Трейлинг (10% от пика)
      // активируется при +15% от входа. Если сервер лежал и цена рухнула — закрываем.
    } else if (tracked.status === "in_run") {
      const peak = tracked.peakPrice ?? currentPrice;
      const peakPnl = computePnl(tracked, peak);
      const exitProfileSr = getExitProfile(tracked.sentimentKey);
      const trailingActive = peakPnl >= exitProfileSr.trailingActivation;
      const trailingStop = peak * (1 - exitProfileSr.trailingGap / 100);
      const trailingHit = trailingActive && currentPrice <= trailingStop;
      const beStopHit = !trailingActive && currentPrice < tracked.entryPrice;

      if (trailingHit || beStopHit) {
        // Для трейлинг-стопа фиксируем выход по теоретическому уровню (peak * (1 - trailing%)),
        // а не по опрошенной цене — это даёт корректный PnL и исключает путаницу «116 - 10 = 106».
        const exitPrice = trailingHit ? trailingStop : currentPrice;
        const finalPnl =
          ((exitPrice - tracked.entryPrice) / tracked.entryPrice) * 100;
        // beStopHit = price returned to entry → стоп в БУ (считается как прибыль)
        // trailingHit = трейлинг сработал → profit/stop_loss в зависимости от pnl
        const closedStatus = beStopHit
          ? "bu_stop"
          : finalPnl >= 0
            ? "profit"
            : "stop_loss";
        // UPDATE первым — RETURNING гарантирует что только один процесс отправит
        const claimedTr = await dbWriteStrict(
          "trackedSignal/startup-trailing-close",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                status: closedStatus,
                exitPrice,
                pnlPercent: finalPnl,
                closedAt: new Date(),
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'in_run'`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimedTr.length === 0) {
          resetCount++;
          continue;
        } // другой процесс уже закрыл
        const msg = trailingHit
          ? `🔴 <b>Пропущен трейлинг-стоп (сервер перезапускался)</b>\n\n` +
            `<b>${tracked.symbol}</b>\n` +
            `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Выход по трейлингу: <b>$${trailingStop.toPrecision(4)}</b>\n` +
            `Пик: <b>$${peak.toPrecision(4)}</b> | Трейлинг уровень: <b>$${trailingStop.toPrecision(4)}</b>\n` +
            `P&L: <b>${finalPnl >= 0 ? "+" : ""}${finalPnl.toFixed(1)}%</b>\n\n` +
            `<a href="${tvUrl}">График</a>\n\n${tickerTag(tracked.symbol)} ${patternTag(tracked.sentimentKey)} #trailing_stop`
          : `🛡 <b>Пропущен стоп в БУ (сервер перезапускался)</b>\n\n` +
            `<b>${tracked.symbol}</b>\n` +
            `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Выход: <b>$${currentPrice.toPrecision(4)}</b>\n` +
            `P&L: <b>${finalPnl >= 0 ? "+" : ""}${finalPnl.toFixed(1)}%</b>\n` +
            `<i>Капитал защищён.</i>\n\n` +
            `<a href="${tvUrl}">График</a>\n\n${tickerTag(tracked.symbol)} ${patternTag(tracked.sentimentKey)} #bu_stop`;

        for (const chatId of targets) {
          try {
            await sendMessage(chatId, msg);
          } catch {
            /* non-critical */
          }
        }
        logger.warn(
          {
            symbol: tracked.symbol,
            entry: tracked.entryPrice,
            peak,
            currentPrice,
            finalPnl: finalPnl.toFixed(1) + "%",
          },
          trailingHit
            ? "🔴 Startup reset: missed trailing-stop (in_run) — signal closed"
            : "🔴 Startup reset: missed be-stop (in_run) — signal closed",
        );
        resetCount++;
      }

      // ── active: достигло первой цели пока сервер лежал → переводим в in_run ──
      // ВАЖНО: entryPrice НЕ сбрасываем — это реальная цена входа. Сигнал уже
      // выполнил условие перехода (+10%), поэтому корректный переход — in_run,
      // а не обнуление entry (что скрывает прибыль и ломает трейлинг).
    } else if (
      tracked.status === "active" &&
      pnl >= getExitProfile(tracked.sentimentKey).firstTarget
    ) {
      const claimedRun = await dbWriteStrict(
        "trackedSignal/startup-to-inRun",
        () =>
          db
            .update(trackedSignalsTable)
            .set({
              status: "in_run",
              peakPrice: currentPrice,
              updatedAt: new Date(),
            })
            .where(
              sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`,
            )
            .returning({ id: trackedSignalsTable.id }),
      );
      if (claimedRun.length === 0) {
        resetCount++;
        continue;
      } // другой процесс уже перевёл
      const sign = pnl >= 0 ? "+" : "";
      const msg =
        `🚀 <b>Цель достигнута пока бот перезапускался</b>\n\n` +
        `<b>${tracked.symbol}</b>\n` +
        `Вход: <b>$${tracked.entryPrice.toPrecision(4)}</b> → Сейчас: <b>$${currentPrice.toPrecision(4)}</b>\n` +
        `Профит: <b>${sign}${pnl.toFixed(1)}%</b>\n\n` +
        `Сигнал переведён в <b>IN RUN</b>. Стоп перенесён в безубыток.\n` +
        `<a href="${tvUrl}">График</a>\n\n` +
        `${tickerTag(tracked.symbol)} ${patternTag(tracked.sentimentKey)} #in_run`;

      for (const chatId of targets) {
        try {
          await sendMessage(chatId, msg);
        } catch {
          /* non-critical */
        }
      }
      logger.warn(
        {
          symbol: tracked.symbol,
          entry: tracked.entryPrice,
          currentPrice,
          pnl: pnl.toFixed(1) + "%",
        },
        "🚀 Startup reset: first target reached while down — transitioned to in_run",
      );
      resetCount++;
    }
  }

  if (resetCount > 0) {
    logger.info(
      { resetCount },
      "Startup reset complete: missed moves notified, entries normalized",
    );
  } else {
    logger.info(
      "Startup reset: all active signals are fresh (no reset needed)",
    );
  }
}

// ── Shared DB retry helper для транзиентного истощения Neon-пула ─────────────
// Несколько фоновых джобов (fast/watcher циклы, price-backfill трекеры) делают
// один "начальный" SELECT в начале своего цикла. Раньше каждая функция либо не
// ретраила вовсе (единичный timeout = весь бэкфилл/цикл пропущен без восстановления),
// либо копировала свой собственный retry-loop (как было в runInRunFastCycle).
// Единая обёртка — чтобы чинить устойчивость к пул-таймаутам один раз, а не
// патчить каждый вызов по отдельности при каждом новом всплытии проблемы.
async function dbReadWithRetry<T>(
  label: string,
  fn: () => Promise<T>,
  attempts = 3,
  delayMs = 5_000,
): Promise<{ ok: true; value: T } | { ok: false }> {
  let lastErr: unknown = null;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      const value = await fn();
      return { ok: true, value };
    } catch (err) {
      lastErr = err;
      logger.warn(
        { err, attempt },
        `${label}: fetch attempt ${attempt}/${attempts} failed`,
      );
      if (attempt < attempts) await new Promise((r) => setTimeout(r, delayMs));
    }
  }
  logger.error(
    { err: lastErr },
    `${label}: fetch failed after ${attempts} attempts — skipping`,
  );
  return { ok: false };
}

// ── In-memory cooldown для accumulation scouts (сбрасывается при рестарте) ───
// Структура: Map<signalId, { volBuild: timestampMs, oiBuild: timestampMs }>
const accumScoutCooldowns = new Map<
  number,
  { volBuild: number; oiBuild: number }
>();
// hourlyPositionUpdateAt removed — dedup now via lastHourlyAt in DB (atomic across 2 processes)

// ── Main watcher cycle (every 10 min): scouts active signals ──────────────────
// Обрабатывает OI drain, объём и OI-скауты, re-entry check.
// Stop loss / trailing stop / in_run промоут — только FastCycle (каждые 2 мин).
export async function runWatcherCycle(): Promise<{
  checked: number;
  updated: number;
}> {
  const accumFetch = await dbReadWithRetry("WatcherCycle", () =>
    db
      .select()
      .from(trackedSignalsTable)
      .where(inArray(trackedSignalsTable.status, ["active", "accumulation"])),
  );
  if (!accumFetch.ok) return { checked: 0, updated: 0 };
  const accumSignals = accumFetch.value;

  if (accumSignals.length === 0) return { checked: 0, updated: 0 };

  logger.info(
    { count: accumSignals.length },
    "Watcher: checking active/accumulation signals",
  );

  let tickers: { symbol: string; lastPrice: string }[] = [];
  try {
    tickers = (await getFutureTickers()) as any[];
  } catch (err) {
    logger.error({ err }, "Watcher: failed to fetch tickers");
    return { checked: 0, updated: 0 };
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  let updated = 0;

  for (const tracked of accumSignals) {
    try {
      const currentPrice = priceMap.get(tracked.symbol);
      if (!currentPrice) continue;

      const pnl = computePnl(tracked, currentPrice);
      const { h: _ageHours } = hoursAndDays(tracked.detectedAt);
      const newPeak = Math.max(currentPrice, tracked.peakPrice ?? currentPrice);
      const peakChanged = newPeak !== tracked.peakPrice;

      // 6h напоминание удалено — сопровождение теперь только по триггеру

      // oi_drop_cvd_confirmed удалён 2026-07-27: бэктест показал 62.5% ошибочных отмен
      // (5 из 8 токенов уходили >10% вверх после отмены). OI 30m временно уходит в -5%
      // при консолидации/ротации — краткосрочный шум не основание для отмены накопления.
      // Accumulation-сигналы теперь живут до stale_oi_vol или hard timeout (4д).
      const scoutNow = Date.now();
      const cooldowns = accumScoutCooldowns.get(tracked.id) ?? {
        volBuild: 0,
        oiBuild: 0,
      };

      // ── Accumulation scout: pre-fetch klines (используется и здесь, и в re-entry) ──
      let scoutVolMult = 0;
      let scoutSpotVol: number | null = null;
      try {
        const [klines, spotVol] = await Promise.all([
          getKlines(tracked.symbol, "30m", 21),
          getFsVolume(tracked.symbol)
            .then((r) => r.spotVolUsd24h ?? null)
            .catch(() => null),
        ]);
        scoutSpotVol = spotVol;
        if (klines.length >= 5) {
          const current = klines[klines.length - 1];
          const historical = klines.slice(0, -1);
          const close = parseFloat(current.close) || 0;
          const currentVol = (parseFloat(current.volume) || 0) * close;
          const avgVol =
            historical.reduce(
              (s, k) =>
                s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0),
              0,
            ) / historical.length;
          scoutVolMult = avgVol > 0 ? currentVol / avgVol : 0;
          // 2.1: спот-объём из prescanTracker (fallback на фьюч если нет данных)
          const _scoutPe = getPrescanEntry(tracked.symbol);
          const scoutSpotVolMult =
            _scoutPe?.spotVolAvg1h && _scoutPe?.lastSpotVol1h
              ? _scoutPe.lastSpotVol1h / _scoutPe.spotVolAvg1h
              : null;
          const effectiveScoutVol = scoutSpotVolMult ?? scoutVolMult;

          // 📡 Объём оживает (2x-3x): ранний сигнал до re-entry порога
          // DB-level guard вместо in-memory: оба процесса разделяют lastVolBuildAt
          if (
            effectiveScoutVol >= 2.0 &&
            effectiveScoutVol < RE_ENTRY_VOL_MULT
          ) {
            const volBuildThreshold = new Date(
              scoutNow - ACCUM_SCOUT_COOLDOWN_MS,
            );
            const claimedVol = await dbWriteStrict(
              "trackedSignal/accum-vol-building",
              () =>
                db
                  .update(trackedSignalsTable)
                  .set({ lastVolBuildAt: new Date(scoutNow) })
                  .where(
                    sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastVolBuildAt} IS NULL OR ${trackedSignalsTable.lastVolBuildAt} < ${volBuildThreshold})`,
                  )
                  .returning({ id: trackedSignalsTable.id }),
            );
            if (claimedVol.length > 0) {
              await broadcastPhoto(
                POSITION_UPDATE_IMG,
                msgAccumVolumeBuilding(
                  tracked,
                  currentPrice,
                  pnl,
                  scoutVolMult,
                  scoutSpotVol,
                  scoutSpotVolMult,
                ),
              );
              accumScoutCooldowns.set(tracked.id, {
                ...(accumScoutCooldowns.get(tracked.id) ?? cooldowns),
                volBuild: scoutNow,
              });
              logger.info(
                {
                  symbol: tracked.symbol,
                  futVolMult: scoutVolMult.toFixed(2),
                  spotVolMult: scoutSpotVolMult?.toFixed(2) ?? "n/a",
                  effectiveVol: effectiveScoutVol.toFixed(2),
                },
                "Watcher: ACCUM VOL BUILDING 📡",
              );
            }
          }
        }
      } catch {
        /* non-critical */
      }

      // 👀 OI растёт при боковике: CoinGlass check с 2ч кулдауном
      // DB-level guard вместо in-memory: оба процесса разделяют lastOiBuildAt
      if (Math.abs(pnl) <= 6) {
        try {
          const oiBuildThreshold = new Date(scoutNow - ACCUM_OI_COOLDOWN_MS);
          const cgOI = await getCoinglassOI(tracked.symbol, currentPrice);
          const oiChange = cgOI.oiChange30m ?? null;
          if (cgOI.available && oiChange !== null && oiChange >= 5) {
            const claimedOi = await dbWriteStrict(
              "trackedSignal/accum-oi-building",
              () =>
                db
                  .update(trackedSignalsTable)
                  .set({ lastOiBuildAt: new Date(scoutNow) })
                  .where(
                    sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastOiBuildAt} IS NULL OR ${trackedSignalsTable.lastOiBuildAt} < ${oiBuildThreshold})`,
                  )
                  .returning({ id: trackedSignalsTable.id }),
            );
            if (claimedOi.length > 0) {
              await broadcastPhoto(
                POSITION_UPDATE_IMG,
                msgAccumOiBuilding(tracked, currentPrice, pnl, oiChange),
              );
              accumScoutCooldowns.set(tracked.id, {
                ...(accumScoutCooldowns.get(tracked.id) ?? cooldowns),
                oiBuild: scoutNow,
              });
              logger.info(
                { symbol: tracked.symbol, oiChange },
                "Watcher: ACCUM OI BUILDING 👀",
              );
            }
          }
        } catch {
          /* non-critical */
        }
      }

      // ── Re-entry check (≥12h in accumulation, 3x объём) ──────────────────────
      const hoursInAccumulation =
        (Date.now() - tracked.updatedAt.getTime()) / 3_600_000;
      if (
        hoursInAccumulation >= ACCUMULATION_REENTRY_H &&
        scoutVolMult >= RE_ENTRY_VOL_MULT
      ) {
        // UPDATE первым — RETURNING гарантирует что только один процесс отправит
        const reEntryThreshold = new Date(
          Date.now() - ACCUMULATION_REENTRY_H * 3_600_000,
        );
        const claimedRE = await dbWriteStrict(
          "trackedSignal/accum-re-entry",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                status: "active",
                reEntryCount: (tracked.reEntryCount ?? 0) + 1,
                peakPrice: newPeak,
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('active', 'accumulation') AND ${trackedSignalsTable.updatedAt} < ${reEntryThreshold}`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimedRE.length > 0) {
          await broadcastPhoto(
            POSITION_UPDATE_IMG,
            msgReEntry(tracked, currentPrice, scoutVolMult, scoutSpotVol),
          );
          logger.info(
            { symbol: tracked.symbol, volMult: scoutVolMult },
            "Watcher: RE-ENTRY 🔄",
          );
          updated++;
        }
        continue;
      }

      // Update peak silently — GREATEST защищает от гонки двух воркер-процессов:
      // оба могут прочитать старое значение одновременно, но SQL max гарантирует
      // что в БД останется наибольший пик.
      if (peakChanged) {
        await dbWriteStrict("trackedSignal/accum-peak-update", () =>
          db
            .update(trackedSignalsTable)
            .set({
              peakPrice: sql`GREATEST(COALESCE(${trackedSignalsTable.peakPrice}, ${newPeak}), ${newPeak})`,
              updatedAt: new Date(),
            })
            .where(eq(trackedSignalsTable.id, tracked.id)),
        );
      }
    } catch (err) {
      logger.error(
        { err, symbol: tracked.symbol },
        "WatcherCycle: ошибка обработки сигнала (пропускаем)",
      );
    }
  }

  return { checked: accumSignals.length, updated };
}

// ── Daily report (21:00 МСК = 18:00 UTC) ─────────────────────────────────────
export async function sendDailyReport(
  targetChatId?: number | string,
  bypassDedupe = false,
): Promise<void> {
  // Атомарный guard: только один из 2 воркер-процессов отправляет плановый отчёт.
  // bypassDedupe=true используется при ручном вызове через дашборд (кнопка "Daily Report").
  if (!targetChatId && !bypassDedupe) {
    const claimed = await claimSettingsBroadcast({
      column: "lastDailyReportAt",
      windowMs: 10 * 60_000,
      label: "Daily report",
    });
    if (!claimed) return;
  }

  // Граница — полночь московского времени (UTC+3).
  // Было: Date.now() - 24h (скользящее окно) → одни и те же сигналы попадали в 2 отчёта подряд
  // если оба отчёта запустились с интервалом <24h (перезапуск, ручной вызов, дрейф расписания).
  // Теперь: строгая граница по календарному дню МСК — дубликаты исключены.
  const mskMidnightMs =
    Math.floor((Date.now() + 3 * 3_600_000) / 86_400_000) * 86_400_000 -
    3 * 3_600_000;
  const since = new Date(mskMidnightMs);

  const allOpen = await db
    .select()
    .from(trackedSignalsTable)
    .where(
      inArray(trackedSignalsTable.status, [
        "active",
        "accumulation",
        "in_run",
        "re_entry",
      ]),
    );

  const closedToday = await db
    .select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.closedAt} >= ${since}`);

  const profitsToday = closedToday.filter((s) => s.status === "profit");
  const buStopsToday = closedToday.filter((s) => s.status === "bu_stop");
  const stopsToday = closedToday.filter((s) => s.status === "stop_loss");
  const cancelledToday = closedToday.filter((s) => s.status === "cancelled");
  // Fetch live prices for open positions
  const priceMap = new Map<string, number>();
  if (allOpen.length > 0) {
    try {
      const tickers = (await getFutureTickers()) as any[];
      for (const t of tickers)
        priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
    } catch {
      /* non-critical — show without live price */
    }
  }

  const lines: string[] = [
    `📊 <b>DAILY REPORT — AltBullet Watcher</b>`,
    `<i>${new Date().toLocaleString("ru-RU", { timeZone: "Europe/Moscow", day: "2-digit", month: "long", year: "numeric" })}</i>`,
    ``,
  ];

  const symBase = (symbol: string) => symbol.replace("-USDT", "");
  const _priceRow = (s: TrackedSignal, curPrice: number | undefined) => {
    if (!s.entryPrice) return "";
    if (!curPrice) return ` | Вход: ${fmtP(s.entryPrice)}`;
    const pnl = ((curPrice - s.entryPrice) / s.entryPrice) * 100;
    const sign = pnl >= 0 ? "+" : "";
    return ` | ${fmtP(s.entryPrice)} → ${fmtP(curPrice)} (${sign}${pnl.toFixed(1)}%)`;
  };
  const priceRowClosed = (s: TrackedSignal) => {
    if (!s.entryPrice) return "";
    const exit = s.exitPrice ?? s.peakPrice;
    if (!exit) return ` | Вход: ${fmtP(s.entryPrice)}`;
    return ` | ${fmtP(s.entryPrice)} → ${fmtP(exit)} (${fmtPct(s.pnlPercent ?? 0)})`;
  };

  const patTag = (s: TrackedSignal) =>
    s.sentimentKey ? ` [${getPatternTgLabel(s.sentimentKey)}]` : "";

  // Единый форматтер — тот же что в рестарт-уведомлении, /status кнопке и 4ч апдейте
  lines.push(...formatOpenPositionLines(allOpen, priceMap));

  if (profitsToday.length > 0) {
    lines.push(`✅ <b>Закрыто в профит (${profitsToday.length}):</b>`);
    for (const s of profitsToday) {
      lines.push(
        `  • ${symBase(s.symbol)}${patTag(s)} ${tickerTag(s.symbol)}${priceRowClosed(s)}`,
      );
    }
    lines.push(``);
  }

  if (buStopsToday.length > 0) {
    lines.push(`🛡 <b>Стоп в БУ (${buStopsToday.length}):</b>`);
    for (const s of buStopsToday) {
      lines.push(
        `  • ${symBase(s.symbol)}${patTag(s)} ${tickerTag(s.symbol)}${priceRowClosed(s)}`,
      );
    }
    lines.push(``);
  }

  if (stopsToday.length > 0) {
    lines.push(`❌ <b>Стоп-лосс (${stopsToday.length}):</b>`);
    for (const s of stopsToday) {
      lines.push(
        `  • ${symBase(s.symbol)}${patTag(s)} ${tickerTag(s.symbol)}${priceRowClosed(s)}`,
      );
    }
    lines.push(``);
  }

  if (cancelledToday.length > 0) {
    lines.push(`🚫 <b>Отменено сегодня (${cancelledToday.length}):</b>`);
    for (const s of cancelledToday) {
      lines.push(
        `  • ${symBase(s.symbol)}${patTag(s)} ${tickerTag(s.symbol)}${priceRowClosed(s)}`,
      );
    }
    lines.push(``);
  }

  if (allOpen.length === 0 && closedToday.length === 0) {
    lines.push(`Сегодня активных сигналов нет.`);
  }

  lines.push(``, `#ежедневный_отчет`);

  const fullText = lines.join("\n");
  await sendPhotoTo(DAILY_REPORT_IMG, fullText, targetChatId);
  logger.info("Daily report sent");
}

// ── Weekly digest (09:00 МСК = 06:00 UTC, воскресенье) ───────────────────────
export async function sendWeeklyDigest(
  targetChatId?: number | string,
  bypassDedupe = false,
): Promise<void> {
  if (!targetChatId && !bypassDedupe) {
    const claimed = await claimSettingsBroadcast({
      column: "lastWeeklyDigestAt",
      windowMs: 10 * 60_000,
      label: "Weekly digest",
    });
    if (!claimed) return;
  }

  const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const all = await db
    .select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.detectedAt} >= ${oneWeekAgo}`);

  const profits = all.filter((s) => s.status === "profit");
  const buStops = all.filter((s) => s.status === "bu_stop");
  const stops = all.filter((s) => s.status === "stop_loss");
  const cancelled = all.filter((s) => s.status === "cancelled");
  const accum = all.filter(
    (s) => s.status === "accumulation" || s.status === "re_entry",
  );
  const inRun = all.filter((s) => s.status === "in_run");
  const breakevens = all.filter((s) => s.status === "breakeven");
  if (all.length === 0) {
    await sendTo(
      "📊 <b>Еженедельный дайджест</b>\n\nНа этой неделе сигналов не было.",
      targetChatId,
    );
    return;
  }

  const breakEvenAvgPnl =
    breakevens.length > 0
      ? breakevens.reduce((s, x) => s + (x.pnlPercent ?? 0), 0) /
        breakevens.length
      : null;

  // All profitable trades (profit + bu_stop) sorted by pnl desc
  const allWins = [...profits, ...buStops].sort(
    (a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0),
  );
  const medals = ["🥇", "🥈", "🥉"];
  const allWinLines = allWins.map((s, i) => {
    const { str } = hoursAndDays(s.detectedAt);
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit = s.exitPrice ?? s.peakPrice;
    const priceStr = entry && exit ? ` (${entry} → ${fmtP(exit)})` : "";
    const pat = s.sentimentKey ? ` [${getPatternTgLabel(s.sentimentKey)}]` : "";
    const isBu = s.status === "bu_stop";
    const prefix = i < 3 ? medals[i] : isBu ? "🛡" : "✅";
    return `${prefix} $${s.symbol.replace("-USDT", "")}${pat}${priceStr} — ${fmtPct(s.pnlPercent ?? 0)} (${str} назад)`;
  });

  // bu_stop counts as profit for win rate and avg profit calculations
  const winRate =
    profits.length + buStops.length + stops.length > 0
      ? Math.round(
          ((profits.length + buStops.length) /
            (profits.length + buStops.length + stops.length)) *
            100,
        )
      : null;
  const allProfits = [...profits, ...buStops];
  const avgProfit =
    allProfits.length > 0
      ? allProfits.reduce((s, x) => s + (x.pnlPercent ?? 0), 0) /
        allProfits.length
      : null;

  const wFmtRow = (s: TrackedSignal) => {
    const base = `$${s.symbol.replace("-USDT", "")}`;
    const pattern = s.sentimentKey
      ? ` [${getPatternTgLabel(s.sentimentKey)}]`
      : "";
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit = s.exitPrice ?? s.peakPrice;
    const exitFmt = exit ? fmtP(exit) : null;
    const pnl = s.pnlPercent ?? 0;
    const sign = pnl >= 0 ? "+" : "";
    const priceStr =
      entry && exitFmt
        ? ` (${entry} → ${exitFmt})`
        : entry
          ? ` (Вход: ${entry})`
          : "";
    return `  • ${base}${pattern}${priceStr} — ${sign}${pnl.toFixed(1)}%`;
  };

  // Stop-loss details
  const stopLines = [...stops]
    .sort((a, b) => (a.pnlPercent ?? 0) - (b.pnlPercent ?? 0))
    .map((s) => wFmtRow(s));

  // Cancelled details
  const cancelLines = [...cancelled]
    .sort((a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0))
    .map((s) => wFmtRow(s));

  const lines = [
    `🏆 <b>ИТОГИ НЕДЕЛИ: TOP BULLETS</b>`,
    ``,
    ...(allWinLines.length > 0
      ? allWinLines
      : ["Закрытых в профит сигналов нет"]),
  ];

  if (stopLines.length > 0) {
    lines.push(``, `❌ <b>Стоп-лоссы (${stops.length}):</b>`);
    lines.push(...stopLines);
  }

  if (cancelLines.length > 0) {
    lines.push(``, `🚫 <b>Отменённые сигналы (${cancelled.length}):</b>`);
    lines.push(...cancelLines);
  }

  lines.push(
    ``,
    `📊 <b>Статистика:</b>`,
    `✅ Профит: ${profits.length} сигналов`,
    `🛡 Стоп в БУ: ${buStops.length} сигналов`,
    `🚀 В полёте: ${inRun.length} сигналов`,
    `⏳ В накоплении: ${accum.length} сигналов`,
    `❌ Стоп-лосс: ${stops.length} сигналов`,
    `🚫 Отменено: ${cancelled.length} сигналов`,
    ...(breakevens.length > 0
      ? [
          `⏱ Таймаут (4д): ${breakevens.length} сделок${breakEvenAvgPnl !== null ? ` | ср. P&L: ${fmtPct(breakEvenAvgPnl)}` : ""}`,
        ]
      : []),
    ...(avgProfit !== null
      ? [`📈 Средний профит (вкл. БУ): ${fmtPct(avgProfit)}`]
      : []),
    ...(winRate !== null ? [`🎯 Win Rate (вкл. БУ): ${winRate}%`] : []),
    ``,
    `<i>Мы видим деньги там, где другие видят тишину.</i>`,
    ``,
    `#еженедельный_отчет`,
  );

  const fullText = lines.join("\n");
  await sendPhotoTo(WEEKLY_REPORT_IMG, fullText, targetChatId);
  logger.info({ total: all.length }, "Weekly digest sent");
}

// ── Monthly digest (30 days stats) ───────────────────────────────────────────
export async function sendMonthlyDigest(
  targetChatId?: number | string,
): Promise<void> {
  if (!targetChatId) {
    const claimed = await claimSettingsBroadcast({
      column: "lastMonthlyDigestAt",
      windowMs: 10 * 60_000,
      label: "Monthly digest",
    });
    if (!claimed) return;
  }

  const oneMonthAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

  const all = await db
    .select()
    .from(trackedSignalsTable)
    .where(sql`${trackedSignalsTable.detectedAt} >= ${oneMonthAgo}`);

  const profits = all.filter((s) => s.status === "profit");
  const buStopsM = all.filter((s) => s.status === "bu_stop");
  const stops = all.filter((s) => s.status === "stop_loss");
  const inRun = all.filter((s) => s.status === "in_run");
  const accum = all.filter(
    (s) => s.status === "accumulation" || s.status === "re_entry",
  );
  const breakevens = all.filter((s) => s.status === "breakeven");
  const cancelledM = all.filter((s) => s.status === "cancelled");
  if (all.length === 0) {
    await sendTo(
      "📆 <b>Ежемесячный дайджест</b>\n\nЗа последние 30 дней сигналов не было.",
      targetChatId,
    );
    return;
  }

  const sorted = [...profits].sort(
    (a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0),
  );
  const medals = ["🥇", "🥈", "🥉", "🏅", "🏅"];
  const topProfits = sorted.slice(0, 5);
  const topLines = topProfits.map((s, i) => {
    const { str } = hoursAndDays(s.detectedAt);
    const pat = s.sentimentKey ? ` [${getPatternTgLabel(s.sentimentKey)}]` : "";
    return `${medals[i] ?? "🏅"} $${s.symbol.replace("-USDT", "")}${pat} — ${fmtPct(s.pnlPercent ?? 0)} (${str} назад)`;
  });

  const mFmtRow = (s: (typeof all)[0]) => {
    const base = `$${s.symbol.replace("-USDT", "")}`;
    const pattern = s.sentimentKey
      ? ` [${getPatternTgLabel(s.sentimentKey)}]`
      : "";
    const entry = s.entryPrice ? fmtP(s.entryPrice) : null;
    const exit = s.exitPrice ?? s.peakPrice;
    const exitFmt = exit ? fmtP(exit) : null;
    const pnl = s.pnlPercent ?? 0;
    const sign = pnl >= 0 ? "+" : "";
    const priceStr =
      entry && exitFmt
        ? ` (${entry} → ${exitFmt})`
        : entry
          ? ` (Вход: ${entry})`
          : "";
    return `  • ${base}${pattern}${priceStr} — ${sign}${pnl.toFixed(1)}%`;
  };

  const breakEvenAvgPnlM =
    breakevens.length > 0
      ? breakevens.reduce((s, x) => s + (x.pnlPercent ?? 0), 0) /
        breakevens.length
      : null;

  const moonshots = sorted.filter((s) => (s.pnlPercent ?? 0) >= 30);
  const winRate =
    profits.length + buStopsM.length + stops.length > 0
      ? Math.round(
          ((profits.length + buStopsM.length) /
            (profits.length + buStopsM.length + stops.length)) *
            100,
        )
      : null;
  const allProfitsM = [...profits, ...buStopsM];
  const avgProfit =
    allProfitsM.length > 0
      ? allProfitsM.reduce((s, x) => s + (x.pnlPercent ?? 0), 0) /
        allProfitsM.length
      : null;

  const lines = [
    `📆 <b>ИТОГИ МЕСЯЦА: BULLET-СТАТИСТИКА</b>`,
    `<i>Последние 30 дней</i>`,
    ``,
    ...(topLines.length > 0
      ? [`🏆 <b>Топ профитов:</b>`, ...topLines]
      : ["Закрытых в профит сигналов нет"]),
  ];

  if (moonshots.length > 0) {
    lines.push(``, `🚀 <b>Moonshots (>+30%):</b> ${moonshots.length} шт`);
    for (const s of moonshots.slice(0, 5)) {
      const peak = computePeakPnl(s);
      const pat = s.sentimentKey
        ? ` [${getPatternTgLabel(s.sentimentKey)}]`
        : "";
      lines.push(
        `  • ${s.symbol.replace("-USDT", "")}${pat} — пик: +${peak.toFixed(1)}% | итог: ${fmtPct(s.pnlPercent ?? 0)}`,
      );
    }
  }

  // Stop-loss details
  if (stops.length > 0) {
    lines.push(``, `❌ <b>Стоп-лоссы (${stops.length}):</b>`);
    [...stops]
      .sort((a, b) => (a.pnlPercent ?? 0) - (b.pnlPercent ?? 0))
      .forEach((s) => lines.push(mFmtRow(s)));
  }

  // Breakeven details
  if (breakevens.length > 0) {
    lines.push(``, `⏱ <b>Таймаут/Безубыток (${breakevens.length}):</b>`);
    breakevens.forEach((s) => lines.push(mFmtRow(s)));
  }

  // BU-stop details
  if (buStopsM.length > 0) {
    lines.push(``, `🛡 <b>Стоп в БУ (${buStopsM.length}):</b>`);
    buStopsM.forEach((s) => lines.push(mFmtRow(s)));
  }

  // Cancelled details
  if (cancelledM.length > 0) {
    lines.push(``, `🚫 <b>Отменённые сигналы (${cancelledM.length}):</b>`);
    [...cancelledM]
      .sort((a, b) => (b.pnlPercent ?? 0) - (a.pnlPercent ?? 0))
      .slice(0, 20)
      .forEach((s) => lines.push(mFmtRow(s)));
    if (cancelledM.length > 20)
      lines.push(`  ... и ещё ${cancelledM.length - 20}`);
  }

  lines.push(
    ``,
    `📊 <b>Статистика за 30 дней:</b>`,
    `📡 Всего сигналов: ${all.length}`,
    `✅ Профит: ${profits.length}`,
    `🛡 Стоп в БУ: ${buStopsM.length}`,
    `🚀 В полёте: ${inRun.length}`,
    `⏳ В накоплении: ${accum.length}`,
    `❌ Стоп-лосс: ${stops.length}`,
    `🚫 Отменено: ${cancelledM.length}`,
    ...(breakevens.length > 0
      ? [
          `⏱ Таймаут (4д, нейтр.): ${breakevens.length} сделок${breakEvenAvgPnlM !== null ? ` | ср. P&L: ${fmtPct(breakEvenAvgPnlM)}` : ""}`,
        ]
      : []),
    ...(avgProfit !== null
      ? [`📈 Средний профит (вкл. БУ): ${fmtPct(avgProfit)}`]
      : []),
    ...(winRate !== null ? [`🎯 Win Rate (вкл. БУ): ${winRate}%`] : []),
    ``,
    `#ежемесячный_отчет`,
  );

  const fullText = lines.join("\n");
  await sendPhotoTo(MONTHLY_REPORT_IMG, fullText, targetChatId);
  logger.info({ total: all.length }, "Monthly digest sent");
}

// ── Market Health: OI + Volume snapshot для апдейтов ─────────────────────────
async function fetchMarketHealth(
  symbol: string,
  priceUsd?: number | null,
): Promise<{
  oiPct: number | null;
  cgTurnover: number | null;
  fundingRate: number | null;
  spotVol24h: number | null;
  futVol24h: number | null;
  futSpotRatio: number | null;
}> {
  let oiPct: number | null = null;
  let cgTurnover: number | null = null;
  let fundingRate: number | null = null;
  let spotVol24h: number | null = null;
  let futVol24h: number | null = null;
  let futSpotRatio: number | null = null;
  try {
    const [cgOI, cgFunding, fsVol] = await Promise.all([
      getCoinglassOI(symbol, priceUsd).catch(() => null),
      getCoinglassAggregateFunding(symbol).catch(() => null),
      getFsVolume(symbol).catch(() => null),
    ]);
    if (cgOI?.available) {
      oiPct = cgOI.oiChange30m ?? null;
      // cgTurnover = futVolUsd24h / oiUsd — доля дневного фьюч-объёма относительно OI.
      // < 0.05 = мёртвый рынок, 0.08–0.15 = норма, >= 0.15 = активно
      if (fsVol?.futVolUsd24h && cgOI.oiUsd && cgOI.oiUsd > 0) {
        cgTurnover = fsVol.futVolUsd24h / cgOI.oiUsd;
      }
    }
    fundingRate = cgFunding;
    spotVol24h = fsVol?.spotVolUsd24h ?? null;
    futVol24h = fsVol?.futVolUsd24h ?? null;
    futSpotRatio = fsVol?.futSpotRatio ?? null;
  } catch {
    /* non-critical */
  }
  return {
    oiPct,
    cgTurnover,
    fundingRate,
    spotVol24h,
    futVol24h,
    futSpotRatio,
  };
}

// ── Fast cycle (every 2 min): active + in_run for stop-loss / first-target / trailing ──────────
async function runInRunFastCycle(): Promise<void> {
  // Check active, in_run AND re_entry signals every 2 min for fast stop-loss and target detection
  let fastSignals: (typeof trackedSignalsTable.$inferSelect)[] = [];
  // Retry loop: Neon connection pool may be temporarily exhausted by scanner
  // 3 attempts × 5s delay — scanner batch typically releases within ~3s
  const fastFetch = await dbReadWithRetry("FastCycle", () =>
    db
      .select()
      .from(trackedSignalsTable)
      .where(
        inArray(trackedSignalsTable.status, [
          "active",
          "in_run",
          "re_entry",
          "accumulation",
        ]),
      ),
  );
  if (!fastFetch.ok) return;
  fastSignals = fastFetch.value;

  logger.info(
    {
      fastSignalsCount: fastSignals.length,
      symbols: fastSignals.map((s) => ({
        symbol: s.symbol,
        status: s.status,
        pnl: s.pnlPercent,
      })),
    },
    "DEBUG: fast cycle snapshot",
  );

  logger.info(
    { count: fastSignals.length, symbols: fastSignals.map((s) => s.symbol) },
    "FastCycle: начало цикла",
  );
  if (fastSignals.length === 0) return;

  let tickers: { symbol: string; lastPrice: string }[] = [];
  let fastFetchOk = false;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      tickers = (await getFutureTickers()) as any[];
      fastFetchOk = true;
      break;
    } catch (err) {
      logger.warn(
        { err, attempt },
        `FastCycle: BingX fetch attempt ${attempt}/2 failed`,
      );
      if (attempt < 2) await new Promise((r) => setTimeout(r, 3000));
    }
  }
  if (!fastFetchOk) {
    logger.error(
      "FastCycle: не удалось получить цены — стоп-лоссы пропущены в этом цикле",
    );
    return;
  }

  const priceMap = new Map<string, number>();
  const knownOnBingX = new Set<string>(); // все символы из BingX тикеров, даже с ценой 0
  for (const t of tickers) {
    knownOnBingX.add(t.symbol);
    const p = parseFloat(t.lastPrice) || 0;
    if (p > 0) priceMap.set(t.symbol, p);
  }

  for (const tracked of fastSignals) {
    try {
      const currentPrice = priceMap.get(tracked.symbol);
      if (!currentPrice) {
        // Если символ ЕСТЬ в тикерах BingX но цена = 0 — временный сбой API.
        // Не отменяем — ждём следующего цикла. no_price_30m применяется только
        // если символ ПОЛНОСТЬЮ отсутствует в списке тикеров BingX.
        if (knownOnBingX.has(tracked.symbol)) {
          logger.debug(
            { symbol: tracked.symbol },
            "FastCycle: цена 0 на BingX — пропускаем цикл (не отмена)",
          );
          continue;
        }
        // Нет цены в течение >30 минут после обнаружения — монета недоступна на BingX.
        // Авто-отмена с уведомлением. Случай BingX down обработан выше (fastFetchOk gate).
        const ageMs = Date.now() - tracked.detectedAt.getTime();
        const NO_PRICE_CANCEL_MS = 30 * 60_000;
        if (ageMs > NO_PRICE_CANCEL_MS) {
          const claimedNP = await dbWriteStrict(
            "trackedSignal/no-price-cancel",
            () =>
              db
                .update(trackedSignalsTable)
                .set({
                  status: "cancelled",
                  cancelReason: "no_price_30m",
                  closedAt: new Date(),
                  updatedAt: new Date(),
                })
                .where(
                  sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('active','in_run','re_entry')`,
                )
                .returning({ id: trackedSignalsTable.id }),
          );
          if (claimedNP.length > 0) {
            const base = tracked.symbol.replace("-USDT", "");
            const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT.P`;
            const msg = [
              `❌ <b>Позиция отменена — цена недоступна</b>`,
              ``,
              `<b>${tracked.symbol}</b>`,
              `Цена не найдена на BingX более ${Math.round(ageMs / 60_000)}м.`,
              `Цена недоступна на BingX — торги приостановлены или символ снят с торгов.`,
              ``,
              `<a href="${tvUrl}">График</a>`,
              ``,
              fmtPattern(tracked),
              `${tickerTag(tracked.symbol)} ${patternTag(tracked.sentimentKey)} #cancelled`,
            ]
              .filter(Boolean)
              .join("\n");
            await broadcastPhoto(CANCEL_IMG, msg).catch((err) => {
              logger.warn(
                { err, symbol: tracked.symbol },
                "no_price_30m: TG broadcast failed",
              );
            });
            logger.warn(
              { symbol: tracked.symbol, ageMin: Math.round(ageMs / 60_000) },
              "⚠️ FastCycle: no BingX price — signal auto-cancelled",
            );
          }
        }
        continue;
      }

      const pnl = computePnl(tracked, currentPrice);
      const newPeak = Math.max(currentPrice, tracked.peakPrice ?? currentPrice);
      const peakChanged = newPeak !== tracked.peakPrice;

      logger.info(
        {
          symbol: tracked.symbol,
          status: tracked.status,
          pnl: pnl.toFixed(2),
          currentPrice,
          peakChanged,
        },
        "FastCycle: обработка сигнала",
      );
      // Регистрируем символ для per-symbol SNF supplement (заполнит map для UI)
      registerSnfSymbol(tracked.symbol);

      const exitProfile = getExitProfile(tracked.sentimentKey);
      const firstTarget = exitProfile.firstTarget;
      const trailingActivation = exitProfile.trailingActivation;

      // Трейлинг активируется только при достижении trailingActivation от входа
      const peakPnlNow = computePnl(tracked, newPeak);
      const prevPeakPnl = tracked.peakPrice
        ? computePnl(tracked, tracked.peakPrice)
        : 0;
      const trailingActive = peakPnlNow >= trailingActivation;
      const trailingStop = newPeak * (1 - exitProfile.trailingGap / 100);
      // Трейлинг сработал: только если активен и цена пробила уровень вниз
      const trailingHit = trailingActive && currentPrice <= trailingStop;
      // Трейлинг только что активировался в этом цикле (пик пересёк порог)
      const trailingJustActivated =
        tracked.status === "in_run" &&
        prevPeakPnl < trailingActivation &&
        peakPnlNow >= trailingActivation;

      // ── Сохраняем peak НЕМЕДЛЕННО — до любого continue ──────────────────────
      // Без этого continue в stale-check / OI-extended window пропускают строки
      // 1725-1733 и peak никогда не записывается в БД. Монета бьёт +10%, но
      // следующий цикл читает peak=entry из БД → trailing stop не активируется,
      // milestone не шлётся, сигнал отменяется с peak=entry.
      // GREATEST защищает от гонки двух воркер-процессов.
      if (peakChanged) {
        await dbWriteStrict("trackedSignal/fast-peak-update", () =>
          db
            .update(trackedSignalsTable)
            .set({
              peakPrice: sql`GREATEST(COALESCE(${trackedSignalsTable.peakPrice}, ${newPeak}), ${newPeak})`,
              ...(trailingActive ? { trailingStopLevel: trailingStop } : {}),
              updatedAt: new Date(),
            })
            .where(eq(trackedSignalsTable.id, tracked.id)),
        );
      }

      const ageMs = Date.now() - tracked.detectedAt.getTime();
      const ageHours = ageMs / 3_600_000;
      const ageDays = ageHours / 24;

      // Hourly update удалён — сопровождение теперь только по триггеру (4h блок ниже)

      // Per-pattern timeout → Breakeven (нейтральный/плюс) или Stop Loss (цена ниже входа)
      // whale_alert: 14д (киты входят рано); остальные: 4д
      if (ageDays >= getMaxWatchDays(tracked.sentimentKey)) {
        const isNegative = pnl < 0;
        const timeoutStatus = isNegative ? "stop_loss" : "breakeven";
        const claimedBeFast = await dbWriteStrict(
          "trackedSignal/fast-timeout-close",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                status: timeoutStatus,
                exitPrice: currentPrice,
                pnlPercent: pnl,
                closedAt: new Date(),
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('active','in_run','re_entry')`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimedBeFast.length > 0) {
          if (isNegative) {
            await broadcastPhoto(
              BREAKEVEN_STOP_IMG,
              msgBreakevenAsStopLoss(tracked, currentPrice, pnl),
            );
            logger.info(
              { symbol: tracked.symbol, pnl },
              "FastCycle: TIMEOUT STOP LOSS (4d, below entry)",
            );
          } else {
            await broadcastPhoto(
              TRAILING_STOP_IMG,
              msgBreakeven(tracked, currentPrice, pnl),
            );
            logger.info(
              { symbol: tracked.symbol, pnl },
              "FastCycle: BREAKEVEN (4d, at/above entry)",
            );
          }
        }
        continue;
      }

      // ── STOP-LOSS ПРИОРИТЕТ: проверяется ДО stale-cancel ────────────────────
      // КРИТИЧНО: stale-cancel "market health" блок содержит continue-ы ("рынок жив →
      // продлеваем"), которые ПРОПУСКАЮТ строку ~2368. Без этого раннего чека активный
      // сигнал может уйти в -18% и ниже пока рынок "здоров" по метрикам OI/стакана.
      // NO-TOUCH PERIOD: бэктест 90д показал 67.8% преждевременных стопов (отскок >5%
      // в течение 3д). Стоп не срабатывает пока ageMs < getNoTouchStopMs (2ч / 4ч для whale).
      if (
        (tracked.status === "active" ||
          tracked.status === "accumulation" ||
          tracked.status === "re_entry") &&
        ageMs >= getNoTouchStopMs(tracked.sentimentKey) &&
        pnl <= -effStopPct(tracked)
      ) {
        const claimedSLEarly = await dbWriteStrict(
          "trackedSignal/fast-early-stop-loss",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                status: "stop_loss",
                exitPrice: currentPrice,
                pnlPercent: pnl,
                closedAt: new Date(),
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('active','accumulation','re_entry')`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimedSLEarly.length > 0) {
          await broadcastPhoto(
            STOPLOSS_IMG,
            msgStopLoss(tracked, currentPrice, pnl),
          );
          logger.info(
            { symbol: tracked.symbol, status: tracked.status, pnl },
            "FastCycle: STOP LOSS (early check) ❌",
          );
        }
        continue;
      }

      // ── STALE SIGNAL: динамическая авто-отмена на основе OI ─────────────────
      // Логика: НЕ ждём 6-8ч статического окна.
      // С 1ч после входа — проверяем CoinGlass OI каждый цикл (~2 мин).
      // Если OI растёт (+2%+ за 30m/5m) → накопление идёт, продлеваем сигнал.
      // Отменяем ТОЛЬКО когда OI иссяк + рынок мёртв одновременно.
      // Статистика: 0 прибыльных из 98 сигналов где peak < 2% к моменту отмены.
      if (
        tracked.status === "active" &&
        tracked.peakPrice != null &&
        tracked.entryPrice != null &&
        tracked.entryPrice > 0
      ) {
        const peakPct =
          ((newPeak - tracked.entryPrice) / tracked.entryPrice) * 100;
        if (peakPct < 2.0) {
          // whale_alert: отмены отключены — только Breakeven по тайм-ауту (14д) и стоп-лосс
          if (tracked.sentimentKey === "whale_alert") continue;

          // ── Pattern-specific grace periods ──────────────────────────────────
          if (tracked.sentimentKey === "spot_vol_accumulation") {
            // spot_vol_accumulation: 2ч OI Watch перед стейл-чеком
            if (ageHours < 2.0) continue;
            const vbHold = _vbStaleHoldUntil.get(tracked.id);
            if (vbHold != null && Date.now() < vbHold) continue; // в периоде расширения до 5ч
            if (vbHold == null) {
              // Первый раз достигли 2ч — проверяем OI1h для решения о расширении
              try {
                const vbCgOI = await getCoinglassOI(
                  tracked.symbol,
                  currentPrice,
                );
                const vbOi1h = vbCgOI.oiChange1h ?? 0;
                if (vbOi1h >= 0) {
                  // OI не снижается → продлеваем до 5ч от момента детекта
                  const holdUntil =
                    tracked.detectedAt.getTime() + 5 * 3_600_000;
                  _vbStaleHoldUntil.set(tracked.id, holdUntil);
                  logger.info(
                    {
                      symbol: tracked.symbol,
                      oi1h: vbOi1h.toFixed(1),
                      ageH: ageHours.toFixed(1),
                    },
                    "⏳ VB STALE: OI1h ≥ 0% → расширяем окно до 5ч",
                  );
                  continue;
                }
                // OI отрицательный → запускаем обычный стейл-чек (помечаем что проверили)
                _vbStaleHoldUntil.set(tracked.id, 0);
                logger.info(
                  {
                    symbol: tracked.symbol,
                    oi1h: vbOi1h.toFixed(1),
                    ageH: ageHours.toFixed(1),
                  },
                  "⚠️ VB STALE: OI1h < 0% → запускаем стейл-чек",
                );
              } catch {
                continue; // API ошибка — ждём следующий цикл
              }
            }
            // vbHold = 0 (не продлено) или истёк → идём в обычный стейл-чек
          } else if (tracked.sentimentKey?.startsWith("volume_breakout")) {
            // volume_breakout*: бэктест 70.8% hit+10% после stale отмены → расширяем окно.
            // 4ч initial grace (было 1ч). При OI1h ≥ 0 → держим до 10ч (было 5ч).
            if (ageHours < 4.0) continue;
            const vbvHold = _vbStaleHoldUntil.get(tracked.id);
            if (vbvHold != null && Date.now() < vbvHold) continue;
            if (vbvHold == null) {
              try {
                const vbvCgOI = await getCoinglassOI(
                  tracked.symbol,
                  currentPrice,
                );
                const vbvOi1h = vbvCgOI.oiChange1h ?? 0;
                if (vbvOi1h >= 0) {
                  // OI не снижается → держим до 10ч от момента детекта
                  const holdUntil =
                    tracked.detectedAt.getTime() + 10 * 3_600_000;
                  _vbStaleHoldUntil.set(tracked.id, holdUntil);
                  logger.info(
                    {
                      symbol: tracked.symbol,
                      pattern: tracked.sentimentKey,
                      oi1h: vbvOi1h.toFixed(1),
                      ageH: ageHours.toFixed(1),
                    },
                    "⏳ VBV STALE: OI1h ≥ 0% → расширяем окно до 10ч",
                  );
                  continue;
                }
                _vbStaleHoldUntil.set(tracked.id, 0);
                logger.info(
                  {
                    symbol: tracked.symbol,
                    pattern: tracked.sentimentKey,
                    oi1h: vbvOi1h.toFixed(1),
                    ageH: ageHours.toFixed(1),
                  },
                  "⚠️ VBV STALE: OI1h < 0% → запускаем стейл-чек",
                );
              } catch {
                continue;
              }
            }
            // hold = 0 (не продлено) или истёк → идём в обычный стейл-чек
          } else if (tracked.sentimentKey === "hidden_accumulation") {
            // hidden_accumulation: бэктест 49% hit+10% после stale отмены → расширяем окно.
            // 4ч initial grace (было 1ч). При OI1h ≥ 0 → держим до 8ч.
            if (ageHours < 4.0) continue;
            const haHold = _haStaleHoldUntil.get(tracked.id);
            if (haHold != null && Date.now() < haHold) continue;
            if (haHold == null) {
              try {
                const haCgOI = await getCoinglassOI(
                  tracked.symbol,
                  currentPrice,
                );
                const haOi1h = haCgOI.oiChange1h ?? 0;
                if (haOi1h >= 0) {
                  // OI не снижается → держим до 8ч от момента детекта
                  const holdUntil =
                    tracked.detectedAt.getTime() + 8 * 3_600_000;
                  _haStaleHoldUntil.set(tracked.id, holdUntil);
                  logger.info(
                    {
                      symbol: tracked.symbol,
                      oi1h: haOi1h.toFixed(1),
                      ageH: ageHours.toFixed(1),
                    },
                    "⏳ HA STALE: OI1h ≥ 0% → расширяем окно до 8ч",
                  );
                  continue;
                }
                _haStaleHoldUntil.set(tracked.id, 0);
                logger.info(
                  {
                    symbol: tracked.symbol,
                    oi1h: haOi1h.toFixed(1),
                    ageH: ageHours.toFixed(1),
                  },
                  "⚠️ HA STALE: OI1h < 0% → запускаем стейл-чек",
                );
              } catch {
                continue;
              }
            }
            // hold = 0 (не продлено) или истёк → идём в обычный стейл-чек
          } else if (tracked.sentimentKey === "liquidation_cascade") {
            // liquidation_cascade: 5ч grace — каскад часто реализуется медленнее
            // (KAITO +13%, EPIC +10% упущены из-за 3ч stale cancel)
            if (ageHours < 5.0) continue;
          } else {
            // Все остальные паттерны: 1ч grace
            if (ageHours < 1.0) continue;
          }

          // Hard max-age 72ч: если peak < 2% и сигнал старше 3 дней — отмена без доп. проверок
          // Grace period: в первые 30 мин после рестарта — пропускаем. FastCycle должен
          // успеть перевести сигнал в in_run или обновить peak прежде чем принять решение.
          if (Date.now() - SERVER_STARTED_AT < RESTART_GRACE_MS) {
            logger.info(
              { symbol: tracked.symbol, ageH: ageHours.toFixed(1) },
              "⏳ STALE SKIP: restart grace period — stale cancel отложен на 30 мин",
            );
            continue;
          }

          // ── Pre-fetch CoinGlass OI для NetChange guard ─────────────────────────
          // getCoinglassOI кэширует 5 мин — повторный вызов в Step 1 ниже бесплатен.
          // Вычисляем netChangePctMcap здесь один раз, используем во всех шагах отмены.
          let _preCgOI: Awaited<ReturnType<typeof getCoinglassOI>> | null =
            null;
          try {
            _preCgOI = await getCoinglassOI(tracked.symbol, currentPrice);
          } catch {
            /* ignore */
          }
          const _netChangePctMcap = ((): number | null => {
            const oiUsd = _preCgOI?.oiUsd ?? null;
            const oi4h = _preCgOI?.oiChange4h ?? null;
            const mcap = tracked.marketCapUsd ?? null;
            if (
              oiUsd === null ||
              oi4h === null ||
              oi4h <= 0 ||
              mcap === null ||
              mcap <= 0
            )
              return null;
            return ((oiUsd * oi4h) / 100 / mcap) * 100;
          })();

          // ── NetChange guard: защита от отмены при значительном притоке в OI vs mCap ──
          // Применяется ДО всех дальнейших шагов отмены (включая 72h hard cancel).
          if (
            _netChangePctMcap !== null &&
            _netChangePctMcap >= NETCHANGE_MCAP_THRESHOLD
          ) {
            logger.info(
              {
                symbol: tracked.symbol,
                ageH: ageHours.toFixed(1),
                oi4hPct: (_preCgOI?.oiChange4h ?? 0).toFixed(1),
                netChangePctMcap: _netChangePctMcap.toFixed(2),
                mcapUsd: tracked.marketCapUsd,
              },
              "⏳ NETCHANGE GUARD: значительный OI-приток vs mCap — откладываем отмену",
            );
            continue;
          }

          if (ageHours >= 72) {
            // ── NETCHANGE GATE (72h): отмена только при двустороннем оттоке ──────
            {
              const _72futOI30m = _preCgOI?.oiChange30m ?? null;
              const _72futBothNeg = _72futOI30m !== null && _72futOI30m < 0;
              let _72spotBothNeg = false;
              try {
                const _72spot = await getSpotCvdMtf(tracked.symbol);
                _72spotBothNeg =
                  _72spot.available === true &&
                  _72spot.cvd30m === false &&
                  _72spot.cvd1h === false;
              } catch {
                /* данные недоступны → не отменяем */
              }
              if (!_72futBothNeg || !_72spotBothNeg) {
                logger.info(
                  {
                    symbol: tracked.symbol,
                    ageH: ageHours.toFixed(1),
                    futOI30m:
                      _72futOI30m != null ? _72futOI30m.toFixed(2) : "n/a",
                    futBothNeg: _72futBothNeg,
                    spotBothNeg: _72spotBothNeg,
                  },
                  "⏳ NETCHANGE GATE (72h): не все TF в оттоке — откладываем hard cancel",
                );
                continue;
              }
            }
            const _oldIsStopLoss = pnl <= -CANCEL_STOP_LOSS_PCT;
            const claimedOld = await dbWriteStrict(
              "trackedSignal/stale-72h-cancel",
              () =>
                db
                  .update(trackedSignalsTable)
                  .set({
                    status: _oldIsStopLoss ? "stop_loss" : "cancelled",
                    exitPrice: currentPrice,
                    pnlPercent: pnl,
                    cancelReason: "stale_72h",
                    closedAt: new Date(),
                    updatedAt: new Date(),
                  })
                  .where(
                    sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`,
                  )
                  .returning({ id: trackedSignalsTable.id }),
            );
            if (claimedOld.length > 0) {
              const { str: oldDur } = hoursAndDays(tracked.detectedAt);
              await broadcastPhoto(
                _oldIsStopLoss ? BREAKEVEN_STOP_IMG : CANCEL_IMG,
                [
                  _oldIsStopLoss
                    ? `🔴⏱ <b>${tracked.symbol.replace("-USDT", "")}</b> — Отменён по времени (72ч) — STOP LOSS`
                    : `⏱ <b>${tracked.symbol.replace("-USDT", "")}</b> — Отменён по времени (72ч)`,
                  `За 3 дня цена не двинулась выше +2% от входа — накопление не подтвердилось`,
                  _oldIsStopLoss
                    ? `⚠️ Засчитан как стоп лосс (цена ниже входа ≥5%)`
                    : `<i>Позиция закрыта принудительно. Попробуем снова при новом сигнале.</i>`,
                  `Вход: <b>${tracked.entryPrice!.toPrecision(4)}</b> | Сейчас: <b>${currentPrice.toPrecision(4)}</b> (${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%)`,
                  `⏱ Время в позиции: ${oldDur}`,
                  ``,
                  fmtPattern(tracked),
                  `${tickerTag(tracked.symbol)} ${patternTag(tracked.sentimentKey)} ${_oldIsStopLoss ? "#stop_loss" : "#stale_cancel #max_age"}`,
                ]
                  .filter(Boolean)
                  .join("\n"),
              );
              logger.info(
                {
                  symbol: tracked.symbol,
                  ageH: ageHours.toFixed(1),
                  pnl: pnl.toFixed(1),
                },
                "STALE CANCEL: hard max-age 72ч, peak < 2%",
              );
            }
            continue;
          }

          // ── Шаг 1: проверяем OI — накопление ещё идёт? ───────────────────────
          // Используем oiChange30m как основной (15–30 мин динамика).
          // Используем oiChange30m (15–30 мин динамика).
          // Порог 2%: соответствует "вырос на 2-3% за период ожидания".
          type OiResult = "positive" | "negative" | "error";
          let oiResult: OiResult = "error";
          let freshOiPct: number | null = null;
          // cgOIData сохраняем вне try-блока чтобы переиспользовать в шагах 1b и 1c
          let cgOIData: Awaited<ReturnType<typeof getCoinglassOI>> | null =
            null;
          try {
            cgOIData = await getCoinglassOI(tracked.symbol, currentPrice);
            freshOiPct = cgOIData.oiChange30m ?? null;
            if (cgOIData.available && freshOiPct !== null) {
              oiResult = freshOiPct >= 2.0 ? "positive" : "negative";
            }
            // available=false или null → error → ждём (не отменяем при недоступности)
          } catch {
            oiResult = "error";
          }

          if (oiResult === "positive") {
            logger.info(
              {
                symbol: tracked.symbol,
                ageH: ageHours.toFixed(1),
                oiPct: freshOiPct?.toFixed(1),
              },
              "⏳ STALE EXTENDED: OI +2%+ — накопление продолжается, продлеваем",
            );
            continue;
          }
          if (oiResult === "error") {
            logger.info(
              { symbol: tracked.symbol, ageH: ageHours.toFixed(1) },
              "⚠️ STALE: CoinGlass недоступен — переходим к проверке Market Health",
            );
            // fall through к шагам 1b/1c/2
          }

          // ── Шаг 1c: Глобальный OI4h guard (макс 2 продления) ────────────────
          // Если OI за 4ч растёт ≥ +0.5% — накопление ещё идёт, не торопиться.
          // Не применяем к быстрым паттернам (FAST_STALE_PATTERNS).
          if (!FAST_STALE_PATTERNS.has(tracked.sentimentKey ?? "")) {
            const oi4hExtCount = _staleOi4hExtCount.get(tracked.id) ?? 0;
            if (oi4hExtCount < 2) {
              const oi4h = cgOIData?.oiChange4h ?? null;
              if (oi4h !== null && oi4h >= 0.5) {
                _staleOi4hExtCount.set(tracked.id, oi4hExtCount + 1);
                logger.info(
                  {
                    symbol: tracked.symbol,
                    oi4h: oi4h.toFixed(1),
                    ageH: ageHours.toFixed(1),
                    ext: oi4hExtCount + 1,
                  },
                  `⏳ STALE OI4H: OI4h +${oi4h.toFixed(1)}% → продлеваем #${oi4hExtCount + 1}/2`,
                );
                continue;
              }
            }
          }

          // ── Шаг 1e: NetChange / mCap guard ────────────────────────────────────
          // Используем cgOIData (уже загружен в Step 1 выше — свежие данные).
          // Формула: netChange4hUsd = oiUsd × oiChange4h / 100
          //          netChangePctMcap = netChange4hUsd / marketCapUsd × 100
          // Порог 0.5%: значительный институциональный приток за 4ч → не отменяем.
          // (BTC $70B mcap: 0.5% = $350M; small cap $100M: 0.5% = $500K)
          if (!FAST_STALE_PATTERNS.has(tracked.sentimentKey ?? "")) {
            const _oiUsd = cgOIData?.oiUsd ?? null;
            const _oi4h = cgOIData?.oiChange4h ?? null;
            const _mcap = tracked.marketCapUsd ?? null;
            if (
              _oiUsd !== null &&
              _oi4h !== null &&
              _oi4h > 0 &&
              _mcap !== null &&
              _mcap > 0
            ) {
              const nc = ((_oiUsd * _oi4h) / 100 / _mcap) * 100;
              if (nc >= NETCHANGE_MCAP_THRESHOLD) {
                logger.info(
                  {
                    symbol: tracked.symbol,
                    ageH: ageHours.toFixed(1),
                    oi4h: _oi4h.toFixed(1),
                    oiUsd: _oiUsd.toFixed(0),
                    netChangePctMcap: nc.toFixed(2),
                    mcapUsd: _mcap,
                  },
                  "⏳ STALE NETCHANGE: значительный OI-приток vs mCap — продлеваем",
                );
                continue;
              }
            }
          }

          // ── Шаг 1f: Spot Taker Flip — ускоренная отмена при развороте тейкера ────────
          // Spot taker 2+ цикла в sell dominance (netBuyPct < -10%) + CVD 1h отрицательный.
          // Не применяется к FAST_STALE_PATTERNS.
          if (!FAST_STALE_PATTERNS.has(tracked.sentimentKey ?? "")) {
            try {
              const takerStale = await getSpotTakerFlow(tracked.symbol).catch(
                () => null,
              );
              if (takerStale?.available)
                updateLiveSpotTaker(
                  tracked.symbol,
                  takerStale.netBuyPct ?? null,
                  takerStale.dominance ?? null,
                );
              if (
                takerStale?.available &&
                takerStale.dominance === "sell" &&
                (takerStale.netBuyPct ?? 0) < -10
              ) {
                const sellCycles =
                  (_staleTakerSellCycles.get(tracked.id) ?? 0) + 1;
                _staleTakerSellCycles.set(tracked.id, sellCycles);
                if (sellCycles >= 2) {
                  const cvdConfirm = await getSpotCvdMtf(tracked.symbol).catch(
                    () => null,
                  );
                  if (cvdConfirm?.available && cvdConfirm.cvd1h === false) {
                    logger.info(
                      {
                        symbol: tracked.symbol,
                        sellCycles,
                        netBuyPct: takerStale.netBuyPct?.toFixed(1),
                      },
                      "⚠️ STALE TAKER FLIP: spot taker продаёт 2+ цикла + CVD 1h отрицательный",
                    );
                    _staleTakerFlipped.add(tracked.id);
                  }
                }
              } else {
                _staleTakerSellCycles.set(tracked.id, 0);
              }
            } catch {
              /* некритично */
            }
          }

          // ── Шаг 1d: CVD snapshot delta ────────────────────────────────────────
          // Если при входе CVD 1h/4h был позитивным, а сейчас оба стали отрицательными —
          // спот-накопление сломано. Запоминаем для сообщения об отмене.
          let _cvdFlippedNeg = false;
          if (tracked.entryCvd1h === true || tracked.entryCvd4h === true) {
            try {
              const cvdNow = await getSpotCvdMtf(tracked.symbol);
              if (
                cvdNow.available &&
                cvdNow.cvd1h === false &&
                cvdNow.cvd4h === false
              ) {
                _cvdFlippedNeg = true;
                logger.info(
                  {
                    symbol: tracked.symbol,
                    entryCvd1h: tracked.entryCvd1h,
                    entryCvd4h: tracked.entryCvd4h,
                  },
                  "⚠️ STALE CVD FLIP: CVD был позитивным при входе, сейчас 1h+4h минус — спот-накопление сломано",
                );
              }
            } catch {
              /* CVD некритичен для stale cancel */
            }
          }

          // ── Шаг 1g: Price Structure Break ─────────────────────────────────────
          // Цена -5% от входа + OI 30m отрицательный → тезис сломан структурно.
          let _priceStructureBroken = false;
          {
            const _psOi30m = cgOIData?.oiChange30m ?? null;
            if (pnl <= -5.0 && _psOi30m !== null && _psOi30m < 0) {
              _priceStructureBroken = true;
              logger.info(
                {
                  symbol: tracked.symbol,
                  pnl: pnl.toFixed(1),
                  oi30m: _psOi30m.toFixed(1),
                },
                "⚠️ PRICE STRUCTURE BREAK: цена -5% от входа + OI 30m отрицательный",
              );
            }
          }

          // ── Шаг 2: OI иссяк — проверяем рынок перед отменой ─────────────────
          // Объём или стакан ещё живые → ждём ещё один цикл.
          const healthCheck = await fetchMarketHealth(
            tracked.symbol,
            currentPrice,
          );
          const obCheck = await getCrossExchangeOrderBook(tracked.symbol, 20);
          const isVolumeDead =
            healthCheck.cgTurnover !== null && healthCheck.cgTurnover < 0.15;
          const isBearishOB = obCheck !== null && obCheck.bias === "bear";
          // 3.4: если фьюч-оборот упал, но спот объём ещё активен (≥0.8x) — не отменяем
          const _stalePreE = getPrescanEntry(tracked.symbol);
          const _staleSpotMult =
            _stalePreE?.spotVolAvg1h && _stalePreE?.lastSpotVol1h
              ? _stalePreE.lastSpotVol1h / _stalePreE.spotVolAvg1h
              : null;
          const cancelByVol =
            isVolumeDead && (_staleSpotMult === null || _staleSpotMult < 0.8);
          const isTakerFlipped = _staleTakerFlipped.has(tracked.id);
          if (!cancelByVol && !isBearishOB && !isTakerFlipped) {
            logger.info(
              {
                symbol: tracked.symbol,
                ageH: ageHours.toFixed(1),
                cgTurnover: healthCheck.cgTurnover,
                spotMult: _staleSpotMult?.toFixed(2) ?? "n/a",
                obBias: obCheck?.bias ?? "n/a",
              },
              _staleSpotMult !== null && _staleSpotMult >= 0.8
                ? "⏳ STALE EXTENDED: OI упал, но спот объём ≥0.8x — продлеваем (спот активен)"
                : "⏳ STALE EXTENDED: OI упал, но объём/стакан ещё держат — продлеваем",
            );
            continue;
          }

          // ── Шаг 3: Smart Cancel Override ─────────────────────────────────────
          // Финальная страховка: strong bid wall или OI за 4ч выше настраиваемого порога.
          try {
            const [scSettings] = await db
              .select({
                smartCancelOiPct: settingsTable.smartCancelOiPct,
              })
              .from(settingsTable)
              .limit(1);
            const scOiPct = scSettings?.smartCancelOiPct ?? 5.0;

            const [scOB, scCgOI] = await Promise.all([
              getCrossExchangeOrderBook(tracked.symbol, 50).catch(() => null),
              getCoinglassOI(tracked.symbol, currentPrice).catch(() => null),
            ]);

            const hasStrongBidWall = scOB?.bias === "strong_bull";
            const oi4h = scCgOI?.oiChange4h ?? null;
            const isOiGrowing4h = oi4h !== null && oi4h >= scOiPct;
            // NetChange / mCap — финальная страховка от отмены при значительном притоке
            const _scOiUsd = scCgOI?.oiUsd ?? null;
            const _scMcap = tracked.marketCapUsd ?? null;
            const scNetChangePctMcap =
              _scOiUsd !== null &&
              oi4h !== null &&
              oi4h > 0 &&
              _scMcap !== null &&
              _scMcap > 0
                ? ((_scOiUsd * oi4h) / 100 / _scMcap) * 100
                : null;
            const isNetChangeSignificant =
              scNetChangePctMcap !== null &&
              scNetChangePctMcap >= NETCHANGE_MCAP_THRESHOLD;

            if (hasStrongBidWall || isOiGrowing4h || isNetChangeSignificant) {
              logger.info(
                {
                  symbol: tracked.symbol,
                  reason: hasStrongBidWall
                    ? "strong_bid_wall"
                    : isOiGrowing4h
                      ? "oi_growing_4h"
                      : "net_change_mcap",
                  obBias: scOB?.bias ?? null,
                  oi4h,
                  scOiPct,
                  netChangePctMcap: scNetChangePctMcap?.toFixed(2) ?? null,
                },
                "⚡ Smart Cancel Override: отмена предотвращена — бычьи сигналы активны",
              );
              continue;
            }
          } catch (scErr) {
            logger.warn(
              { err: scErr, symbol: tracked.symbol },
              "Smart Cancel: ошибка проверки — продолжаем отмену",
            );
          }

          // ── NETCHANGE GATE: финальная проверка перед отменой ─────────────────
          // Правило: отменяем ТОЛЬКО если деньги уходят одновременно из фьючей И спота
          // по 30m TF. Если хоть один TF показывает приток → ждём.
          // OI 30m = futures NETCHANGE; SpotCVD 30m + 1h = spot NETCHANGE.
          // При недоступности данных — НЕ отменяем (принцип "не уверен — жди").
          {
            const _ncFutOI30m = cgOIData?.oiChange30m ?? null;
            const _ncFutBothNeg = _ncFutOI30m !== null && _ncFutOI30m < 0;
            let _ncSpotBothNeg = false;
            try {
              const _ncSpot = await getSpotCvdMtf(tracked.symbol);
              // SpotCVD 30m + 1h = устойчивый отток.
              _ncSpotBothNeg =
                _ncSpot.available === true &&
                _ncSpot.cvd30m === false &&
                _ncSpot.cvd1h === false;
            } catch {
              /* данные недоступны → считаем как не подтверждено */
            }
            if (!_ncFutBothNeg || !_ncSpotBothNeg) {
              logger.info(
                {
                  symbol: tracked.symbol,
                  ageH: ageHours.toFixed(1),
                  futOI30m:
                    _ncFutOI30m != null ? _ncFutOI30m.toFixed(2) : "n/a",
                  futBothNeg: _ncFutBothNeg,
                  spotBothNeg: _ncSpotBothNeg,
                },
                "⏳ NETCHANGE GATE: не все TF в оттоке — откладываем stale cancel",
              );
              continue;
            }
          }

          // ── Отмена: OI + объём + стакан — всё мёртво ─────────────────────────
          // NO-TOUCH: в первые 2ч/4ч — cancelled, не stop_loss
          const _staleIsStopLoss =
            pnl <= -CANCEL_STOP_LOSS_PCT &&
            ageMs >= getNoTouchStopMs(tracked.sentimentKey);
          const claimedStale = await dbWriteStrict(
            "trackedSignal/stale-oi-cancel",
            () =>
              db
                .update(trackedSignalsTable)
                .set({
                  status: _staleIsStopLoss ? "stop_loss" : "cancelled",
                  exitPrice: currentPrice,
                  pnlPercent: pnl,
                  cancelReason: "stale_oi_vol",
                  closedAt: new Date(),
                  updatedAt: new Date(),
                })
                .where(
                  sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`,
                )
                .returning({ id: trackedSignalsTable.id }),
          );
          if (claimedStale.length > 0) {
            _staleTakerSellCycles.delete(tracked.id);
            _staleTakerFlipped.delete(tracked.id);
            _staleOi4hExtCount.delete(tracked.id);
            const { str: staleDur } = hoursAndDays(tracked.detectedAt);
            const staleCancelReason = _priceStructureBroken
              ? `📉 Цена упала на ${Math.abs(pnl).toFixed(1)}% ниже входа при отрицательном OI — тезис сломан`
              : isTakerFlipped
                ? `📊 Спот тейкер 2+ цикла в sell dominance + CVD 1h отрицательный — спрос иссяк`
                : `OI иссяк — накопление не продолжилось`;

            const WF_PAT = [] as string[];
            const ACC_PAT = ["trend_accumulation", "bullish_accumulation"];
            const SPT_PAT = ["spot_vol_accumulation"];

            const staleHint = _staleIsStopLoss
              ? `⚠️ Засчитан как стоп лосс (цена ниже входа ≥5%)`
              : WF_PAT.includes(tracked.sentimentKey ?? "")
                ? `<i>Кит не активировал позицию в ожидаемое окно. Мониторинг завершён.</i>`
                : ACC_PAT.includes(tracked.sentimentKey ?? "")
                  ? `<i>Накопление не переросло в импульс. Возможен повторный вход при новом сигнале.</i>`
                  : SPT_PAT.includes(tracked.sentimentKey ?? "")
                    ? `<i>Спот активность угасла. Капитал освобождён.</i>`
                    : `<i>Капитал освобождён для новых сделок.</i>`;

            await broadcastPhoto(
              _staleIsStopLoss ? BREAKEVEN_STOP_IMG : CANCEL_IMG,
              [
                _staleIsStopLoss
                  ? `🔴⏱ <b>${tracked.symbol.replace("-USDT", "")}</b> — Сигнал отменён — STOP LOSS`
                  : `⏱ <b>${tracked.symbol.replace("-USDT", "")}</b> — Сигнал отменён`,
                ``,
                staleCancelReason,
                _cvdFlippedNeg
                  ? `⚠️ Спот CVD (1h+4h) перевернулся — устойчивая распродажа`
                  : null,
                ``,
                `💰 Вход: <b>${tracked.entryPrice.toPrecision(4)}</b> | Сейчас: <b>${currentPrice.toPrecision(4)}</b> (${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%)`,
                `⏱ Время в позиции: ${staleDur}`,
                ``,
                staleHint,
                fmtPattern(tracked),
                `${tickerTag(tracked.symbol)} ${patternTag(tracked.sentimentKey)} ${_staleIsStopLoss ? "#stop_loss" : "#stale_cancel"}`,
              ]
                .filter(Boolean)
                .join("\n"),
            );
            logger.info(
              {
                symbol: tracked.symbol,
                ageHours: ageHours.toFixed(1),
                peakPct: peakPct.toFixed(1),
              },
              "FastCycle: STALE CANCEL (dynamic OI check, OI+vol+OB dead)",
            );
          }
          continue;
        }
      }

      // Реальная защита в безубыток: active сигнал уже достиг milestone (стоп перенесён в БУ),
      // цена вернулась к уровню входа (~0%) → закрываем СРАЗУ, не дожидаясь стоп-лосса.
      // Без этой проверки позиция могла падать с +5-9% до -10/-12% и всё равно
      // маркировалась как "bu_stop" (см. CAP -10.17%, TAIKO -11.98%, июль 2026).
      // bullish_accumulation: milestone = 10% (остальные: 5%).
      if (
        tracked.status === "active" &&
        (tracked.lastMilestone ?? 0) >=
          getBuStopMilestone(tracked.sentimentKey) &&
        currentPrice !== undefined &&
        currentPrice <= (tracked.entryPrice ?? 0)
      ) {
        const claimedRealBU = await dbWriteStrict(
          "trackedSignal/real-bu-stop",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                status: "bu_stop",
                exitPrice: currentPrice,
                pnlPercent: pnl,
                peakPrice: newPeak,
                closedAt: new Date(),
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimedRealBU.length > 0) {
          await broadcastPhoto(
            BU_STOP_IMG,
            msgBUStop(tracked, currentPrice, pnl),
          );
          logger.info(
            { symbol: tracked.symbol, pnl },
            "FastCycle: BU STOP (active, реальный возврат к entry) 🛡",
          );
        }
        continue;
      }

      // Фолбэк: active сигнал уже достиг milestone (стоп перенесён в БУ), но цена проскочила
      // сразу до -effStop между циклами (гэп/резкое падение) — верхняя проверка не успела
      // поймать возврат к entry. Частичная фиксация уже была → всё равно bu_stop,
      // никогда stop_loss (это не должно срабатываться часто после фикса выше).
      // bullish_accumulation: milestone = 10% (остальные: 5%).
      if (
        tracked.status === "active" &&
        (tracked.lastMilestone ?? 0) >=
          getBuStopMilestone(tracked.sentimentKey) &&
        pnl <= -effStopPct(tracked)
      ) {
        const actualStatus = "bu_stop" as const;
        const claimedBEStop = await dbWriteStrict(
          "trackedSignal/be-stop-fallback",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                status: actualStatus,
                exitPrice: currentPrice,
                pnlPercent: pnl,
                peakPrice: newPeak,
                closedAt: new Date(),
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimedBEStop.length > 0) {
          await broadcastPhoto(
            BU_STOP_IMG,
            msgBUStop(tracked, currentPrice, pnl),
          );
          logger.info(
            {
              symbol: tracked.symbol,
              pnl,
              milestone: getBuStopMilestone(tracked.sentimentKey),
            },
            "FastCycle: BE STOP (fallback: milestone hit → gapped to stop) 🛡",
          );
        }
        continue;
      }

      // Стоп-лосс (персональный по heatmap или стандартный -10%) применяется к ACTIVE,
      // ACCUMULATION и RE_ENTRY (до первой цели). ACCUMULATION = active > 24ч.
      // NO-TOUCH PERIOD: стоп пропускается пока ageMs < getNoTouchStopMs (2ч / 4ч whale).
      if (
        (tracked.status === "active" ||
          tracked.status === "accumulation" ||
          tracked.status === "re_entry") &&
        ageMs >= getNoTouchStopMs(tracked.sentimentKey) &&
        pnl <= -effStopPct(tracked)
      ) {
        const claimedSLFast = await dbWriteStrict(
          "trackedSignal/fast-stop-loss",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                status: "stop_loss",
                exitPrice: currentPrice,
                pnlPercent: pnl,
                closedAt: new Date(),
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('active','accumulation','re_entry')`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimedSLFast.length > 0) {
          await broadcastPhoto(
            STOPLOSS_IMG,
            msgStopLoss(tracked, currentPrice, pnl),
          );
          logger.info(
            { symbol: tracked.symbol, status: tracked.status, pnl },
            "FastCycle: STOP LOSS (active/accumulation/re_entry) ❌",
          );
        }
        continue;
      }

      // Стоп в БУ: in_run, трейлинг ещё не активен, цена вернулась к уровню входа (0%)
      // Позиция защищена — стоп в безубытке считается как прибыль, не как убыток
      if (
        (tracked.status === "in_run" || tracked.status === "re_entry") &&
        !trailingActive &&
        currentPrice !== undefined &&
        currentPrice <= (tracked.entryPrice ?? 0)
      ) {
        const claimedBU = await dbWriteStrict(
          "trackedSignal/fast-bu-stop",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                status: "bu_stop",
                exitPrice: currentPrice,
                pnlPercent: pnl,
                peakPrice: newPeak,
                closedAt: new Date(),
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} IN ('in_run','re_entry')`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimedBU.length > 0) {
          await broadcastPhoto(
            BU_STOP_IMG,
            msgBUStop(tracked, currentPrice, pnl),
          );
          logger.info({ symbol: tracked.symbol, pnl }, "FastCycle: BU STOP 🛡");
        }
        continue;
      }

      // Стоп: in_run, трейлинг ещё не активен, цена упала ниже -10% от входа
      // in_run означает что сигнал уже прошёл +10% (стоп в БУ) → всегда bu_stop
      if (
        tracked.status === "in_run" &&
        !trailingActive &&
        pnl <= -effStopPct(tracked)
      ) {
        const claimedSmallLoss = await dbWriteStrict(
          "trackedSignal/fast-inRun-bu-stop",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                status: "bu_stop",
                exitPrice: currentPrice,
                pnlPercent: pnl,
                peakPrice: newPeak,
                closedAt: new Date(),
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'in_run'`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimedSmallLoss.length > 0) {
          await broadcastPhoto(
            BU_STOP_IMG,
            msgBUStop(tracked, currentPrice, pnl),
          );
          logger.info(
            { symbol: tracked.symbol, pnl },
            "FastCycle: BU STOP (in_run, сервер лежал, пропущен BU на 0%) 🛡",
          );
        }
        continue;
      }

      // ── ТРИГГЕРНОЕ СОПРОВОЖДЕНИЕ ──────────────────────────────────────────────
      // Отправляем ТОЛЬКО когда ситуация реально меняется: OI/объём резко двигается.
      // Нейтральная картина — молчим. Cooldown 4ч между сообщениями одной позиции.
      if (
        (tracked.status === "active" ||
          tracked.status === "in_run" ||
          tracked.status === "re_entry") &&
        ageMs >= 60 * 60_000
      ) {
        const triggerThreshold = new Date(
          Date.now() - 4 * 3_600_000 + 5 * 60_000,
        );
        const claimedPeriodic = await dbWriteStrict(
          "trackedSignal/periodic-update-dedup",
          () =>
            db
              .update(trackedSignalsTable)
              .set({ lastPeriodicUpdateAt: new Date() })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastPeriodicUpdateAt} IS NULL OR ${trackedSignalsTable.lastPeriodicUpdateAt} < ${triggerThreshold})`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimedPeriodic.length > 0) {
          try {
            const health4h = await fetchMarketHealth(
              tracked.symbol,
              currentPrice,
            );
            const spotCvd = await getSpotCvdMtf(tracked.symbol).catch(
              () => null,
            );
            const coin = tracked.symbol.replace("-USDT", "");
            const pnlSign = pnl >= 0 ? "+" : "";

            // ДЕРЖИ: OI > 5% И оборот ≥ 15% OI — оба одновременно
            const oiGood = health4h.oiPct !== null && health4h.oiPct > 5;
            const volGood =
              health4h.cgTurnover !== null && health4h.cgTurnover >= 0.15;
            const holdLine = oiGood && volGood;

            // РАССМОТРИ ВЫХОД: все три одновременно — OI < -5% И оборот < 8% OI И CVD везде минус
            const oiBad = health4h.oiPct !== null && health4h.oiPct < -5;
            const volBad =
              health4h.cgTurnover !== null && health4h.cgTurnover < 0.08;
            const cvdBad =
              spotCvd !== null &&
              spotCvd.available === true &&
              spotCvd.cvd30m === false &&
              spotCvd.cvd1h === false;
            const exitLine = oiBad && volBad && cvdBad;

            // СЛЕДИ: смешанные сигналы — не hold, не exit, но что-то слабеет
            const followLine =
              !holdLine &&
              !exitLine &&
              ((health4h.oiPct !== null && health4h.oiPct < 0) ||
                (health4h.cgTurnover !== null && health4h.cgTurnover < 0.1));

            let holdExitLine: string | null = null;
            if (holdLine) {
              holdExitLine = `💪 <b>ДЕРЖИ</b> — OI: +${health4h.oiPct!.toFixed(1)}% | Оборот: ${(health4h.cgTurnover! * 100).toFixed(1)}% OI — накопление подтверждено`;
            } else if (exitLine) {
              holdExitLine = `⚠️ <b>РАССМОТРИ ВЫХОД</b> — OI падает + объём мёртвый + CVD минус`;
            } else if (followLine) {
              holdExitLine = `👀 <b>СЛЕДИ</b> — сигналы смешанные, импульс ослабевает`;
            }
            // Нейтрально (всё хорошо но не сильно) → молчим

            if (holdExitLine) {
              const { str: timeInPos } = hoursAndDays(tracked.detectedAt);
              const updateMsg = [
                `🟣📊 <b>POSITION UPDATE — ${coin}</b>`,
                `${fmtP(tracked.entryPrice)} → ${fmtP(currentPrice)} (${pnlSign}${pnl.toFixed(1)}%) | ${timeInPos}`,
                ``,
                holdExitLine,
                ``,
                fmtPattern(tracked),
                `${tickerTag(tracked.symbol)} ${patternTag(tracked.sentimentKey)} #position_update`,
              ]
                .filter(Boolean)
                .join("\n");
              const triggerImg = holdLine
                ? POSITION_HOLD_IMG
                : exitLine
                  ? POSITION_EXIT_IMG
                  : POSITION_FOLLOW_IMG;
              await broadcastPhoto(triggerImg, updateMsg);
              logger.info(
                {
                  symbol: tracked.symbol,
                  pnl: pnl.toFixed(1),
                  oiPct: health4h.oiPct,
                  cgTurnover: health4h.cgTurnover,
                  state: holdLine ? "hold" : exitLine ? "exit" : "follow",
                },
                "📊 Trigger update sent",
              );
            } else {
              logger.debug(
                { symbol: tracked.symbol },
                "Trigger check: нейтрально — молчим",
              );
            }
          } catch (err) {
            logger.warn(
              { err, symbol: tracked.symbol },
              "Trigger monitor failed",
            );
          }
        }
      }

      // 24h/48h переход в accumulation удалён — нет спонтанных переходов по времени

      // ── DEMARK COUNTER-TD CANCEL ────────────────────────────────────────────────────
      // Специфичная отмена для demark: если td1h ≤ -3, продавец уже формирует встречный
      // сетап (3+ баров ниже [close[i] > close[i-4]]) — разворот не состоялся.
      if (
        tracked.status === "active" &&
        tracked.sentimentKey === "demark" &&
        ageMs >= SMART_CANCEL_MIN_AGE_MS
      ) {
        const _dmBase = tracked.symbol.replace("-USDT", "");
        const _dmEntry = getTdAtrEntry(_dmBase);
        const _dmTd1h = _dmEntry?.td1h ?? null;
        if (_dmTd1h !== null && _dmTd1h <= -3) {
          const claimedDm = await dbWriteStrict(
            "trackedSignal/demark-counter-cancel",
            () =>
              db
                .update(trackedSignalsTable)
                .set({
                  status: "cancelled",
                  exitPrice: currentPrice,
                  pnlPercent: pnl,
                  cancelReason: "demark_counter_td",
                  closedAt: new Date(),
                  updatedAt: new Date(),
                })
                .where(
                  sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} NOT IN ('cancelled','profit','stop_loss','breakeven','bu_stop')`,
                )
                .returning({ id: trackedSignalsTable.id }),
          );
          if (claimedDm.length > 0) {
            const base = tracked.symbol.replace("-USDT", "");
            const { str: dmDur } = hoursAndDays(tracked.detectedAt);
            await broadcastPhoto(
              CANCEL_IMG,
              [
                `🟣🚫 <b>SIGNAL CANCELLED — ${base}</b>`,
                `ДеМарк контр-TD: td1h=${_dmTd1h} — продавец набирает ${Math.abs(_dmTd1h)} баров сетапа`,
                `Разворот не состоялся — тезис TD9 Buy аннулирован`,
                `${fmtP(tracked.entryPrice)} → ${fmtP(currentPrice)} (${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%) | ${dmDur}`,
                ``,
                `${tickerTag(tracked.symbol)} ${patternTag(tracked.sentimentKey)} #demark_counter_td`,
              ].join("\n"),
            );
            logger.info(
              { symbol: tracked.symbol, td1h: _dmTd1h, pnl: pnl.toFixed(1) },
              "🕯 Demark COUNTER-TD CANCEL: sell setup нарастает",
            );
          }
          continue;
        }
      }

      // ── SMART CANCEL v11: Спот CVD 5m + 30m + 1h — все три одновременно минус ──────
      // Единственное основание для отмены. Применяется ко всем паттернам без исключения.
      // Условие: pnl <= -2% (порог ужесточён с -1%: бэктест 37.8% ошибочных отмен).
      // Grace period 4ч: CVD временно уходит в минус на обычной волатильности после входа.
      // OI 4h guard: 1.5% (поднят с 1.0% — более агрессивная защита при накоплении OI).
      // whale_alert: smart cancel отключён — только Breakeven по тайм-ауту и стоп-лосс.
      if (tracked.status === "active" && ageMs >= SMART_CANCEL_MIN_AGE_MS && tracked.sentimentKey !== "whale_alert") {
        try {
          const spotCvdSC = await getSpotCvdMtf(tracked.symbol);
          const scPnlThreshold = -2;
          if (spotCvdSC.available && pnl <= scPnlThreshold) {
            // Защита: если при входе CVD данных не было (BingX-exclusive токен) —
            // не можем оценить "ухудшение" CVD. Smart cancel не применяем.
            const hadNoCvdAtEntry =
              tracked.entryCvd1h === null && tracked.entryCvd4h === null;
            if (hadNoCvdAtEntry) {
              logger.info(
                { symbol: tracked.symbol, pnl: pnl.toFixed(1) },
                "SMART CANCEL blocked — нет CVD данных при входе (BingX-exclusive), пропускаем",
              );
            } else {
              const allThreeNegative =
                spotCvdSC.cvd30m === false && spotCvdSC.cvd1h === false;
              if (allThreeNegative) {
                // OI 4h guard: если кит ещё держит деривативы — не отменяем
                try {
                  const scOI = await getCoinglassOI(
                    tracked.symbol,
                    currentPrice,
                  );
                  if (
                    scOI.available &&
                    scOI.oiChange4h !== null &&
                    scOI.oiChange4h >= 1.5
                  ) {
                    logger.info(
                      { symbol: tracked.symbol, oi4h: scOI.oiChange4h },
                      "SMART CANCEL blocked — OI 4h positive, whale still holding",
                    );
                    continue;
                  }
                } catch {
                  /* non-critical: если OI недоступен — отменяем как обычно */
                }

                // ── SMART CANCEL PAUSE v11 ─────────────────────────────────────────
                // Первый цикл: CVD минус → сохраняем метку, НЕ отменяем сразу.
                // Второй цикл >= 4 мин позже: если CVD всё ещё отрицательный → отменяем.
                // Защита от ложных отмен на коротких 5m флуктуациях CVD.
                const SMART_CANCEL_PAUSE_MS = 4 * 60_000;
                if (!tracked.lastSmartCancelCheckAt) {
                  await dbWriteBestEffort(
                    "trackedSignal/smart-cancel-mark",
                    () =>
                      db
                        .update(trackedSignalsTable)
                        .set({
                          lastSmartCancelCheckAt: new Date(),
                          updatedAt: new Date(),
                        })
                        .where(eq(trackedSignalsTable.id, tracked.id)),
                  );
                  logger.info(
                    { symbol: tracked.symbol, pnl: pnl.toFixed(1) },
                    "SMART CANCEL: первый триггер — сохраняем метку, ждём повторного подтверждения",
                  );
                  continue;
                }
                const scPausedMs =
                  Date.now() - tracked.lastSmartCancelCheckAt.getTime();
                if (scPausedMs < SMART_CANCEL_PAUSE_MS) {
                  logger.debug(
                    {
                      symbol: tracked.symbol,
                      pausedSec: Math.round(scPausedMs / 1000),
                    },
                    "SMART CANCEL: пауза — ждём 4 мин до подтверждения",
                  );
                  continue;
                }

                // Цикл 2 (>= 4 мин): перепроверяем CVD — мог восстановиться
                try {
                  const cvdRecheck = await getSpotCvdMtf(tracked.symbol);
                  const cvdRecovered =
                    cvdRecheck.available &&
                    (cvdRecheck.cvd30m === true || cvdRecheck.cvd1h === true);
                  if (cvdRecovered) {
                    // CVD восстановился — сбрасываем маркер, держим позицию
                    await dbWriteBestEffort(
                      "trackedSignal/smart-cancel-reset",
                      () =>
                        db
                          .update(trackedSignalsTable)
                          .set({
                            lastSmartCancelCheckAt: null,
                            updatedAt: new Date(),
                          })
                          .where(eq(trackedSignalsTable.id, tracked.id)),
                    );
                    logger.info(
                      {
                        symbol: tracked.symbol,
                        pnl: pnl.toFixed(1),
                        cvd30m: cvdRecheck.cvd30m,
                        cvd1h: cvdRecheck.cvd1h,
                      },
                      "SMART CANCEL blocked — CVD восстановился, держим позицию",
                    );
                    continue;
                  }
                } catch {
                  /* non-critical: если recheck упал — отменяем как обычно */
                }

                // NO-TOUCH: в первые 2ч/4ч — cancelled, не stop_loss
                const _scIsStopLoss =
                  pnl <= -CANCEL_STOP_LOSS_PCT &&
                  ageMs >= getNoTouchStopMs(tracked.sentimentKey);
                const claimedSC = await dbWriteStrict(
                  "trackedSignal/smart-cancel-claim",
                  () =>
                    db
                      .update(trackedSignalsTable)
                      .set({
                        status: _scIsStopLoss ? "stop_loss" : "cancelled",
                        exitPrice: currentPrice,
                        pnlPercent: pnl,
                        cancelReason: "smart_cancel_oi_taker",
                        closedAt: new Date(),
                        updatedAt: new Date(),
                      })
                      .where(
                        sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} NOT IN ('cancelled','profit','stop_loss','breakeven','bu_stop')`,
                      )
                      .returning({ id: trackedSignalsTable.id }),
                );
                if (claimedSC.length > 0) {
                  const base = tracked.symbol.replace("-USDT", "");
                  const { str: scDur } = hoursAndDays(tracked.detectedAt);
                  await broadcastPhoto(
                    _scIsStopLoss ? BREAKEVEN_STOP_IMG : CANCEL_IMG,
                    [
                      _scIsStopLoss
                        ? `🔴🚫 <b>SIGNAL CANCELLED — ${base} — STOP LOSS</b>`
                        : `🟣🚫 <b>SIGNAL CANCELLED — ${base}</b>`,
                      `Спот CVD (30m + 1h) устойчиво отрицательный — разворот тренда подтверждён`,
                      `${fmtP(tracked.entryPrice)} → ${fmtP(currentPrice)} (${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%) | ${scDur}`,
                      ``,
                      _scIsStopLoss
                        ? `⚠️ Засчитан как стоп лосс (цена ниже входа ≥5%)`
                        : null,
                      ``,
                      fmtPattern(tracked),
                      `${tickerTag(tracked.symbol)} ${patternTag(tracked.sentimentKey)} ${_scIsStopLoss ? "#stop_loss" : "#smart_cancel"}`,
                    ]
                      .filter(Boolean)
                      .join("\n"),
                  );
                  logger.info(
                    {
                      symbol: tracked.symbol,
                      pnl: pnl.toFixed(1),
                      cvd30m: spotCvdSC.cvd30m,
                      cvd1h: spotCvdSC.cvd1h,
                    },
                    "FastCycle: SMART CANCEL 5m+30m+1h 🔴",
                  );
                }
                continue;
              }
            } // end else (hadNoCvdAtEntry)
          }
        } catch (scErr) {
          logger.debug(
            { err: scErr, symbol: tracked.symbol },
            "Smart Cancel: ошибка — пропускаем",
          );
        }
      }

      // Milestone (5% по умолчанию, 10% для bullish_accumulation):
      // уведомление о частичной фиксации + переносе стопа в БУ (один раз).
      // Отправляем и продолжаем — в том же цикле может сработать FIRST_TARGET.
      // ВАЖНО: нотификация в отдельном try/catch — её ошибка НЕ должна блокировать
      // переход active→in_run который идёт следующим в этом же цикле.
      const _buMilestone = getBuStopMilestone(tracked.sentimentKey);
      if (
        tracked.status === "active" &&
        pnl >= _buMilestone &&
        (tracked.lastMilestone ?? 0) < _buMilestone
      ) {
        const claimed5 = await dbWriteStrict(
          "trackedSignal/fast-partial-target",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                lastMilestone: _buMilestone,
                peakPrice: newPeak,
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastMilestone} IS NULL OR ${trackedSignalsTable.lastMilestone} < ${_buMilestone})`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimed5.length > 0) {
          try {
            await broadcastPhoto(
              FIRST_TARGET_IMG,
              msgPartialTakeProfit(tracked, currentPrice, pnl),
            );
            logger.info(
              {
                symbol: tracked.symbol,
                pnl: pnl.toFixed(2),
                milestone: _buMilestone,
              },
              `FastCycle: PARTIAL TARGET +${_buMilestone}% 📌`,
            );
          } catch (notifErr) {
            logger.warn(
              { err: notifErr, symbol: tracked.symbol },
              "FastCycle: partial target notification failed (non-critical, continuing to in_run check)",
            );
          }
        }
      }

      // Active milestone +8% — промежуточное уведомление между +5% и первой целью
      // Не применяется к whale-паттернам, у которых firstTarget=8 (у них эта точка
      // уже является первой целью и обрабатывается блоком ниже).
      if (
        tracked.status === "active" &&
        firstTarget > 8 &&
        pnl >= 8 &&
        (tracked.lastMilestone ?? 0) < 8
      ) {
        const claimed8 = await dbWriteStrict(
          "trackedSignal/fast-8pct-milestone",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                lastMilestone: 8,
                peakPrice: newPeak,
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastMilestone} IS NULL OR ${trackedSignalsTable.lastMilestone} < 8)`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimed8.length > 0) {
          try {
            const _liqCtx8 = await _buildLiqCtx(
              tracked.symbol,
              currentPrice,
            ).catch(() => null);
            await broadcastPhoto(
              MILESTONE8_IMG,
              msg8PercentHit(tracked, currentPrice, _liqCtx8),
            );
            logger.info(
              { symbol: tracked.symbol, pnl: pnl.toFixed(2) },
              "FastCycle: MILESTONE +8% 🎯",
            );
          } catch (notifErr) {
            logger.warn(
              { err: notifErr, symbol: tracked.symbol },
              "FastCycle: 8% milestone notification failed (non-critical)",
            );
          }
        }
      }

      // Active → in_run transition (first target)
      if (tracked.status === "active" && pnl >= firstTarget) {
        const claimedRun = await dbWriteStrict(
          "trackedSignal/fast-to-inRun",
          () =>
            db
              .update(trackedSignalsTable)
              .set({
                status: "in_run",
                peakPrice: newPeak,
                trailingStopLevel: trailingStop,
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'active'`,
              )
              .returning({ id: trackedSignalsTable.id }),
        );
        if (claimedRun.length === 0) continue; // другой процесс уже сделал переход

        // DB уже обновлён в in_run — нотификация в отдельном try/catch, её ошибка не критична
        try {
          const minutesSinceDetection = ageMs / 60000;
          const isLateSignal = minutesSinceDetection < 10 && pnl >= 25;
          if (isLateSignal) {
            await broadcastPhoto(
              POSITION_UPDATE_IMG,
              msgLateSignal(tracked, currentPrice, pnl),
            );
            logger.info(
              {
                symbol: tracked.symbol,
                pnl,
                minutesSinceDetection: minutesSinceDetection.toFixed(1),
              },
              "FastCycle: → IN_RUN (late signal) ⚠️",
            );
          } else {
            const _liqCtxFirst = await _buildLiqCtx(
              tracked.symbol,
              currentPrice,
            ).catch(() => null);
            await broadcastPhoto(
              MILESTONE10_IMG,
              msgFirstTarget(tracked, currentPrice, _liqCtxFirst),
            );
            logger.info(
              { symbol: tracked.symbol, pnl },
              "FastCycle: → IN_RUN 🚀",
            );
          }
        } catch (notifErr) {
          logger.warn(
            { err: notifErr, symbol: tracked.symbol },
            "FastCycle: in_run notification failed (non-critical, DB already updated)",
          );
        }
        continue;
      }

      // in_run: trailing stop and milestones
      if (tracked.status === "in_run") {
        // Трейлинг только что активировался (пик пересёк trailingActivation%)
        if (trailingJustActivated) {
          // ВАЖНО: guard по lastMilestone, а НЕ по trailingStopLevel IS NULL.
          // Ранний peakChanged-апдейт (строка выше) уже выставил trailingStopLevel до
          // того, как мы сюда дошли — IS NULL guard всегда даёт 0 строк → сообщение
          // никогда не отправлялось. Используем lastMilestone как атомарный lock:
          // ставим trailingActivation (15 или 12) — тот же механизм, что у milestone-блока.
          const claimedTrail = await dbWriteStrict(
            "trackedSignal/trailing-activated",
            () =>
              db
                .update(trackedSignalsTable)
                .set({
                  peakPrice: newPeak,
                  trailingStopLevel: trailingStop,
                  lastMilestone: trailingActivation,
                  updatedAt: new Date(),
                })
                .where(
                  sql`${trackedSignalsTable.id} = ${tracked.id}
            AND (${trackedSignalsTable.lastMilestone} IS NULL OR ${trackedSignalsTable.lastMilestone} < ${trailingActivation})`,
                )
                .returning({ id: trackedSignalsTable.id }),
          );
          if (claimedTrail.length === 0) continue; // другой процесс уже активировал трейлинг
          const _liqCtxTrail = await _buildLiqCtx(
            tracked.symbol,
            currentPrice,
          ).catch(() => null);
          const trailingMsg = msgTrailingActivated(
            tracked,
            currentPrice,
            trailingStop,
            _liqCtxTrail,
          );
          if (trailingActivation === 15) {
            await broadcastPhoto(MILESTONE15_IMG, trailingMsg);
          } else {
            await broadcast(trailingMsg);
          }
          logger.info(
            { symbol: tracked.symbol, pnl: pnl.toFixed(2), trailingStop },
            "FastCycle: TRAILING ACTIVATED 🚀",
          );
          continue;
        }

        // Трейлинг сработал — фиксируем прибыль
        if (trailingHit && newPeak !== tracked.entryPrice) {
          const peakPnl = computePeakPnl({ ...tracked, peakPrice: newPeak });
          // Используем теоретическую цену трейлинг-стопа (peak * (1 - trailing%)) как exitPrice.
          // Это даёт корректный PnL: (peak * 0.90 - entry) / entry * 100, а не peak_pnl - 10%.
          const trailingExitPnl =
            ((trailingStop - tracked.entryPrice) / tracked.entryPrice) * 100;
          const claimedProfit = await dbWriteStrict(
            "trackedSignal/trailing-stop-profit",
            () =>
              db
                .update(trackedSignalsTable)
                .set({
                  status: "profit",
                  exitPrice: trailingStop,
                  pnlPercent: trailingExitPnl,
                  peakPrice: newPeak,
                  trailingStopLevel: trailingStop,
                  closedAt: new Date(),
                  updatedAt: new Date(),
                })
                .where(
                  sql`${trackedSignalsTable.id} = ${tracked.id} AND ${trackedSignalsTable.status} = 'in_run'`,
                )
                .returning({ id: trackedSignalsTable.id }),
          );
          if (claimedProfit.length === 0) continue; // другой процесс уже закрыл
          await broadcastPhoto(
            TRAILING_STOP_IMG,
            msgTrailingStopHit(tracked, currentPrice, peakPnl, trailingExitPnl),
          );
          logger.info(
            { symbol: tracked.symbol, trailingExitPnl, peakPnl },
            "FastCycle: TRAILING STOP hit 🏁",
          );
          continue;
        }

        const reachedMilestone = nextMilestone(tracked.lastMilestone, pnl);
        if (reachedMilestone) {
          const claimedMs = await dbWriteStrict(
            "trackedSignal/milestone-claim",
            () =>
              db
                .update(trackedSignalsTable)
                .set({
                  peakPrice: newPeak,
                  trailingStopLevel: trailingStop,
                  lastMilestone: reachedMilestone,
                  updatedAt: new Date(),
                })
                .where(
                  sql`${trackedSignalsTable.id} = ${tracked.id} AND (${trackedSignalsTable.lastMilestone} IS NULL OR ${trackedSignalsTable.lastMilestone} < ${reachedMilestone})`,
                )
                .returning({ id: trackedSignalsTable.id }),
          );
          if (claimedMs.length === 0) continue; // другой процесс уже отправил этот milestone
          const _liqCtxMs = await _buildLiqCtx(
            tracked.symbol,
            currentPrice,
          ).catch(() => null);
          const msText = msgMilestone(
            tracked,
            reachedMilestone,
            currentPrice,
            trailingStop,
            _liqCtxMs,
          );
          if (reachedMilestone === 10) {
            await broadcastPhoto(MILESTONE10_IMG, msText);
          } else if (reachedMilestone === 20) {
            await broadcastPhoto(MILESTONE20_IMG, msText);
          } else if (reachedMilestone === 25) {
            await broadcastPhoto(MILESTONE25_IMG, msText);
          } else if (reachedMilestone === 30) {
            await broadcastPhoto(MILESTONE30_IMG, msText);
          } else if (reachedMilestone === 50) {
            await broadcastPhoto(MILESTONE50_IMG, msText);
          } else if (reachedMilestone === 55) {
            await broadcastPhoto(MILESTONE55_IMG, msText);
          } else if (reachedMilestone === 60) {
            await broadcastPhoto(MILESTONE60_IMG, msText);
          } else if (reachedMilestone === 65) {
            await broadcastPhoto(MILESTONE65_IMG, msText);
          } else if (reachedMilestone === 70) {
            await broadcastPhoto(MILESTONE70_IMG, msText);
          } else if (reachedMilestone === 75) {
            await broadcastPhoto(MILESTONE75_IMG, msText);
          } else if (reachedMilestone === 80) {
            await broadcastPhoto(MILESTONE80_IMG, msText);
          } else if (reachedMilestone === 85) {
            await broadcastPhoto(MILESTONE85_IMG, msText);
          } else if (reachedMilestone === 90) {
            await broadcastPhoto(MILESTONE90_IMG, msText);
          } else if (reachedMilestone === 95) {
            await broadcastPhoto(MILESTONE95_IMG, msText);
          } else if (reachedMilestone === 100) {
            await broadcastPhoto(MILESTONE100_IMG, msText);
          } else {
            await broadcast(msText);
          }
          logger.info(
            { symbol: tracked.symbol, milestone: reachedMilestone },
            "FastCycle: MILESTONE 🎯",
          );
          continue;
        }

        if (peakChanged) {
          await dbWriteBestEffort("trackedSignal/inRun-peak-silent", () =>
            db
              .update(trackedSignalsTable)
              .set({
                peakPrice: newPeak,
                trailingStopLevel: trailingStop,
                updatedAt: new Date(),
              })
              .where(eq(trackedSignalsTable.id, tracked.id)),
          );
        }
      } else if (peakChanged) {
        // Update peak for active signals silently
        await dbWriteBestEffort("trackedSignal/active-peak-silent", () =>
          db
            .update(trackedSignalsTable)
            .set({ peakPrice: newPeak, updatedAt: new Date() })
            .where(eq(trackedSignalsTable.id, tracked.id)),
        );
      }
    } catch (err) {
      logger.error(
        { err, symbol: tracked.symbol },
        "FastCycle: ошибка обработки сигнала (пропускаем)",
      );
    }
  }
}

// ── OI Watch Cycle: checks every 2 min for volume/price confirmation ──────────
export async function runOiWatchCycle(): Promise<void> {
  const now = new Date();

  // Expire stale entries
  await dbWriteBestEffort("oiWatch/stale-expire", () =>
    db
      .update(oiWatchTable)
      .set({ status: "expired" })
      .where(
        and(
          eq(oiWatchTable.status, "watching"),
          lt(oiWatchTable.expiresAt, now),
        ),
      ),
  );

  const watching = await db
    .select()
    .from(oiWatchTable)
    .where(eq(oiWatchTable.status, "watching"));

  if (watching.length === 0) return;

  // Fetch all prices in one call
  let tickers: { symbol: string; lastPrice: string }[] = [];
  try {
    tickers = (await getFutureTickers()) as any[];
  } catch {
    return;
  }

  const priceMap = new Map<string, number>();
  for (const t of tickers) priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);

  for (const w of watching) {
    const currentPrice = priceMap.get(w.symbol);
    if (!currentPrice) continue;

    const priceMovePct =
      ((currentPrice - w.priceAtEntry) / w.priceAtEntry) * 100;

    // ── Fill missing OI columns ───────────────────────────────────────────────
    // Записи созданные через prescan-path (isVolConfirmed=true) не содержат OI полей.
    // CoinGlass кэш TTL 5 мин — если сканер уже запрашивал этот символ, вызов мгновенный.
    if (w.oi30mChange === null) {
      // oi5mChange removed, use oi30mChange as proxy
      try {
        const cg = await getCoinglassOI(w.symbol, currentPrice);
        if (cg?.available) {
          await dbWriteBestEffort("oiWatch/fill-missing-oi", () =>
            db
              .update(oiWatchTable)
              .set({
                oi30mChange: cg.oiChange30m ?? null,
                oi1hChange: cg.oiChange1h ?? null,
                oi24hChange: cg.oiChange24h ?? null,
              })
              .where(eq(oiWatchTable.id, w.id)),
          );
        }
      } catch {
        /* non-critical */
      }
    }

    // ── PATH A: Confirmed signal (vol was already ≥ 2x at scanner time) ────────
    // Full payload stored — re-confirm price didn't collapse, then fire full signal.
    if (w.isVolConfirmed && w.signalPayload) {
      const pathAPayload = w.signalPayload as {
        alphaResult: any;
        signalRow: any;
      };
      const pathASentimentKey: string =
        pathAPayload.alphaResult?.sentimentKey ?? "";

      // ── UNIFIED PRICE CONFIRMATION GATE ──────────────────────────────────────
      // Сигнал публикуется ТОЛЬКО если цена уже реально двинулась с момента обнаружения.
      // Статистика: 0 прибыльных сделок из 98 сигналов где итоговый пик < 3%.
      // Окно мониторинга 90 мин — либо цена подтверждает движение, либо сигнал тихо истекает.
      const PRICE_CONFIRM_PCT: Record<string, number> = {
        trend_accumulation: 1.5, // трендовое — снижено с 2.0: тренд подтверждён, не нужен большой порог
        bullish_accumulation: 2.0,
      };
      const minPriceMove = PRICE_CONFIRM_PCT[pathASentimentKey] ?? 2.0;

      // Если цена ещё не дошла до порога — ждём следующего цикла (не удаляем запись)
      if (priceMovePct < minPriceMove) {
        logger.debug(
          {
            symbol: w.symbol,
            pattern: pathASentimentKey,
            priceMovePct: priceMovePct.toFixed(1),
            required: minPriceMove,
          },
          `OI Watch: ждём подтверждения цены — нужно +${minPriceMove}%, сейчас ${priceMovePct.toFixed(1)}%`,
        );
        continue;
      }

      // Hard dump cancel: если цена упала > 5% с начала watch — монета не туда идёт
      if (priceMovePct < -5) {
        await dbWriteBestEffort("oiWatch/pathA-hard-dump-cancel", () =>
          db
            .update(oiWatchTable)
            .set({ status: "expired" })
            .where(eq(oiWatchTable.id, w.id)),
        );
        logger.info(
          { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) },
          "OI Watch: отменён (дамп > 5% с начала watch)",
        );
        continue;
      }

      // CVD финальная проверка: если продажи доминируют в момент выстрела — откладываем
      // Не expire (постоянная потеря) — CVD может кратковременно уходить в минус прямо
      // перед пампом (ликвидации лонгов → разворот). Ждём следующего цикла.
      const cvd = await fetchCVD(w.symbol);
      if (cvd && !cvd.positive) {
        logger.info(
          {
            symbol: w.symbol,
            buyPct: cvd.buyPct.toFixed(1) + "%",
            sellPct: cvd.sellPct.toFixed(1) + "%",
          },
          "🔴 OI Watch PATH A: CVD негативный — откладываем до следующего цикла",
        );
        continue;
      }
      if (cvd) {
        logger.info(
          {
            symbol: w.symbol,
            buyPct: cvd.buyPct.toFixed(1) + "%",
            sellPct: cvd.sellPct.toFixed(1) + "%",
          },
          "🟢 OI Watch PATH A: CVD подтверждён — стреляем",
        );
      }

      // Trend Accumulation: защита от выстрела на затухающем импульсе.
      // Тейкеры не подтверждают покупки в момент выстрела → ждём следующего цикла.
      // Vol-decay (70% от entryVolMult) проверяется в PATH B где есть доступ к текущему volMult.
      if (pathASentimentKey === "trend_accumulation") {
        const freshTaker = await getCoinglassTakerFlow(w.symbol).catch(
          () => null,
        );
        if (
          freshTaker?.available &&
          freshTaker.dominance === "sell" &&
          freshTaker.netBuyPct < -5
        ) {
          logger.info(
            { symbol: w.symbol, netBuyPct: freshTaker.netBuyPct.toFixed(1) },
            "PATH A trend_accum: отложен — taker медвежий (dominance=sell, netBuyPct < -5%)",
          );
          continue;
        }

        if (w.avgVolume && w.avgVolume > 0) {
          const freshKlines = await getKlines(w.symbol, "15m", 2).catch(
            () => [] as BingXKline[],
          );
          const freshCandle = freshKlines[freshKlines.length - 1];
          if (freshCandle) {
            const freshClose = parseFloat(freshCandle.close) || 0;
            const freshVol = (parseFloat(freshCandle.volume) || 0) * freshClose;
            const freshVolMult = freshVol / w.avgVolume;
            if (freshVolMult < 0.8) {
              logger.info(
                {
                  symbol: w.symbol,
                  freshVolMult: freshVolMult.toFixed(2),
                  avgVol: w.avgVolume.toFixed(0),
                },
                "PATH A trend_accum: отложен — свежий volMult затух (< 0.8x)",
              );
              continue;
            }
          }
        }
      }

      try {
        const payload = w.signalPayload as {
          alphaResult: any;
          signalRow: InsertSignal;
        };
        const alphaResult = payload.alphaResult;
        const signalRow = payload.signalRow;

        // ── Spot volume gate (OI Watch PATH A) ──────────────────────────────────
        // Проверяем спот-объём перед выстрелом — токены без реального спот-рынка
        // не должны попадать к подписчикам даже если OI/объём на фьючах аномальные.
        let paSpotVol24h: number | null = null;
        let paMcapUsdA: number | null = null;
        {
          const [paFsVol, paMcapRaw] = await Promise.all([
            getFsVolume(w.symbol).catch(() => null),
            fetchMarketCap(w.symbol).catch(() => null),
          ]);
          const paSpotVol = paFsVol?.spotVolUsd24h ?? null;
          paMcapUsdA = paMcapRaw?.mcap ?? null;
          if (paSpotVol === null) {
            // Fallback 1: getSpotVolume (pairs-markets, ВСЕ биржи — шире чем Binance/OKX/Bybit)
            // getFsVolume возвращает null для токенов без спота на Binance/OKX/Bybit (напр. BingX-exclusive).
            // pairs-markets покрывает Gate.io, KuCoin и др. — даёт реальный спот-объём.
            const svFb = await getSpotVolume(w.symbol).catch(() => null);
            const svFbVol =
              (svFb?.volumeUsd24h ?? 0) > 0 ? svFb!.volumeUsd24h! : null;
            if (svFbVol !== null) {
              paSpotVol24h = svFbVol;
              paMcapUsdA = paMcapRaw?.mcap ?? null;
              logger.info(
                { symbol: w.symbol, spotVol24h: svFbVol },
                "OI Watch PATH A: getFsVolume→null, getSpotVolume (pairs-markets) fallback",
              );
            } else {
              // Fallback 2: SpotPool кэш (обновляется каждые 30 мин, тоже через getFsVolume)
              const poolFallback = getSpotPoolEntry(w.symbol);
              paSpotVol24h = poolFallback?.spotVol24h ?? null;
              paMcapUsdA = paMcapRaw?.mcap ?? poolFallback?.mcapUsd ?? null;
              logger.warn(
                { symbol: w.symbol, spotPoolFallback: paSpotVol24h !== null },
                "OI Watch PATH A: CoinGlass spot недоступен — degraded mode, spot gate пропущен",
              );
            }
          } else {
            paSpotVol24h = paSpotVol;
            if (paMcapUsdA === null || paSpotVol < paMcapUsdA * 0.01) {
              await dbWriteBestEffort("oiWatch/pathA-spot-gate-cancel", () =>
                db
                  .update(oiWatchTable)
                  .set({ status: "expired" })
                  .where(eq(oiWatchTable.id, w.id)),
              );
              const pct = paMcapUsdA
                ? ((paSpotVol / paMcapUsdA) * 100).toFixed(3)
                : "нет MCap";
              logger.info(
                { symbol: w.symbol, paSpotVol, paMcapUsdA, pct },
                "OI Watch PATH A: спот-объём < 1% MCap — сигнал отменён",
              );
              continue;
            }
          }
        }

        // Атомарно захватываем запись ПЕРВЫМ — гарантирует что только один PID
        // вставит сигнал в БД и отправит Telegram (при параллельном деплое).
        // Раньше: insert → trackSignal → claim → broadcast (оба PID вставляли в signals до claim).
        // Теперь: claim → insert → trackSignal → broadcast (только победивший PID пишет в БД).
        const claimedA = await dbWriteStrict("oiWatch/pathA-fire-claim", () =>
          db
            .update(oiWatchTable)
            .set({ status: "fired", firedAt: new Date() })
            .where(
              and(
                eq(oiWatchTable.id, w.id),
                eq(oiWatchTable.status, "watching"),
              ),
            )
            .returning({ id: oiWatchTable.id }),
        );
        if (claimedA.length === 0) continue; // другой PID уже обработал — пропускаем
        // Supersede: гасим другие активные watching/confirming записи того же символа
        const _supersededA =
          (await dbWriteBestEffort("oiWatch/supersede-A", () =>
            db
              .update(oiWatchTable)
              .set({ status: "expired", volStatusReason: "superseded" })
              .where(
                and(
                  eq(oiWatchTable.symbol, w.symbol),
                  inArray(oiWatchTable.status, ["watching", "confirming"]),
                ),
              )
              .returning({
                id: oiWatchTable.id,
                oi30m: oiWatchTable.oi30mChange,
                oi1h: oiWatchTable.oi1hChange,
                oi24h: oiWatchTable.oi24hChange,
                volMult: oiWatchTable.volumeMultiplier,
              }),
          )) ??
          ([] as {
            id: number;
            oi30m: number | null;
            oi1h: number | null;
            oi24h: number | null;
            volMult: number;
          }[]);

        // Insert signal to DB (только один PID дошёл до этой строки)
        const [inserted] = await dbWriteStrict(
          "signals/oiWatch-pathA-insert",
          () =>
            db
              .insert(signalsTable)
              .values({
                ...signalRow,
                price: currentPrice, // обновляем до текущей рыночной цены
                detectedAt: new Date(),
              })
              .returning(),
        );

        // Start tracking (stop-loss / targets) — проверяем успех
        const tracked = await trackSignal({
          symbol: w.symbol,
          signalId: inserted.id,
          signalType: alphaResult.grade ?? "alpha",
          sentiment: alphaResult.sentiment,
          sentimentKey: alphaResult.sentimentKey,
          alphaScore: alphaResult.alphaScore,
          entryPrice: currentPrice,
          entryOi:
            alphaResult.openInterest > 0 ? alphaResult.openInterest : null,
          entryCvd30m: inserted.entryCvd30m ?? null,
          entryCvd1h: inserted.entryCvd1h ?? null,
          entryCvd4h: inserted.entryCvd4h ?? null,
          marketCapUsd: paMcapUsdA ?? null,
          entrySpotVol24h: paSpotVol24h ?? null,
          entrySpotMcapPct:
            paSpotVol24h !== null && paMcapUsdA
              ? (paSpotVol24h / paMcapUsdA) * 100
              : null,
        });
        if (tracked === false) {
          logger.error(
            { symbol: w.symbol },
            "PATH A: trackSignal упал — broadcast отменён (слежка не создана)",
          );
          continue;
        }
        if (tracked === "skip") {
          logger.info(
            { symbol: w.symbol },
            "PATH A: монета уже в трекере — broadcast всё равно отправляем (claim атомарный)",
          );
        } else {
          resetPrescanCycleCount(w.symbol);
        }

        // Send full Telegram alert — включаем priceConfirmPct: насколько цена уже прошла
        await broadcastBatchAlert([
          {
            ...alphaResult,
            price: currentPrice,
            priceConfirmPct: priceMovePct,
            spotVol24h: paSpotVol24h,
            marketCapUsd: paMcapUsdA,
            _oiWatchPath: "A",
            entryOb: consumeObAtFire(w.symbol),
          },
        ]);

        logger.info(
          {
            symbol: w.symbol,
            grade: alphaResult.grade,
            alphaScore: alphaResult.alphaScore,
            priceMovePct: priceMovePct.toFixed(1),
          },
          "✅ OI Watch → ПОЛНЫЙ СИГНАЛ: подтверждён и отправлен",
        );
      } catch (err) {
        logger.error(
          { err, symbol: w.symbol },
          "OI Watch: ошибка при firing confirmed signal",
        );
      }
      continue; // не падаем в PATH B
    }

    // ── PATH B: Unconfirmed watch (vol was < 2x at scanner time) ────────────────
    // Waiting for volume spike or price breakout to fire a lightweight alert.
    if (priceMovePct < -8) {
      await dbWriteBestEffort("oiWatch/pathB-price-dump-cancel", () =>
        db
          .update(oiWatchTable)
          .set({ status: "expired" })
          .where(eq(oiWatchTable.id, w.id)),
      );
      logger.info(
        { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) },
        "OI Watch: expired (price dumped)",
      );
      continue;
    }

    // Если цена уже улетела >20% от точки входа в watch — памп уже случился.
    // Входить сейчас = покупать на хае. BLEND: +61% от точки входа → не стреляем.
    if (priceMovePct >= 20) {
      // Атомарно захватываем запись (AND status='watching') — гарантирует что только один
      // процесс отправит уведомление при параллельном запуске двух инстансов во время деплоя.
      const claimed = await dbWriteBestEffort("oiWatch/pathB-pump-expire", () =>
        db
          .update(oiWatchTable)
          .set({ status: "expired" })
          .where(
            and(eq(oiWatchTable.id, w.id), eq(oiWatchTable.status, "watching")),
          )
          .returning({ id: oiWatchTable.id }),
      );
      if (!claimed || claimed.length === 0) continue; // другой процесс обработал или DB недоступен
      logger.info(
        { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) },
        "OI Watch PATH B: expired — памп уже случился (price >= 20% от входа в watch)",
      );
      continue;
    }

    try {
      const klines = await getKlines(w.symbol, "30m", 7);
      if (klines.length < 5) continue;

      const cur = klines[klines.length - 1];
      const hist = klines.slice(0, -1);
      const close = parseFloat(cur.close) || 0;
      const curVol = (parseFloat(cur.volume) || 0) * close;
      const avgVol =
        w.avgVolume ??
        hist.reduce(
          (s, k) =>
            s + (parseFloat(k.volume) || 0) * (parseFloat(k.close) || 0),
          0,
        ) / hist.length;
      if (!avgVol) continue;

      const volMult = curVol / avgVol;
      const _currentPriceMove =
        ((close - parseFloat(cur.open)) / parseFloat(cur.open)) * 100;

      // Записываем текущий volMult в БД — фронтенд отображает прогресс к порогу.
      await dbWriteBestEffort("oiWatch/pathB-volMult-update", () =>
        db
          .update(oiWatchTable)
          .set({ currentVolMult: volMult })
          .where(eq(oiWatchTable.id, w.id)),
      );

      // Подтверждение объёма — только CoinGlass агрег. turnover >= 10%.
      // BingX volMult не используется: одна биржа не показатель глобальной активности.
      // Если CoinGlass недоступен — токен остаётся в watching до экспайра.
      let volConfirmed = false; // определяется CoinGlass turnover ниже

      // Если OI отрицательный — накопления нет, это распродажа. Не стреляем.
      if (w.oiChange < 0) {
        await dbWriteBestEffort("oiWatch/pathB-oi-negative-cancel", () =>
          db
            .update(oiWatchTable)
            .set({ status: "expired" })
            .where(eq(oiWatchTable.id, w.id)),
        );
        logger.debug(
          { symbol: w.symbol, oiChange: w.oiChange },
          "OI Watch PATH B: OI отрицательный — сигнал отменён",
        );
        continue;
      }

      // OI cap 20%: если OI при добавлении в watch уже был > 20% — это перегретый лонг/ловушка.
      // Данные: OI 25%+ = 0% win rate. AXL(90%), PIPPIN(56%), MOODENG(23%) — все SL.
      // Было 10% — слишком жёстко: PLAYSOUT (11.33%) попал под фильтр и пропустил памп +20%.
      // Поднято до 20% — совпадает с реальными проблемными случаями (23%+).
      // Исключение: oi24h_accum (Layer 8) — там oiChange это OI ЗА 24Ч у лидеров накопления,
      // это норма 25-100%+ по определению триггера, а не признак перегрева короткого спайка.
      // Защита от реального перегрева для этой ветки уже есть на этапе seeding (scanner.ts
      // Layer 8: price24h должен быть -5%..+35%) — колпак по OI здесь не нужен.
      if (w.triggerTf !== "oi24h_accum" && w.oiChange > 20) {
        await dbWriteBestEffort("oiWatch/pathB-oi-cap-cancel", () =>
          db
            .update(oiWatchTable)
            .set({ status: "expired" })
            .where(eq(oiWatchTable.id, w.id)),
        );
        logger.info(
          { symbol: w.symbol, oiChange: w.oiChange.toFixed(1) + "%" },
          "OI Watch PATH B: OI > 20% — ловушка перегретого лонга, отменяем",
        );
        continue;
      }

      // Если цена уже упала >4% с момента входа в watch — движение идёт против нас.
      // Это либо распродажа, либо OI-рост был за счёт шортов. Отменяем.
      if (priceMovePct < -4.0) {
        await dbWriteBestEffort("oiWatch/pathB-price-drop-cancel", () =>
          db
            .update(oiWatchTable)
            .set({ status: "expired" })
            .where(eq(oiWatchTable.id, w.id)),
        );
        logger.debug(
          { symbol: w.symbol, priceMovePct: priceMovePct.toFixed(1) },
          "OI Watch PATH B: цена упала >4% от входа — сигнал отменён",
        );
        continue;
      }

      // ── ОБЯЗАТЕЛЬНАЯ ПРОВЕРКА: Cross OI должен быть положительным при срабатывании ──
      // Подтягиваем свежие данные CoinGlass — 30m OI отражает текущий импульс.
      // Если он стал отрицательным — накопление завершилось / шорты уже закрыты. Отменяем.
      let cgOI: Awaited<ReturnType<typeof getCoinglassOI>> | null = null;
      try {
        cgOI = await getCoinglassOI(w.symbol, priceMap.get(w.symbol));
      } catch {
        /* non-critical */
      }

      // ── Подтверждение объёма: два обязательных условия ─────────────────────────
      // 1. CoinGlass агрег. turnover >= 15% (vol/OI по всем биржам) — глобальная активность.
      //    Fallback: BingX volMult >= 1.5x если turnover недоступен или ниже порога.
      //    Данные: 0.5-0.68x = шум, MEGA/ZKP прошли с 0.52-0.68x → SL/cancel.
      // 2. Спотовый CVD положительный: cvd30m ИЛИ cvd1h — покупки реальные, не шорт-сквиз.
      // Оба условия должны выполняться одновременно.
      // Если любой источник недоступен — volConfirmed = false, токен остаётся в watching.

      // ── OI межцикловый контроль: early expire если OI падает 2 цикла подряд ──────
      // oiChange30m из свежего CoinGlass запроса; lastOiCheck/prevOiCheck накапливаются в DB.
      const freshOi30m = cgOI?.available ? (cgOI.oiChange30m ?? null) : null;
      if (
        freshOi30m !== null &&
        w.lastOiCheck !== null &&
        w.prevOiCheck !== null &&
        w.prevOiCheck2 !== null
      ) {
        const decline1 = w.prevOiCheck < w.prevOiCheck2;
        const decline2 = w.lastOiCheck < w.prevOiCheck;
        const decline3 = freshOi30m < w.lastOiCheck;
        if (decline1 && decline2 && decline3) {
          await dbWriteBestEffort("oiWatch/pathB-oi-3cycle-decline", () =>
            db
              .update(oiWatchTable)
              .set({ status: "expired" })
              .where(eq(oiWatchTable.id, w.id)),
          );
          logger.info(
            {
              symbol: w.symbol,
              prevOiCheck2: w.prevOiCheck2.toFixed(2),
              prevOiCheck: w.prevOiCheck.toFixed(2),
              lastOiCheck: w.lastOiCheck.toFixed(2),
              freshOi30m: freshOi30m.toFixed(2),
            },
            "OI Watch PATH B: OI падает 3 цикла подряд — early expire",
          );
          continue;
        }
      }
      // Обновляем OI tracking для следующего цикла (non-critical)
      if (freshOi30m !== null) {
        await dbWriteBestEffort("oiWatch/pathB-oi-tracking", () =>
          db
            .update(oiWatchTable)
            .set({
              prevOiCheck2: w.prevOiCheck,
              prevOiCheck: w.lastOiCheck,
              lastOiCheck: freshOi30m,
            })
            .where(eq(oiWatchTable.id, w.id)),
        );
      }

      const cgVolUsd = cgOI?.cgVolUsd ?? null;
      const cgOiUsd = cgOI?.oiUsd ?? null;
      const cgTurnover =
        cgVolUsd && cgOiUsd && cgOiUsd > 0 ? cgVolUsd / cgOiUsd : null;
      // Третий путь: объём вырос на 80%+ с момента входа в watch (межцикловая дельта)
      const entryVolMult_w = w.entryVolMult ?? null;
      const volAccelWatch =
        entryVolMult_w && entryVolMult_w > 0 ? volMult / entryVolMult_w : null;
      // Спот объём: норм. мультипликатор из prescanTracker (lastSpotVol1h / spotVolAvg1h)
      const _peW = getPrescanEntry(w.symbol);
      const spotVolMult =
        _peW?.spotVolAvg1h && _peW?.lastSpotVol1h
          ? _peW.lastSpotVol1h / _peW.spotVolAvg1h
          : null;
      const turnoverOk =
        (cgTurnover !== null && cgTurnover >= 0.15) ||
        (spotVolMult !== null && spotVolMult >= 1.5) ||
        (volAccelWatch !== null && volAccelWatch >= 1.8);

      const spotCvdB = await getSpotCvdMtf(w.symbol).catch(() => null);
      const cvdOk =
        spotCvdB?.available === true &&
        (spotCvdB.cvd30m === true || spotCvdB.cvd1h === true);

      volConfirmed = turnoverOk && cvdOk;

      const volStatusReason: string = !turnoverOk
        ? "no_turnover"
        : spotCvdB === null
          ? "cvd_unavail"
          : !cvdOk
            ? "cvd_negative"
            : "confirmed";

      await dbWriteBestEffort("oiWatch/pathB-volStatus", () =>
        db
          .update(oiWatchTable)
          .set({ volStatusReason })
          .where(eq(oiWatchTable.id, w.id)),
      );

      logger.info(
        {
          symbol: w.symbol,
          turnover: cgTurnover?.toFixed(3) ?? "n/a",
          turnoverOk,
          cvd30m: spotCvdB?.cvd30m ?? "n/a",
          cvd1h: spotCvdB?.cvd1h ?? "n/a",
          cvdOk,
          volStatusReason,
        },
        "OI Watch PATH B: проверка объёма",
      );

      // OI30m временно может уйти в минус при ротации лонгов; expire только если
      // отрицательны оба ТФ (30m И 1h) — устойчивое снижение, а не шум.
      if (
        cgOI?.available &&
        cgOI.oiChange30m !== null &&
        cgOI.oiChange30m < 0 &&
        cgOI.oiChange1h !== null &&
        cgOI.oiChange1h < 0
      ) {
        await dbWriteBestEffort("oiWatch/pathB-crossOI-cancel", () =>
          db
            .update(oiWatchTable)
            .set({ status: "expired" })
            .where(eq(oiWatchTable.id, w.id)),
        );
        logger.info(
          {
            symbol: w.symbol,
            crossOi30m: cgOI.oiChange30m.toFixed(1) + "%",
            crossOi1h: cgOI.oiChange1h.toFixed(1) + "%",
          },
          "OI Watch PATH B: Cross OI отрицательный на 30m+1h — сигнал отменён",
        );
        continue;
      }

      // ── ФИЛЬТР: для накопления требуем подтверждение ценой ──────────────────────
      // PATH B стреляет когда объём подтвердился. Но для аккумуляционных паттернов
      // нужно чтобы цена ТОЖЕ начала двигаться (>= 2%). Иначе накопление без выстрела.
      // null payload = добавлен из low-vol пути (OI есть, объём не пришёл) = всегда накопление.
      // Токены без движения цены (RARE +0.9%, WAVES +0.76%) остаются в watching до 2h экспайра.
      const pathBSentimentKey =
        (w.signalPayload as any)?.alphaResult?.sentimentKey ?? null;
      // Аномалия добавлена в список "требует подтверждения ценой" (наравне с накоплением).
      // Данные: anomaly win rate 13%, 9 SL из 15. Без OI-поддержки это просто спайк объёма — шум.
      // Требуем price >= 2% перед выстрелом — хотя бы минимальное подтверждение движения.
      const isAccumPatternB =
        pathBSentimentKey === "trend_accumulation" ||
        pathBSentimentKey === "bullish_accumulation" ||
        pathBSentimentKey === "spot_vol_accumulation" ||
        pathBSentimentKey === null;
      const minPriceMoveB = 2.0;

      if (isAccumPatternB && priceMovePct < minPriceMoveB) {
        logger.debug(
          {
            symbol: w.symbol,
            priceMovePct: priceMovePct.toFixed(1),
            sentimentKey: pathBSentimentKey,
          },
          `OI Watch PATH B: накопление — ждём движения цены >= ${minPriceMoveB}% (держим в watching)`,
        );
        continue; // Остаётся в watching, не меняем статус — ждём пока цена тронется
      }

      // ── TF-фильтр для накопительных паттернов ────────────────────────────────────
      // Одиночный "30m" или "1h" недостаточен — это может быть разовый спайк.
      // Требуем подтверждение минимум двумя ТФ: "all+30m", "all+1h", "1h+4h".
      // Данные: MEGA #2 прошёл с триггером "30m only" → cancel -9.2%.
      const ACCUM_VALID_TF = ["all+30m", "all+1h", "1h+4h"];
      // TF-фильтр применяем ТОЛЬКО когда sentimentKey известен (паттерн уже определён).
      // Fallback-записи (cg_timeout/cg_building/dark_flow/tSteady) имеют sentimentKey=null —
      // они попали в OI Watch не как "single-TF спайк", а из-за недоступности CG или
      // медленного накопления. Для них multi-TF требование семантически неприменимо.
      if (
        isAccumPatternB &&
        pathBSentimentKey !== null &&
        !ACCUM_VALID_TF.includes(w.triggerTf)
      ) {
        logger.info(
          {
            symbol: w.symbol,
            triggerTf: w.triggerTf,
            validTf: ACCUM_VALID_TF,
            sentimentKey: pathBSentimentKey,
          },
          "OI Watch PATH B: накоп. паттерн — triggerTf не прошёл multi-TF фильтр, держим в watching",
        );
        continue;
      }

      // ── OI при выстреле: хотя бы один ТФ >= 5% (обязательно, CG required) ──────
      // Проверяем свежие данные CoinGlass (уже запрошены выше через cgOI).
      // Цель: не стрелять если OI накопился давно и уже выдыхается.
      // Если CoinGlass недоступен — НЕ стреляем: именно через недоступный CG
      // прошли проблемные сигналы (MEGA #2, ZKP). Держим в watching до появления данных.
      if (isAccumPatternB) {
        if (!cgOI?.available) {
          logger.info(
            { symbol: w.symbol, sentimentKey: pathBSentimentKey },
            "OI Watch PATH B: накоп. паттерн — CoinGlass недоступен, держим в watching",
          );
          continue;
        }
        const oiAtFire = [
          cgOI.oiChange30m,
          cgOI.oiChange1h,
          cgOI.oiChange4h,
        ].filter((v): v is number => v !== null && v !== undefined);
        const maxOiAtFire = oiAtFire.length > 0 ? Math.max(...oiAtFire) : null;
        if (maxOiAtFire === null || maxOiAtFire < 3) {
          logger.info(
            {
              symbol: w.symbol,
              maxOiAtFire: maxOiAtFire?.toFixed(1) ?? "n/a",
              oiAtFire,
              sentimentKey: pathBSentimentKey,
            },
            "OI Watch PATH B: накоп. паттерн — OI при выстреле < 3% на всех ТФ, держим в watching",
          );
          continue;
        }
      }

      let pbSpotVol24h: number | null = null;
      let pbMcapUsdB: number | null = null;
      if (volConfirmed) {
        // ── Spot volume gate (PATH B) ────────────────────────────────────────────
        {
          const [pbFsVol, pbMcapRaw] = await Promise.all([
            getFsVolume(w.symbol).catch(() => null),
            fetchMarketCap(w.symbol).catch(() => null),
          ]);
          const pbSpotVol = pbFsVol?.spotVolUsd24h ?? null;
          const pbMcapUsd = pbMcapRaw?.mcap ?? null;
          pbSpotVol24h = pbSpotVol;
          pbMcapUsdB = pbMcapUsd;
          if (pbSpotVol === null) {
            // CoinGlass временно недоступен — не отменяем сигнал, пропускаем spot gate
            logger.warn(
              { symbol: w.symbol },
              "OI Watch PATH B: CoinGlass spot недоступен — degraded mode, spot gate пропущен",
            );
          } else if (pbMcapUsd === null || pbSpotVol < pbMcapUsd * 0.01) {
            await dbWriteBestEffort("oiWatch/pathB-spot-gate-cancel", () =>
              db
                .update(oiWatchTable)
                .set({ status: "expired" })
                .where(eq(oiWatchTable.id, w.id)),
            );
            const pct = pbMcapUsd
              ? ((pbSpotVol / pbMcapUsd) * 100).toFixed(3)
              : "нет MCap";
            logger.info(
              { symbol: w.symbol, pbSpotVol, pbMcapUsd, pct },
              "OI Watch PATH B: спот-объём < 1% MCap — сигнал отменён",
            );
            continue;
          }
        }

        // Alpha score больше не является блокирующим гейтом — только информационное поле.

        // ── накоп. паттерн spot CVD gate (fallback / tSteady path) ────────────────
        // tSteady-записи (sentimentKey=null) и все накопительные паттерны
        // обязаны проходить spot CVD 1h+4h гейты.
        // Без этого watcher PATH B был «лазейкой» мимо spot CVD проверки.
        //
        // Строгий гейт: раньше блокировал только явный cvd1h/cvd4h === false, а null
        // (данные недоступны или не набрались) пропускал как "не подтверждённо отрицательный".
        // По разбору KAITO выяснилось, что 100% исторических trend_accumulation сигналов идут
        // именно через этот путь — значит именно здесь должно быть обязательное подтверждение,
        // а не в теоретическом live-scan гейте, до которого эти записи фактически не доходят.
        // Теперь требуем строго true на обоих ТФ — null блокирует наравне с false.
        const FB_ACCUM_KEYS = ["trend_accumulation"];
        let pbEntryCvd30m: boolean | null = null;
        let pbEntryCvd1h: boolean | null = null;
        let pbEntryCvd4h: boolean | null = null;
        if (
          !w.signalPayload &&
          (w.sentimentKey === null ||
            FB_ACCUM_KEYS.includes(w.sentimentKey ?? ""))
        ) {
          const fbSpotCvd = await getSpotCvdMtf(w.symbol).catch(() => null);
          if (!fbSpotCvd?.available) {
            // Данных нет — ждём, не отменяем: null ≠ негативный CVD
            logger.info(
              { symbol: w.symbol, sentimentKey: w.sentimentKey },
              "OI Watch PATH B: нет спот CVD данных — откладываем",
            );
            continue;
          }
          if (fbSpotCvd.cvd1h === false && fbSpotCvd.cvd4h === false) {
            // Оба ТФ явно медвежьи (false, не null) — устойчивое давление продаж
            await dbWriteBestEffort("oiWatch/pathB-cvd-bearish-cancel", () =>
              db
                .update(oiWatchTable)
                .set({ status: "expired" })
                .where(eq(oiWatchTable.id, w.id)),
            );
            logger.info(
              {
                symbol: w.symbol,
                sentimentKey: w.sentimentKey,
                cvd1h: fbSpotCvd.cvd1h,
                cvd4h: fbSpotCvd.cvd4h,
              },
              "SKIP OI Watch PATH B: накоп. паттерн fallback — спот CVD 1h+4h оба медвежьи",
            );
            continue;
          }
          if (fbSpotCvd.cvd1h === false && fbSpotCvd.cvd4h !== true) {
            // 1h медвежий и 4h не подтверждает — ждём, не отменяем
            logger.info(
              {
                symbol: w.symbol,
                sentimentKey: w.sentimentKey,
                cvd1h: fbSpotCvd.cvd1h,
                cvd4h: fbSpotCvd.cvd4h,
              },
              "OI Watch PATH B: накоп. паттерн fallback — CVD неоднозначен (1h медвежий) — откладываем",
            );
            continue;
          }
          pbEntryCvd30m = fbSpotCvd.cvd30m ?? null;
          pbEntryCvd1h = fbSpotCvd.cvd1h;
          pbEntryCvd4h = fbSpotCvd.cvd4h;
        }

        // Атомарно захватываем запись перед отправкой — защита от дублей при деплое.
        const claimedB = await dbWriteStrict("oiWatch/pathB-fire-claim", () =>
          db
            .update(oiWatchTable)
            .set({ status: "fired", firedAt: new Date() })
            .where(
              and(
                eq(oiWatchTable.id, w.id),
                eq(oiWatchTable.status, "watching"),
              ),
            )
            .returning({ id: oiWatchTable.id }),
        );
        if (claimedB.length === 0) continue; // другой процесс уже обработал
        // Supersede: гасим другие активные watching/confirming записи того же символа
        const _supersededB =
          (await dbWriteBestEffort("oiWatch/supersede-B", () =>
            db
              .update(oiWatchTable)
              .set({ status: "expired", volStatusReason: "superseded" })
              .where(
                and(
                  eq(oiWatchTable.symbol, w.symbol),
                  inArray(oiWatchTable.status, ["watching", "confirming"]),
                ),
              )
              .returning({
                id: oiWatchTable.id,
                oi30m: oiWatchTable.oi30mChange,
                oi1h: oiWatchTable.oi1hChange,
                oi24h: oiWatchTable.oi24hChange,
                volMult: oiWatchTable.volumeMultiplier,
              }),
          )) ??
          ([] as {
            id: number;
            oi30m: number | null;
            oi1h: number | null;
            oi24h: number | null;
            volMult: number;
          }[]);

        // Берём свежие спот-данные из пула для обогащения сигнала
        const bpEntry = getSpotPoolEntry(w.symbol);
        const bpSpotVol24h = bpEntry?.spotVol24h ?? null;
        const bpMcapUsd = bpEntry?.mcapUsd ?? null;

        // Снимок стакана BingX перед отправкой сигнала (PATH B: broadcast идёт до trackSignal)
        const obAtFireB = await getOrderBookAnalysis(w.symbol, 20).catch(
          () => null,
        );

        // Если payload с полным AlphaResult сохранён — используем полный формат с OI по ТФ
        if (w.signalPayload) {
          const payload = w.signalPayload as {
            alphaResult: any;
            signalRow: any;
          };
          // signalRow был построен в момент постановки в очередь (scanner.ts CONFIRMED FIRE /
          // OI Watch queueing) — он уже содержит реальный spotCvd 1h/4h, увиденный гейтом тогда.
          // Раньше эти значения терялись (PATH B хардкодил entryCvd*: null при вставке).
          pbEntryCvd30m = payload.signalRow?.entryCvd30m ?? null;
          pbEntryCvd1h = payload.signalRow?.entryCvd1h ?? null;
          pbEntryCvd4h = payload.signalRow?.entryCvd4h ?? null;
          // Обновляем globalOiChange свежими данными CoinGlass перед отправкой
          const freshGlobalOi =
            cgOI?.oiChange30m ?? payload.alphaResult.globalOiChange ?? null;
          const fullResult = {
            ...payload.alphaResult,
            price: currentPrice,
            volumeMultiplier: spotVolMult ?? volMult, // 2.2: спот вместо фьюч
            priceChange30m: priceMovePct,
            globalOiChange: freshGlobalOi,
            spotVol24h: payload.alphaResult.spotVol24h ?? bpSpotVol24h,
            marketCapUsd: payload.alphaResult.marketCapUsd ?? bpMcapUsd,
            _oiWatchPath: "B" as const,
            entryOb: obAtFireB ?? undefined,
          };
          await broadcastBatchAlert([fullResult]);
        } else {
          // Fallback: payload отсутствует (токен добавлен с низким объёмом без полного скана).
          // Используем уже полученный cgOI (не делаем повторный запрос).
          const base = w.symbol.replace("-USDT", "");
          const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT`;
          const bingxUrl = `https://bingx.com/en/trade/${base}USDT/`;
          const waitMin = Math.round(
            (Date.now() - w.addedAt.getTime()) / 60_000,
          );

          // Определяем triggerTf — убираем префикс "all+" если был
          const displayTf = w.triggerTf.replace(/^all\+/, "");

          // Если CoinGlass API недоступен (cgOI = null) — используем сохранённое w.oiChange
          // как значение для сработавшего TF, чтобы в сигнале было видно OI по ТФ, а не просто число.
          const storedOi = w.oiChange;
          const cgOi30m =
            cgOI?.oiChange30m ??
            (displayTf === "30m" || displayTf === "steady" ? storedOi : null);
          const cgOi1h =
            cgOI?.oiChange1h ?? (displayTf === "1h" ? storedOi : null);
          const cgOi4h =
            cgOI?.oiChange4h ?? (displayTf === "4h" ? storedOi : null);
          const cgOi24h =
            cgOI?.oiChange24h ?? (displayTf === "24h" ? storedOi : null);

          const syntheticResult: Parameters<typeof broadcastBatchAlert>[0][0] =
            {
              symbol: w.symbol,
              grade: "alpha",
              price: currentPrice,
              priceChange30m: priceMovePct,
              currentVolume: curVol,
              avgVolume: avgVol,
              volumeMultiplier: spotVolMult ?? volMult, // 2.2: спот вместо фьюч
              oiChangePercent: w.oiChange,
              openInterest: null,
              cmcRank: null,
              cmcSource: null,
              cmcAvailable: false,
              liquidationsUsd: null,
              liquidationsMultiple: null,
              coinglassAvailable: cgOI?.available ?? false,
              globalOiChange: cgOi30m,
              globalOiConfirmed: false,
              isNewListing: false,
              isExhaustedSqueeze: false,
              pumpFromOpen: null,
              candleCount: 48,
              sentiment: "🔭 OI Watch",
              sentimentKey: w.sentimentKey ?? "trend_accumulation",
              traderAction: `Наблюдал ${waitMin} мин — CG turnover подтверждён (объём ${volMult.toFixed(1)}x BingX)`,
              alphaScore: 6,
              isContinuing: false,
              cumulativeOiChange: w.oiChange,
              tradingViewUrl: tvUrl,
              bingxUrl,
              oiTriggerTf: displayTf,
              oiChange1h: cgOi1h,
              oiChange4h: cgOi4h,
              oiChange24h: cgOi24h,
              spotVol24h: bpSpotVol24h,
              marketCapUsd: bpMcapUsd,
              entryOb: obAtFireB ?? undefined,
            };
          await broadcastBatchAlert([syntheticResult]);
        }

        // ── Создаём tracked_signal чтобы вотчер мог сопровождать сигнал ─────────
        // PATH B раньше не создавал запись → не было уведомлений о БУ и milestone.
        // Теперь вставляем сигнал и запускаем tracking, как в PATH A.
        try {
          const base = w.symbol.replace("-USDT", "");
          const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${base}USDT.P`;

          // Используем свежую цену из тикера (currentPrice), а не close из kline!
          // close — это цена закрытия 30м свечи, может быть на 30 минут устаревшей.
          // Ошибка: entryPrice: close → бот считал +11% вместо реального +1%.
          const [inserted] = await dbWriteStrict(
            "signals/oiWatch-pathB-insert",
            () =>
              db
                .insert(signalsTable)
                .values({
                  symbol: w.symbol,
                  type: "alpha",
                  value: volMult, // множитель объёма (как в PATH A), не OI
                  threshold: 0,
                  price: currentPrice,
                  priceChangePercent: priceMovePct,
                  volume24h: curVol,
                  avgVolume: w.avgVolume ?? 0,
                  openInterest: null,
                  oiChangePercent: w.oiChange,
                  tradingViewUrl: tvUrl,
                  sentimentKey: w.sentimentKey ?? "trend_accumulation",
                  detectedAt: new Date(),
                })
                .returning(),
          );

          // Если памп уже случился до выстрела (priceMovePct > 10%) — используем
          // оригинальную цену обнаружения как точку отсчёта для peakPct и stale cancel.
          // Иначе stale cancel видит peak=0% и отменяет сигнал где уже было +17%.
          const effectiveEntry =
            priceMovePct > 10 ? w.priceAtEntry : currentPrice;

          const pbTracked = await trackSignal({
            symbol: w.symbol,
            signalId: inserted.id,
            signalType: "alpha",
            sentiment: null,
            sentimentKey: w.sentimentKey ?? "trend_accumulation",
            alphaScore: 6,
            entryPrice: effectiveEntry,
            entryOi: null,
            entryCvd30m: pbEntryCvd30m,
            entryCvd1h: pbEntryCvd1h,
            entryCvd4h: pbEntryCvd4h,
            entrySource: w.triggerTf,
            entryFutVolMult: volMult,
            entryOi30m: w.oi30mChange ?? null,
            entryOi1h: w.oi1hChange ?? null,
            entryOi24h: w.oi24hChange ?? null,
            marketCapUsd: pbMcapUsdB ?? null,
            entrySpotVol24h: pbSpotVol24h ?? null,
            entrySpotMcapPct:
              pbSpotVol24h !== null && pbMcapUsdB
                ? (pbSpotVol24h / pbMcapUsdB) * 100
                : null,
          });

          if (pbTracked === false) {
            logger.error(
              { symbol: w.symbol },
              "OI Watch PATH B: trackSignal упал — позиция не создана, сопровождение отсутствует",
            );
            // broadcast уже ушёл — логируем но не отменяем
          } else if (pbTracked === "skip") {
            logger.info(
              { symbol: w.symbol },
              "OI Watch PATH B: монета уже в трекере — сопровождение активно",
            );
          } else {
            resetPrescanCycleCount(w.symbol);
            logger.info(
              {
                symbol: w.symbol,
                entryPrice: effectiveEntry,
                firePriceNow: currentPrice,
                klinesClose: close,
                priceMovePct: priceMovePct.toFixed(1),
              },
              "🔭 OI Watch PATH B: tracked_signal создан — сопровождение активно",
            );
          }
        } catch (trackErr) {
          logger.error(
            { err: trackErr, symbol: w.symbol },
            "OI Watch PATH B: ошибка при создании tracked_signal",
          );
        }

        logger.info(
          {
            symbol: w.symbol,
            volMult: volMult.toFixed(2),
            priceMovePct: priceMovePct.toFixed(1),
            volConfirmed,
          },
          "🔭➡️🚀 OI Watch FIRED (volume confirmed)",
        );
      }
    } catch (err) {
      logger.debug(
        { err, symbol: w.symbol },
        "OI Watch PATH B: klines fetch failed",
      );
    }
  }
}

// ── Scheduler ─────────────────────────────────────────────────────────────────
let cycleTimer: NodeJS.Timeout | null = null;
let fastTimer: NodeJS.Timeout | null = null;
let dailyTimer: NodeJS.Timeout | null = null;
let weeklyTimer: NodeJS.Timeout | null = null;
let monthlyTimer: NodeJS.Timeout | null = null;
let whaleTimer: NodeJS.Timeout | null = null;
let positionsTimer: NodeJS.Timeout | null = null;
let taScannerTimer: NodeJS.Timeout | null = null;

/** Миллисекунды до следующего HH:MM:00 UTC */
function msUntilUtc(
  targetHour: number,
  targetMin: number,
  targetDayOfWeek?: number,
): number {
  const now = new Date();
  const next = new Date(now);
  next.setUTCSeconds(0, 0);
  next.setUTCMinutes(targetMin);
  next.setUTCHours(targetHour);

  if (targetDayOfWeek !== undefined) {
    // Воскресенье = 0
    const currentDay = now.getUTCDay();
    let daysUntil = (targetDayOfWeek - currentDay + 7) % 7;
    // Если сегодня целевой день, но время уже прошло — ждём следующей недели
    if (daysUntil === 0 && next.getTime() <= now.getTime()) {
      daysUntil = 7;
    }
    next.setUTCDate(now.getUTCDate() + daysUntil);
  } else {
    // Ежедневно — если уже прошло сегодня, переносим на завтра
    if (next.getTime() <= now.getTime()) {
      next.setUTCDate(next.getUTCDate() + 1);
    }
  }

  return next.getTime() - now.getTime();
}

/** Миллисекунды до следующего 1-го числа месяца в HH:MM UTC */
function msUntilFirstOfMonth(targetHour: number, targetMin: number): number {
  const now = new Date();
  const next = new Date(
    Date.UTC(
      now.getUTCFullYear(),
      now.getUTCMonth() + 1,
      1,
      targetHour,
      targetMin,
      0,
      0,
    ),
  );
  // Если сейчас уже 1-е число и время ещё не наступило — отправляем сегодня
  if (now.getUTCDate() === 1) {
    const today = new Date(
      Date.UTC(
        now.getUTCFullYear(),
        now.getUTCMonth(),
        1,
        targetHour,
        targetMin,
        0,
        0,
      ),
    );
    if (today.getTime() > now.getTime()) return today.getTime() - now.getTime();
  }
  return next.getTime() - now.getTime();
}

// ── Job timing tracker ────────────────────────────────────────────────────────
// Обновляется внутри startWatcher() по завершению каждого цикла.
interface _JobTiming {
  label: string;
  intervalMs: number;
  lastRunAt: number | null;
}
const _jobTimings: Record<string, _JobTiming> = {
  fastCycle: {
    label: "Fast Cycle (2мин)",
    intervalMs: 2 * 60_000,
    lastRunAt: null,
  },
  watcherCycle: {
    label: "Watcher Cycle (10мин)",
    intervalMs: 10 * 60_000,
    lastRunAt: null,
  },
  liqCascade: {
    label: "Liq Cascade L10 (3мин)",
    intervalMs: 3 * 60_000,
    lastRunAt: null,
  },
  whaleAlert: {
    label: "Whale Alert L11 (3мин)",
    intervalMs: 3 * 60_000,
    lastRunAt: null,
  },
  price24hRefresh: {
    label: "Price24h Refresh (20мин)",
    intervalMs: 20 * 60_000,
    lastRunAt: null,
  },
  backfill: {
    label: "Entry Metrics Backfill (30мин)",
    intervalMs: 30 * 60_000,
    lastRunAt: null,
  },
  whalePostExit: {
    label: "Whale Post-Exit Price (30мин)",
    intervalMs: 30 * 60_000,
    lastRunAt: null,
  },
};

export interface WatcherJobTiming {
  label: string;
  intervalMs: number;
  lastRunAt: number | null;
  overdueMs: number | null;
}

/** Возвращает статус всех фоновых job'ов: время последнего запуска и превышение интервала. */
export function getWatcherJobTimings(): Record<string, WatcherJobTiming> {
  const now = Date.now();
  return Object.fromEntries(
    Object.entries(_jobTimings).map(([key, t]) => [
      key,
      {
        label: t.label,
        intervalMs: t.intervalMs,
        lastRunAt: t.lastRunAt,
        overdueMs:
          t.lastRunAt !== null
            ? Math.max(0, now - t.lastRunAt - t.intervalMs)
            : null,
      } satisfies WatcherJobTiming,
    ]),
  );
}

export function startWatcher(): void {
  logger.info("AltBullet Watcher started");

  // TA Scanner cache: восстанавливаем последний снапшот из БД при старте.
  // Без этого вкладка Layer TA пуста 19 мин после каждого деплоя.
  setTimeout(async () => {
    try {
      await loadTaScannerCacheFromDb();
    } catch (err) {
      logger.warn({ err }, "TA Scanner cache load startup error");
    }
  }, 4_000);

  // Layer 11 Whale Alerts: загрузка активного пула из БД в in-memory зеркало.
  setTimeout(async () => {
    try {
      await loadWhaleAlertPoolFromDb();
    } catch (err) {
      logger.error({ err }, "WhaleAlert pool load startup error");
    }
  }, 11_000);

  // Whale Index (BTC, 4h) — фоновый кэш для строки контекста в Telegram-алертах.
  startWhaleIndexUpdater();

  // cleanupPowerCollisionArtifacts (см. выше) — одноразовая чистка POWER-USDT
  // сигнала/снимков, испорченных CoinGlass ticker-collision (2026-07-10).
  // Заменена на общую cleanupOiCollisionArtifacts ниже, которая покрывает
  // POWER заодно со всеми остальными символами — оставлена как no-op ссылка.
  // Идемпотентно: после первого прогона status уже не active/in_run и
  // oi_usd уже NULL — повторные рестарты no-op.
  setTimeout(async () => {
    try {
      await cleanupPowerCollisionArtifacts();
    } catch (err) {
      logger.error({ err }, "POWER collision cleanup startup error");
    }
  }, 7_000);

  // cleanupOiCollisionArtifacts — теперь узкий whitelist из 5 вручную
  // подтверждённых символов (см. комментарий у функции, 2026-07-10). Первая
  // версия сканировала ВСЕ символы по ratio и ложно обнулила ~300 легитимных
  // тикеров + отменила APE-USDT — см. restoreFalseApeCancellation ниже.
  setTimeout(async () => {
    try {
      await cleanupOiCollisionArtifacts();
    } catch (err) {
      logger.error({ err }, "OI collision cleanup startup error");
    }
  }, 8_000);

  // Разовое исправление ложной отмены APE-USDT сломанной версией
  // cleanupOiCollisionArtifacts (2026-07-10). Идемпотентно — см. функцию.
  setTimeout(async () => {
    try {
      await restoreFalseApeCancellation();
    } catch (err) {
      logger.error({ err }, "APE restore startup error");
    }
  }, 9_000);

  // Одноразовая очистка signals от мёртвых паттернов (oi24h_accumulation и др.,
  // 2026-07-15). Только таблица signals — tracked_signals не трогаем. Идемпотентно.
  setTimeout(async () => {
    try {
      await cleanupDeadPatternSignals();
    } catch (err) {
      logger.error({ err }, "Dead pattern cleanup startup error");
    }
    // Отменяем открытые позиции (active/in_run/…) с мёртвыми паттернами.
    // cleanupDeadPatternSignals не трогает tracked_signals — нужен отдельный шаг.
    try {
      await cancelDeadPatternTrackedSignals();
    } catch (err) {
      logger.error(
        { err },
        "Cancel dead pattern tracked_signals startup error",
      );
    }
  }, 12_000);

  // Бэкафилл oi_daily_snapshots за 2026-07-08/07-09 (и 07-10 если отсутствует)
  // для ~376 символов, обнулённых сломанной cleanupOiCollisionArtifacts.
  // Тянет реальную историю из CoinGlass aggregated-history вместо ожидания
  // 3 суток естественного накопления. Идемпотентно — обрабатывает только
  // строки с oi_usd IS NULL. См. oiHistoryBackfill.ts.
  // Запуск отложен на 18 мин — сразу после старта Neon-пул насыщен первым
  // сканом (~14 мин, см. startup-positions-timer.md), ранний старт бэкафилла
  // ловил "timeout exceeded when trying to connect" и падал целиком.
  setTimeout(async () => {
    try {
      await backfillOiHistoryAfterCollisionCleanup();
    } catch (err) {
      logger.error({ err }, "OI history backfill startup error");
    }
  }, 18 * 60_000);

  // Startup reset — проверяем стоп-лоссы и трейлинги пропущенные за время простоя.
  // Запуск 1: через 10с (BingX API ещё может быть холодным — внутри retry 3×3s).
  // Запуск 2: через 3 мин — страховочный прогон если первый упал на API таймауте.
  setTimeout(async () => {
    try {
      await runStartupReset();
    } catch (err) {
      logger.error({ err }, "Startup reset #1 error");
    }
  }, 10_000);

  setTimeout(async () => {
    try {
      await runStartupReset();
    } catch (err) {
      logger.error({ err }, "Startup reset #2 error");
    }
    logger.info("Startup reset #2 complete (safety net)");
  }, 3 * 60_000);

  // Fast cycle every 2 min — active + in_run (stop-loss, first target, trailing)
  // Also runs OI Watch cycle (check for volume confirmation on watch candidates)
  const runFast = async () => {
    if (!fastTimer) return;
    try {
      await runInRunFastCycle();
    } catch (err) {
      logger.error({ err }, "FastCycle error");
    }
    try {
      await runOiWatchCycle();
    } catch (err) {
      logger.error({ err }, "OiWatchCycle error");
    }
    _jobTimings.fastCycle.lastRunAt = Date.now();
    fastTimer = setTimeout(runFast, FAST_CYCLE_MS);
  };
  // First fast cycle at 2 min (after startup reset at 5s)
  fastTimer = setTimeout(runFast, FAST_CYCLE_MS);
  logger.info(
    { intervalMin: FAST_CYCLE_MS / 60000 },
    "Fast cycle started (active + in_run + OI watch, 2min)",
  );

  // Layer 10 Liquidation Cascade Watch — сканирует ВСЕ тикеры каждые 3 мин.
  // Детектирует лонг-ликвидационные спайки → пул liq_cascade_watch.
  // После каждого цикла _runLiqCascadeFireCycle() проверяет пул и выдаёт
  // liquidation_cascade сигнал напрямую (Path B, без инжекта в основной скан).
  // Первый запуск через 5 мин (после первого скана уже есть тикеры).
  const LIQ_CASCADE_INTERVAL_MS = 3 * 60_000; // 3 мин
  let liqCascadeTimer: ReturnType<typeof setTimeout> | null = null;
  const runLiqCascade = async () => {
    if (!liqCascadeTimer) return;
    if (isScannerActive()) {
      logger.info("LiqCascadeJob: пропуск — идёт основной скан");
      liqCascadeTimer = setTimeout(runLiqCascade, LIQ_CASCADE_INTERVAL_MS);
      return;
    }
    try {
      await runLiqCascadeWatcherJob(
        (sym) => getPrescanEntry(sym)?.cycleCount ?? null,
      );
    } catch (err) {
      logger.error({ err }, "LiqCascadeWatcherJob error");
    }
    try {
      await _runLiqCascadeFireCycle();
    } catch (err) {
      logger.error({ err }, "LiqCascadeFireCycle error");
    }
    _jobTimings.liqCascade.lastRunAt = Date.now();
    liqCascadeTimer = setTimeout(runLiqCascade, LIQ_CASCADE_INTERVAL_MS);
  };
  liqCascadeTimer = setTimeout(runLiqCascade, 5 * 60_000);
  logger.info("Layer 10 Liq Cascade Watch scheduled (3min, first run at 5min)");

  // Layer 11 Whale Alerts (Hyperliquid) — опрос CoinGlass whale-alert ленты
  // каждые 3 мин. Киты открывающие лонги ≥$500K → пул whale_alert_pool (24ч)
  // → Layer 11 инжекция в скан → паттерн whale_alert. Первый запуск через 5 мин.
  const WHALE_ALERT_INTERVAL_MS = 3 * 60_000;
  let whaleAlertTimer: ReturnType<typeof setTimeout> | null = null;
  const runWhaleAlert = async () => {
    if (!whaleAlertTimer) return;
    if (isScannerActive()) {
      logger.info("WhaleAlertJob: пропуск — идёт основной скан");
      whaleAlertTimer = setTimeout(runWhaleAlert, WHALE_ALERT_INTERVAL_MS);
      return;
    }
    try {
      await runWhaleAlertJob();
    } catch (err) {
      logger.error({ err }, "WhaleAlertJob error");
    }
    try {
      await _runWhaleAlertFireCycle();
    } catch (err) {
      logger.error({ err }, "WhaleAlertFireCycle error");
    }
    _jobTimings.whaleAlert.lastRunAt = Date.now();
    whaleAlertTimer = setTimeout(runWhaleAlert, WHALE_ALERT_INTERVAL_MS);
  };
  whaleAlertTimer = setTimeout(runWhaleAlert, 5 * 60_000);
  logger.info("Layer 11 Whale Alerts scheduled (3min, first run at 5min)");

  // Price24h refresh every 20 min — пересчитывает lastPrice24h через 1h klines.
  // BingX ticker priceChangePercent считается от суточной свечи (UTC midnight), а не
  // от реального 24h назад. Первый запуск через 25 мин (после окончания первого скана).
  const PRICE24H_REFRESH_INTERVAL_MS = 20 * 60_000;
  let price24hRefreshTimer: ReturnType<typeof setTimeout> | null = null;
  const runPrice24hRefresh = async () => {
    if (!price24hRefreshTimer) return;
    try {
      await runPrice24hRefreshCycle();
    } catch (err) {
      logger.error({ err }, "Price24hRefreshCycle error");
    }
    _jobTimings.price24hRefresh.lastRunAt = Date.now();
    price24hRefreshTimer = setTimeout(
      runPrice24hRefresh,
      PRICE24H_REFRESH_INTERVAL_MS,
    );
  };
  price24hRefreshTimer = setTimeout(runPrice24hRefresh, 25 * 60_000);
  logger.info("Price24h refresh scheduled (20min, first run at 25min)");

  // Entry-metrics backfill — заполняет null WI/OB/OI/FutTaker для открытых позиций.
  // Запуск через 32 мин (после первого скана и prescan tracker заполнен), затем каждые 30 мин.
  const BACKFILL_INTERVAL_MS = 30 * 60_000;
  let backfillTimer: ReturnType<typeof setTimeout> | null = null;
  const runBackfill = async () => {
    if (!backfillTimer) return;
    try {
      await refreshNullEntryMetrics();
    } catch (err) {
      logger.error({ err }, "refreshNullEntryMetrics error");
    }
    _jobTimings.backfill.lastRunAt = Date.now();
    backfillTimer = setTimeout(runBackfill, BACKFILL_INTERVAL_MS);
  };
  backfillTimer = setTimeout(runBackfill, 32 * 60_000);
  logger.info("Entry-metrics backfill scheduled (30min, first run at 32min)");

  // Whale Alert post-exit price tracking (30min, first run at 35min).
  // Fills price_72h_pct in whale_alert_pool and price_72h_after_exit_pct in tracked_signals
  // for entries that are 72h+ past their fire/expire/close time.
  const WHALE_POST_EXIT_INTERVAL_MS = 30 * 60_000;
  let whalePostExitTimer: ReturnType<typeof setTimeout> | null = null;
  const runWhalePostExit = async () => {
    if (!whalePostExitTimer) return;
    try {
      await runPostExitPriceTracking();
    } catch (err) {
      logger.error({ err }, "WhaleAlertPostExitTracking error");
    }
    _jobTimings.whalePostExit.lastRunAt = Date.now();
    whalePostExitTimer = setTimeout(
      runWhalePostExit,
      WHALE_POST_EXIT_INTERVAL_MS,
    );
  };
  whalePostExitTimer = setTimeout(runWhalePostExit, 35 * 60_000);
  logger.info(
    "Whale Alert post-exit tracking scheduled (30min, first run at 35min)",
  );

  // Watcher cycle every 10 min — handles ONLY accumulation signals.
  // Starts at 14 min (NOT 7 min) — первый скан 551 токена занимает ~10мин и
  // исчерпывает Neon connection pool. При старте в 7 мин все DB-запросы (watcher,
  // fastcycle, restart notif, positions) падают с "connection timeout". 14 мин —
  // надёжный зазор после окончания первого скана.
  const runCycle = async () => {
    if (!cycleTimer) return;
    try {
      const r = await runWatcherCycle();
      logger.info(r, "Watcher cycle complete");
    } catch (err) {
      logger.error({ err }, "Watcher cycle error");
    }
    _jobTimings.watcherCycle.lastRunAt = Date.now();
    cycleTimer = setTimeout(runCycle, 10 * 60 * 1000);
  };
  cycleTimer = setTimeout(runCycle, 14 * 60 * 1000);

  // Уведомление о рестарте — через 2 мин после старта.
  // Канал (_channelIdCache) закэширован при startWatcher → нет DB-запроса на старте.
  // Near-stop warning — через 4 мин (DB уже доступна, пул стабилен после первого прогрева).
  if (process.env.NODE_ENV !== "development") {
    setTimeout(() => {
      sendBotRestartNotification().catch((err) =>
        logger.warn({ err }, "Restart notification failed (non-critical)"),
      );
    }, 2 * 60_000);
    setTimeout(() => {
      sendNearStopWarning().catch((err) =>
        logger.warn({ err }, "Near-stop warning failed (non-critical)"),
      );
    }, 4 * 60_000);
  }

  // Daily at 22:00 МСК = 19:00 UTC
  const scheduleDaily = () => {
    const ms = msUntilUtc(19, 0);
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Daily report scheduled (22:00 МСК)");
    dailyTimer = setTimeout(async () => {
      try {
        await sendDailyReport();
      } catch (err) {
        logger.error({ err }, "Daily report error");
      }
      scheduleDaily();
    }, ms);
  };
  scheduleDaily();

  // ── Missed-report guard ───────────────────────────────────────────────────────
  // Ловим два случая пропуска:
  // 1. Перезапуск ПОСЛЕ 18:00 UTC сегодня — отчёт за сегодня не отправлен.
  // 2. Перезапуск утром (до 18:00 UTC) — но вчерашний отчёт тоже не отправлен.
  // Задержка 90с: продакшн-DB иногда требует 30–60с на холодный reconnect.
  // При ошибке DB — retry через 60с (до 3 попыток).
  const runDailyGuard = async (attempt = 1): Promise<void> => {
    try {
      const nowUtc = new Date();

      // Порог за сегодня (19:00 UTC = 22:00 МСК)
      const todayReportUtc = new Date(nowUtc);
      todayReportUtc.setUTCHours(19, 0, 0, 0);

      // Порог за вчера (19:00 UTC вчерашнего дня)
      const yesterdayReportUtc = new Date(todayReportUtc);
      yesterdayReportUtc.setUTCDate(yesterdayReportUtc.getUTCDate() - 1);

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastDailyReportAt;

      // Буфер 5 мин: setTimeout может сработать на несколько мс раньше цели →
      // timestamp пишется как 18:59:59.xxx → guard считает вчерашний отчёт пропущенным.
      const REPORT_BUFFER_MS = 5 * 60 * 1000;

      // Пропущен сегодняшний отчёт: уже после 19:00, но не отправляли с 18:55
      const missedToday =
        nowUtc >= todayReportUtc &&
        (!lastSent ||
          lastSent < new Date(todayReportUtc.getTime() - REPORT_BUFFER_MS));

      // Пропущен вчерашний отчёт: последний раз отправляли раньше 18:55 вчера
      const missedYesterday =
        !lastSent ||
        lastSent < new Date(yesterdayReportUtc.getTime() - REPORT_BUFFER_MS);

      if (!missedToday && !missedYesterday) {
        logger.info(
          { lastSent },
          "Daily report guard: всё в порядке, пропуска нет",
        );
        return;
      }

      logger.warn(
        { lastSent, nowUtc, missedToday, missedYesterday },
        "Missed daily report detected — sending now",
      );
      await sendDailyReport();
    } catch (err) {
      logger.error({ err, attempt }, "Missed-report guard error");
      if (attempt < 3) {
        logger.info(
          { nextAttempt: attempt + 1 },
          "Missed-report guard: retry in 60s",
        );
        setTimeout(() => runDailyGuard(attempt + 1), 60_000);
      }
    }
  };
  setTimeout(() => runDailyGuard(), 90_000); // 90с после старта — даём DB восстановить соединение

  // ── Missed-weekly guard ───────────────────────────────────────────────────────
  // Если сервер перезапустился в воскресенье после 09:00 МСК (06:00 UTC) и дайджест
  // ещё не был отправлен на этой неделе — отправляем через 120с после старта.
  const runWeeklyGuard = async (attempt = 1): Promise<void> => {
    try {
      const nowUtc = new Date();
      if (nowUtc.getUTCDay() !== 0) return; // Не воскресенье — пропускаем

      const thisWeekDigestUtc = new Date(nowUtc);
      thisWeekDigestUtc.setUTCHours(6, 0, 0, 0); // 06:00 UTC = 09:00 МСК

      if (nowUtc < thisWeekDigestUtc) return; // Ещё не время — плановый таймер сработает сам

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastWeeklyDigestAt;

      const alreadySentThisWeek = lastSent && lastSent >= thisWeekDigestUtc;
      if (alreadySentThisWeek) {
        logger.info(
          { lastSent },
          "Weekly digest already sent this week — skipping missed-digest check",
        );
        return;
      }

      logger.warn(
        { lastSent, nowUtc },
        "Missed weekly digest detected — sending now",
      );
      await sendWeeklyDigest();
    } catch (err) {
      logger.error({ err, attempt }, "Missed-weekly guard error");
      if (attempt < 3) {
        setTimeout(() => runWeeklyGuard(attempt + 1), 60_000);
      }
    }
  };
  setTimeout(() => runWeeklyGuard(), 120_000); // 120с после старта

  // Weekly Sunday at 09:00 МСК = 06:00 UTC
  const scheduleWeekly = () => {
    const ms = msUntilUtc(6, 0, 0); // 0 = Sunday
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Weekly digest scheduled (Вс 09:00 МСК)");
    weeklyTimer = setTimeout(async () => {
      try {
        await sendWeeklyDigest();
      } catch (err) {
        logger.error({ err }, "Weekly digest error");
      }
      scheduleWeekly();
    }, ms);
  };
  scheduleWeekly();

  // ── Missed-monthly guard ──────────────────────────────────────────────────────
  // Если сервер перезапустился 1-го числа после 10:00 МСК (07:00 UTC) и дайджест
  // ещё не был отправлен в этом месяце — отправляем через 90с после старта.
  setTimeout(async () => {
    try {
      const nowUtc = new Date();
      if (nowUtc.getUTCDate() !== 1) return; // Не 1-е число — пропускаем

      const thisMonthDigestUtc = new Date(
        Date.UTC(nowUtc.getUTCFullYear(), nowUtc.getUTCMonth(), 1, 7, 0, 0, 0),
      );
      if (nowUtc < thisMonthDigestUtc) return; // Ещё не время — плановый таймер сработает сам

      const settings = await db.select().from(settingsTable).limit(1);
      const lastSent = settings[0]?.lastMonthlyDigestAt;

      const alreadySentThisMonth = lastSent && lastSent >= thisMonthDigestUtc;
      if (alreadySentThisMonth) {
        logger.info(
          { lastSent },
          "Monthly digest already sent this month — skipping missed-digest check",
        );
        return;
      }

      logger.warn(
        { lastSent, nowUtc },
        "Missed monthly digest detected — sending now",
      );
      await sendMonthlyDigest();
    } catch (err) {
      logger.error({ err }, "Missed-monthly guard error");
    }
  }, 90_000); // 90с после старта

  // Monthly — 1-е число каждого месяца в 10:00 МСК = 07:00 UTC
  // ВНИМАНИЕ: setTimeout имеет лимит ~24.8 дней (2^31 мс). Для месячного таймера
  // это может переполниться (30 дней = 2.6 млрд мс > 2.15 млрд лимита) и вызвать
  // бесконечный цикл (таймер срабатывает немедленно через 1мс).
  // Решение: если до события > 23 дней — планируем промежуточную проверку.
  const MAX_SAFE_TIMEOUT_MS = 23 * 24 * 60 * 60 * 1000; // 23 дня — безопасный максимум
  const scheduleMonthly = () => {
    const ms = msUntilFirstOfMonth(7, 0);
    if (ms > MAX_SAFE_TIMEOUT_MS) {
      // Слишком далеко для одного setTimeout — планируем промежуточную проверку через 23 дня
      logger.info(
        { nextAt: new Date(Date.now() + ms).toISOString(), retryIn: "23d" },
        "Monthly digest: слишком далеко, промежуточная проверка через 23 дня",
      );
      monthlyTimer = setTimeout(scheduleMonthly, MAX_SAFE_TIMEOUT_MS);
      return;
    }
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info({ nextAt }, "Monthly digest scheduled (1-е число, 10:00 МСК)");
    monthlyTimer = setTimeout(async () => {
      try {
        await sendMonthlyDigest();
      } catch (err) {
        logger.error({ err }, "Monthly digest error");
      }
      scheduleMonthly();
    }, ms);
  };
  scheduleMonthly();

  // ── Fixed-schedule positions update: 09:00, 15:00, 21:00 Самара (UTC+4) ──
  // = 05:00, 11:00, 17:00 UTC
  const POSITIONS_SLOTS_UTC = [5, 11, 17]; // UTC: 05=09Самара 11=15Самара 17=21Самара (UTC+4, 8ч интервал)
  const POSITIONS_DEDUP_MS = 7 * 60 * 60 * 1000 + 50 * 60 * 1000; // 7ч 50мин — чтобы только один процесс отправлял в каждый слот (слоты каждые 8ч)

  const msUntilNextPositionsSlot = (): number => {
    const now = new Date();
    let minMs = Infinity;
    for (const h of POSITIONS_SLOTS_UTC) {
      const candidate = new Date(now);
      candidate.setUTCHours(h, 0, 0, 0);
      let diff = candidate.getTime() - now.getTime();
      if (diff <= 0) diff += 24 * 60 * 60 * 1000; // перенос на следующие сутки
      if (diff < minMs) minMs = diff;
    }
    return minMs;
  };

  // dedupMs: окно дедупликации. Для старта — 5 мин (чтобы не блокировалось предыдущим плановым отчётом).
  // Для плановых отправок — 2 часа (защита от двойного fire из 2 процессов при одновременном срабатывании).
  const sendPositionsUpdate = async (
    reason: string,
    dedupMs = POSITIONS_DEDUP_MS,
  ): Promise<void> => {
    // Retry loop: Neon DB может быть временно перегружен при старте (scanner batch).
    // 3 попытки × 30с — аналогично sendBotRestartNotification.
    const claimed = await claimSettingsBroadcast({
      column: "lastPositionsReportAt",
      windowMs: dedupMs,
      label: `Positions update (${reason})`,
      retries: 2,
      retryDelayMs: 30_000,
    });
    if (!claimed) {
      return;
    }
    try {
      const text = await buildPositionsStatusText();
      logger.info(
        {
          positionsCount: (
            await db
              .select()
              .from(trackedSignalsTable)
              .where(
                inArray(trackedSignalsTable.status, [
                  "active",
                  "in_run",
                  "accumulation",
                  "re_entry",
                ]),
              )
          ).length,
          text: text.slice(0, 200),
        },
        "DEBUG: positions update about to broadcast",
      );
      await broadcastPhotoWithText(POSITIONS_IMG, text);
      logger.info({ reason }, "Positions update broadcast to all subscribers");
    } catch (err) {
      logger.error({ err, reason }, "Positions update: broadcast error");
    }
  };

  const schedulePositions = () => {
    const ms = msUntilNextPositionsSlot();
    const nextAt = new Date(Date.now() + ms).toISOString();
    logger.info(
      { nextAt, slots: "05/11/17 UTC = 09/15/21 Самара" },
      "Next positions update scheduled",
    );
    positionsTimer = setTimeout(async () => {
      if (!positionsTimer) return;
      await sendPositionsUpdate("scheduled");
      schedulePositions();
    }, ms);
  };

  schedulePositions();

  // ── TA Scanner timer: каждые 5 мин, первый запуск через 19 мин ──────────────
  // Первый запуск через 19 мин — после завершения первого скана и RSI Watch.
  const scheduleTaScanner = () => {
    taScannerTimer = setTimeout(async () => {
      if (!taScannerTimer) return;
      await runTaScannerCycle();
      scheduleTaScanner();
    }, TA_SCANNER_INTERVAL_MS);
  };
  taScannerTimer = setTimeout(async () => {
    await runTaScannerCycle();
    scheduleTaScanner();
  }, 19 * 60_000);
}

// ── Watchdog: следим чтобы сканер не завис ────────────────────────────────────
const WATCHDOG_CHECK_MS = 10 * 60 * 1000; // проверяем каждые 10 мин
const WATCHDOG_WARN_MS = 35 * 60 * 1000; // тревога если сканер IDLE >35 мин
// Во время скана используем WATCHDOG_CRIT_MS как порог (prefetch ~18мин + main loop ~22мин = ~40мин)
const WATCHDOG_CRIT_MS = 70 * 60 * 1000; // критично если 70+ мин (скан завис или 2+ пропущенных цикла)
const WATCHDOG_COOLDOWN = 60 * 60 * 1000; // не спамим чаще раза в час
const WATCHDOG_RESTART_AFTER = 2; // авторестарт после N критических алертов подряд
const WATCHDOG_MAX_RESTARTS = 3; // max авторестартов за сутки
const WATCHDOG_RESTART_WINDOW = 24 * 60 * 60 * 1000; // окно для подсчёта рестартов

let watchdogTimer: ReturnType<typeof setTimeout> | null = null;
let watchdogLastAlertAt = 0;
let watchdogAlertCount = 0;
let watchdogGetLastScanAt: (() => Date | null) | null = null;
let watchdogGetIsScanning: (() => boolean) | null = null;
let watchdogRestartScanner: (() => Promise<void>) | null = null;
let watchdogRestartTimestamps: number[] = []; // история рестартов для rate-limit

async function runWatchdog(): Promise<void> {
  try {
    const now = Date.now();
    const lastScanAtRaw = watchdogGetLastScanAt?.() ?? null;
    const lastScanAt = lastScanAtRaw ? lastScanAtRaw.getTime() : null;
    const staleness = lastScanAt ? now - lastScanAt : null;

    // Если сканер активно работает — используем CRIT порог (40+ мин скан норма).
    // Если idle — используем WARN порог (35 мин).
    const isScanning = watchdogGetIsScanning?.() ?? false;
    const effectiveThreshold = isScanning ? WATCHDOG_CRIT_MS : WATCHDOG_WARN_MS;

    // Первый скан ещё не прошёл (холодный старт) или всё в норме
    if (staleness === null || staleness < effectiveThreshold) {
      watchdogAlertCount = 0;
      watchdogTimer = setTimeout(runWatchdog, WATCHDOG_CHECK_MS);
      return;
    }

    // Быстрый in-memory пре-чек — не идём в DB если локальный кулдаун явно не истёк
    if (now - watchdogLastAlertAt < WATCHDOG_COOLDOWN - 60_000) {
      watchdogTimer = setTimeout(runWatchdog, WATCHDOG_CHECK_MS);
      return;
    }
    // Атомарный DB-клейм: оба worker-а видят одну строку settings — только один пройдёт.
    // Решает «двойные алерты» в 2-процессном production-деплое.
    const _wdCooldownBoundary = new Date(now - WATCHDOG_COOLDOWN);
    let _wdClaimed = false;
    try {
      const _wdResult = await dbWriteStrict("settings/watchdog-claim", () =>
        db
          .update(settingsTable)
          .set({ lastWatchdogAlertAt: new Date(now) })
          .where(
            sql`id = (SELECT id FROM settings LIMIT 1) AND (last_watchdog_alert_at IS NULL OR last_watchdog_alert_at < ${_wdCooldownBoundary})`,
          )
          .returning({ id: settingsTable.id }),
      );
      _wdClaimed = _wdResult.length > 0;
    } catch {
      // DB недоступен → fallback: in-memory кулдаун
      _wdClaimed = now - watchdogLastAlertAt > WATCHDOG_COOLDOWN;
    }
    if (!_wdClaimed) {
      watchdogLastAlertAt = now; // синхронизируем local-чек чтобы не спамить DB
      watchdogTimer = setTimeout(runWatchdog, WATCHDOG_CHECK_MS);
      return;
    }

    // Определяем уровень
    const isCritical = staleness >= WATCHDOG_CRIT_MS;
    const staleMinutes = Math.round(staleness / 60_000);
    watchdogAlertCount++;

    const emoji = isCritical ? "🔴" : "🟡";
    const level = isCritical ? "КРИТИЧНО" : "ПРЕДУПРЕЖДЕНИЕ";
    const lastStr = lastScanAt
      ? new Date(lastScanAt).toISOString().replace("T", " ").slice(0, 19) +
        " UTC"
      : "неизвестно";

    const lines = [
      `${emoji} <b>Watchdog: ${level}</b>`,
      ``,
      `Сканер не делал скан <b>${staleMinutes} мин</b>`,
      `Последний скан: <code>${lastStr}</code>`,
      isCritical
        ? `⚠️ Возможно сканер завис или упал. Проверь сервер.`
        : `Возможно временная задержка. Слежу дальше.`,
      ``,
      `<i>Предупреждение #${watchdogAlertCount}</i>`,
    ];

    const targets = await getTargets().catch(() => [] as (number | string)[]);
    const caption = lines.join("\n");
    for (const t of targets) {
      const sent = await sendPhotoCaption(t, WATCHDOG_IMG, caption).catch(
        () => false,
      );
      if (!sent) await sendMessage(t, caption).catch(() => {});
    }

    watchdogLastAlertAt = now;
    logger.warn(
      { staleMinutes, isCritical, alertCount: watchdogAlertCount },
      "Watchdog alert sent",
    );

    // ── Авторестарт: если критично 2+ алертов подряд и лимит не исчерпан ──
    if (
      isCritical &&
      watchdogAlertCount >= WATCHDOG_RESTART_AFTER &&
      watchdogRestartScanner
    ) {
      // Rate-limit: не более WATCHDOG_MAX_RESTARTS рестартов за сутки
      watchdogRestartTimestamps = watchdogRestartTimestamps.filter(
        (t) => now - t < WATCHDOG_RESTART_WINDOW,
      );
      if (watchdogRestartTimestamps.length < WATCHDOG_MAX_RESTARTS) {
        watchdogRestartTimestamps.push(now);
        logger.warn(
          { restartCount: watchdogRestartTimestamps.length },
          "Watchdog: initiating auto-restart of scanner",
        );
        try {
          await watchdogRestartScanner();
          // Сбрасываем счётчик — даём сканеру прогреться
          watchdogAlertCount = 0;
          watchdogLastAlertAt = now;
          const restartCaption = [
            `🔄 <b>Watchdog: авторестарт сканера</b>`,
            ``,
            `Сканер завис на <b>${staleMinutes} мин</b> — выполнен автоматический рестарт.`,
            `Рестартов за 24ч: ${watchdogRestartTimestamps.length}/${WATCHDOG_MAX_RESTARTS}`,
          ].join("\n");
          for (const t of targets) {
            const sent = await sendPhotoCaption(
              t,
              RESTART_IMG,
              restartCaption,
            ).catch(() => false);
            if (!sent) await sendMessage(t, restartCaption).catch(() => {});
          }
          logger.info("Watchdog: scanner restarted successfully");
        } catch (restartErr) {
          logger.error({ err: restartErr }, "Watchdog: auto-restart failed");
        }
      } else {
        logger.error(
          { restartCount: watchdogRestartTimestamps.length },
          "Watchdog: restart limit reached — manual intervention required",
        );
        const limitCaption = `🚨 <b>Watchdog: лимит рестартов исчерпан</b>\n\nАвторестарт выполнялся ${WATCHDOG_MAX_RESTARTS}x за 24ч, сканер всё равно не работает.\n⚠️ Требуется ручное вмешательство.`;
        for (const t of targets) {
          const sent = await sendPhotoCaption(
            t,
            WATCHDOG_IMG,
            limitCaption,
          ).catch(() => false);
          if (!sent) await sendMessage(t, limitCaption).catch(() => {});
        }
      }
    }
  } catch (err) {
    logger.error({ err }, "Watchdog check failed");
  }

  watchdogTimer = setTimeout(runWatchdog, WATCHDOG_CHECK_MS);
}

export function startWatchdog(
  getLastScanAt: () => Date | null,
  restartScanner?: () => Promise<void>,
  getIsScanning?: () => boolean,
): void {
  if (watchdogTimer) return;
  watchdogGetLastScanAt = getLastScanAt;
  watchdogGetIsScanning = getIsScanning ?? null;
  watchdogRestartScanner = restartScanner ?? null;
  // Первая проверка через 20 мин после старта — даём боту прогреться
  watchdogTimer = setTimeout(runWatchdog, 20 * 60 * 1000);
  const autoRestart = !!restartScanner;
  logger.info(
    {
      checkIntervalMin: 10,
      warnIdleMin: 35,
      warnScanningMin: 70,
      critAfterMin: 70,
      autoRestart,
    },
    "Watchdog started",
  );
}

/**
 * Одноразовый аудит открытых сигналов (confirming в oi_watch за последние 7 дней).
 * Прогоняет каждый символ через Taker Flow и отправляет сводный отчёт в канал.
 */
export async function runAuditReport(): Promise<void> {
  logger.info("🔍 Audit report started");

  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const entries = await db
    .select({
      symbol: oiWatchTable.symbol,
      priceAtEntry: oiWatchTable.priceAtEntry,
      addedAt: oiWatchTable.addedAt,
      sentimentKey: oiWatchTable.sentimentKey,
      oiChange: oiWatchTable.oiChange,
    })
    .from(oiWatchTable)
    .where(
      and(
        eq(oiWatchTable.status, "confirming"),
        gte(oiWatchTable.addedAt, sevenDaysAgo),
      ),
    )
    .orderBy(sql`${oiWatchTable.addedAt} DESC`);

  const targets = await getTargets();

  if (targets.length === 0) {
    logger.warn("🔍 Audit: нет активных получателей");
    return;
  }

  if (entries.length === 0) {
    const msg = `🔍 <b>Аудит сигналов</b>\n\nОткрытых сигналов за последние 7 дней не найдено.`;
    for (const t of targets) await sendMessage(t, msg).catch(() => {});
    return;
  }

  // Батч цены из BingX (один запрос на все тикеры)
  const priceMap = new Map<string, number>();
  try {
    const tickers = await getFutureTickers();
    for (const t of tickers)
      priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
  } catch (err) {
    logger.warn({ err }, "🔍 Audit: BingX tickers failed — prices unavailable");
  }

  type Verdict = "enter" | "wait" | "skip";
  type AuditRow = {
    symbol: string;
    sentimentKey: string | null;
    entryPrice: number;
    currentPrice: number;
    pricePct: number;
    ageH: number;
    tfNetPct: number | null;
    tfDominance: "buy" | "sell" | "neutral" | null;
    verdict: Verdict;
  };

  const rows: AuditRow[] = [];

  for (const entry of entries) {
    const currentPrice = priceMap.get(entry.symbol) ?? 0;
    const entryPrice = entry.priceAtEntry ?? 0;
    const pricePct =
      entryPrice > 0 ? ((currentPrice - entryPrice) / entryPrice) * 100 : 0;
    const ageH = (Date.now() - new Date(entry.addedAt).getTime()) / 3_600_000;

    // Небольшая задержка чтобы не долбить API
    await new Promise((r) => setTimeout(r, 200));
    const tf = await getSpotTakerFlow(entry.symbol).catch(() => null);
    if (tf?.available)
      updateLiveSpotTaker(
        entry.symbol,
        tf.netBuyPct ?? null,
        tf.dominance ?? null,
      );

    let verdict: Verdict;
    if (
      pricePct < -15 ||
      (tf?.available && tf.dominance === "sell" && (tf.netBuyPct ?? 0) < -5)
    ) {
      verdict = "skip";
    } else if (
      tf?.available &&
      tf.dominance === "buy" &&
      (tf.netBuyPct ?? 0) > 3 &&
      pricePct < 12 &&
      ageH < 72
    ) {
      verdict = "enter";
    } else {
      verdict = "wait";
    }

    rows.push({
      symbol: entry.symbol,
      sentimentKey: entry.sentimentKey,
      entryPrice,
      currentPrice,
      pricePct,
      ageH,
      tfNetPct: tf?.available ? (tf.netBuyPct ?? null) : null,
      tfDominance: tf?.available ? tf.dominance : null,
      verdict,
    });
  }

  // Сортировка: сначала enter, потом wait, потом skip; внутри — по свежести
  const ORDER: Record<Verdict, number> = { enter: 0, wait: 1, skip: 2 };
  rows.sort((a, b) => ORDER[a.verdict] - ORDER[b.verdict] || a.ageH - b.ageH);

  const enterCount = rows.filter((r) => r.verdict === "enter").length;
  const waitCount = rows.filter((r) => r.verdict === "wait").length;
  const skipCount = rows.filter((r) => r.verdict === "skip").length;

  const lines: string[] = [
    `🔍 <b>Аудит открытых сигналов</b>  (7д, ${rows.length} позиций)`,
    `🟢 Войти: ${enterCount}  🟡 Ждать: ${waitCount}  🔴 Пропустить: ${skipCount}`,
    ``,
  ];

  for (const r of rows) {
    const base = r.symbol.replace("-USDT", "");
    const pctStr =
      r.pricePct >= 0
        ? `+${r.pricePct.toFixed(1)}%`
        : `${r.pricePct.toFixed(1)}%`;
    const ageStr =
      r.ageH < 24 ? `${Math.round(r.ageH)}ч` : `${(r.ageH / 24).toFixed(0)}д`;
    const tfStr =
      r.tfNetPct !== null
        ? `TF ${r.tfNetPct >= 0 ? "+" : ""}${r.tfNetPct.toFixed(0)}%`
        : `TF н/д`;
    const emoji =
      r.verdict === "enter" ? "🟢" : r.verdict === "wait" ? "🟡" : "🔴";
    const action =
      r.verdict === "enter"
        ? "ВХОДИТЬ"
        : r.verdict === "wait"
          ? "ЖДАТЬ"
          : "ПРОПУСТИТЬ";
    const pattern = r.sentimentKey
      ? ` <i>${r.sentimentKey.replace(/_/g, " ")}</i>`
      : "";

    lines.push(
      `${emoji} <b>${base}</b>${pattern}  ${pctStr}  ${ageStr}  ${tfStr} → <b>${action}</b>`,
    );
  }

  lines.push(
    ``,
    `📅 ${new Date().toLocaleString("ru-RU", { timeZone: "Europe/Moscow", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })} МСК`,
  );

  // Разбиваем на чанки по 4000 символов (лимит Telegram)
  const fullText = lines.join("\n");
  const CHUNK = 4000;
  const chunks: string[] = [];
  if (fullText.length <= CHUNK) {
    chunks.push(fullText);
  } else {
    const lineArr = lines;
    let cur = "";
    for (const ln of lineArr) {
      if ((cur + "\n" + ln).length > CHUNK) {
        if (cur) chunks.push(cur);
        cur = ln;
      } else {
        cur = cur ? cur + "\n" + ln : ln;
      }
    }
    if (cur) chunks.push(cur);
  }

  for (const target of targets) {
    for (const chunk of chunks) {
      await sendMessage(target, chunk).catch((err: unknown) => {
        logger.warn({ err, target }, "🔍 Audit: ошибка отправки");
      });
    }
  }

  logger.info(
    { total: rows.length, enter: enterCount, wait: waitCount, skip: skipCount },
    "🔍 Audit report sent",
  );
}

// ── Path B: прямой файр whale_alert из WhaleAlertJob (каждые 3 мин) ─────────────
// Вызывается сразу после runWhaleAlertJob(). Проверяет активные записи
// whale_alert_pool на OI/taker-подтверждение и выдаёт сигнал напрямую.
/**
 * Post-exit price tracking: заполняет price_72h_pct в whale_alert_pool
 * и price_72h_after_exit_pct в tracked_signals через 72ч после закрытия.
 * Запускается каждые 30 мин. Обрабатывает до 100 записей за цикл.
 * Покрывает ВСЕ паттерны (не только whale_alert).
 */
async function runPostExitPriceTracking(): Promise<void> {
  const cutoff72h = new Date(Date.now() - 72 * 60 * 60 * 1000);

  // ── 1. whale_alert_pool: fired/expired записи без price_72h_pct ──────────
  try {
    const poolRows = await db
      .select({
        id: whaleAlertPoolTable.id,
        symbol: whaleAlertPoolTable.symbol,
        entryPrice: whaleAlertPoolTable.entryPrice,
        status: whaleAlertPoolTable.status,
        firedAt: whaleAlertPoolTable.firedAt,
        expiresAt: whaleAlertPoolTable.expiresAt,
        price72hPct: whaleAlertPoolTable.price72hPct,
      })
      .from(whaleAlertPoolTable)
      .where(
        and(
          inArray(whaleAlertPoolTable.status, ["fired", "expired"]),
          isNull(whaleAlertPoolTable.price72hPct),
        ),
      )
      .limit(20);

    const eligible = poolRows.filter((r) => {
      const refTime = r.firedAt ?? r.expiresAt;
      return refTime && refTime <= cutoff72h;
    });

    if (eligible.length > 0) {
      const tickers = await getFutureTickers().catch(() => null);
      if (tickers) {
        const priceMap = new Map<string, number>();
        for (const t of tickers) {
          const p = parseFloat(t.lastPrice ?? "0");
          if (p > 0) priceMap.set(t.symbol, p);
        }
        let updated = 0;
        for (const r of eligible) {
          const ep = r.entryPrice;
          if (!ep || ep <= 0) continue;
          const cur = priceMap.get(r.symbol);
          if (!cur) continue;
          const pct = ((cur - ep) / ep) * 100;
          await dbWriteBestEffort(
            "whalePost72hPool",
            () =>
              db
                .update(whaleAlertPoolTable)
                .set({ price72hPct: pct })
                .where(eq(whaleAlertPoolTable.id, r.id)),
            { perAttemptTimeoutMs: 5000, retryDelayMs: 1000 },
          );
          updated++;
        }
        if (updated > 0)
          logger.info(
            { updated },
            "WhalePost72h: заполнено price_72h_pct в whale_alert_pool",
          );
      }
    }
  } catch (err) {
    logger.warn({ err }, "WhalePost72h: ошибка whale_alert_pool");
  }

  // ── 2. tracked_signals: все закрытые сигналы без price_72h_after_exit_pct ─
  const cutoff30d = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  try {
    const sigRows = await db
      .select({
        id: trackedSignalsTable.id,
        symbol: trackedSignalsTable.symbol,
        exitPrice: trackedSignalsTable.exitPrice,
        closedAt: trackedSignalsTable.closedAt,
      })
      .from(trackedSignalsTable)
      .where(
        and(
          inArray(trackedSignalsTable.status, [
            "cancelled",
            "stop_loss",
            "bu_stop",
            "profit",
          ]),
          isNull(trackedSignalsTable.price72hAfterExitPct),
          lt(trackedSignalsTable.closedAt, cutoff72h),
          gt(trackedSignalsTable.closedAt, cutoff30d),
        ),
      )
      .limit(100);

    if (sigRows.length > 0) {
      const tickers = await getFutureTickers().catch(() => null);
      if (tickers) {
        const priceMap = new Map<string, number>();
        for (const t of tickers) {
          const p = parseFloat(t.lastPrice ?? "0");
          if (p > 0) priceMap.set(t.symbol, p);
        }
        let updated = 0;
        for (const r of sigRows) {
          const ep = r.exitPrice;
          if (!ep || ep <= 0) continue;
          const cur = priceMap.get(r.symbol);
          if (!cur) continue;
          const pct = ((cur - ep) / ep) * 100;
          await dbWriteBestEffort(
            "whalePost72hSignal",
            () =>
              db
                .update(trackedSignalsTable)
                .set({ price72hAfterExitPct: pct })
                .where(eq(trackedSignalsTable.id, r.id)),
            { perAttemptTimeoutMs: 5000, retryDelayMs: 1000 },
          );
          updated++;
        }
        if (updated > 0)
          logger.info(
            { updated },
            "WhalePost72h: заполнено price_72h_after_exit_pct в tracked_signals",
          );
      }
    }
  } catch (err) {
    logger.warn({ err }, "WhalePost72h: ошибка tracked_signals");
  }
}

async function _runWhaleAlertFireCycle(): Promise<void> {
  const active = getActiveWhaleAlertPoolEntries();
  if (active.length === 0) return;

  const tickers = await getFutureTickers().catch(() => null);
  if (!tickers?.length) return;

  const priceMap = new Map<string, number>();
  const price24hMap = new Map<string, number>();
  for (const t of tickers) {
    const p = parseFloat(t.lastPrice ?? "0");
    if (p > 0) priceMap.set(t.symbol, p);
    price24hMap.set(t.symbol, parseFloat(t.priceChangePercent ?? "0") || 0);
  }

  // Символы, исключённые из whale_alert (паттерн не применяется вне зависимости от данных)
  const WHALE_ALERT_SYMBOL_BLACKLIST = new Set(["HYPE-USDT"]);

  let firedCount = 0;

  for (const { symbol } of active) {
    try {
      if (WHALE_ALERT_SYMBOL_BLACKLIST.has(symbol)) {
        logger.info({ symbol }, "WhaleAlert: пропуск — символ в блэклисте");
        continue;
      }

      const entry = getWhaleAlertPoolEntry(symbol);
      if (!entry) continue;

      // Считаем, сколько раз этот символ прошёл через fire-цикл — аналог prescanCycles
      const whaleFireCycles = incrementWhalePoolCycleCount(symbol);

      // ── Cycle gate ────────────────────────────────────────────────────────
      // Данные 33 сигналов: все 5 ранних выстрелов (cycle 0–1) дали плохой исход
      // (1× SL −8.3%, 4× отмена), единственный profit (+5.63%) пришёл на цикле 286.
      // Gate=2 (≥6 мин в пуле) блокирует 5 ранних сигналов без потери прибыли.
      // При gate=0–1 cancel% = 83%; gate=2 → 81% при n=32. Оптимум = 2.
      if (whaleFireCycles < 2) {
        logger.debug(
          { symbol, whaleFireCycles },
          "WhaleAlert: пропуск — min cycle gate (< 2 циклов)",
        );
        continue;
      }

      const currentPrice = priceMap.get(symbol);
      if (currentPrice === undefined) continue;

      const price24hPct = price24hMap.get(symbol) ?? 0;
      // Фильтр: если токен уже вырос >20% за 24ч — кит поздно, рынок знает
      if (price24hPct > 20.0) continue;

      const priceChange =
        entry.entryPrice !== null && entry.entryPrice > 0
          ? ((currentPrice - entry.entryPrice) / entry.entryPrice) * 100
          : 0;
      if (priceChange < -1.0) continue;

      // Gate 1: per-whale cooldown — тот же кит закрыл позицию < 4ч назад
      if (entry.whaleAddress && isWhaleOnCooldown(entry.whaleAddress)) {
        logger.info(
          { symbol, whaleAddr: entry.whaleAddress.slice(0, 8) + "…" },
          "🐋🎯 WhaleAlert: пропуск — кит на кулдауне (закрывал позицию < 4ч назад)",
        );
        continue;
      }

      // Gate 2: liq proximity — цена ближе чем 8% к ликвидации кита
      // Fail-open: liqPrice === null → нет данных → пропускаем gate
      if (
        entry.liqPrice !== null &&
        entry.liqPrice > 0 &&
        (currentPrice - entry.liqPrice) / currentPrice < 0.08
      ) {
        logger.info(
          {
            symbol,
            currentPrice,
            liqPrice: entry.liqPrice,
            distPct: (
              ((currentPrice - entry.liqPrice) / currentPrice) *
              100
            ).toFixed(1),
          },
          "🐋🎯 WhaleAlert: пропуск — цена в пределах 8% от ликвидации кита",
        );
        continue;
      }

      if (
        entry.futLargeOrderConfirmed === false ||
        entry.spotLargeOrderConfirmed === false
      )
        continue;

      // WI gate: per-token Whale Index (CoinGlass, Binance 4h).
      // Если общий потоком китов активно продаёт токен — HL-лонг противоречит рынку.
      // Fail-open: null (нет данных / BingX-exclusive) → продолжаем.
      const _tokenWi = await getTokenWhaleIndex(symbol).catch(() => null);
      if (_tokenWi !== null && _tokenWi < -100) {
        logger.info(
          { symbol, tokenWi: _tokenWi },
          "🐋🎯 WhaleAlert: пропуск — per-token WI слишком медвежий (< −100)",
        );
        continue;
      }

      const [oiData, takerData, fsVol, cvdData, spotTakerData] =
        await Promise.all([
          getCoinglassOI(symbol, currentPrice).catch(() => null),
          getCoinglassTakerFlow(symbol).catch(() => null),
          getFsVolume(symbol).catch(() => null),
          getSpotCvdMtf(symbol).catch(() => null),
          getSpotTakerFlow(symbol).catch(() => null),
        ]);
      const oi30m = oiData?.oiChange30m ?? null;
      const oi1h = oiData?.oiChange1h ?? null;

      // Подтверждение рынком: OI достаточно само по себе.
      // Taker без SpotCVD1h — слишком слабо: рынок не подтвердил ни ценой, ни накоплением.
      // Gate 3: порог поднят — OI 30m ≥1.5% (было 1.0%) / OI 1h ≥2.0% (было 1.5%)
      const oiPass =
        (oi30m !== null && oi30m >= 1.5) || (oi1h !== null && oi1h >= 2.0);
      const cvd1hPositive =
        (cvdData?.available ?? false) && cvdData?.cvd1h === true;
      const takerPass =
        takerData !== null &&
        takerData.available &&
        (takerData.netBuyPct ?? 0) >= 10;
      const confirmed = oiPass || (takerPass && cvd1hPositive);
      if (!confirmed) continue;

      const confirmNote = oiPass
        ? `OI подтверждён (${((oi30m !== null && oi30m >= 1.5 ? oi30m : oi1h) ?? 0).toFixed(1)}%)`
        : `Taker+SpotCVD (${(takerData?.netBuyPct ?? 0).toFixed(0)}%)`;

      // Lag metrics: время от открытия позиции кита до детекта и до выстрела
      const _firedAtMs = Date.now();
      const _detectLagMin =
        entry.hlCreateTime != null
          ? Math.round((entry.detectedAt - entry.hlCreateTime) / 60_000)
          : null;
      const _confirmLagMin = Math.round(
        (_firedAtMs - entry.detectedAt) / 60_000,
      );
      const _lagNote =
        _detectLagMin != null
          ? `⏱ det ${_detectLagMin}м·conf ${_confirmLagMin}м`
          : `⏱ conf ${_confirmLagMin}м`;

      // Gate 4: stale confirm lag — кит держит > 3ч и цена не сдвинулась (<0.5%)
      if (_confirmLagMin > 180 && priceChange < 0.5) {
        logger.info(
          { symbol, confirmLagMin: _confirmLagMin, priceChange },
          "🐋🎯 WhaleAlert: пропуск — кит держит >3ч без движения цены",
        );
        continue;
      }

      const usdM = (entry.positionValueUsd / 1e6).toFixed(1);
      const totalM = (entry.totalWhaleUsd / 1e6).toFixed(1);
      const loParts: string[] = [];
      if (entry.futLargeOrderConfirmed === true)
        loParts.push("фьюч-лимитники ✓");
      if (entry.spotLargeOrderConfirmed === true)
        loParts.push("спот-лимитники ✓");
      const loNote = loParts.length > 0 ? ", " + loParts.join(", ") : "";
      const countNote =
        entry.whaleCount > 1
          ? `, китов ×${entry.whaleCount} ($${totalM}M суммарно)`
          : "";

      const alphaScore =
        6 +
        (entry.positionValueUsd >= 5_000_000 ||
        (entry.futLargeOrderConfirmed === true &&
          entry.spotLargeOrderConfirmed === true)
          ? 1
          : 0);

      const alphaResult: AlphaResult = {
        symbol,
        grade: "alpha",
        price: currentPrice,
        priceChange30m: priceChange,
        currentVolume: 0,
        avgVolume: 0,
        volumeMultiplier: 0,
        oiChangePercent: oi30m ?? 0,
        openInterest: oiData?.oiUsd ?? null,
        cmcRank: null,
        cmcSource: null,
        cmcAvailable: false,
        liquidationsUsd: null,
        liquidationsMultiple: null,
        coinglassAvailable: oiData?.available ?? false,
        globalOiChange: oi30m,
        spotVol24h: fsVol?.spotVolUsd24h ?? null,
        oiChange1h: oi1h,
        oiChange4h: oiData?.oiChange4h ?? null,
        oiChange24h: oiData?.oiChange24h ?? null,
        sentiment: "Whale Alert",
        sentimentKey: "whale_alert",
        traderAction: `LONG (кит Hyperliquid открыл лонг $${usdM}M${countNote}${loNote}, ${confirmNote})`,
        alphaScore,
        isContinuing: false,
        cumulativeOiChange: oi30m ?? 0,
        tradingViewUrl: `https://www.tradingview.com/chart/?symbol=BINGX:${symbol.replace("-", "")}`,
        bingxUrl: `https://bingx.com/en/perpetual/${symbol.replace("-USDT", "")}USDT/`,
        marketCapUsd: getSpotPoolEntry(symbol)?.mcapUsd ?? null,
        scoreBreakdown: [
          `HL лонг $${usdM}M`,
          oi30m != null
            ? `OI 30m${oi30m >= 0 ? "+" : ""}${oi30m.toFixed(1)}%${oi1h != null ? `/1h${oi1h >= 0 ? "+" : ""}${oi1h.toFixed(1)}%` : ""}`
            : null,
          confirmNote,
          _lagNote,
        ]
          .filter(Boolean)
          .join(" · "),
      };

      const tracked = await trackSignal({
        symbol,
        signalId: null,
        signalType: "alpha",
        sentiment: "Whale Alert",
        sentimentKey: "whale_alert",
        alphaScore,
        entryPrice: currentPrice,
        prescanCycles: whaleFireCycles,
        entryOi: oiData?.oiUsd ?? null,
        entryOi30m: oi30m,
        entryOi1h: oi1h,
        entryOi4h: oiData?.oiChange4h ?? null,
        entryOi24h: oiData?.oiChange24h ?? null,
        entryFutTakerNetBuy: takerData?.available
          ? (takerData.netBuyPct ?? null)
          : null,
        entryCvd30m: cvdData?.available ? (cvdData.cvd30m ?? null) : null,
        entryCvd1h: cvdData?.available ? (cvdData.cvd1h ?? null) : null,
        entryCvd4h: cvdData?.available ? (cvdData.cvd4h ?? null) : null,
        entrySpotTakerNetBuy: spotTakerData?.available
          ? (spotTakerData.netBuyPct ?? null)
          : null,
        entrySpotVol24h: fsVol?.spotVolUsd24h ?? null,
      });

      if (tracked === false) {
        logger.error(
          { symbol },
          "WhaleAlert Path B: trackSignal упал → broadcast отменён",
        );
        continue;
      }
      // "skip"  — сигнал уже активен (entry price protected), не дублируем TG и не помечаем fired
      // "reentry" — существующий сигнал сброшен на новую цену, TG отправит broadcastBatchAlert ниже
      if (tracked === "skip") {
        logger.info(
          { symbol },
          "WhaleAlert Path B: сигнал уже активен — broadcast и markFired пропущены",
        );
        continue;
      }

      resetPrescanCycleCount(symbol);
      await broadcastBatchAlert([
        { ...alphaResult, entryOb: consumeObAtFire(symbol) },
      ]);
      injectLiveMarketData(symbol, {
        oi30m: oiData?.oiChange30m ?? null,
        oi1h: oiData?.oiChange1h ?? null,
        oi4h: oiData?.oiChange4h ?? null,
        oi24h: oiData?.oiChange24h ?? null,
        netBuyPct: takerData?.netBuyPct ?? null,
      });
      markWhaleAlertFired(symbol);
      firedCount++;

      logger.info(
        {
          symbol,
          usdM,
          oi30m,
          oi1h,
          taker: takerData?.netBuyPct,
          alphaScore,
          detectLagMin: _detectLagMin,
          confirmLagMin: _confirmLagMin,
        },
        "🐋🎯 WHALE ALERT Path B: кит подтверждён → прямой сигнал выдан",
      );
    } catch (err) {
      logger.error(
        { err, symbol },
        "WhaleAlert Path B: ошибка при попытке выстрела",
      );
    }
  }

  if (firedCount > 0)
    logger.info({ firedCount }, "WhaleAlert Path B: цикл завершён");
}

/**
 * Backfill job: заполняет null entry-метрики для открытых сигналов.
 * Запускается каждые 30 мин из startWatcher.
 * Обрабатывает до 10 сигналов за цикл (rate limiting CoinGlass).
 * Не перезаписывает уже заполненные поля.
 */
async function refreshNullEntryMetrics(): Promise<void> {
  let candidates: Array<{
    id: number;
    symbol: string;
    entryPrice: string | number | null;
    entryWhaleIndex: number | null;
    entryObRatio: number | null;
    entryOi30m: number | null;
    entryOi1h: number | null;
    entryOi4h: number | null;
    entryOi24h: number | null;
    entryFutTakerNetBuy: number | null;
    entrySpotTakerNetBuy: number | null;
    entrySpotNetBuy1h: number | null;
    entrySpotNetBuy4h: number | null;
    entrySpotNetBuy24h: number | null;
    entryCvd30m: boolean | null;
  }>;
  try {
    candidates = await db
      .select({
        id: trackedSignalsTable.id,
        symbol: trackedSignalsTable.symbol,
        entryPrice: trackedSignalsTable.entryPrice,
        entryWhaleIndex: trackedSignalsTable.entryWhaleIndex,
        entryObRatio: trackedSignalsTable.entryObRatio,
        entryOi30m: trackedSignalsTable.entryOi30m,
        entryOi1h: trackedSignalsTable.entryOi1h,
        entryOi4h: trackedSignalsTable.entryOi4h,
        entryOi24h: trackedSignalsTable.entryOi24h,
        entryFutTakerNetBuy: trackedSignalsTable.entryFutTakerNetBuy,
        entrySpotTakerNetBuy: trackedSignalsTable.entrySpotTakerNetBuy,
        entrySpotNetBuy1h: trackedSignalsTable.entrySpotNetBuy1h,
        entrySpotNetBuy4h: trackedSignalsTable.entrySpotNetBuy4h,
        entrySpotNetBuy24h: trackedSignalsTable.entrySpotNetBuy24h,
        entryCvd30m: trackedSignalsTable.entryCvd30m,
      })
      .from(trackedSignalsTable)
      .where(
        and(
          inArray(trackedSignalsTable.status, [
            "active",
            "in_run",
            "accumulation",
            "re_entry",
          ]),
          or(
            isNull(trackedSignalsTable.entryWhaleIndex),
            isNull(trackedSignalsTable.entryObRatio),
            isNull(trackedSignalsTable.entryOi30m),
            isNull(trackedSignalsTable.entryOi1h),
            isNull(trackedSignalsTable.entryOi4h),
            isNull(trackedSignalsTable.entryOi24h),
            isNull(trackedSignalsTable.entryFutTakerNetBuy),
            isNull(trackedSignalsTable.entrySpotTakerNetBuy),
            isNull(trackedSignalsTable.entrySpotNetBuy1h),
            isNull(trackedSignalsTable.entrySpotNetBuy4h),
            isNull(trackedSignalsTable.entrySpotNetBuy24h),
            isNull(trackedSignalsTable.entryCvd30m),
          ),
        ),
      )
      .orderBy(desc(trackedSignalsTable.detectedAt))
      .limit(10);
  } catch (err) {
    logger.warn(
      { err },
      "refreshNullEntryMetrics: DB query failed — пропуск цикла",
    );
    return;
  }

  if (candidates.length === 0) return;

  const withTimeout6s = <T>(p: Promise<T>): Promise<T | null> =>
    Promise.race([
      p.catch(() => null),
      new Promise<null>((res) => setTimeout(() => res(null), 6000)),
    ]);

  let totalFilled = 0;
  let totalSignals = 0;

  for (const sig of candidates) {
    try {
      const ep = Number(sig.entryPrice ?? 0);

      // Trigger OI fetch if ANY of the four OI companion fields is null
      const needsOi =
        sig.entryOi30m === null ||
        sig.entryOi1h === null ||
        sig.entryOi4h === null ||
        sig.entryOi24h === null;

      const [wi, ob, oi, taker, spotTaker, cvd] = await Promise.all([
        sig.entryWhaleIndex === null
          ? withTimeout6s(getTokenWhaleIndex(sig.symbol))
          : Promise.resolve(undefined as undefined),
        sig.entryObRatio === null
          ? withTimeout6s(
              getOrderBookAnalysis(sig.symbol, 20).catch(() => null),
            )
          : Promise.resolve(undefined as undefined),
        needsOi
          ? withTimeout6s(getCoinglassOI(sig.symbol, ep).catch(() => null))
          : Promise.resolve(undefined as undefined),
        sig.entryFutTakerNetBuy === null
          ? withTimeout6s(getCoinglassTakerFlow(sig.symbol).catch(() => null))
          : Promise.resolve(undefined as undefined),
        sig.entrySpotTakerNetBuy === null
          ? withTimeout6s(getSpotTakerFlow(sig.symbol))
          : Promise.resolve(undefined as undefined),
        sig.entryCvd30m === null
          ? withTimeout6s(getSpotCvdMtf(sig.symbol))
          : Promise.resolve(undefined as undefined),
      ]);

      const patch: Record<string, unknown> = {};
      let filled = 0;

      if (wi != null && sig.entryWhaleIndex === null) {
        patch.entryWhaleIndex = wi;
        filled++;
      }
      if (ob != null && sig.entryObRatio === null) {
        const obR = ob as OrderBookAnalysis;
        patch.entryObRatio = obR.bidAskRatio;
        patch.entryObBids = obR.bidVolumeUsd;
        patch.entryObAsks = obR.askVolumeUsd;
        filled++;
      }
      if (oi != null && needsOi) {
        const oiR = oi as Awaited<ReturnType<typeof getCoinglassOI>>;
        if (sig.entryOi30m === null) patch.entryOi30m = oiR.oiChange30m ?? null;
        if (sig.entryOi1h === null) patch.entryOi1h = oiR.oiChange1h ?? null;
        if (sig.entryOi4h === null) patch.entryOi4h = oiR.oiChange4h ?? null;
        if (sig.entryOi24h === null) patch.entryOi24h = oiR.oiChange24h ?? null;
        filled++;
      }
      if (taker != null && sig.entryFutTakerNetBuy === null) {
        const takerR = taker as Awaited<
          ReturnType<typeof getCoinglassTakerFlow>
        >;
        if (takerR.available) {
          patch.entryFutTakerNetBuy = takerR.netBuyPct ?? null;
          filled++;
        }
      }
      if (
        spotTaker != null &&
        (sig.entrySpotTakerNetBuy === null || sig.entrySpotNetBuy1h === null)
      ) {
        const stR = spotTaker as Awaited<ReturnType<typeof getSpotTakerFlow>>;
        if (stR.available) {
          if (sig.entrySpotTakerNetBuy === null) {
            patch.entrySpotTakerNetBuy = stR.netBuyPct ?? null;
          }
          if (sig.entrySpotNetBuy1h === null && stR.takerNetBuy1h != null) {
            patch.entrySpotNetBuy1h = stR.takerNetBuy1h;
          }
          filled++;
        }
      }
      // SNF 4h / 24h — мгновенный кэш, без API-вызова
      if (sig.entrySpotNetBuy4h === null || sig.entrySpotNetBuy24h === null) {
        const _snf = getSpotNetflowEntry(sig.symbol);
        if (_snf) {
          if (sig.entrySpotNetBuy4h === null && _snf.netPct4h != null) {
            patch.entrySpotNetBuy4h = _snf.netPct4h;
            filled++;
          }
          if (sig.entrySpotNetBuy24h === null && _snf.netPct24h != null) {
            patch.entrySpotNetBuy24h = _snf.netPct24h;
            filled++;
          }
        }
      }
      if (cvd != null && sig.entryCvd30m === null) {
        const cvdR = cvd as Awaited<ReturnType<typeof getSpotCvdMtf>>;
        if (cvdR.available) {
          patch.entryCvd30m = cvdR.cvd30m ?? null;
          patch.entryCvd1h = cvdR.cvd1h ?? null;
          patch.entryCvd4h = cvdR.cvd4h ?? null;
          filled++;
        }
      }

      if (filled > 0) {
        patch.updatedAt = new Date();
        const patchTyped =
          patch as unknown as (typeof trackedSignalsTable)["$inferInsert"];
        const written = await dbWriteBestEffort(
          "refreshNullEntryMetrics:update",
          async () => {
            await db
              .update(trackedSignalsTable)
              .set(patchTyped)
              .where(eq(trackedSignalsTable.id, sig.id));
          },
          { perAttemptTimeoutMs: 5000 },
        );
        if (written !== null) {
          totalFilled += filled;
          totalSignals++;
        }
      }
    } catch (err) {
      logger.warn(
        { err, symbol: sig.symbol },
        "refreshNullEntryMetrics: ошибка обработки сигнала — пропуск",
      );
    }
  }

  if (totalFilled > 0) {
    logger.info(
      { totalFilled, totalSignals, candidates: candidates.length },
      `backfilled ${totalFilled} fields for ${totalSignals} signals`,
    );
  }
}

async function _runLiqCascadeFireCycle(): Promise<void> {
  const candidates = getLiqCascadeLayer10Candidates();
  if (candidates.length === 0) return;

  const tickers = await getFutureTickers().catch(() => null);
  if (!tickers?.length) return;

  const priceMap = new Map<string, number>();
  const price24hMap = new Map<string, number>();
  const futVol24hMap = new Map<string, number>();
  for (const t of tickers) {
    const p = parseFloat(t.lastPrice ?? "0");
    if (p > 0) priceMap.set(t.symbol, p);
    price24hMap.set(t.symbol, parseFloat(t.priceChangePercent ?? "0") || 0);
    const v = parseFloat(t.quoteVolume ?? "0") || 0;
    if (v > 0) futVol24hMap.set(t.symbol, v);
  }

  let firedCount = 0;

  for (const entry of candidates) {
    try {
      const {
        symbol,
        detectedAt,
        liqExhausted,
        entryReason,
        longLiq1hAtDetect,
        longLiq24hAtDetect,
        cycleCountAtDetect,
      } = entry;

      _pdbCheck("liquidation_cascade_bg");

      // cycleCount гейт отключён (2026-07-29): недостаточно данных для надёжного cut-off.
      // cycleCount по-прежнему пишется в prescanCycles при файре — для ретроспективного анализа.

      // Файр только когда liqExhausted строго true — каскад точно исчерпан.
      // null (данные CoinGlass недоступны) → не стреляем вслепую, ждём следующего цикла.
      if (liqExhausted !== true) {
        _pdbReject("liquidation_cascade_bg", "liq_not_exhausted");
        continue;
      }

      const ageMin = (Date.now() - detectedAt) / 60_000;
      if (ageMin < 30 && entryReason !== "liq_order_stream") {
        _pdbReject("liquidation_cascade_bg", "too_fresh_<30min");
        continue;
      }

      const currentPrice = priceMap.get(symbol);
      if (currentPrice === undefined) {
        _pdbReject("liquidation_cascade_bg", "no_price");
        continue;
      }

      const price24hPct = price24hMap.get(symbol) ?? 0;
      if (price24hPct < -50) {
        _pdbReject("liquidation_cascade_bg", "price24h_crash");
        continue;
      }

      const [oiData, fsVol, cvdData, futTakerData, spotTakerData] =
        await Promise.all([
          getCoinglassOI(symbol, currentPrice).catch(() => null),
          getFsVolume(symbol).catch(() => null),
          getSpotCvdMtf(symbol).catch(() => null),
          getCoinglassTakerFlow(symbol).catch(() => null),
          getSpotTakerFlow(symbol).catch(() => null),
        ]);
      const oi30m = oiData?.oiChange30m ?? null;
      // OI30m gate: требуем минимальный рост OI как подтверждение импульса.
      // Порог откачен с 1.5% → 0.3%: SQL-анализ по prod-данным показал что
      // PROFIT-группа имеет медиану 0.59% (p75=0.89%) — порог 1.5% отсекал 0/4
      // исторических профитов при наличии данных (100% ложных блоков).
      // null (данные недоступны) → fail-open, поведение не меняется.
      if (oi30m !== null && oi30m <= 0.3) {
        _pdbReject("liquidation_cascade_bg", "oi30m_below_0.3");
        continue;
      }

      // CVD 4h gate (fail-open): если 4h накопление явно отрицательное — каскад ещё не
      // получил поддержки со стороны покупателей на старшем ТФ, пропускаем.
      // Данные: 79% отменённых сигналов (27/34 с данными CVD4h) имели CVD4h=false.
      // null / unavailable → fail-open (не блокируем при отсутствии данных).
      if (cvdData?.available === true && cvdData.cvd4h === false) {
        _pdbReject("liquidation_cascade_bg", "cvd4h_false");
        continue;
      }

      // CVD30m gate удалён: SQL-аудит 27.07 показал profit pass=50%, cancel pass=47%
      // — нет дискриминации между группами исходов (ratio 1.05x), гейт бесполезен.

      const ageStr = `${Math.round(ageMin)}мин`;
      const exhausted = liqExhausted === null ? "неизв." : "да";
      const reasonStr =
        entryReason === "liq_order_stream" ? "ордер-стрим" : "liq_spike";

      const alphaScore = 6;
      const alphaResult: AlphaResult = {
        symbol,
        grade: "alpha",
        price: currentPrice,
        priceChange30m: 0,
        currentVolume: futVol24hMap.get(symbol) ?? 0,
        avgVolume: 0,
        volumeMultiplier: 0,
        oiChangePercent: oi30m ?? 0,
        openInterest: oiData?.oiUsd ?? null,
        cmcRank: null,
        cmcSource: null,
        cmcAvailable: false,
        liquidationsUsd: null,
        liquidationsMultiple: null,
        coinglassAvailable: oiData?.available ?? false,
        globalOiChange: oi30m,
        spotVol24h: fsVol?.spotVolUsd24h ?? null,
        oiChange1h: oiData?.oiChange1h ?? null,
        oiChange4h: oiData?.oiChange4h ?? null,
        oiChange24h: oiData?.oiChange24h ?? null,
        sentiment: "Liquidation Cascade",
        sentimentKey: "liquidation_cascade",
        traderAction: `LONG (каскад лонг-ликвидаций исчерпан ${ageStr} назад, источник: ${reasonStr}, liqExhausted: ${exhausted}, стоп -8%)`,
        alphaScore,
        isContinuing: false,
        cumulativeOiChange: oi30m ?? 0,
        tradingViewUrl: `https://www.tradingview.com/chart/?symbol=BINGX:${symbol.replace("-", "")}`,
        bingxUrl: `https://bingx.com/en/perpetual/${symbol.replace("-USDT", "")}USDT/`,
        marketCapUsd: getSpotPoolEntry(symbol)?.mcapUsd ?? null,
        scoreBreakdown: [
          `Лонг-ликв исчерпаны ${ageStr} назад`,
          oi30m != null
            ? `OI 30m${oi30m >= 0 ? "+" : ""}${oi30m.toFixed(1)}%`
            : null,
          `источник: ${reasonStr}`,
        ]
          .filter(Boolean)
          .join(" · "),
      };

      const liqRatio =
        longLiq1hAtDetect != null &&
        longLiq24hAtDetect != null &&
        longLiq24hAtDetect > 0
          ? longLiq1hAtDetect / longLiq24hAtDetect
          : null;
      const tracked = await trackSignal({
        symbol,
        signalId: null,
        signalType: "alpha",
        sentiment: "Liquidation Cascade",
        sentimentKey: "liquidation_cascade",
        alphaScore,
        entryPrice: currentPrice,
        // cycleCountAtDetect = prescan cycles когда была обнаружена liq-волна;
        // fallback на live prescan для токенов присутствующих в prescan_tracker.
        prescanCycles:
          cycleCountAtDetect ?? getPrescanEntry(symbol)?.cycleCount ?? null,
        entryOi: oiData?.oiUsd ?? null,
        entryOi30m: oi30m,
        entryOi1h: oiData?.oiChange1h ?? null,
        entryOi4h: oiData?.oiChange4h ?? null,
        entryOi24h: oiData?.oiChange24h ?? null,
        entryCvd30m: cvdData?.available ? (cvdData.cvd30m ?? null) : null,
        entryCvd1h: cvdData?.available ? (cvdData.cvd1h ?? null) : null,
        entryCvd4h: cvdData?.available ? (cvdData.cvd4h ?? null) : null,
        entryFutTakerNetBuy: futTakerData?.available
          ? (futTakerData.netBuyPct ?? null)
          : null,
        entrySpotTakerNetBuy: spotTakerData?.available
          ? (spotTakerData.netBuyPct ?? null)
          : null,
        entrySpotVol24h: fsVol?.spotVolUsd24h ?? null,
        entryLiqLong1h: longLiq1hAtDetect,
        entryLiqLong24h: longLiq24hAtDetect,
        entryLiqRatio: liqRatio,
        entryLiqReason: entryReason,
      });

      if (tracked === false) {
        logger.error(
          { symbol },
          "LiqCascade Path B: trackSignal упал → broadcast отменён",
        );
        continue;
      }
      if (tracked === "skip") {
        logger.info(
          { symbol },
          "LiqCascade Path B: сигнал уже активен → пропуск",
        );
        continue;
      }

      resetPrescanCycleCount(symbol);
      _pdbPass("liquidation_cascade_bg");
      const _liqBcastSent = await broadcastBatchAlert([
        { ...alphaResult, entryOb: consumeObAtFire(symbol) },
      ]);
      if (_liqBcastSent === 0) {
        logger.error(
          { symbol, ageMin: Math.round(ageMin), entryReason },
          "LiqCascade Path B: broadcastBatchAlert — ни одно TG сообщение не доставлено",
        );
      }
      injectLiveMarketData(symbol, {
        oi30m: oiData?.oiChange30m ?? null,
        oi1h: oiData?.oiChange1h ?? null,
        oi4h: oiData?.oiChange4h ?? null,
        oi24h: oiData?.oiChange24h ?? null,
      });
      firedCount++;

      logger.info(
        {
          symbol,
          ageMin: Math.round(ageMin),
          entryReason,
          liqExhausted,
          oi30m,
          alphaScore,
          tgSent: _liqBcastSent,
        },
        "💥🔄 LIQUIDATION CASCADE Path B: каскад исчерпан → прямой сигнал выдан",
      );
    } catch (err) {
      logger.error(
        { err, symbol: entry.symbol },
        "LiqCascade Path B: ошибка при выстреле",
      );
    }
  }

  if (firedCount > 0)
    logger.info({ firedCount }, "LiqCascadeFireCycle завершён");
}

// ── TA Scanner — мульти-TF технический анализ (MA/EMA/MACD/TD/ATR) ──────────

export interface TaScannerEntry {
  symbol: string;
  currentPrice: number | null;
  ma1h: number | null;
  ma4h: number | null;
  ma1d: number | null;
  ema1h: number | null;
  ema4h: number | null;
  ema1d: number | null;
  macd1h: number | null;
  signal1h: number | null;
  macd4h: number | null;
  signal4h: number | null;
  macd1d: number | null;
  signal1d: number | null;
  /** Положительное = buy setup, отрицательное = sell setup. |9| = завершённый setup */
  td1h: number | null;
  td4h: number | null;
  td1d: number | null;
  td1w: number | null;
  atr1h: number | null;
  atr4h: number | null;
  updatedAt: number;
}

let _taScannerCache: { entries: TaScannerEntry[]; ts: number } | null = null;

export function getTaSnapshot(): {
  entries: TaScannerEntry[];
  updatedAt: number;
} {
  return {
    entries: _taScannerCache?.entries ?? [],
    updatedAt: _taScannerCache?.ts ?? 0,
  };
}

/** Сохраняет текущий снапшот TA-данных в БД (best-effort, не бросает).
 *  Вызывается в конце каждого runTaScannerCycle() — одна строка id=1, UPSERT. */
async function persistTaScannerCacheToDb(
  entries: TaScannerEntry[],
  ts: number,
): Promise<void> {
  await dbWriteBestEffort(
    "persistTaScannerCache",
    () =>
      db
        .insert(taScannerCacheTable)
        .values({
          id: 1,
          entries: entries as unknown as Record<string, unknown>[],
          updatedAt: new Date(ts),
        })
        .onConflictDoUpdate({
          target: taScannerCacheTable.id,
          set: {
            entries: sql`excluded.entries`,
            updatedAt: sql`excluded.updated_at`,
          },
        }),
    { perAttemptTimeoutMs: 8000, attempts: 2, retryDelayMs: 2000 },
  );
}

/** Загружает последний TA-снапшот из БД в _taScannerCache при старте.
 *  Вызывается из startWatcher() — вкладка Layer TA не пустеет после деплоя. */
async function loadTaScannerCacheFromDb(): Promise<void> {
  try {
    const rows = await db
      .select({
        entries: taScannerCacheTable.entries,
        updatedAt: taScannerCacheTable.updatedAt,
      })
      .from(taScannerCacheTable)
      .limit(1);
    const row = rows[0];
    if (!row || !Array.isArray(row.entries) || row.entries.length === 0) return;
    _taScannerCache = {
      entries: row.entries as unknown as TaScannerEntry[],
      ts: row.updatedAt.getTime(),
    };
    logger.info(
      { symbols: row.entries.length },
      "TA Scanner: кэш восстановлен из БД (до первого цикла)",
    );
  } catch (err) {
    logger.warn(
      { err },
      "TA Scanner: не удалось загрузить кэш из БД (non-critical)",
    );
  }
}

const TA_SCANNER_INTERVAL_MS = 5 * 60 * 1000; // 5 мин

async function runTaScannerCycle(): Promise<void> {
  try {
    const [maMap, emaMap, macdMap, tdMap, atrMap] = await Promise.all([
      loadMaBulkMap().catch(() => new Map<string, MaListEntry>()),
      loadEmaBulkMap().catch(() => new Map<string, EmaListEntry>()),
      loadMacdBulkMap().catch(() => new Map<string, MacdListEntry>()),
      loadTdBulkMap().catch(() => new Map<string, TdListEntry>()),
      loadAtrBulkMap().catch(() => new Map<string, AtrListEntry>()),
    ]);

    if (tdMap.size === 0 && maMap.size === 0) {
      logger.warn("TA Scanner: all data maps empty — skip cache update");
      return;
    }

    const allSymbols = new Set<string>([
      ...maMap.keys(),
      ...emaMap.keys(),
      ...macdMap.keys(),
      ...tdMap.keys(),
      ...atrMap.keys(),
    ]);

    const now = Date.now();
    const entries: TaScannerEntry[] = [];
    for (const sym of allSymbols) {
      const ma = maMap.get(sym);
      const ema = emaMap.get(sym);
      const macd = macdMap.get(sym);
      const td = tdMap.get(sym);
      const atr = atrMap.get(sym);
      const currentPrice = ma?.closePrice ?? ema?.closePrice ?? null;

      entries.push({
        symbol: sym,
        currentPrice,
        ma1h: ma?.ma1h ?? null,
        ma4h: ma?.ma4h ?? null,
        ma1d: ma?.ma1d ?? null,
        ema1h: ema?.ema1h ?? null,
        ema4h: ema?.ema4h ?? null,
        ema1d: ema?.ema1d ?? null,
        macd1h: macd?.macd1h ?? null,
        signal1h: macd?.signal1h ?? null,
        macd4h: macd?.macd4h ?? null,
        signal4h: macd?.signal4h ?? null,
        macd1d: macd?.macd1d ?? null,
        signal1d: macd?.signal1d ?? null,
        td1h: td?.td1h ?? null,
        td4h: td?.td4h ?? null,
        td1d: td?.td1d ?? null,
        td1w: td?.td1w ?? null,
        atr1h: atr?.atr1h ?? null,
        atr4h: atr?.atr4h ?? null,
        updatedAt: now,
      });
    }

    _taScannerCache = { entries, ts: now };

    // Populate ta-cache для demark pattern detection в scanner.ts
    for (const e of entries) {
      setTdAtrEntry(e.symbol, {
        td1h: e.td1h,
        td4h: e.td4h,
        atr1h: e.atr1h,
        updatedAt: e.updatedAt,
      });
    }

    logger.info(
      { symbols: entries.length, tdSize: tdMap.size },
      "TA Scanner cycle complete",
    );
    void persistTaScannerCacheToDb(entries, now);
  } catch (err) {
    logger.error({ err }, "TA Scanner cycle: unexpected error");
  }
}

export function stopWatcher(): void {
  if (fastTimer) {
    clearTimeout(fastTimer);
    fastTimer = null;
  }
  if (cycleTimer) {
    clearTimeout(cycleTimer);
    cycleTimer = null;
  }
  if (dailyTimer) {
    clearTimeout(dailyTimer);
    dailyTimer = null;
  }
  if (weeklyTimer) {
    clearTimeout(weeklyTimer);
    weeklyTimer = null;
  }
  if (monthlyTimer) {
    clearTimeout(monthlyTimer);
    monthlyTimer = null;
  }
  if (whaleTimer) {
    clearTimeout(whaleTimer);
    whaleTimer = null;
  }
  if (positionsTimer) {
    clearTimeout(positionsTimer);
    positionsTimer = null;
  }
  if (taScannerTimer) {
    clearTimeout(taScannerTimer);
    taScannerTimer = null;
  }
  if (watchdogTimer) {
    clearTimeout(watchdogTimer);
    watchdogTimer = null;
  }
  logger.info("AltBullet Watcher stopped");
}
