/**
 * Whale Watch 2.0 — Market Cap cache + weekly report + stale watchlist expiry.
 *
 * Активный сканирующий движок (CVD accumulation → breakout → smart cancel)
 * удалён как мёртвый код (2026-07-10, нет вызовов из scanner.ts/watcher.ts).
 * whale_futures_watchlist — актуальная замена.
 *
 * Market Cap: CoinGecko free API, кэш 24ч.
 * Fallback: если mcap недоступен — используем 24h Vol как прокси (порог от vol).
 */

import { db, whaleWatchlistTable, marketCapCacheTable } from "@workspace/db";
import { sql, gte } from "drizzle-orm";
import { logger } from "./logger.js";
import { reportApiSuccess, reportApiFailure } from "./apiHealth.js";
import { getNextCgKey } from "./coinglass_keys.js";

// ── Параметры ─────────────────────────────────────────────────────────────────
/** Expire watchlist entry after X hours with no accumulation */
const EXPIRE_HOURS = 24;

// ── Market Cap Cache (per-symbol, 6 hours in-memory / 7 days in DB) ───────────
const mcapCache = new Map<string, { mcap: number; ts: number }>();
const MCAP_CACHE_TTL = 6 * 60 * 60 * 1000; // 6 часов (in-memory TTL — MCap меняется медленно)
const MCAP_DB_TTL_MS = 7 * 24 * 60 * 60 * 1000; // 7 дней (DB TTL)

// ── CoinGlass batch cache ──────────────────────────────────────────────────────
// Источник: /api/futures/coins-markets (~79 futures-listed tokens).
// TTL 7h — дольше чем интервал preloader (6h), чтобы скан никогда не триггерил
// HTTP самостоятельно: данные всегда в памяти из scheduled refresh.
let cgBatchCache: { data: Map<string, number>; ts: number } | null = null;
const CG_BATCH_TTL = 7 * 60 * 60 * 1000; // 7 часов

// ── CoinGecko batch cache ──────────────────────────────────────────────────────
// Fallback 1: top-1000 coins by MCap (pages 1–4 × 250).
// Free API, no key. TTL 7h — только preloader обновляет, скан читает из памяти.
let cgeckoBatchCache: { data: Map<string, number>; ts: number } | null = null;
const CGECKO_BATCH_TTL = 7 * 60 * 60 * 1000; // 7 часов
// Cooldown после провала: не повторяем запрос 5 мин (safety net для ручных вызовов).
let cgeckoFailureCooldown = 0;
const CGECKO_FAILURE_COOLDOWN_MS = 5 * 60 * 1000;

// ── CoinPaprika batch cache ────────────────────────────────────────────────────
// Fallback 2: top-2000 coins (broader coverage of small/mid caps).
// Free API, no key. TTL 7h — только preloader обновляет, скан читает из памяти.
let cpaprikaBatchCache: { data: Map<string, number>; ts: number } | null = null;
const CPAPRIKA_BATCH_TTL = 7 * 60 * 60 * 1000; // 7 часов
// Cooldown после провала: не повторяем запрос 5 мин (safety net).
let cpaprikaFailureCooldown = 0;
const CPAPRIKA_FAILURE_COOLDOWN_MS = 5 * 60 * 1000;

// ── BingX ticker → canonical symbol aliases ────────────────────────────────────
// BingX uses non-standard tickers for some tokens that differ from CoinGecko/CoinPaprika.
// Map: BingX_BASE → lookup_symbol used in external APIs.
const SYMBOL_ALIASES: Record<string, string> = {
  TONCOIN: "TON", // The Open Network
  "1000000MOG": "MOG", // 1 million MOG contract → MOG MCap
  "1000PEPE": "PEPE", // 1000 PEPE contract → PEPE MCap
  "1000SHIB": "SHIB", // 1000 SHIB contract
  "1000FLOKI": "FLOKI", // 1000 FLOKI contract
  "1000BONK": "BONK", // 1000 BONK contract
  "1000XEC": "XEC",
  "1000BTT": "BTT",
  "1000LUNC": "LUNC",
  "1000NEIRO": "NEIRO",
  "100000AIDOGE": "AIDOGE",
  WBTC: "BTC", // Wrapped BTC → BTC MCap proxy
};

/**
 * CoinGecko fallback: top-1000 coins by MCap (free API, no key).
 * Fetches 4 pages × 250 = 1000 coins. Cache 1h.
 * Returns Map<UPPERCASE_SYMBOL → market_cap_usd>.
 * If a ticker has multiple coins, keeps the highest-MCap entry (page 1 wins).
 */
async function loadCoinGeckoMarketCaps(): Promise<Map<string, number>> {
  if (cgeckoBatchCache && Date.now() - cgeckoBatchCache.ts < CGECKO_BATCH_TTL) {
    return cgeckoBatchCache.data;
  }
  // Если недавно падал — не повторяем тяжёлый fetch, возвращаем стейл/пустой кэш мгновенно.
  if (Date.now() - cgeckoFailureCooldown < CGECKO_FAILURE_COOLDOWN_MS) {
    return cgeckoBatchCache?.data ?? new Map();
  }

  const map = new Map<string, number>();
  try {
    for (let page = 1; page <= 4; page++) {
      const res = await fetch(
        `https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=250&page=${page}`,
        {
          headers: { Accept: "application/json" },
          signal: AbortSignal.timeout(10000),
        },
      );
      if (!res.ok) {
        logger.warn(
          { page, status: res.status },
          "CoinGecko MCap: страница не загрузилась",
        );
        reportApiFailure("coingecko", res.status);
        cgeckoFailureCooldown = Date.now();
        break;
      }
      const data = (await res.json()) as Array<{
        symbol: string;
        market_cap: number | null;
      }>;
      for (const coin of data) {
        if (!coin.symbol || !coin.market_cap || coin.market_cap <= 0) continue;
        const sym = coin.symbol.toUpperCase();
        if (!map.has(sym)) map.set(sym, coin.market_cap); // page 1 = highest MCap wins for dupe symbols
      }
    }
    cgeckoBatchCache = { data: map, ts: Date.now() };
    cgeckoFailureCooldown = 0; // сброс cooldown при успехе
    logger.info(
      { symbols: map.size },
      "CoinGecko market caps loaded (fallback)",
    );
    if (map.size > 0) reportApiSuccess("coingecko");
  } catch (err) {
    logger.warn({ err }, "CoinGecko MCap batch fetch failed");
    reportApiFailure("coingecko");
    cgeckoFailureCooldown = Date.now(); // блокируем повторы на 5 мин
  }
  return map;
}

/**
 * CoinPaprika fallback 2: top-2000 coins ranked by MCap (free, no key).
 * Broader coverage than CoinGecko for small/mid caps.
 * Cache 1h — one HTTP call per hour.
 */
async function loadCoinPaprikaMarketCaps(): Promise<Map<string, number>> {
  if (
    cpaprikaBatchCache &&
    Date.now() - cpaprikaBatchCache.ts < CPAPRIKA_BATCH_TTL
  ) {
    return cpaprikaBatchCache.data;
  }
  // Если недавно падал — не повторяем тяжёлый fetch, возвращаем стейл/пустой кэш мгновенно.
  if (Date.now() - cpaprikaFailureCooldown < CPAPRIKA_FAILURE_COOLDOWN_MS) {
    return cpaprikaBatchCache?.data ?? new Map();
  }

  const map = new Map<string, number>();
  try {
    const res = await fetch(
      "https://api.coinpaprika.com/v1/tickers?quotes=USD&limit=5000",
      {
        headers: { Accept: "application/json" },
        signal: AbortSignal.timeout(20000),
      },
    );
    if (!res.ok) {
      logger.warn({ status: res.status }, "CoinPaprika MCap: ответ не 200");
      reportApiFailure("coinpaprika", res.status);
      cpaprikaFailureCooldown = Date.now();
      return cpaprikaBatchCache?.data ?? map;
    }
    const data = (await res.json()) as Array<{
      symbol: string;
      rank: number;
      quotes?: { USD?: { market_cap?: number } };
    }>;
    // Sort by rank (lowest = biggest cap) so duplicates: highest-ranked entry wins
    const sorted = [...data].sort(
      (a, b) => (a.rank || 9999) - (b.rank || 9999),
    );
    for (const coin of sorted) {
      if (!coin.symbol) continue;
      const mcap = coin.quotes?.USD?.market_cap;
      if (!mcap || mcap <= 0) continue;
      const sym = coin.symbol.toUpperCase();
      if (!map.has(sym)) map.set(sym, mcap);
    }
    cpaprikaBatchCache = { data: map, ts: Date.now() };
    cpaprikaFailureCooldown = 0; // сброс cooldown при успехе
    logger.info(
      { symbols: map.size },
      "CoinPaprika market caps loaded (fallback 2)",
    );
    reportApiSuccess("coinpaprika");
  } catch (err) {
    logger.warn({ err }, "CoinPaprika MCap batch fetch failed");
    reportApiFailure("coinpaprika");
    cpaprikaFailureCooldown = Date.now(); // блокируем повторы на 5 мин
    return cpaprikaBatchCache?.data ?? map;
  }
  return map;
}

/**
 * Загружает market cap для всех ~100 токенов одним запросом к CoinGlass.
 * Кешируется на 30 минут. Возвращает Map<base_symbol → market_cap_usd>.
 */
async function loadCoinGlassMarketCaps(): Promise<Map<string, number>> {
  if (cgBatchCache && Date.now() - cgBatchCache.ts < CG_BATCH_TTL) {
    return cgBatchCache.data;
  }

  const apiKey = getNextCgKey();
  if (!apiKey) return new Map();

  try {
    const res = await fetch(
      "https://open-api-v4.coinglass.com/api/futures/coins-markets",
      {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(10000),
      },
    );
    if (!res.ok) {
      logger.warn(
        { status: res.status },
        "CoinGlass MCap batch fetch failed (HTTP error)",
      );
      return cgBatchCache?.data ?? new Map();
    }

    const json = (await res.json()) as {
      code: string;
      msg?: string;
      data?: Array<{ symbol: string; market_cap_usd: number }>;
    };
    if (json.code !== "0" || !json.data) {
      logger.warn(
        { code: json.code, msg: json.msg },
        "CoinGlass MCap batch fetch failed (API error)",
      );
      return cgBatchCache?.data ?? new Map();
    }

    const map = new Map<string, number>();
    for (const item of json.data) {
      if (item.symbol && item.market_cap_usd > 0) {
        map.set(item.symbol.toUpperCase(), item.market_cap_usd);
      }
    }

    cgBatchCache = { data: map, ts: Date.now() };
    logger.info({ symbols: map.size }, "CoinGlass market caps loaded");
    return map;
  } catch {
    return cgBatchCache?.data ?? new Map();
  }
}

/**
 * Загружает MCap из DB в in-memory кэш при старте сервера.
 * Записи старше 7 дней игнорируются. Не перезаписывает уже заполненный кэш.
 * Экспортируется для вызова из watcher.ts до первого скан-цикла.
 */
export async function loadMarketCapFromDB(): Promise<void> {
  try {
    const cutoff = new Date(Date.now() - MCAP_DB_TTL_MS);
    const rows = await db
      .select()
      .from(marketCapCacheTable)
      .where(gte(marketCapCacheTable.updatedAt, cutoff));
    let loaded = 0;
    for (const row of rows) {
      if (!mcapCache.has(row.symbol)) {
        // ts = now → in-memory запись живёт стандартные 30 мин перед следующим API-refresh
        mcapCache.set(row.symbol, { mcap: row.mcapUsd, ts: Date.now() });
        loaded++;
      }
    }
    logger.info(
      { loaded, total: rows.length },
      "MarketCap DB cache loaded at startup",
    );
  } catch (err) {
    logger.warn(
      { err },
      "MarketCap DB cache load failed — продолжаем без персистентного кэша",
    );
  }
}

/**
 * Сохраняет успешно загруженные MCap в DB (upsert).
 * Только записи с mcapUsd > 0. Батч по 200 строк.
 */
async function persistMarketCapsToDB(
  source: string,
  map: Map<string, number>,
): Promise<void> {
  if (map.size === 0) return;
  try {
    const now = new Date();
    const rows = Array.from(map.entries())
      .filter(([, mcapUsd]) => mcapUsd > 0)
      .map(([symbol, mcapUsd]) => ({
        symbol,
        mcapUsd,
        source,
        updatedAt: now,
      }));
    const CHUNK = 200;
    for (let i = 0; i < rows.length; i += CHUNK) {
      await db
        .insert(marketCapCacheTable)
        .values(rows.slice(i, i + CHUNK))
        .onConflictDoUpdate({
          target: marketCapCacheTable.symbol,
          set: {
            mcapUsd: sql`excluded.mcap_usd`,
            source: sql`excluded.source`,
            updatedAt: sql`excluded.updated_at`,
          },
        });
    }
    logger.info({ source, count: rows.length }, "MarketCap persisted to DB");
  } catch (err) {
    logger.warn({ err, source }, "MarketCap DB persist failed — пропускаем");
  }
}

/**
 * Принудительно сбрасывает timestamp всех трёх MCap кэшей и перегружает их.
 * Вызывается preloader-ом при старте и каждые 6 часов.
 * При старте сначала загружает из DB — скан получит данные даже если все API упадут.
 * Cooldown'ы сбрасываются чтобы forced refresh всегда работал.
 */
async function forceReloadAllMarketCaps(): Promise<void> {
  // Загружаем персистентный кэш из DB прежде чем идти в API.
  // Это гарантирует: даже если все три API таймаутнут при старте,
  // скан-цикл получит MCap из DB (данные с прошлого запуска).
  await loadMarketCapFromDB();

  // Сброс timestamps → следующий вызов loader-а сделает HTTP-запрос
  if (cgBatchCache) cgBatchCache.ts = 0;
  if (cgeckoBatchCache) cgeckoBatchCache.ts = 0;
  if (cpaprikaBatchCache) cpaprikaBatchCache.ts = 0;
  cgeckoFailureCooldown = 0;
  cpaprikaFailureCooldown = 0;

  const [cg, cgecko, cpaprika] = await Promise.allSettled([
    loadCoinGlassMarketCaps(),
    loadCoinGeckoMarketCaps(),
    loadCoinPaprikaMarketCaps(),
  ]);

  const cgSize = cg.status === "fulfilled" ? cg.value.size : 0;
  const geckoSize = cgecko.status === "fulfilled" ? cgecko.value.size : 0;
  const papSize = cpaprika.status === "fulfilled" ? cpaprika.value.size : 0;
  logger.info({ cgSize, geckoSize, papSize }, "MarketCap preload complete");

  // Персистим успешные источники в DB параллельно (fire-and-forget, ошибки не критичны).
  const persistJobs: Promise<void>[] = [];
  if (cg.status === "fulfilled" && cg.value.size > 0)
    persistJobs.push(persistMarketCapsToDB("coinglass", cg.value));
  if (cgecko.status === "fulfilled" && cgecko.value.size > 0)
    persistJobs.push(persistMarketCapsToDB("coingecko", cgecko.value));
  if (cpaprika.status === "fulfilled" && cpaprika.value.size > 0)
    persistJobs.push(persistMarketCapsToDB("coinpaprika", cpaprika.value));
  void Promise.all(persistJobs);
}

/**
 * Запускает фоновый preloader MCap данных.
 * — Загружает все три источника сразу при старте бота.
 * — Обновляет каждые 6 часов по расписанию.
 * — Скан loop никогда не делает HTTP для MCap: только читает из кэша.
 */
export function startMarketCapPreloader(): void {
  const REFRESH_INTERVAL_MS = 6 * 60 * 60 * 1000; // 6 часов

  void forceReloadAllMarketCaps().catch((err) =>
    logger.warn({ err }, "MarketCap initial preload failed"),
  );

  setInterval(() => {
    void forceReloadAllMarketCaps().catch((err) =>
      logger.warn({ err }, "MarketCap scheduled refresh failed"),
    );
  }, REFRESH_INTERVAL_MS);
}

/**
 * Resolves a BingX base symbol to the canonical lookup symbol used in external MCap APIs.
 * Handles contracts like 1000PEPE → PEPE, TONCOIN → TON, etc.
 */
function resolveSymbol(base: string): string {
  return SYMBOL_ALIASES[base] ?? base;
}

/**
 * Ищет MCap по символу во всех трёх источниках (CoinGlass → CoinGecko → CoinPaprika).
 * Применяет алиасы (TONCOIN→TON, 1000PEPE→PEPE и т.д.) перед поиском.
 * Возвращает null если токен не найден ни в одном источнике.
 */
export async function fetchMarketCap(
  symbol: string,
): Promise<{ mcap: number; vol24h: number } | null> {
  const base = symbol.replace("-USDT", "").toUpperCase();
  const lookup = resolveSymbol(base);

  // Per-symbol cache keyed on original base (not alias, to avoid cross-contamination)
  const cached = mcapCache.get(base);
  if (cached && Date.now() - cached.ts < MCAP_CACHE_TTL) {
    return cached.mcap > 0 ? { mcap: cached.mcap, vol24h: 0 } : null; // mcap=0 — sentinel "не найдено"
  }

  // Load all three sources in parallel (each has its own internal cache)
  const [cglass, cgecko, cpaprika] = await Promise.all([
    loadCoinGlassMarketCaps(),
    loadCoinGeckoMarketCaps(),
    loadCoinPaprikaMarketCaps(),
  ]);

  const mcap =
    cglass.get(lookup) ?? // 1. CoinGlass (~79 major futures tokens)
    cgecko.get(lookup) ?? // 2. CoinGecko top-1000
    cpaprika.get(lookup) ?? // 3. CoinPaprika top-2000
    null;

  if (mcap) {
    const src = cglass.has(lookup)
      ? "CoinGlass"
      : cgecko.has(lookup)
        ? "CoinGecko"
        : "CoinPaprika";
    if (src !== "CoinGlass") {
      logger.debug(
        { symbol: base, lookup, mcap, src },
        "MCap via fallback source",
      );
    }
  }

  if (!mcap) {
    // Кэшируем отсутствие MCap на 5 мин — иначе каждый скан этого символа
    // снова триггерит batch-fetch всех трёх источников.
    // Используем mcap=0 как sentinel; при чтении mcap=0 → пропускаем (символ не найден).
    mcapCache.set(base, {
      mcap: 0,
      ts: Date.now() - (MCAP_CACHE_TTL - 5 * 60 * 1000),
    });
    return null;
  }

  mcapCache.set(base, { mcap, ts: Date.now() });
  return { mcap, vol24h: 0 };
}

/**
 * Батч market cap для списка символов.
 * Загружает все три источника параллельно (единый кеш), затем резолвит каждый символ.
 */
export async function batchFetchMarketCap(
  symbols: string[],
): Promise<Map<string, { mcap: number; vol24h: number } | null>> {
  const result = new Map<string, { mcap: number; vol24h: number } | null>();
  if (symbols.length === 0) return result;

  const [cglass, cgecko, cpaprika] = await Promise.all([
    loadCoinGlassMarketCaps(),
    loadCoinGeckoMarketCaps(),
    loadCoinPaprikaMarketCaps(),
  ]);

  for (const sym of symbols) {
    const base = sym.replace("-USDT", "").toUpperCase();
    const lookup = resolveSymbol(base);
    const mcap =
      cglass.get(lookup) ?? cgecko.get(lookup) ?? cpaprika.get(lookup) ?? null;
    result.set(sym, mcap ? { mcap, vol24h: 0 } : null);
  }

  return result;
}

// ── Expire stale watchlist entries ───────────────────────────────────────────

export async function expireStaleWatchlist(): Promise<void> {
  const cutoff = new Date(Date.now() - EXPIRE_HOURS * 60 * 60 * 1000);
  await db
    .update(whaleWatchlistTable)
    .set({ status: "expired", updatedAt: new Date() })
    .where(
      sql`status IN ('watching','accumulating') AND updated_at < ${cutoff}`,
    );
}

// ── Weekly Whale Report ───────────────────────────────────────────────────────

export interface WhaleWatchEntry {
  symbol: string;
  accumulatedCvdUsd: number;
  accumPeriods: number;
  avgBuyPrice: number | null;
  marketCapUsd: number | null;
  accumPct: number | null;
  priceAtEntry: number | null;
  lastPrice: number | null;
  firstSeenAt: Date;
  status: string;
}

export async function getWhaleWatchlist(): Promise<WhaleWatchEntry[]> {
  const rows = await db
    .select()
    .from(whaleWatchlistTable)
    .where(sql`status IN ('watching','accumulating','breakout')`)
    .orderBy(sql`accumulated_cvd_usd DESC`);

  return rows.map((r) => ({
    symbol: r.symbol,
    accumulatedCvdUsd: r.accumulatedCvdUsd,
    accumPeriods: r.accumPeriods,
    avgBuyPrice: r.avgBuyPrice ?? null,
    marketCapUsd: r.marketCapUsd ?? null,
    accumPct:
      r.marketCapUsd && r.marketCapUsd > 0
        ? (r.accumulatedCvdUsd / r.marketCapUsd) * 100
        : null,
    priceAtEntry: r.priceAtEntry ?? null,
    lastPrice: r.lastPrice ?? null,
    firstSeenAt: r.firstSeenAt,
    status: r.status,
  }));
}
