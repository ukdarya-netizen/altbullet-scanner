/**
 * Телеметрия латентности CoinGlass-запросов + лаг event loop.
 *
 * Цель — отличить «CoinGlass медленный» от «мы сами захлебнулись»:
 *  - cgTimedFetch() оборачивает fetch к CoinGlass, замеряет длительность каждой
 *    HTTP-попытки и классифицирует исход (ok / timeout / error).
 *  - monitorEventLoopDelay замеряет лаг event loop: если p95 лага велик (сотни мс),
 *    таймауты внешних API — следствие локальной перегрузки инстанса, а не API.
 *
 * Снапшот и сброс окна делает сканер в конце цикла (лог "Scan complete").
 * Диагностический модуль: никогда не бросает, при ошибке телеметрии просто молчит.
 */
import { monitorEventLoopDelay, type IntervalHistogram } from "node:perf_hooks";

const MAX_SAMPLES = 8000; // ~достаточно на самый длинный цикл; защита памяти

// ─── Concurrency limiter ───────────────────────────────────────────────────
// Ограничиваем одновременные CG-запросы: при 20+ параллельных fetch
// event loop блокируется очередью микрозадач → таймауты нарастают лавиной.
// 5 одновременных запросов = плавная нагрузка при runConcurrent(4) + джобы.
const MAX_CONCURRENT_CG = 5;
let _cgInFlight = 0;
const _cgWaiters: Array<() => void> = [];

function _acquireCgSlot(): Promise<void> {
  if (_cgInFlight < MAX_CONCURRENT_CG) {
    _cgInFlight++;
    return Promise.resolve();
  }
  return new Promise((resolve) =>
    _cgWaiters.push(() => {
      _cgInFlight++;
      resolve();
    }),
  );
}

function _releaseCgSlot(): void {
  _cgInFlight = Math.max(0, _cgInFlight - 1);
  const next = _cgWaiters.shift();
  if (next) next();
}

let durations: number[] = [];
let okCount = 0;
let timeoutCount = 0;
let errorCount = 0;
let windowStartedAt = Date.now();

let elHistogram: IntervalHistogram | null = null;
try {
  elHistogram = monitorEventLoopDelay({ resolution: 20 });
  elHistogram.enable();
} catch {
  elHistogram = null;
}

export type CgOutcome = "ok" | "timeout" | "error";

/** Записывает одну HTTP-попытку к CoinGlass. */
export function recordCgLatency(durationMs: number, outcome: CgOutcome): void {
  if (durations.length < MAX_SAMPLES) durations.push(durationMs);
  if (outcome === "ok") okCount++;
  else if (outcome === "timeout") timeoutCount++;
  else errorCount++;
}

/**
 * Обёртка вокруг fetch для CoinGlass-запросов: замеряет длительность попытки
 * и классифицирует исход. Поведение fetch не меняет — ошибки пробрасываются.
 */
export async function cgTimedFetch(
  url: string,
  init: RequestInit,
): Promise<Response> {
  await _acquireCgSlot();
  const t0 = Date.now();
  try {
    const res = await fetch(url, init);
    recordCgLatency(Date.now() - t0, res.ok ? "ok" : "error");
    return res;
  } catch (err) {
    const isTimeout =
      err instanceof Error &&
      (err.name === "TimeoutError" || err.name === "AbortError");
    recordCgLatency(Date.now() - t0, isTimeout ? "timeout" : "error");
    throw err;
  } finally {
    _releaseCgSlot();
  }
}

function percentile(sorted: number[], p: number): number {
  if (sorted.length === 0) return 0;
  const idx = Math.min(
    sorted.length - 1,
    Math.floor((p / 100) * sorted.length),
  );
  return sorted[idx];
}

export interface CgTelemetrySnapshot {
  /** Всего HTTP-попыток к CoinGlass за окно (по инструментированным модулям: OI + SpotCVD) */
  cgReq: number;
  cgOk: number;
  cgTimeouts: number;
  cgErrors: number;
  /** Доля таймаутов, % */
  cgTimeoutPct: number;
  cgP50Ms: number;
  cgP95Ms: number;
  cgMaxMs: number;
  /** Средний темп запросов за окно, req/min */
  cgReqPerMin: number;
  /** Лаг event loop за окно, мс (p50/p95/max). Здоровый p95 < 50мс. */
  elLagP50Ms: number;
  elLagP95Ms: number;
  elLagMaxMs: number;
  /** Длительность окна замера, мин */
  windowMin: number;
}

/** Возвращает статистику за окно с прошлого снапшота и начинает новое окно. */
export function snapshotCgTelemetry(): CgTelemetrySnapshot {
  const now = Date.now();
  const windowMs = Math.max(1, now - windowStartedAt);
  const sorted = [...durations].sort((a, b) => a - b);
  const total = okCount + timeoutCount + errorCount;

  const nsToMs = (v: number) => Math.round(v / 1e6);
  const snap: CgTelemetrySnapshot = {
    cgReq: total,
    cgOk: okCount,
    cgTimeouts: timeoutCount,
    cgErrors: errorCount,
    cgTimeoutPct: total > 0 ? Math.round((timeoutCount / total) * 100) : 0,
    cgP50Ms: percentile(sorted, 50),
    cgP95Ms: percentile(sorted, 95),
    cgMaxMs: sorted.length > 0 ? sorted[sorted.length - 1] : 0,
    cgReqPerMin: Math.round(total / (windowMs / 60000)),
    elLagP50Ms: elHistogram ? nsToMs(elHistogram.percentile(50)) : -1,
    elLagP95Ms: elHistogram ? nsToMs(elHistogram.percentile(95)) : -1,
    elLagMaxMs: elHistogram ? nsToMs(elHistogram.max) : -1,
    windowMin: +(windowMs / 60000).toFixed(1),
  };

  durations = [];
  okCount = 0;
  timeoutCount = 0;
  errorCount = 0;
  windowStartedAt = now;
  elHistogram?.reset();

  return snap;
}
