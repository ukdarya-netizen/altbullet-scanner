/**
 * Shared state: какие BingX-символы с whale_alert сигналами подтверждены
 * как "кит ещё держит позицию на Hyperliquid".
 *
 * Чистый state-модуль без внешних импортов — исключает циклические зависимости.
 * Обновляется из hl-position-tracker.ts; читается из telegram.ts.
 */

/** BingX символы где кит-триггер whale_alert подтверждён открытой позицией HL */
const _holdingBingxSymbols = new Set<string>();
let _lastUpdatedAt = 0;

/** Обновить множество "держащих" символов (вызывается из hl-position-tracker.ts). */
export function setWhaleHoldingState(symbols: Set<string>): void {
  _holdingBingxSymbols.clear();
  for (const s of symbols) _holdingBingxSymbols.add(s);
  _lastUpdatedAt = Date.now();
}

/**
 * Кит L11 по этому BingX символу ещё держит позицию на Hyperliquid?
 * null = ещё не было ни одного run трекера (нет данных).
 * Синхронный геттер — безопасно вызывать из telegram.ts formatAlphaSignal.
 */
export function isWhaleStillHolding(bingxSymbol: string): boolean | null {
  if (_lastUpdatedAt === 0) return null;
  return _holdingBingxSymbols.has(bingxSymbol);
}
