/**
 * HL Position Tracker — мониторинг позиций китов Hyperliquid после whale_alert fire.
 *
 * Запускается каждые 15 мин в prod-блоке index.ts.
 * Для каждого BingX-токена с активным whale_alert сигналом (status=active/in_run):
 *   • загружает текущие открытые позиции через CoinGlass /api/hyperliquid/whale-position
 *   • если кит (whaleAddress из whale_alert_pool) закрыл позицию → Telegram-алерт
 *
 * Синхронный геттер isWhaleStillHolding() экспортируется через whale-position-state.ts,
 * чтобы formatAlphaSignal в telegram.ts мог добавить «🐋 держит» без циклических импортов.
 *
 * Fail-open на все внешние запросы.
 */

import { logger } from "./logger.js";
import {
  db,
  trackedSignalsTable,
  whaleAlertPoolTable,
  whaleAlertWatchLogTable,
} from "@workspace/db";
import { eq, and, inArray, desc, sql } from "drizzle-orm";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";
import { sendMessageWithKeyboard, getTargets } from "./telegram.js";
import { tickerTag } from "./watcher-formatters.js";
import { setWhaleHoldingState } from "./whale-position-state.js";

// ── Types ─────────────────────────────────────────────────────────────────────

interface HlWhalePositionRaw {
  user?: string;
  symbol?: string;
  position_size?: number | string;
  entry_price?: number | string | null;
  position_value_usd?: number | string;
  liq_price?: number | string | null;
}

interface HlWhalePosition {
  user: string;
  hlSymbol: string;
  positionSize: number;
  positionValueUsd: number;
  entryPrice: number | null;
  liqPrice: number | null;
}

// ── State ─────────────────────────────────────────────────────────────────────

/** Символы уже оповещённые о закрытии позиции (дедуп по рестарту — in-memory) */
const _closedAlertedSymbols = new Set<string>();

/**
 * Per-whale cooldown: адрес кита → unix ms когда он закрыл позицию.
 * Используется в _runWhaleAlertFireCycle чтобы не стрелять повторно
 * по тому же киту в течение WHALE_FIRE_COOLDOWN_MS после закрытия.
 */
const _whaleCooldowns = new Map<string, number>();
const WHALE_FIRE_COOLDOWN_MS = 4 * 60 * 60 * 1000; // 4 часа

/** Проверить cooldown для адреса кита (возвращает true если кит на кулдауне). */
export function isWhaleOnCooldown(whaleAddress: string): boolean {
  const ts = _whaleCooldowns.get(whaleAddress.toLowerCase());
  if (ts === undefined) return false;
  if (Date.now() - ts < WHALE_FIRE_COOLDOWN_MS) return true;
  _whaleCooldowns.delete(whaleAddress.toLowerCase()); // TTL истёк — чистим
  return false;
}

let _positionsFetchedAt = 0;
let _lastPositions: HlWhalePosition[] = [];
let _running = false;

const POSITIONS_CACHE_TTL = 10 * 60 * 1000; // 10 мин

// ── Fetch ─────────────────────────────────────────────────────────────────────

async function fetchHlWhalePositions(): Promise<HlWhalePosition[] | null> {
  const now = Date.now();
  if (
    now - _positionsFetchedAt < POSITIONS_CACHE_TTL &&
    _positionsFetchedAt > 0
  ) {
    return _lastPositions;
  }

  const apiKey = getNextCgKey();
  if (!apiKey) return null;

  try {
    const res = await fetch(
      "https://open-api-v4.coinglass.com/api/hyperliquid/whale-position",
      {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(6000),
      },
    );

    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "hyperliquid/whale-position" });
      return null;
    }
    if (!res.ok) {
      logger.debug(
        { status: res.status },
        "fetchHlWhalePositions: HTTP error — fail-open",
      );
      return null;
    }

    const json = (await res.json()) as {
      code: string;
      data?: HlWhalePositionRaw[];
    };
    if (json.code !== "0" || !Array.isArray(json.data)) return null;

    const positions: HlWhalePosition[] = [];
    for (const r of json.data) {
      if (!r.user || !r.symbol) continue;
      const size = Number(r.position_size);
      const usd = Number(r.position_value_usd);
      if (!Number.isFinite(size) || !Number.isFinite(usd)) continue;
      if (size <= 0) continue; // только лонги
      positions.push({
        user: r.user.toLowerCase(),
        hlSymbol: String(r.symbol).toUpperCase(),
        positionSize: size,
        positionValueUsd: usd,
        entryPrice: Number.isFinite(Number(r.entry_price))
          ? Number(r.entry_price)
          : null,
        liqPrice: Number.isFinite(Number(r.liq_price))
          ? Number(r.liq_price)
          : null,
      });
    }

    _lastPositions = positions;
    _positionsFetchedAt = now;
    logger.debug(
      { count: positions.length },
      "HlPositionTracker: открытые позиции загружены",
    );
    return positions;
  } catch (err) {
    logger.debug(
      { err: String(err) },
      "fetchHlWhalePositions: fetch error — fail-open",
    );
    return null;
  }
}

// ── Main job ──────────────────────────────────────────────────────────────────

export async function runHlPositionTracker(): Promise<void> {
  if (_running) {
    logger.debug("HlPositionTracker: предыдущий цикл ещё идёт — пропуск");
    return;
  }
  _running = true;
  const t0 = Date.now();

  try {
    // 1. Загрузить все активные whale_alert сигналы (без ограничения по времени,
    //    чтобы не пропустить долгоживущие сигналы).
    let activeSignals: { id: number; symbol: string }[] = [];
    try {
      activeSignals = await db
        .select({
          id: trackedSignalsTable.id,
          symbol: trackedSignalsTable.symbol,
        })
        .from(trackedSignalsTable)
        .where(
          and(
            eq(trackedSignalsTable.sentimentKey, "whale_alert"),
            inArray(trackedSignalsTable.status, ["active", "in_run"]),
          ),
        );
    } catch (err) {
      logger.warn(
        { err },
        "HlPositionTracker: не удалось загрузить активные сигналы — пропуск",
      );
      return;
    }

    if (activeSignals.length === 0) {
      logger.debug("HlPositionTracker: нет активных whale_alert сигналов");
      setWhaleHoldingState(new Set());
      return;
    }

    const symbols = activeSignals.map((s) => s.symbol);

    // 2. Загрузить whale_address + hl_symbol из whale_alert_pool (fired/watching)
    let poolEntries: {
      id: number;
      symbol: string;
      hlSymbol: string;
      whaleAddress: string | null;
      totalWhaleUsd: number | null;
    }[] = [];
    try {
      // Только status='fired' — это записи которые реально выстрелили сигнал.
      // watching-записи не привязаны к активному tracked_signal и могут быть
      // совершенно другим китом. ORDER BY firedAt DESC NULLS LAST чтобы при
      // нескольких исторических fires на одном токене брался самый свежий.
      poolEntries = await db
        .select({
          id: whaleAlertPoolTable.id,
          symbol: whaleAlertPoolTable.symbol,
          hlSymbol: whaleAlertPoolTable.hlSymbol,
          whaleAddress: whaleAlertPoolTable.whaleAddress,
          totalWhaleUsd: whaleAlertPoolTable.totalWhaleUsd,
        })
        .from(whaleAlertPoolTable)
        .where(
          and(
            inArray(whaleAlertPoolTable.symbol, symbols),
            eq(whaleAlertPoolTable.status, "fired"),
          ),
        )
        .orderBy(
          sql`${whaleAlertPoolTable.firedAt} DESC NULLS LAST`,
          desc(whaleAlertPoolTable.detectedAt),
        );
    } catch (err) {
      logger.warn(
        { err },
        "HlPositionTracker: не удалось загрузить pool — fail-open",
      );
    }

    // Берём только первую (самую свежую) запись на символ
    const poolBySymbol = new Map<
      string,
      {
        id: number;
        hlSymbol: string;
        whaleAddress: string | null;
        totalWhaleUsd: number | null;
      }
    >();
    for (const p of poolEntries) {
      if (!poolBySymbol.has(p.symbol)) {
        poolBySymbol.set(p.symbol, {
          id: p.id,
          hlSymbol: p.hlSymbol,
          whaleAddress: p.whaleAddress,
          totalWhaleUsd: p.totalWhaleUsd,
        });
      }
    }

    // 3. Загрузить текущие открытые HL-позиции (кэш 10 мин)
    const positions = await fetchHlWhalePositions();
    if (positions === null) {
      logger.debug(
        "HlPositionTracker: позиции недоступны (fail-open) — сохраняем предыдущее состояние",
      );
      return; // не меняем holding-state — оставляем предыдущие данные
    }

    // Индекс: `${userAddress}:${hlSymbol}` → true
    const openIndex = new Set<string>();
    for (const p of positions) {
      openIndex.add(`${p.user}:${p.hlSymbol}`);
    }

    // 4. Обновить holding-state и отправить алерты о закрытиях
    const newHoldingSet = new Set<string>();
    const activeSet = new Set(symbols);

    for (const sig of activeSignals) {
      const pool = poolBySymbol.get(sig.symbol);
      if (!pool?.whaleAddress || !pool?.hlSymbol) continue;

      const key = `${pool.whaleAddress.toLowerCase()}:${pool.hlSymbol.toUpperCase()}`;
      const isHolding = openIndex.has(key);

      if (isHolding) {
        newHoldingSet.add(sig.symbol);
      } else if (!_closedAlertedSymbols.has(sig.symbol)) {
        // ── Атомарный claim через DB — дедуп между 2 worker-процессами ──────────
        // Меняем status fired→expired с RETURNING: только тот процесс,
        // который получил >0 строк, отправляет уведомление.
        let claimed = false;
        try {
          const rows = await db
            .update(whaleAlertPoolTable)
            .set({ status: "expired" })
            .where(
              and(
                eq(whaleAlertPoolTable.id, pool.id),
                eq(whaleAlertPoolTable.status, "fired"),
              ),
            )
            .returning({ id: whaleAlertPoolTable.id });
          claimed = rows.length > 0;
        } catch {
          claimed = true; // fail-open: DB недоступна — отправляем алерт
        }

        _closedAlertedSymbols.add(sig.symbol); // in-memory guard в любом случае

        // Записать cooldown по адресу кита — блокирует повторный fire на 4ч
        if (pool.whaleAddress) {
          _whaleCooldowns.set(pool.whaleAddress.toLowerCase(), Date.now());
        }

        if (claimed) {
          // Отменить tracked_signal — позиция-триггер закрыта китом
          try {
            await db
              .update(trackedSignalsTable)
              .set({
                status: "cancelled",
                cancelReason: "whale_position_closed",
                closedAt: new Date(),
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${sig.id} AND ${trackedSignalsTable.status} NOT IN ('cancelled','profit','stop_loss','breakeven','bu_stop')`,
              );
            logger.info(
              { symbol: sig.symbol, signalId: sig.id },
              "HlPositionTracker: tracked_signal отменён (whale_position_closed)",
            );
          } catch (dbErr) {
            logger.warn(
              { dbErr, symbol: sig.symbol },
              "HlPositionTracker: не удалось отменить tracked_signal — продолжаем",
            );
          }

          const base = sig.symbol.replace("-USDT", "");
          const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${sig.symbol.replace("-", "")}.P`;
          const usdLine =
            pool.totalWhaleUsd && pool.totalWhaleUsd > 0
              ? `\n💰 Позиция кита: <b>$${(pool.totalWhaleUsd / 1e6).toFixed(1)}m</b>`
              : "";
          const msg = [
            `🐋 <b>Кит L11 закрыл лонг: ${base}</b>`,
            ``,
            `Кит Hyperliquid закрыл позицию по <b>${base}</b>.`,
            `Сигнал whale_alert <b>автоматически отменён</b>.${usdLine}`,
            ``,
            `${tickerTag(sig.symbol)} #whale_alert #position_closed`,
          ].join("\n");
          const keyboard = [[{ text: `📊 ${base} TradingView`, url: tvUrl }]];
          try {
            const targets = await getTargets();
            for (const chatId of targets) {
              await sendMessageWithKeyboard(chatId, msg, keyboard);
            }
            logger.info(
              {
                symbol: sig.symbol,
                hlSymbol: pool.hlSymbol,
                addr: pool.whaleAddress.slice(0, 8) + "…",
              },
              "🐋 HlPositionTracker: кит закрыл позицию → Telegram-алерт отправлен",
            );
          } catch (err) {
            logger.warn(
              { err, symbol: sig.symbol },
              "HlPositionTracker: Telegram-алерт не удался",
            );
          }
          // Записать закрытие в whale_alert_watch_log (аудит-трейл)
          try {
            await db.insert(whaleAlertWatchLogTable).values({
              poolId: pool.id,
              symbol: sig.symbol,
            });
          } catch (dbErr) {
            logger.debug(
              { dbErr, symbol: sig.symbol },
              "HlPositionTracker: watch_log INSERT не удался (некритично)",
            );
          }
        } else {
          logger.debug(
            { symbol: sig.symbol },
            "HlPositionTracker: другой процесс уже отправил алерт — пропуск",
          );
        }
      }
    }

    // ── Cleanup: отменяем tracked_signals где кит уже закрыл позицию (pool=expired) ──
    // Нужно для сигналов которые были активны до внедрения автоотмены (e.g. HYPE).
    // Без алерта — он уже был отправлен ранее. Просто закрываем застрявший сигнал.
    if (symbols.length > 0) {
      try {
        const expiredInPool = await db
          .select({ symbol: whaleAlertPoolTable.symbol })
          .from(whaleAlertPoolTable)
          .where(
            and(
              inArray(whaleAlertPoolTable.symbol, symbols),
              eq(whaleAlertPoolTable.status, "expired"),
            ),
          );

        if (expiredInPool.length > 0) {
          const expiredSymbols = new Set(expiredInPool.map((e) => e.symbol));
          const toCancel = activeSignals.filter((s) =>
            expiredSymbols.has(s.symbol),
          );
          for (const sig of toCancel) {
            await db
              .update(trackedSignalsTable)
              .set({
                status: "cancelled",
                cancelReason: "whale_position_closed",
                closedAt: new Date(),
                updatedAt: new Date(),
              })
              .where(
                sql`${trackedSignalsTable.id} = ${sig.id} AND ${trackedSignalsTable.status} NOT IN ('cancelled','profit','stop_loss','breakeven','bu_stop')`,
              );
            logger.info(
              { symbol: sig.symbol, signalId: sig.id },
              "HlPositionTracker: cleanup — закрыт застрявший whale_alert сигнал (pool=expired)",
            );
          }
        }
      } catch (err) {
        logger.warn(
          { err },
          "HlPositionTracker: cleanup expired signals failed (некритично)",
        );
      }
    }

    // Чистим closed-дедуп от символов без активных сигналов
    for (const sym of _closedAlertedSymbols) {
      if (!activeSet.has(sym)) _closedAlertedSymbols.delete(sym);
    }

    setWhaleHoldingState(newHoldingSet);

    const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
    logger.info(
      {
        activeSignals: activeSignals.length,
        holding: newHoldingSet.size,
        openPositions: positions.length,
        elapsed: `${elapsed}s`,
      },
      "HlPositionTracker: цикл завершён",
    );
  } finally {
    _running = false;
  }
}
