// ── Canonical pattern label map ───────────────────────────────────────────────
// Single source of truth for all pattern display names (backend).
// Frontend mirror: artifacts/alpha-scanner/src/lib/pattern-labels.ts
// Format: {emoji} {Русское название} · {English name} #{sentimentKey}
// Both files must stay in sync — update both when adding/changing patterns.

export const PATTERN_LABELS: Record<string, string> = {
  // ── Активные паттерны ──────────────────────────────────────────────────────
  trend_accumulation:
    "📈🔥 Фьюч трендовое накопление · Futures Trend Accum #trend_accumulation",
  bullish_accumulation:
    "📊 Бычье накопление · Bullish Accum #bullish_accumulation",
  spot_vol_accumulation:
    "📊🌊 Спот объём накопление · Spot Vol Accum #spot_vol_accumulation",
  whale_alert: "🐋🎯 Кит открыл лонг · Whale Alert #whale_alert",
  whale_futures: "🐳 Накопление кита · Whale Futures #whale_futures",
  "4h_pullback_continuation":
    "🔻📈 Коррекция в тренде · 4H Pullback Continuation #4h_pullback_continuation",
  price_led_momentum: "🟡 Цена без OI · Price-Led Momentum #price_led_momentum",
  balanced_grind: "🟢 Умеренный широкий рост · Balanced Grind #balanced_grind",
  stealth_breakout:
    "⚪ Пробой из тихой зоны · Stealth Breakout #stealth_breakout",
  demark: "🕯 ДеМарк TD9 разворот · Demark TD9 Buy Setup #demark",
  liquidation_cascade:
    "💥🔄 Каскад ликвидаций · Liquidation Cascade #liquidation_cascade",
  liquidation_cascade_bg:
    "💥🔄 Каскад ликвидаций [L10·фон] · Liq Cascade Job #liquidation_cascade_bg",
};

export function getPatternLabel(key: string | null | undefined): string {
  if (!key) return "—";
  return PATTERN_LABELS[key] ?? key;
}

/** Short label for Telegram — strips " #hashtag" suffix, keeps "emoji RU · EN" */
export function getPatternTgLabel(key: string | null | undefined): string {
  if (!key) return "—";
  const full = PATTERN_LABELS[key] ?? key;
  return full.split(" #")[0];
}
