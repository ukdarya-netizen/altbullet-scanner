/**
 * CoinGlass — Hyperliquid Long/Short Account Ratio by Tag.
 *
 * Endpoint: GET /api/hyperliquid/long-short-account-ratio-by-tag/history
 *   ?symbol=BTC&interval=1h&limit=1
 *
 * Метаданные:
 *   tag = "verified"   → smart money (верифицированные трейдеры)
 *   tag = "unverified" → retail (розница, неверифицированные)
 *
 * Паттерн smart_money_divergence:
 *   - smartMoneyLongPct ≥ 60% (верифицированные в основном лонге)
 *   - retailLongPct ≤ 40% (розница в основном шорте, ≥ 60% шорт)
 *   → дивергенция = умные деньги vs розница → потенциальный шорт-сквиз
 *
 * Кэш: 5 мин per symbol.
 * Fail-open: null при любой ошибке.
 */

import { logger } from "./logger.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";

export interface HlLsTagResult {
  /** Доля лонгов у верифицированных трейдеров (smart money), 0–100 */
  smartMoneyLongPct: number;
  /** Доля лонгов у неверифицированных (retail), 0–100 */
  retailLongPct: number;
  /** Доля шортов у retail = 100 - retailLongPct */
  retailShortPct: number;
}

interface RawTagRow {
  tag?: string;
  long_account?: number | string;
  short_account?: number | string;
  long_account_ratio?: number | string;
  short_account_ratio?: number | string;
}

interface RawHistoryItem {
  timestamp?: number;
  data?: RawTagRow[];
}

const CACHE_TTL = 5 * 60 * 1000; // 5 мин

const _cache = new Map<string, { data: HlLsTagResult | null; ts: number }>();

/**
 * Получить Long/Short Account Ratio by Tag (Hyperliquid) для символа.
 * Fail-open: null при любой ошибке или отсутствии данных.
 */
export async function getHlLsTagRatio(
  symbol: string,
): Promise<HlLsTagResult | null> {
  const cached = _cache.get(symbol);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.data;

  const base = symbol.replace("-USDT", "").replace(/^1000/, "");
  const apiKey = getNextCgKey();
  if (!apiKey) return null;

  try {
    const url = `https://open-api-v4.coinglass.com/api/hyperliquid/long-short-account-ratio-by-tag/history?symbol=${encodeURIComponent(base)}&interval=1h&limit=1`;
    const res = await fetch(url, {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(5000),
    });

    if (res.status === 429) {
      logCg429(apiKey, {
        endpoint: "hyperliquid/long-short-account-ratio-by-tag/history",
        symbol: base,
      });
      return null;
    }
    if (!res.ok) {
      logger.debug(
        { status: res.status, symbol: base },
        "getHlLsTagRatio: HTTP error — fail-open",
      );
      const result = null;
      _cache.set(symbol, { data: result, ts: Date.now() });
      return result;
    }

    const json = (await res.json()) as {
      code?: string;
      data?: RawHistoryItem[];
    };
    if (
      json.code !== "0" ||
      !Array.isArray(json.data) ||
      json.data.length === 0
    ) {
      _cache.set(symbol, { data: null, ts: Date.now() });
      return null;
    }

    // Берём последнюю точку (limit=1)
    const latest = json.data[json.data.length - 1];
    const rows: RawTagRow[] = Array.isArray(latest?.data) ? latest.data : [];

    let smartMoneyLongPct: number | null = null;
    let retailLongPct: number | null = null;

    for (const row of rows) {
      const tag = (row.tag ?? "").toLowerCase();
      // Соотношение: long_account_ratio (0–1) или long_account (%) — нужно нормализовать
      const rawLong = Number(row.long_account_ratio ?? row.long_account ?? 0);
      if (!Number.isFinite(rawLong)) continue;
      // Если значение в диапазоне 0–1, переводим в %
      const longPct = rawLong <= 1 ? rawLong * 100 : rawLong;

      if (tag === "verified") smartMoneyLongPct = longPct;
      if (tag === "unverified") retailLongPct = longPct;
    }

    if (smartMoneyLongPct === null || retailLongPct === null) {
      _cache.set(symbol, { data: null, ts: Date.now() });
      return null;
    }

    const result: HlLsTagResult = {
      smartMoneyLongPct,
      retailLongPct,
      retailShortPct: 100 - retailLongPct,
    };

    _cache.set(symbol, { data: result, ts: Date.now() });
    return result;
  } catch (err) {
    logger.debug(
      { err: String(err), symbol: base },
      "getHlLsTagRatio: fetch error — fail-open",
    );
    return null;
  }
}
