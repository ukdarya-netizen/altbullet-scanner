/**
 * CoinGlass — Futures vs Spot Volume.
 *
 * PRIMARY: GET /api/futures_spot_volume_ratio
 *   exchange_list: "Binance,OKX,Bybit" (top-3 by volume, required param)
 *   interval: "1h", limit: 24  →  rolling 24h totals (sum of last 24 hourly candles)
 *   Returns: futVolUsd24h + spotVolUsd24h aggregated across all three exchanges.
 *   Fails (code=500) for BingX-exclusive tokens not listed on those exchanges.
 *
 * SPOT FALLBACK: GET /api/spot/taker-buy-sell-volume/history
 *   Used when primary returns spotVolUsd24h=null (token not on Binance/OKX/Bybit spot,
 *   OR futures_spot_volume_ratio has no spot data for that symbol).
 *   Tries Binance → OKX → Bybit → Bitget in order; first non-zero result wins.
 *   Sums taker_buy_volume_usd + taker_sell_volume_usd over last 24 × 1h candles.
 *
 * Caches: 30 min positive. Negative: 2h for main endpoint code≠0 / empty.
 *         Spot fallback has its own 2h negative cache per symbol.
 *
 * Available on Professional plan (open-api-v4.coinglass.com, CG-API-KEY header).
 */

import { logger } from "./logger.js";
import { reportApiSuccess, reportApiFailure } from "./apiHealth.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";

export interface FsVolumeResult {
  available: boolean;
  futVolUsd24h: number | null; // Futures 24h volume USD (sum last 24×1h candles)
  spotVolUsd24h: number | null; // Spot 24h volume USD (primary or fallback)
  futSpotRatio: number | null; // futVolUsd24h / spotVolUsd24h
}

const CACHE_TTL = 30 * 60 * 1000; // 30 min positive cache
const NEGATIVE_TTL = 2 * 60 * 60 * 1000; // 2h negative cache (was 24h — retries sooner)
const SPOT_NEG_TTL = 2 * 60 * 60 * 1000; // 2h negative for spot fallback
const EXCHANGE_LIST = "Binance,OKX,Bybit";
const INTERVAL = "1h";
const LIMIT = 24; // last 24 × 1h candles = rolling 24h

// Spot fallback: try these exchanges in order until one returns data
const SPOT_EXCHANGES = ["Binance", "OKX", "Bybit", "Bitget"] as const;

const cache = new Map<string, { result: FsVolumeResult; ts: number }>();
const negativeCache = new Map<string, number>(); // symbol → expiry (main endpoint)
const spotNegCache = new Map<string, number>(); // symbol → expiry (spot fallback)

// ── Concurrency limiter (max 8 parallel requests) ─────────────────────────────
const MAX_CONCURRENT = 8;
let activeRequests = 0;
const semaphoreQueue: Array<() => void> = [];

function acquireSemaphore(): Promise<void> {
  return new Promise((resolve) => {
    if (activeRequests < MAX_CONCURRENT) {
      activeRequests++;
      resolve();
    } else {
      semaphoreQueue.push(() => {
        activeRequests++;
        resolve();
      });
    }
  });
}

function releaseSemaphore(): void {
  activeRequests--;
  const next = semaphoreQueue.shift();
  if (next) next();
}

/**
 * Strip BingX suffix/multiplier to get CoinGlass base symbol.
 * Examples: "1000PEPE-USDT" → "PEPE", "BTC-USDT" → "BTC"
 */
function toFsSymbol(bingxSymbol: string): string {
  const base = bingxSymbol.replace(/-USDT$/, "");
  return base.replace(/^(1000000|100000|10000|1000)(?=[A-Z])/, "");
}

interface FsCandle {
  time: number;
  futures_spot_vol_ratio: number;
  futures_vol_usd: number;
  spot_vol_usd: number;
}

interface SpotTakerCandle {
  time: number;
  taker_buy_volume_usd: string;
  taker_sell_volume_usd: string;
}

/**
 * Spot volume fallback via /api/spot/taker-buy-sell-volume/history.
 * Tries Binance → OKX → Bybit → Bitget; returns total spot vol USD for 24h or null.
 * Symbol format: CoinGlass base (e.g. "BTC") → "BTCUSDT" for the exchange query.
 */
async function fetchSpotTakerVol24h(
  cgSymbol: string,
  bingxSymbol: string,
): Promise<number | null> {
  const negExpiry = spotNegCache.get(bingxSymbol);
  if (negExpiry && Date.now() < negExpiry) return null;

  const spotSymbol = cgSymbol + "USDT"; // "BTC" → "BTCUSDT"

  for (const exchange of SPOT_EXCHANGES) {
    const apiKey = getNextCgKey();
    if (!apiKey) return null;

    await acquireSemaphore();
    try {
      const url = new URL(
        "https://open-api-v4.coinglass.com/api/spot/taker-buy-sell-volume/history",
      );
      url.searchParams.set("exchange", exchange);
      url.searchParams.set("symbol", spotSymbol);
      url.searchParams.set("interval", INTERVAL);
      url.searchParams.set("limit", String(LIMIT));

      const res = await fetch(url.toString(), {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(6000),
      });

      if (res.status === 429) {
        logCg429(apiKey, {
          symbol: cgSymbol,
          endpoint: "spot/taker-buy-sell-volume/history",
          exchange,
        });
        reportApiFailure("coinglass", 429);
        continue;
      }
      if (!res.ok) continue;

      const body = (await res.json()) as {
        code: string;
        msg?: string;
        data?: SpotTakerCandle[];
      };
      if (body.code !== "0" || !body.data?.length) continue;

      let total = 0;
      for (const candle of body.data) {
        total +=
          Number(candle.taker_buy_volume_usd ?? 0) +
          Number(candle.taker_sell_volume_usd ?? 0);
      }

      if (total > 0) {
        logger.debug(
          { symbol: cgSymbol, exchange, spotVol24h: total },
          "CG FsVol spot fallback: данные получены",
        );
        reportApiSuccess("coinglass");
        return total;
      }
    } catch {
      // try next exchange
    } finally {
      releaseSemaphore();
    }
  }

  // All exchanges failed — negative cache 2h
  spotNegCache.set(bingxSymbol, Date.now() + SPOT_NEG_TTL);
  logger.debug(
    { symbol: cgSymbol },
    "CG FsVol spot fallback: нет данных ни на одной бирже — neg cache 2h",
  );
  return null;
}

/**
 * Fetch rolling 24h futures + spot trading volume for a BingX-format symbol.
 *
 * Primary: aggregated across Binance, OKX, Bybit via futures_spot_volume_ratio.
 * Spot fallback: /api/spot/taker-buy-sell-volume/history (Binance→OKX→Bybit→Bitget)
 *   — used when primary returns spotVolUsd24h=null (BingX-exclusive or no spot data).
 *
 * Result cached 30 minutes per symbol.
 */
export async function getFsVolume(
  bingxSymbol: string,
): Promise<FsVolumeResult> {
  const cached = cache.get(bingxSymbol);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.result;

  const symbol = toFsSymbol(bingxSymbol);

  let futVolUsd24h: number | null = null;
  let spotVolUsd24h: number | null = null;
  let mainAvailable = false;

  // ── Primary: futures_spot_volume_ratio ──────────────────────────────────────
  const negExpiry = negativeCache.get(bingxSymbol);
  const mainSkipped = negExpiry != null && Date.now() < negExpiry;

  if (!mainSkipped) {
    const apiKey = getNextCgKey();
    if (apiKey) {
      const url = new URL(
        "https://open-api-v4.coinglass.com/api/futures_spot_volume_ratio",
      );
      url.searchParams.set("exchange_list", EXCHANGE_LIST);
      url.searchParams.set("symbol", symbol);
      url.searchParams.set("interval", INTERVAL);
      url.searchParams.set("limit", String(LIMIT));

      await acquireSemaphore();
      try {
        const res = await fetch(url.toString(), {
          headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
          signal: AbortSignal.timeout(8000),
        });

        if (res.status === 429) {
          logCg429(apiKey, { symbol, endpoint: "futures_spot_volume_ratio" });
          reportApiFailure("coinglass", 429);
        } else if (res.ok) {
          const body = (await res.json()) as {
            code: string;
            msg?: string;
            data?: FsCandle[];
          };
          if (body.code === "0" && body.data?.length) {
            let futTotal = 0;
            let spotTotal = 0;
            for (const candle of body.data) {
              futTotal += Number(candle.futures_vol_usd ?? 0);
              spotTotal += Number(candle.spot_vol_usd ?? 0);
            }
            futVolUsd24h = futTotal > 0 ? futTotal : null;
            spotVolUsd24h = spotTotal > 0 ? spotTotal : null;
            mainAvailable = true;
            reportApiSuccess("coinglass");
          } else if (body.code === "500" || !body.data?.length) {
            // Symbol not found on Binance/OKX/Bybit — neg cache 2h then retry
            negativeCache.set(bingxSymbol, Date.now() + NEGATIVE_TTL);
            logger.debug(
              { symbol },
              "CG FsVol: symbol not found on primary exchanges — neg cache 2h",
            );
          } else {
            logger.warn(
              { symbol, code: body.code, msg: body.msg },
              "CG FsVol: API error on primary",
            );
          }
        } else {
          logger.debug(
            { symbol, status: res.status },
            "CG FsVol: non-OK response on primary",
          );
        }
      } catch {
        logger.debug({ symbol }, "CG FsVol: fetch error on primary");
      } finally {
        releaseSemaphore();
      }
    }
  }

  // ── Spot fallback: taker-buy-sell-volume/history ─────────────────────────────
  // Runs whenever spotVolUsd24h is null — regardless of whether primary succeeded.
  // Covers: BingX-exclusive (no Binance/OKX/Bybit listing) AND tokens where the
  // primary endpoint returns futures data but spot_vol_usd=0 in all candles.
  if (spotVolUsd24h == null) {
    spotVolUsd24h = await fetchSpotTakerVol24h(symbol, bingxSymbol);
  }

  const available = mainAvailable || spotVolUsd24h != null;
  const futSpotRatio =
    futVolUsd24h && spotVolUsd24h ? futVolUsd24h / spotVolUsd24h : null;
  const result: FsVolumeResult = {
    available,
    futVolUsd24h,
    spotVolUsd24h,
    futSpotRatio,
  };

  if (available) {
    cache.set(bingxSymbol, { result, ts: Date.now() });
  }
  return result;
}

/** Invalidate per-symbol cache (e.g. after forced refresh). */
export function clearFsVolumeCache(bingxSymbol: string): void {
  cache.delete(bingxSymbol);
  negativeCache.delete(bingxSymbol);
  spotNegCache.delete(bingxSymbol);
}
