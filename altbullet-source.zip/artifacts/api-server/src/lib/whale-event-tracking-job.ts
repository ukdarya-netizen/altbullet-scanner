/**
 * Whale Event Tracking Job — Part 2 (forward accumulation).
 *
 * Два режима:
 * 1. saveWhaleEventT0(payload) — вызывается из whale-alert-job.ts
 *    при каждом новом ките ≥$500K. Сохраняет T0 checkpoint.
 * 2. runWhaleEventCheckpointJob() — запускается каждые 15 мин.
 *    Находит события без следующего чекпоинта и заполняет T+1h/.../T+48h.
 *
 * Данные идут в whale_event_tracking (создаётся в runStartupMigration).
 */

import { logger } from "./logger.js";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { getFutureTicker } from "./bingx.js";
import { dbWriteBestEffort } from "./dbWriteFast.js";

const CHECKPOINT_OFFSETS_MS: Record<string, number> = {
  T0: 0,
  "T+1h": 1 * 60 * 60 * 1000,
  "T+4h": 4 * 60 * 60 * 1000,
  "T+12h": 12 * 60 * 60 * 1000,
  "T+24h": 24 * 60 * 60 * 1000,
  "T+48h": 48 * 60 * 60 * 1000,
};
const CHECKPOINT_LABELS = Object.keys(CHECKPOINT_OFFSETS_MS);

export interface WhaleEventPayload {
  eventId: string;
  userAddress: string;
  symbol: string;
  positionAction: number;
  positionValueUsd: number;
  entryPrice: number | null;
  eventTimeMs: number;
}

export async function saveWhaleEventT0(
  payload: WhaleEventPayload,
): Promise<void> {
  try {
    await db.execute(sql`
      INSERT INTO whale_event_tracking
        (event_id, user_address, symbol, position_action, position_value_usd,
         entry_price, event_time, checkpoint_label, checkpoint_at, price_at_checkpoint)
      VALUES
        (${payload.eventId}, ${payload.userAddress}, ${payload.symbol},
         ${payload.positionAction}, ${payload.positionValueUsd},
         ${payload.entryPrice}, ${payload.eventTimeMs},
         'T0', NOW(), ${payload.entryPrice})
      ON CONFLICT (event_id, checkpoint_label) DO NOTHING
    `);
    logger.info(
      { symbol: payload.symbol, eventId: payload.eventId },
      "WhaleEventTracking: T0 saved",
    );
  } catch (err) {
    logger.warn(
      { err, symbol: payload.symbol },
      "WhaleEventTracking: T0 save failed",
    );
  }
}

export async function runWhaleEventCheckpointJob(): Promise<void> {
  try {
    const nowMs = Date.now();
    const cutoffMs = nowMs - 49 * 60 * 60 * 1000;

    const result = await db.execute(sql`
      SELECT DISTINCT ON (event_id)
        event_id, symbol, entry_price, event_time, checkpoint_label
      FROM whale_event_tracking
      WHERE event_time > ${cutoffMs}
      ORDER BY event_id, checkpoint_at DESC
    `);

    type Row = {
      event_id: string;
      symbol: string;
      entry_price: number | null;
      event_time: number;
      checkpoint_label: string;
    };
    const rows = result.rows as Row[];
    if (!rows.length) return;

    let written = 0;
    for (const row of rows) {
      const lastIdx = CHECKPOINT_LABELS.indexOf(row.checkpoint_label);
      if (lastIdx < 0 || lastIdx === CHECKPOINT_LABELS.length - 1) continue;

      const nextLabel = CHECKPOINT_LABELS[lastIdx + 1];
      const nextOffset = CHECKPOINT_OFFSETS_MS[nextLabel];
      const nextDueMs = Number(row.event_time) + nextOffset;
      if (nextDueMs > nowMs) continue;

      let price: number | null = null;
      try {
        const ticker = await getFutureTicker(row.symbol);
        price = ticker ? parseFloat(ticker.lastPrice) : null;
      } catch {
        /* fail-open */
      }

      const priceChangePct =
        price != null && row.entry_price != null && row.entry_price !== 0
          ? ((price - row.entry_price) / row.entry_price) * 100
          : null;

      await dbWriteBestEffort("WhaleEventCheckpoint", () =>
        db.execute(sql`
        INSERT INTO whale_event_tracking
          (event_id, user_address, symbol, position_action, position_value_usd,
           entry_price, event_time, checkpoint_label, checkpoint_at,
           price_at_checkpoint, price_change_pct)
        SELECT event_id, user_address, symbol, position_action, position_value_usd,
               entry_price, event_time,
               ${nextLabel}, NOW(), ${price}, ${priceChangePct}
        FROM whale_event_tracking
        WHERE event_id = ${row.event_id}
        LIMIT 1
        ON CONFLICT (event_id, checkpoint_label) DO NOTHING
      `),
      );
      written++;
    }

    if (written > 0)
      logger.info({ written }, "WhaleEventCheckpointJob: checkpoints written");
  } catch (err) {
    logger.warn({ err }, "WhaleEventCheckpointJob: error");
  }
}
