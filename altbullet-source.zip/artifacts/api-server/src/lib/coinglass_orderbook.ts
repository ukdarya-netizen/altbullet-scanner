/**
 * CoinGlass — агрегированный стакан фьючерсов.
 *
 * Endpoint: GET /api/futures/orderbook/ask-bids-history
 *   ?symbol=BTCUSDT&exchange=Binance&interval=1h&limit=1
 * Header: CG-API-KEY
 *
 * Возвращает суммарный объём bid/ask за последний 1h бар на Binance —
 * крупнейшей фьючерсной бирже, задающей ценовой ориентир.
 * Если Binance возвращает null или объём слишком мал (< $50K) → пробуем Bybit.
 *
 * bidAskRatio = bids_usd / asks_usd
 *   ≥ 1.3 → strong_bull (+2 к alpha score)
 *   ≥ 1.1 → bull        (+1)
 *   < 0.9 → bear        (0)
 *   иначе → neutral     (0)
 */

import { logger } from "./logger.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";

export interface CgAskBidsResult {
  bidAskRatio: number;
  bidsUsd: number;
  asksUsd: number;
  bias: "strong_bull" | "bull" | "neutral" | "bear";
  scoreBonus: number;
  exchange?: "Binance" | "Bybit";
}

const CG_BASE = "https://open-api-v4.coinglass.com";
const MIN_LIQUIDITY_USD = 50_000;

function deriveBias(ratio: number): CgAskBidsResult["bias"] {
  if (ratio >= 1.3) return "strong_bull";
  if (ratio >= 1.1) return "bull";
  if (ratio < 0.9) return "bear";
  return "neutral";
}

function deriveBonus(bias: CgAskBidsResult["bias"]): number {
  if (bias === "strong_bull") return 2;
  if (bias === "bull") return 1;
  return 0;
}

/**
 * Fetch order book for one exchange. Returns null if unavailable or liquidity too low.
 */
async function fetchOrderbook(
  cgPair: string,
  exchange: "Binance" | "Bybit",
  key: string,
): Promise<CgAskBidsResult | null> {
  try {
    const url = `${CG_BASE}/api/futures/orderbook/ask-bids-history?symbol=${cgPair}&exchange=${exchange}&interval=1h&limit=1`;
    const res = await fetch(url, {
      headers: { "CG-API-KEY": key },
      signal: AbortSignal.timeout(4000),
    });
    if (res.status === 429) {
      logCg429(key, { symbol: cgPair, exchange });
      return null;
    }
    if (!res.ok) return null;

    const json = (await res.json()) as {
      code: string;
      data?: Array<{ bids_usd: number; asks_usd: number; time: number }>;
    };

    if (json.code !== "0" || !json.data?.length) return null;

    const row = json.data[0];
    const bidsUsd = row.bids_usd ?? 0;
    const asksUsd = row.asks_usd ?? 0;
    if (asksUsd === 0) return null;
    if (bidsUsd + asksUsd < MIN_LIQUIDITY_USD) return null;

    const bidAskRatio = bidsUsd / asksUsd;
    const bias = deriveBias(bidAskRatio);
    const scoreBonus = deriveBonus(bias);

    return { bidAskRatio, bidsUsd, asksUsd, bias, scoreBonus, exchange };
  } catch {
    return null;
  }
}

/**
 * @param bingxSymbol — формат BingX: "BTC-USDT", "SOL-USDT" и т.д.
 */
export async function getCgAskBids(
  bingxSymbol: string,
): Promise<CgAskBidsResult | null> {
  const key = getNextCgKey();
  if (!key) return null;

  const cgPair = bingxSymbol.replace("-", "");

  const binance = await fetchOrderbook(cgPair, "Binance", key);
  if (binance) return binance;

  // Binance нет данных или ликвидность слишком низкая → fallback на Bybit
  logger.debug(
    { symbol: bingxSymbol },
    "getCgAskBids: Binance нет данных — fallback Bybit",
  );
  const bybit = await fetchOrderbook(cgPair, "Bybit", key);
  if (bybit) return bybit;

  logger.warn(
    { symbol: bingxSymbol },
    "getCgAskBids: нет данных ни с Binance, ни с Bybit",
  );
  return null;
}
