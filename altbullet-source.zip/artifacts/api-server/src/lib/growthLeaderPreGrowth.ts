/**
 * growthLeaderPreGrowth.ts
 *
 * Собирает исторические метрики по retro-токенам за T-2/3/4/6/12h
 * ДО момента retro-логирования (когда p24h уже был ≥20%).
 *
 * Источники:
 *  - BingX 1h klines → price_1h, price_3h, price_4h, price_24h, vol_mult
 *  - CoinGlass OI 30m history → oi_30m, oi_prev_30m
 *  - CoinGlass OI 1h history  → oi_1h, oi_prev_1h
 *  - CoinGlass OI 4h history  → oi_4h
 *  - CoinGlass SpotTaker 1h   → cvd_1h_ratio, spot_net_pct, spot_buy_usd, spot_sell_usd
 *  - CoinGlass SpotTaker 30m  → cvd_30m, cvd_30m_ratio
 *  - CoinGlass FutTaker 1h    → net_buy_pct (futures taker)
 *  - CoinGlass Funding 8h     → funding
 */

import { db, pool } from "@workspace/db";
import { sql as drizzleSql } from "drizzle-orm";
import { getKlines, type BingXKline } from "./bingx.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";
import { logger } from "./logger.js";

const HOURS_BEFORE = [2, 3, 4, 6, 12] as const;
const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

// ── Semaphore ─────────────────────────────────────────────────────────────────

async function withSem<T>(
  sem: { used: number; max: number },
  fn: () => Promise<T>,
): Promise<T> {
  while (sem.used >= sem.max) await delay(50);
  sem.used++;
  try {
    return await fn();
  } finally {
    sem.used--;
  }
}

// ── CoinGlass fetch ───────────────────────────────────────────────────────────

interface CgOiPoint {
  time: number;
  open: number;
  close: number;
}
interface CgTakerPt {
  time: number;
  taker_buy_volume_usd: string;
  taker_sell_volume_usd: string;
}
interface CgFundingPt {
  time: number;
  fundingRate: string;
}

async function cgFetch<T>(url: string, ctx: string): Promise<T[] | null> {
  const key = getNextCgKey();
  if (!key) return null;
  try {
    const res = await fetch(url, {
      headers: { "CG-API-KEY": key, Accept: "application/json" },
      signal: AbortSignal.timeout(15_000),
    });
    if (res.status === 429) {
      logCg429(key, { ctx });
      return null;
    }
    const json = (await res.json()) as { code?: string; data?: T[] };
    if (
      json.code !== "0" ||
      !Array.isArray(json.data) ||
      json.data.length === 0
    )
      return null;
    return json.data;
  } catch {
    return null;
  }
}

// ── BingX klines ──────────────────────────────────────────────────────────────

interface KBar {
  time: number;
  close: number;
  volUsd: number;
}

async function fetchKlines1h(symbol: string, startMs: number): Promise<KBar[]> {
  // getKlines fetches last N candles from NOW → limit must cover startMs to NOW
  const limitFromNow = Math.ceil((Date.now() - startMs) / 3_600_000) + 10;
  try {
    const raw = (await Promise.race([
      getKlines(symbol, "1h", Math.min(limitFromNow, 1000)),
      new Promise<never>((_, rej) =>
        setTimeout(() => rej(new Error("BingX timeout")), 15_000),
      ),
    ])) as BingXKline[];
    return raw
      .map((k) => ({
        time: k.time,
        close: parseFloat(k.close),
        volUsd: parseFloat(k.volume) * parseFloat(k.close),
      }))
      .filter((k) => k.close > 0 && k.time >= startMs - 3_600_000)
      .sort((a, b) => a.time - b.time);
  } catch {
    return [];
  }
}

// ── Metrics from klines at snapshot time ──────────────────────────────────────

function klineMetrics(bars: KBar[], atMs: number, avgVol: number) {
  let best = -1,
    bestDist = Infinity;
  for (let i = 0; i < bars.length; i++) {
    const d = Math.abs(bars[i]!.time - atMs);
    if (d < bestDist) {
      bestDist = d;
      best = i;
    }
  }
  if (best < 0 || bestDist > 2 * 3_600_000) return null;

  const bar = bars[best]!;
  const b1h = best >= 1 ? bars[best - 1] : null;
  const b3h = best >= 3 ? bars[best - 3] : null;
  const b4h = best >= 4 ? bars[best - 4] : null;
  const b24h = best >= 24 ? bars[best - 24] : null;

  return {
    price: bar.close,
    price_1h:
      b1h && b1h.close > 0 ? ((bar.close - b1h.close) / b1h.close) * 100 : null,
    price_3h:
      b3h && b3h.close > 0 ? ((bar.close - b3h.close) / b3h.close) * 100 : null,
    price_4h:
      b4h && b4h.close > 0 ? ((bar.close - b4h.close) / b4h.close) * 100 : null,
    price_24h:
      b24h && b24h.close > 0
        ? ((bar.close - b24h.close) / b24h.close) * 100
        : null,
    vol_mult: avgVol > 0 ? bar.volUsd / avgVol : null,
  };
}

// ── OI % over window ──────────────────────────────────────────────────────────

function calcOiPct(
  pts: CgOiPoint[],
  atMs: number,
  winMs: number,
): number | null {
  const cur = pts.reduce<CgOiPoint | null>(
    (b, p) => (!b || Math.abs(p.time - atMs) < Math.abs(b.time - atMs) ? p : b),
    null,
  );
  if (!cur) return null;
  const prevT = atMs - winMs;
  const prev = pts.reduce<CgOiPoint | null>((b, p) => {
    if (p.time > atMs - winMs / 2) return b;
    return !b || Math.abs(p.time - prevT) < Math.abs(b.time - prevT) ? p : b;
  }, null);
  if (!prev || prev.close <= 0) return null;
  return ((cur.close - prev.close) / prev.close) * 100;
}

// ── Taker window sum ──────────────────────────────────────────────────────────

function sumTaker(pts: CgTakerPt[], atMs: number, winMs: number) {
  let buy = 0,
    sell = 0;
  for (const p of pts) {
    if (p.time >= atMs - winMs && p.time <= atMs + winMs * 0.5) {
      buy += parseFloat(p.taker_buy_volume_usd) || 0;
      sell += parseFloat(p.taker_sell_volume_usd) || 0;
    }
  }
  return { buy, sell };
}

// ── Funding rate closest to snapshot ─────────────────────────────────────────

function closestFunding(pts: CgFundingPt[], atMs: number): number | null {
  if (!pts.length) return null;
  const best = pts.reduce<CgFundingPt | null>(
    (b, p) => (!b || Math.abs(p.time - atMs) < Math.abs(b.time - atMs) ? p : b),
    null,
  );
  if (!best) return null;
  const v = parseFloat(best.fundingRate);
  return isNaN(v) ? null : v;
}

// ── Process one symbol ────────────────────────────────────────────────────────

interface RetroEntry {
  id: number;
  symbol: string;
  retroMs: number;
}

async function processSymbol(
  symbol: string,
  entries: RetroEntry[],
  cgSem: { used: number; max: number },
): Promise<number> {
  const base = symbol.replace(/-USDT$/, "").replace(/USDT$/, "");
  const minMs = Math.min(...entries.map((e) => e.retroMs));
  const maxMs = Math.max(...entries.map((e) => e.retroMs));
  // startMs for klines: earliest snapshot (T-12h of earliest retro) - 25h buffer for price_24h
  const startMs = minMs - 37 * 3_600_000;
  // CG start: earliest snapshot time
  const cgStart = minMs - 13 * 3_600_000;
  const cgHours = Math.ceil((maxMs - cgStart) / 3_600_000) + 15;

  // ── Fetch BingX 1h klines ──
  const bars = await fetchKlines1h(symbol, startMs);
  if (bars.length < 10) {
    logger.warn(
      { symbol, bars: bars.length },
      "preGrowth: слишком мало BingX свечей",
    );
    return 0;
  }
  const avgVol = bars.reduce((s, b) => s + b.volUsd, 0) / bars.length;

  // ── Fetch CoinGlass data (7 calls, staggered to avoid 429) ──
  const [oi1h, oi30m, oi4h, spotTaker1h, spotTaker30m, futTaker1h, funding] =
    await Promise.all([
      // OI 1h
      withSem(cgSem, () =>
        cgFetch<CgOiPoint>(
          `https://open-api-v4.coinglass.com/api/futures/open-interest/aggregated-history?symbol=${encodeURIComponent(base)}&interval=1h&start_time=${cgStart}&limit=${Math.min(cgHours + 5, 200)}`,
          `OI1h ${base}`,
        ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
      ),

      // OI 30m
      delay(150).then(() =>
        withSem(cgSem, () =>
          cgFetch<CgOiPoint>(
            `https://open-api-v4.coinglass.com/api/futures/open-interest/aggregated-history?symbol=${encodeURIComponent(base)}&interval=30m&start_time=${cgStart}&limit=${Math.min(cgHours * 2 + 10, 400)}`,
            `OI30m ${base}`,
          ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
        ),
      ),

      // OI 4h
      delay(300).then(() =>
        withSem(cgSem, () =>
          cgFetch<CgOiPoint>(
            `https://open-api-v4.coinglass.com/api/futures/open-interest/aggregated-history?symbol=${encodeURIComponent(base)}&interval=4h&start_time=${cgStart}&limit=${Math.min(Math.ceil(cgHours / 4) + 5, 100)}`,
            `OI4h ${base}`,
          ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
        ),
      ),

      // SpotTaker 1h (Binance symbol = base + USDT)
      delay(450).then(() =>
        withSem(cgSem, () =>
          cgFetch<CgTakerPt>(
            `https://open-api-v4.coinglass.com/api/spot/taker-buy-sell-volume/history?exchange=Binance&symbol=${base}USDT&interval=1h&start_time=${cgStart}&limit=${Math.min(cgHours + 5, 200)}`,
            `SpotTaker1h ${base}`,
          ),
        ),
      ),

      // SpotTaker 30m
      delay(600).then(() =>
        withSem(cgSem, () =>
          cgFetch<CgTakerPt>(
            `https://open-api-v4.coinglass.com/api/spot/taker-buy-sell-volume/history?exchange=Binance&symbol=${base}USDT&interval=30m&start_time=${cgStart}&limit=${Math.min(cgHours * 2 + 10, 400)}`,
            `SpotTaker30m ${base}`,
          ),
        ),
      ),

      // FutTaker 1h
      delay(750).then(() =>
        withSem(cgSem, () =>
          cgFetch<CgTakerPt>(
            `https://open-api-v4.coinglass.com/api/futures/taker-buy-sell-volume/history?exchange=Binance&symbol=${base}USDT&interval=1h&start_time=${cgStart}&limit=${Math.min(cgHours + 5, 200)}`,
            `FutTaker1h ${base}`,
          ),
        ),
      ),

      // Funding rate 8h
      delay(900).then(() =>
        withSem(cgSem, () =>
          cgFetch<CgFundingPt>(
            `https://open-api-v4.coinglass.com/api/futures/funding-rate/aggregated-history?symbol=${encodeURIComponent(base)}&interval=8h&start_time=${cgStart}&limit=${Math.min(Math.ceil(cgHours / 8) + 5, 50)}`,
            `Funding ${base}`,
          ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
        ),
      ),
    ]);

  const rows: Array<{
    retro_log_id: number;
    symbol: string;
    retro_time: Date;
    hours_before: number;
    snapshot_time: Date;
    price: number | null;
    price_1h: number | null;
    price_3h: number | null;
    price_4h: number | null;
    price_24h: number | null;
    oi_30m: number | null;
    oi_prev_30m: number | null;
    oi_1h: number | null;
    oi_prev_1h: number | null;
    oi_4h: number | null;
    vol_mult: number | null;
    cvd_1h: boolean | null;
    cvd_1h_ratio: number | null;
    cvd_30m: boolean | null;
    cvd_30m_ratio: number | null;
    net_buy_pct: number | null;
    spot_net_pct: number | null;
    spot_buy_usd: number | null;
    spot_sell_usd: number | null;
    funding: number | null;
  }> = [];

  for (const entry of entries) {
    for (const hb of HOURS_BEFORE) {
      const snapMs = entry.retroMs - hb * 3_600_000;
      const km = klineMetrics(bars, snapMs, avgVol);
      if (!km) continue;

      // OI values
      const oi1hVal = oi1h ? calcOiPct(oi1h, snapMs, 60 * 60_000) : null;
      const oi1hPrevVal = oi1h
        ? calcOiPct(oi1h, snapMs - 60 * 60_000, 60 * 60_000)
        : null;
      const oi30mVal = oi30m ? calcOiPct(oi30m, snapMs, 30 * 60_000) : null;
      const oi30mPrevVal = oi30m
        ? calcOiPct(oi30m, snapMs - 30 * 60_000, 30 * 60_000)
        : null;
      const oi4hVal = oi4h ? calcOiPct(oi4h, snapMs, 4 * 60 * 60_000) : null;

      // SpotTaker 1h
      let cvd1h: boolean | null = null;
      let cvd1hRatio: number | null = null;
      let spotNetPct: number | null = null;
      let spotBuyUsd: number | null = null;
      let spotSellUsd: number | null = null;
      if (spotTaker1h) {
        const w = sumTaker(spotTaker1h, snapMs, 3_600_000);
        if (w.buy + w.sell > 0) {
          cvd1h = w.buy > w.sell;
          cvd1hRatio = w.buy / (w.buy + w.sell);
          spotNetPct = ((w.buy - w.sell) / (w.buy + w.sell)) * 100;
          spotBuyUsd = w.buy;
          spotSellUsd = w.sell;
        }
      }

      // SpotTaker 30m
      let cvd30m: boolean | null = null;
      let cvd30mRatio: number | null = null;
      if (spotTaker30m) {
        const w = sumTaker(spotTaker30m, snapMs, 30 * 60_000);
        if (w.buy + w.sell > 0) {
          cvd30m = w.buy > w.sell;
          cvd30mRatio = w.buy / (w.buy + w.sell);
        }
      }

      // FutTaker 1h
      let netBuyPct: number | null = null;
      if (futTaker1h) {
        const w = sumTaker(futTaker1h, snapMs, 3_600_000);
        if (w.buy + w.sell > 0)
          netBuyPct = ((w.buy - w.sell) / (w.buy + w.sell)) * 100;
      }

      // Funding
      const fundingVal = funding ? closestFunding(funding, snapMs) : null;

      rows.push({
        retro_log_id: entry.id,
        symbol,
        retro_time: new Date(entry.retroMs),
        hours_before: hb,
        snapshot_time: new Date(snapMs),
        price: km.price,
        price_1h: km.price_1h,
        price_3h: km.price_3h,
        price_4h: km.price_4h,
        price_24h: km.price_24h,
        oi_30m: oi30mVal,
        oi_prev_30m: oi30mPrevVal,
        oi_1h: oi1hVal,
        oi_prev_1h: oi1hPrevVal,
        oi_4h: oi4hVal,
        vol_mult: km.vol_mult,
        cvd_1h: cvd1h,
        cvd_1h_ratio: cvd1hRatio,
        cvd_30m: cvd30m,
        cvd_30m_ratio: cvd30mRatio,
        net_buy_pct: netBuyPct,
        spot_net_pct: spotNetPct,
        spot_buy_usd: spotBuyUsd,
        spot_sell_usd: spotSellUsd,
        funding: fundingVal,
      });
    }
  }

  if (rows.length === 0) return 0;

  const NCOLS = 25;
  const vals = rows
    .map((_, i) => {
      const b = i * NCOLS;
      return `(${Array.from({ length: NCOLS }, (_, j) => `$${b + j + 1}`).join(",")})`;
    })
    .join(",");

  const params = rows.flatMap((r) => [
    r.retro_log_id,
    r.symbol,
    r.retro_time,
    r.hours_before,
    r.snapshot_time,
    r.price,
    r.price_1h,
    r.price_3h,
    r.price_4h,
    r.price_24h,
    r.oi_30m,
    r.oi_prev_30m,
    r.oi_1h,
    r.oi_prev_1h,
    r.oi_4h,
    r.vol_mult,
    r.cvd_1h,
    r.cvd_1h_ratio,
    r.cvd_30m,
    r.cvd_30m_ratio,
    r.net_buy_pct,
    r.spot_net_pct,
    r.spot_buy_usd,
    r.spot_sell_usd,
    r.funding,
  ]);

  try {
    await pool.query(
      `
      INSERT INTO retro_pre_growth
        (retro_log_id,symbol,retro_time,hours_before,snapshot_time,
         price,price_1h,price_3h,price_4h,price_24h,
         oi_30m,oi_prev_30m,oi_1h,oi_prev_1h,oi_4h,
         vol_mult,
         cvd_1h,cvd_1h_ratio,cvd_30m,cvd_30m_ratio,
         net_buy_pct,spot_net_pct,spot_buy_usd,spot_sell_usd,
         funding)
      VALUES ${vals}
      ON CONFLICT (retro_log_id,hours_before) DO UPDATE SET
        price=EXCLUDED.price, price_1h=EXCLUDED.price_1h, price_3h=EXCLUDED.price_3h,
        price_4h=EXCLUDED.price_4h, price_24h=EXCLUDED.price_24h,
        oi_30m=EXCLUDED.oi_30m, oi_prev_30m=EXCLUDED.oi_prev_30m,
        oi_1h=EXCLUDED.oi_1h, oi_prev_1h=EXCLUDED.oi_prev_1h, oi_4h=EXCLUDED.oi_4h,
        vol_mult=EXCLUDED.vol_mult,
        cvd_1h=EXCLUDED.cvd_1h, cvd_1h_ratio=EXCLUDED.cvd_1h_ratio,
        cvd_30m=EXCLUDED.cvd_30m, cvd_30m_ratio=EXCLUDED.cvd_30m_ratio,
        net_buy_pct=EXCLUDED.net_buy_pct, spot_net_pct=EXCLUDED.spot_net_pct,
        spot_buy_usd=EXCLUDED.spot_buy_usd, spot_sell_usd=EXCLUDED.spot_sell_usd,
        funding=EXCLUDED.funding
    `,
      params,
    );
    return rows.length;
  } catch (err) {
    logger.warn({ err, symbol }, "preGrowth: INSERT error");
    return 0;
  }
}

// ── Public entry point ────────────────────────────────────────────────────────

export interface PreGrowthOpts {
  batchSize?: number;
  batchDelayMs?: number;
  force?: boolean;
}

export async function runCollectPreGrowth(
  opts: PreGrowthOpts = {},
): Promise<{ inserted: number; symbols: number }> {
  const batchSize = opts.batchSize ?? 5;
  const batchDelayMs = opts.batchDelayMs ?? 1500;
  const force = opts.force ?? false;

  logger.info({ batchSize, force }, "collectPreGrowth: старт");

  if (force) {
    try {
      await db.execute(drizzleSql`TRUNCATE retro_pre_growth`);
      logger.info("collectPreGrowth: таблица очищена (force)");
    } catch (e) {
      logger.warn({ err: e }, "collectPreGrowth: truncate failed");
    }
  }

  const result = await db.execute(drizzleSql`
    SELECT id, symbol, EXTRACT(EPOCH FROM logged_at)*1000 AS retro_ms
    FROM growth_leader_log
    WHERE retro = true
    ORDER BY symbol, logged_at
  `);

  type Row = { id: number; symbol: string; retro_ms: string };
  const allEntries: RetroEntry[] = (result.rows as Row[]).map((r) => ({
    id: r.id,
    symbol: r.symbol,
    retroMs: Math.round(parseFloat(r.retro_ms)),
  }));

  logger.info(
    { total: allEntries.length },
    "collectPreGrowth: retro-строк загружено",
  );

  const bySymbol = new Map<string, RetroEntry[]>();
  for (const e of allEntries) {
    if (!bySymbol.has(e.symbol)) bySymbol.set(e.symbol, []);
    bySymbol.get(e.symbol)!.push(e);
  }
  const symbols = [...bySymbol.keys()];

  const cgSem = { used: 0, max: 5 };
  let totalInserted = 0;

  for (let i = 0; i < symbols.length; i += batchSize) {
    const batch = symbols.slice(i, i + batchSize);
    const results = await Promise.allSettled(
      batch.map((sym) => processSymbol(sym, bySymbol.get(sym)!, cgSem)),
    );
    for (const r of results) {
      if (r.status === "fulfilled") totalInserted += r.value;
    }

    if ((i / batchSize) % 5 === 0 && i > 0) {
      logger.info(
        {
          processed: Math.min(i + batchSize, symbols.length),
          total: symbols.length,
          inserted: totalInserted,
        },
        "collectPreGrowth: прогресс",
      );
    }
    if (i + batchSize < symbols.length) await delay(batchDelayMs);
  }

  logger.info(
    { inserted: totalInserted, symbols: symbols.length },
    "collectPreGrowth: завершён",
  );
  return { inserted: totalInserted, symbols: symbols.length };
}

// ── Per-signal pre-growth snapshot ───────────────────────────────────────────
// Вызывается автоматически при каждом trackSignal "new" (fire-and-forget).
// Сохраняет снимки T-1/2/4/12ч ДО момента выстрела в таблицу signal_pre_growth.
// archetype / archetypeConf — результат archetype-detector на момент выстрела.

const SIGNAL_HOURS_BEFORE = [1, 2, 4, 12] as const;

export async function collectSingleSignalPreGrowth(
  symbol: string,
  firedAtMs: number,
  archetype: string | null,
  archetypeConf: number | null,
  sentimentKey?: string | null,
): Promise<number> {
  const base = symbol.replace(/-USDT$/, "");
  const startMs = firedAtMs - 13 * 3_600_000;
  const cgStart = Math.floor(startMs / 1000);
  const cgHours = 14;
  const sem = { used: 0, max: 3 };

  const [bars, oi30m, oi1h, oi4h, spotTaker1h, spotTaker30m] =
    await Promise.all([
      fetchKlines1h(symbol, startMs),
      delay(0).then(() =>
        withSem(sem, () =>
          cgFetch<CgOiPoint>(
            `https://open-api-v4.coinglass.com/api/futures/openInterest/ohlc-aggregated-history?symbol=${base}&interval=30m&start_time=${cgStart}&limit=${Math.min(cgHours * 2 + 5, 200)}`,
            `SigPG OI30m ${base}`,
          ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
        ),
      ),
      delay(200).then(() =>
        withSem(sem, () =>
          cgFetch<CgOiPoint>(
            `https://open-api-v4.coinglass.com/api/futures/openInterest/ohlc-aggregated-history?symbol=${base}&interval=1h&start_time=${cgStart}&limit=${Math.min(cgHours + 5, 200)}`,
            `SigPG OI1h ${base}`,
          ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
        ),
      ),
      delay(400).then(() =>
        withSem(sem, () =>
          cgFetch<CgOiPoint>(
            `https://open-api-v4.coinglass.com/api/futures/openInterest/ohlc-aggregated-history?symbol=${base}&interval=4h&start_time=${cgStart}&limit=${Math.min(Math.ceil(cgHours / 4) + 5, 50)}`,
            `SigPG OI4h ${base}`,
          ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
        ),
      ),
      delay(600).then(() =>
        withSem(sem, () =>
          cgFetch<CgTakerPt>(
            `https://open-api-v4.coinglass.com/api/futures/taker-buy-sell-volume/history?exchange=Binance&symbol=${base}USDT&interval=1h&start_time=${cgStart}&limit=${Math.min(cgHours + 5, 200)}`,
            `SigPG SpotTaker1h ${base}`,
          ),
        ),
      ),
      delay(800).then(() =>
        withSem(sem, () =>
          cgFetch<CgTakerPt>(
            `https://open-api-v4.coinglass.com/api/futures/taker-buy-sell-volume/history?exchange=Binance&symbol=${base}USDT&interval=30m&start_time=${cgStart}&limit=${Math.min(cgHours * 2 + 5, 200)}`,
            `SigPG SpotTaker30m ${base}`,
          ),
        ),
      ),
    ]);

  if (bars.length < 2) {
    logger.debug({ symbol }, "signalPreGrowth: кlines пустые — пропускаем");
    return 0;
  }
  const avgVol = bars.reduce((s, b) => s + b.volUsd, 0) / bars.length;

  const rows: Array<{
    symbol: string;
    fire_time: Date;
    hours_before: number;
    snapshot_time: Date;
    sentiment_key: string | null;
    archetype: string | null;
    archetype_conf: number | null;
    price: number | null;
    price_1h: number | null;
    price_3h: number | null;
    price_4h: number | null;
    price_24h: number | null;
    oi_30m: number | null;
    oi_prev_30m: number | null;
    oi_1h: number | null;
    oi_prev_1h: number | null;
    oi_4h: number | null;
    vol_mult: number | null;
    cvd_1h: boolean | null;
    cvd_1h_ratio: number | null;
    cvd_30m: boolean | null;
    cvd_30m_ratio: number | null;
    net_buy_pct: number | null;
    spot_net_pct: number | null;
    spot_buy_usd: number | null;
    spot_sell_usd: number | null;
    funding: number | null;
  }> = [];

  for (const hb of SIGNAL_HOURS_BEFORE) {
    const snapMs = firedAtMs - hb * 3_600_000;
    const km = klineMetrics(bars, snapMs, avgVol);
    if (!km) continue;

    const oi30mVal = oi30m ? calcOiPct(oi30m, snapMs, 30 * 60_000) : null;
    const oi30mPrevVal = oi30m
      ? calcOiPct(oi30m, snapMs - 30 * 60_000, 30 * 60_000)
      : null;
    const oi1hVal = oi1h ? calcOiPct(oi1h, snapMs, 60 * 60_000) : null;
    const oi1hPrevVal = oi1h
      ? calcOiPct(oi1h, snapMs - 60 * 60_000, 60 * 60_000)
      : null;
    const oi4hVal = oi4h ? calcOiPct(oi4h, snapMs, 4 * 60 * 60_000) : null;

    let cvd1h: boolean | null = null,
      cvd1hRatio: number | null = null;
    let spotNetPct: number | null = null,
      spotBuyUsd: number | null = null,
      spotSellUsd: number | null = null;
    if (spotTaker1h) {
      const w = sumTaker(spotTaker1h, snapMs, 3_600_000);
      if (w.buy + w.sell > 0) {
        cvd1h = w.buy > w.sell;
        cvd1hRatio = w.buy / (w.buy + w.sell);
        spotNetPct = ((w.buy - w.sell) / (w.buy + w.sell)) * 100;
        spotBuyUsd = w.buy;
        spotSellUsd = w.sell;
      }
    }
    let cvd30m: boolean | null = null,
      cvd30mRatio: number | null = null;
    if (spotTaker30m) {
      const w = sumTaker(spotTaker30m, snapMs, 30 * 60_000);
      if (w.buy + w.sell > 0) {
        cvd30m = w.buy > w.sell;
        cvd30mRatio = w.buy / (w.buy + w.sell);
      }
    }

    rows.push({
      symbol,
      fire_time: new Date(firedAtMs),
      hours_before: hb,
      snapshot_time: new Date(snapMs),
      sentiment_key: sentimentKey ?? null,
      archetype,
      archetype_conf: archetypeConf,
      price: km.price,
      price_1h: km.price_1h,
      price_3h: km.price_3h,
      price_4h: km.price_4h,
      price_24h: km.price_24h,
      oi_30m: oi30mVal,
      oi_prev_30m: oi30mPrevVal,
      oi_1h: oi1hVal,
      oi_prev_1h: oi1hPrevVal,
      oi_4h: oi4hVal,
      vol_mult: km.vol_mult,
      cvd_1h: cvd1h,
      cvd_1h_ratio: cvd1hRatio,
      cvd_30m: cvd30m,
      cvd_30m_ratio: cvd30mRatio,
      net_buy_pct: null,
      spot_net_pct: spotNetPct,
      spot_buy_usd: spotBuyUsd,
      spot_sell_usd: spotSellUsd,
      funding: null,
    });
  }

  if (rows.length === 0) return 0;

  const NCOLS = 27;
  const vals = rows
    .map((_, i) => {
      const b = i * NCOLS;
      return `(${Array.from({ length: NCOLS }, (_, j) => `$${b + j + 1}`).join(",")})`;
    })
    .join(",");
  const params = rows.flatMap((r) => [
    r.symbol,
    r.fire_time,
    r.hours_before,
    r.snapshot_time,
    r.sentiment_key,
    r.archetype,
    r.archetype_conf,
    r.price,
    r.price_1h,
    r.price_3h,
    r.price_4h,
    r.price_24h,
    r.oi_30m,
    r.oi_prev_30m,
    r.oi_1h,
    r.oi_prev_1h,
    r.oi_4h,
    r.vol_mult,
    r.cvd_1h,
    r.cvd_1h_ratio,
    r.cvd_30m,
    r.cvd_30m_ratio,
    r.net_buy_pct,
    r.spot_net_pct,
    r.spot_buy_usd,
    r.spot_sell_usd,
    r.funding,
  ]);

  try {
    await pool.query(
      `
      INSERT INTO signal_pre_growth
        (symbol,fire_time,hours_before,snapshot_time,
         sentiment_key,archetype,archetype_conf,
         price,price_1h,price_3h,price_4h,price_24h,
         oi_30m,oi_prev_30m,oi_1h,oi_prev_1h,oi_4h,
         vol_mult,
         cvd_1h,cvd_1h_ratio,cvd_30m,cvd_30m_ratio,
         net_buy_pct,spot_net_pct,spot_buy_usd,spot_sell_usd,
         funding)
      VALUES ${vals}
      ON CONFLICT (symbol,fire_time,hours_before) DO NOTHING
    `,
      params,
    );
    logger.info(
      { symbol, rows: rows.length, archetype, sentimentKey },
      "signalPreGrowth: сохранён снимок",
    );
    return rows.length;
  } catch (err) {
    logger.warn({ err, symbol }, "signalPreGrowth: INSERT error");
    return 0;
  }
}
