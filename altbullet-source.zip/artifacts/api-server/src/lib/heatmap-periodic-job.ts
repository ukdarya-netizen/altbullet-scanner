/**
 * Heatmap Periodic Job — Part 2.2 (forward accumulation).
 *
 * Запускается каждые 4 часа. Собирает снапшоты liq-heatmap для всех
 * активных символов в prescan_tracker (цикл ≥3) и сохраняет в
 * cg_liq_heatmap_snapshot (таблица уже существует из backfill).
 *
 * Данные используются для:
 * - Анализа изменений liq-кластеров во времени
 * - Проверки гипотезы "Liquidity Magnet" (цена притягивается к крупным кластерам)
 * - Обогащения confusion matrix для новых паттернов
 *
 * Примечание: getLiqMapClusters использует model2 (агрегированный по биржам),
 * тот же endpoint, что и scanner.ts для liq-паттернов.
 */

import { logger } from "./logger.js";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";
import { getNextCgKey } from "./coinglass_keys.js";

const JOB_NAME = "heatmap_periodic";
const RATE_LIMIT_MS = 2500; // ~24 req/min (CoinGlass standard limit)
const MAX_SYMBOLS = 200; // не более 200 символов за цикл

async function fetchHeatmapClusters(
  baseSymbol: string,
): Promise<{ price: number; liqUsd: number; side: "long" | "short" }[] | null> {
  const apiKey = getNextCgKey();
  const url = `https://open-api-v4.coinglass.com/api/futures/liquidation/aggregated-heatmap/model2?symbol=${baseSymbol}&range=3d`;
  try {
    const headers: Record<string, string> = { Accept: "application/json" };
    if (apiKey) headers["CG-API-KEY"] = apiKey;
    const res = await fetch(url, {
      headers,
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;
    const d = (await res.json()) as {
      code: string;
      data?: {
        y_axis?: number[];
        liquidation_leverage_data?: [number, number, number][];
      };
    };
    if (d.code !== "0" || !d.data?.y_axis || !d.data?.liquidation_leverage_data)
      return null;

    const yAxis = d.data.y_axis;
    const leverageData = d.data.liquidation_leverage_data;
    if (!yAxis.length || !leverageData.length) return null;

    // Текущий срез = столбец с max(x)
    const maxX = Math.max(...leverageData.map((r) => r[0]));
    const currentSlice = leverageData.filter((r) => r[0] === maxX);

    // Top-10 кластеров по liqUsd
    const sorted = currentSlice
      .filter((r) => r[2] > 0)
      .map((r) => ({
        price: yAxis[r[1]] ?? 0,
        liqUsd: r[2],
        side: (r[1] < yAxis.length / 2 ? "long" : "short") as "long" | "short",
      }))
      .sort((a, b) => b.liqUsd - a.liqUsd)
      .slice(0, 10);

    return sorted;
  } catch {
    return null;
  }
}

let _lastRunAt = 0;
const RUN_INTERVAL_MS = 4 * 60 * 60 * 1000; // 4 часа

export async function runHeatmapPeriodicJob(): Promise<void> {
  const now = Date.now();
  if (now - _lastRunAt < RUN_INTERVAL_MS - 60_000) return; // debounce
  _lastRunAt = now;

  const logStart = await db
    .execute(
      sql`
    INSERT INTO periodic_collection_log (job_name, started_at)
    VALUES (${JOB_NAME}, NOW())
    RETURNING id
  `,
    )
    .catch(() => null);
  const logId: number | null =
    (logStart?.rows?.[0] as { id: number } | undefined)?.id ?? null;

  try {
    // Берём активные символы из prescan_tracker (≥3 циклов)
    const rows = await db.execute<{ symbol: string }>(sql`
      SELECT symbol FROM prescan_tracker
      WHERE cycle_count >= 3
      ORDER BY cycle_count DESC
      LIMIT ${MAX_SYMBOLS}
    `);

    const symbols = rows.rows.map((r) => r.symbol);
    if (!symbols.length) {
      logger.info("HeatmapPeriodicJob: нет символов в prescan_tracker");
      return;
    }

    logger.info({ n: symbols.length }, "HeatmapPeriodicJob: start");

    const snapshotAt = new Date();
    const hourBucket = new Date(
      Math.floor(snapshotAt.getTime() / 3_600_000) * 3_600_000,
    );
    let written = 0;
    let errors = 0;

    for (const sym of symbols) {
      const base = sym.replace(/-USDT$/, "");
      const clusters = await fetchHeatmapClusters(base);

      if (clusters && clusters.length > 0) {
        // Сохраняем топ кластеры как строки
        for (const cl of clusters) {
          await db
            .execute(
              sql`
            INSERT INTO cg_liq_heatmap_snapshot
              (symbol, range, snapshot_at, cluster_price, liq_usd, side)
            VALUES
              (${sym}, '3d', ${hourBucket}, ${cl.price}, ${cl.liqUsd}, ${cl.side})
            ON CONFLICT (symbol, range, snapshot_at) DO NOTHING
          `,
            )
            .catch(() => {
              errors++;
            });
        }
        written++;
      }

      await new Promise((res) => setTimeout(res, RATE_LIMIT_MS));
    }

    if (logId) {
      await db
        .execute(
          sql`
        UPDATE periodic_collection_log
        SET finished_at = NOW(), records_written = ${written}
        WHERE id = ${logId}
      `,
        )
        .catch(() => {});
    }

    logger.info(
      { written, errors, symbols: symbols.length },
      "HeatmapPeriodicJob: done",
    );
  } catch (err) {
    logger.warn({ err }, "HeatmapPeriodicJob: error");
    if (logId) {
      await db
        .execute(
          sql`
        UPDATE periodic_collection_log
        SET finished_at = NOW(), error = ${String(err)}
        WHERE id = ${logId}
      `,
        )
        .catch(() => {});
    }
  }
}
