/**
 * CoinGlass — EMA и MACD batch fetch (один запрос на весь рынок).
 *
 * Endpoints:
 *   GET /api/futures/indicators/ema/list?interval=<tf>
 *   GET /api/futures/indicators/macd/list?interval=<tf>
 *
 * Загружается batch (все символы), кэш 5 мин.
 * Fail-open: пустой Map при любой ошибке.
 */

import { logger } from "./logger.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";

const CACHE_TTL = 5 * 60 * 1000; // 5 мин

// ── EMA cache ──────────────────────────────────────────────────────────────────

let _emaCache1h: { data: Map<string, number>; ts: number } | null = null;

async function fetchEmaList(
  interval: "1h" | "4h" | "1D",
): Promise<Map<string, number>> {
  const apiKey = getNextCgKey();
  if (!apiKey) return new Map();

  try {
    const url = `https://open-api-v4.coinglass.com/api/futures/indicators/ema/list?interval=${interval}`;
    const res = await fetch(url, {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(8000),
    });

    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "futures/indicators/ema/list", interval });
      return new Map();
    }
    if (!res.ok) {
      logger.debug(
        { status: res.status, interval },
        "fetchEmaList: HTTP error — fail-open",
      );
      return new Map();
    }

    const json = (await res.json()) as {
      code?: string;
      data?: Array<{
        symbol?: string;
        instrumentId?: string;
        ema?: number | string;
        value?: number | string;
      }>;
    };
    if (json.code !== "0" || !Array.isArray(json.data)) return new Map();

    const result = new Map<string, number>();
    for (const row of json.data) {
      const sym = (row.symbol ?? row.instrumentId ?? "")
        .replace(/USDT.*$/i, "")
        .toUpperCase()
        .trim();
      if (!sym) continue;
      const val = Number(row.ema ?? row.value ?? 0);
      if (!Number.isFinite(val) || val <= 0) continue;
      result.set(sym, val);
    }

    logger.debug(
      { interval, count: result.size },
      "fetchEmaList: loaded EMA batch",
    );
    return result;
  } catch (err) {
    logger.debug(
      { err: String(err), interval },
      "fetchEmaList: error — fail-open",
    );
    return new Map();
  }
}

/**
 * Загрузить EMA 1h для всех символов. Кэш 5 мин.
 * Fail-open: пустой Map при любой ошибке.
 */
export async function loadEmaMap1h(): Promise<Map<string, number>> {
  if (_emaCache1h && Date.now() - _emaCache1h.ts < CACHE_TTL)
    return _emaCache1h.data;
  const data = await fetchEmaList("1h");
  _emaCache1h = { data, ts: Date.now() };
  return data;
}

/**
 * Получить EMA по символу из предзагруженного Map.
 * symbol — BingX pair вида "BTC-USDT".
 * Возвращает number | null.
 */
export function getEmaFromMap(
  symbol: string,
  emaMap: Map<string, number>,
): number | null {
  const base = symbol.replace("-USDT", "").replace(/^1000/, "").toUpperCase();
  const val = emaMap.get(base);
  return val != null ? val : null;
}

// ── MACD cache ─────────────────────────────────────────────────────────────────

// MACD batch: каждая строка содержит MACD line, signal line, histogram.
// Histogram (momentum indicator) используется в TA Scanner.
export interface MacdSnapshot {
  macdLine: number;
  signalLine: number;
  histogram: number;
}

let _macdCache1h: { data: Map<string, MacdSnapshot>; ts: number } | null = null;

async function fetchMacdList(
  interval: "1h" | "4h" | "1D",
): Promise<Map<string, MacdSnapshot>> {
  const apiKey = getNextCgKey();
  if (!apiKey) return new Map();

  try {
    const url = `https://open-api-v4.coinglass.com/api/futures/indicators/macd/list?interval=${interval}`;
    const res = await fetch(url, {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(8000),
    });

    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "futures/indicators/macd/list", interval });
      return new Map();
    }
    if (!res.ok) {
      logger.debug(
        { status: res.status, interval },
        "fetchMacdList: HTTP error — fail-open",
      );
      return new Map();
    }

    const json = (await res.json()) as {
      code?: string;
      data?: Array<{
        symbol?: string;
        instrumentId?: string;
        // CoinGlass может возвращать разные имена полей
        macd?: number | string;
        macdLine?: number | string;
        signal?: number | string;
        signalLine?: number | string;
        histogram?: number | string;
        hist?: number | string;
        value?: number | string;
      }>;
    };
    if (json.code !== "0" || !Array.isArray(json.data)) return new Map();

    const result = new Map<string, MacdSnapshot>();
    for (const row of json.data) {
      const sym = (row.symbol ?? row.instrumentId ?? "")
        .replace(/USDT.*$/i, "")
        .toUpperCase()
        .trim();
      if (!sym) continue;
      const macdLine = Number(row.macd ?? row.macdLine ?? 0);
      const signalLine = Number(row.signal ?? row.signalLine ?? 0);
      const histogram = Number(
        row.histogram ?? row.hist ?? row.value ?? macdLine - signalLine,
      );
      if (!Number.isFinite(macdLine) && !Number.isFinite(histogram)) continue;
      result.set(sym, {
        macdLine: Number.isFinite(macdLine) ? macdLine : 0,
        signalLine: Number.isFinite(signalLine) ? signalLine : 0,
        histogram: Number.isFinite(histogram) ? histogram : 0,
      });
    }

    logger.debug(
      { interval, count: result.size },
      "fetchMacdList: loaded MACD batch",
    );
    return result;
  } catch (err) {
    logger.debug(
      { err: String(err), interval },
      "fetchMacdList: error — fail-open",
    );
    return new Map();
  }
}

/**
 * Загрузить MACD 1h для всех символов. Кэш 5 мин.
 * Fail-open: пустой Map при любой ошибке.
 */
export async function loadMacdMap1h(): Promise<Map<string, MacdSnapshot>> {
  if (_macdCache1h && Date.now() - _macdCache1h.ts < CACHE_TTL)
    return _macdCache1h.data;
  const data = await fetchMacdList("1h");
  _macdCache1h = { data, ts: Date.now() };
  return data;
}

/**
 * Получить MACD по символу из предзагруженного Map.
 * symbol — BingX pair вида "BTC-USDT".
 * Возвращает MacdSnapshot | null.
 */
export function getMacdFromMap(
  symbol: string,
  macdMap: Map<string, MacdSnapshot>,
): MacdSnapshot | null {
  const base = symbol.replace("-USDT", "").replace(/^1000/, "").toUpperCase();
  const val = macdMap.get(base);
  return val ?? null;
}

// ═══════════════════════════════════════════════════════════════════════════════
// TA SCANNER — bulk list endpoints (возвращают ВСЕ TF в одном запросе)
// Используются runTaScannerCycle() для агрегации мульти-TF данных.
// ═══════════════════════════════════════════════════════════════════════════════

const BULK_CACHE_TTL = 4 * 60 * 1000; // 4 мин

/** Хелпер: безопасное число или null */
function safeNum(v: unknown): number | null {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

/** Хелпер: извлечь cgBase из CoinGlass symbol field */
function toCgBase(raw: unknown): string {
  return String(raw ?? "")
    .replace(/USDT.*$/i, "")
    .toUpperCase()
    .trim();
}

// ── MA List (/api/futures/ma/list) ───────────────────────────────────────────

export interface MaListEntry {
  ma1h: number | null;
  ma4h: number | null;
  ma1d: number | null;
  closePrice: number | null;
}

let _maBulkCache: { data: Map<string, MaListEntry>; ts: number } | null = null;

export async function loadMaBulkMap(): Promise<Map<string, MaListEntry>> {
  if (_maBulkCache && Date.now() - _maBulkCache.ts < BULK_CACHE_TTL)
    return _maBulkCache.data;

  const apiKey = getNextCgKey();
  if (!apiKey) return new Map();

  try {
    const res = await fetch(
      "https://open-api-v4.coinglass.com/api/futures/ma/list",
      {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(10_000),
      },
    );
    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "futures/ma/list" });
      return _maBulkCache?.data ?? new Map();
    }
    if (!res.ok) return _maBulkCache?.data ?? new Map();

    const json = (await res.json()) as {
      code?: string;
      data?: Array<Record<string, unknown>>;
    };
    if (json.code !== "0" || !Array.isArray(json.data))
      return _maBulkCache?.data ?? new Map();

    const result = new Map<string, MaListEntry>();
    for (const row of json.data) {
      const sym = toCgBase(row.symbol);
      if (!sym) continue;
      result.set(sym, {
        ma1h: safeNum(row.ma_1h),
        ma4h: safeNum(row.ma_4h),
        ma1d: safeNum(row.ma_1d),
        closePrice: safeNum(row.close_price),
      });
    }
    _maBulkCache = { data: result, ts: Date.now() };
    logger.debug({ count: result.size }, "loadMaBulkMap: loaded");
    return result;
  } catch (err) {
    logger.debug({ err: String(err) }, "loadMaBulkMap: error — fail-open");
    return _maBulkCache?.data ?? new Map();
  }
}

// ── EMA List (/api/futures/ema/list) ─────────────────────────────────────────

export interface EmaListEntry {
  ema1h: number | null;
  ema4h: number | null;
  ema1d: number | null;
  closePrice: number | null;
}

let _emaBulkCache: { data: Map<string, EmaListEntry>; ts: number } | null =
  null;

export async function loadEmaBulkMap(): Promise<Map<string, EmaListEntry>> {
  if (_emaBulkCache && Date.now() - _emaBulkCache.ts < BULK_CACHE_TTL)
    return _emaBulkCache.data;

  const apiKey = getNextCgKey();
  if (!apiKey) return new Map();

  try {
    const res = await fetch(
      "https://open-api-v4.coinglass.com/api/futures/ema/list",
      {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(10_000),
      },
    );
    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "futures/ema/list" });
      return _emaBulkCache?.data ?? new Map();
    }
    if (!res.ok) return _emaBulkCache?.data ?? new Map();

    const json = (await res.json()) as {
      code?: string;
      data?: Array<Record<string, unknown>>;
    };
    if (json.code !== "0" || !Array.isArray(json.data))
      return _emaBulkCache?.data ?? new Map();

    const result = new Map<string, EmaListEntry>();
    for (const row of json.data) {
      const sym = toCgBase(row.symbol);
      if (!sym) continue;
      result.set(sym, {
        ema1h: safeNum(row.ema_1h),
        ema4h: safeNum(row.ema_4h),
        ema1d: safeNum(row.ema_1d),
        closePrice: safeNum(row.close_price),
      });
    }
    _emaBulkCache = { data: result, ts: Date.now() };
    logger.debug({ count: result.size }, "loadEmaBulkMap: loaded");
    return result;
  } catch (err) {
    logger.debug({ err: String(err) }, "loadEmaBulkMap: error — fail-open");
    return _emaBulkCache?.data ?? new Map();
  }
}

// ── MACD List (/api/futures/macd/list) ───────────────────────────────────────

export interface MacdListEntry {
  macd1h: number | null;
  signal1h: number | null;
  macd4h: number | null;
  signal4h: number | null;
  macd1d: number | null;
  signal1d: number | null;
}

let _macdBulkCache: { data: Map<string, MacdListEntry>; ts: number } | null =
  null;

export async function loadMacdBulkMap(): Promise<Map<string, MacdListEntry>> {
  if (_macdBulkCache && Date.now() - _macdBulkCache.ts < BULK_CACHE_TTL)
    return _macdBulkCache.data;

  const apiKey = getNextCgKey();
  if (!apiKey) return new Map();

  try {
    const res = await fetch(
      "https://open-api-v4.coinglass.com/api/futures/macd/list",
      {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(10_000),
      },
    );
    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "futures/macd/list" });
      return _macdBulkCache?.data ?? new Map();
    }
    if (!res.ok) return _macdBulkCache?.data ?? new Map();

    const json = (await res.json()) as {
      code?: string;
      data?: Array<Record<string, unknown>>;
    };
    if (json.code !== "0" || !Array.isArray(json.data))
      return _macdBulkCache?.data ?? new Map();

    const result = new Map<string, MacdListEntry>();
    for (const row of json.data) {
      const sym = toCgBase(row.symbol);
      if (!sym) continue;
      result.set(sym, {
        macd1h: safeNum(row.macd_1h),
        signal1h: safeNum(row.signal_1h),
        macd4h: safeNum(row.macd_4h),
        signal4h: safeNum(row.signal_4h),
        macd1d: safeNum(row.macd_1d),
        signal1d: safeNum(row.signal_1d),
      });
    }
    _macdBulkCache = { data: result, ts: Date.now() };
    logger.debug({ count: result.size }, "loadMacdBulkMap: loaded");
    return result;
  } catch (err) {
    logger.debug({ err: String(err) }, "loadMacdBulkMap: error — fail-open");
    return _macdBulkCache?.data ?? new Map();
  }
}

// ── TD Sequential List (/api/futures/td/list) ─────────────────────────────────
// Положительное значение = buy setup (бычий сигнал).
// Отрицательное значение = sell setup (медвежий сигнал).
// |value| = 9 — завершённый setup (возможный разворот).

export interface TdListEntry {
  td1h: number | null;
  td4h: number | null;
  td1d: number | null;
  td1w: number | null;
}

let _tdBulkCache: { data: Map<string, TdListEntry>; ts: number } | null = null;

export async function loadTdBulkMap(): Promise<Map<string, TdListEntry>> {
  if (_tdBulkCache && Date.now() - _tdBulkCache.ts < BULK_CACHE_TTL)
    return _tdBulkCache.data;

  const apiKey = getNextCgKey();
  if (!apiKey) return new Map();

  try {
    const res = await fetch(
      "https://open-api-v4.coinglass.com/api/futures/td/list",
      {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(10_000),
      },
    );
    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "futures/td/list" });
      return _tdBulkCache?.data ?? new Map();
    }
    if (!res.ok) return _tdBulkCache?.data ?? new Map();

    const json = (await res.json()) as {
      code?: string;
      data?: Array<Record<string, unknown>>;
    };
    if (json.code !== "0" || !Array.isArray(json.data))
      return _tdBulkCache?.data ?? new Map();

    const result = new Map<string, TdListEntry>();
    for (const row of json.data) {
      const sym = toCgBase(row.symbol);
      if (!sym) continue;
      result.set(sym, {
        td1h: safeNum(row.td_1h),
        td4h: safeNum(row.td_4h),
        td1d: safeNum(row.td_1d),
        td1w: safeNum(row.td_1w),
      });
    }
    _tdBulkCache = { data: result, ts: Date.now() };
    logger.debug({ count: result.size }, "loadTdBulkMap: loaded");
    return result;
  } catch (err) {
    logger.debug({ err: String(err) }, "loadTdBulkMap: error — fail-open");
    return _tdBulkCache?.data ?? new Map();
  }
}

// ── ATR List (/api/futures/avg-true-range/list) ───────────────────────────────

export interface AtrListEntry {
  atr1h: number | null;
  atr4h: number | null;
  atr1d: number | null;
}

let _atrBulkCache: { data: Map<string, AtrListEntry>; ts: number } | null =
  null;

export async function loadAtrBulkMap(): Promise<Map<string, AtrListEntry>> {
  if (_atrBulkCache && Date.now() - _atrBulkCache.ts < BULK_CACHE_TTL)
    return _atrBulkCache.data;

  const apiKey = getNextCgKey();
  if (!apiKey) return new Map();

  try {
    const res = await fetch(
      "https://open-api-v4.coinglass.com/api/futures/avg-true-range/list",
      {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(10_000),
      },
    );
    if (res.status === 429) {
      logCg429(apiKey, { endpoint: "futures/avg-true-range/list" });
      return _atrBulkCache?.data ?? new Map();
    }
    if (!res.ok) return _atrBulkCache?.data ?? new Map();

    const json = (await res.json()) as {
      code?: string;
      data?: Array<Record<string, unknown>>;
    };
    if (json.code !== "0" || !Array.isArray(json.data))
      return _atrBulkCache?.data ?? new Map();

    const result = new Map<string, AtrListEntry>();
    for (const row of json.data) {
      const sym = toCgBase(row.symbol);
      if (!sym) continue;
      result.set(sym, {
        atr1h: safeNum(row.avg_true_range_1h),
        atr4h: safeNum(row.avg_true_range_4h),
        atr1d: safeNum(row.avg_true_range_1d),
      });
    }
    _atrBulkCache = { data: result, ts: Date.now() };
    logger.debug({ count: result.size }, "loadAtrBulkMap: loaded");
    return result;
  } catch (err) {
    logger.debug({ err: String(err) }, "loadAtrBulkMap: error — fail-open");
    return _atrBulkCache?.data ?? new Map();
  }
}
