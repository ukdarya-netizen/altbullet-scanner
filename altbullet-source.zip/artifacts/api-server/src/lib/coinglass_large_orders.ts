/**
 * CoinGlass — Futures Large Limit Orders (live).
 *
 * Живые крупные лимитные ордера в фьючерсном стакане Binance.
 * Применение: во время дампа крупные биды НИЖЕ цены = абсорбция
 * (кто-то крупный выставил стену на откуп паники) → boost-флаг в тексте
 * алерта liquidation_cascade. НЕ гейт — только обогащение.
 *
 * Endpoint: GET /api/futures/orderbook/large-limit-order
 *   ?symbol=BTCUSDT&exchange=Binance
 *
 * Определение бида: limit_price < текущей цены (надёжнее, чем enum order_side,
 * который в доках не описан; наблюдение: order_side=2 у resting-ордеров ниже рынка).
 * Учитываем только активные ордера (order_state=1) в пределах -6% от цены.
 *
 * Fail-open: null при любой ошибке. Кэш 5 мин.
 */

import { logger } from "./logger.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";

export interface LargeBidsResult {
  /** суммарный USD крупных бидов в пределах -6% от цены */
  totalBidUsd: number;
  /** число таких ордеров */
  orderCount: number;
  /** ближайший к цене бид (%от цены, отрицательный) */
  nearestBidPct: number | null;
}

const CACHE_TTL = 5 * 60 * 1000;
// Негативный кэш: пары нет на Binance (HTTP 4xx / нет данных) — не дёргаем CG повторно
const NEG_CACHE_TTL = 10 * 60 * 1000;
const cache = new Map<string, { result: LargeBidsResult | null; ts: number }>();

/** Насколько глубоко под ценой учитываем стены (-6%) */
const BID_RANGE_PCT = 0.06;

function toCgSymbol(bingxSymbol: string): string {
  return bingxSymbol.replace("-", "");
}

interface LargeOrderItem {
  limit_price: number;
  current_usd_value: number;
  order_state: number; // 1 = active
  order_side: number;
}

/**
 * Возвращает суммарные крупные биды под текущей ценой (стены на откуп).
 * Fail-open: null при любой ошибке.
 */
export async function getFuturesLargeBids(
  bingxSymbol: string,
  currentPrice: number,
  exchange = "Binance",
): Promise<LargeBidsResult | null> {
  if (!Number.isFinite(currentPrice) || currentPrice <= 0) return null;

  const cgSymbol = toCgSymbol(bingxSymbol);
  const cacheKey = `${exchange}:${cgSymbol}`;
  const cached = cache.get(cacheKey);
  if (
    cached &&
    Date.now() - cached.ts <
      (cached.result === null ? NEG_CACHE_TTL : CACHE_TTL)
  ) {
    return cached.result;
  }

  const apiKey = getNextCgKey();
  if (!apiKey) return null;

  const url = new URL(
    "https://open-api-v4.coinglass.com/api/futures/orderbook/large-limit-order",
  );
  url.searchParams.set("symbol", cgSymbol);
  url.searchParams.set("exchange", exchange);

  try {
    const res = await fetch(url.toString(), {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(4000),
    });

    if (res.status === 429) {
      logCg429(apiKey, {
        symbol: cgSymbol,
        endpoint: "orderbook/large-limit-order",
      });
      return null;
    }
    if (!res.ok) {
      logger.debug(
        { status: res.status, symbol: cgSymbol },
        "getFuturesLargeBids: HTTP error — fail-open",
      );
      cache.set(cacheKey, { result: null, ts: Date.now() });
      return null;
    }

    const json = (await res.json()) as {
      code: string;
      data?: LargeOrderItem[];
    };
    if (json.code !== "0" || !Array.isArray(json.data)) {
      cache.set(cacheKey, { result: null, ts: Date.now() });
      return null;
    }

    const minPrice = currentPrice * (1 - BID_RANGE_PCT);
    let totalBidUsd = 0;
    let orderCount = 0;
    let nearestBidPct: number | null = null;

    for (const o of json.data) {
      const price = Number(o.limit_price);
      const usd = Number(o.current_usd_value) || 0;
      if (o.order_state !== 1) continue; // только активные
      if (!Number.isFinite(price) || price >= currentPrice) continue; // только биды (ниже цены)
      if (price < minPrice) continue; // не глубже -6%
      totalBidUsd += usd;
      orderCount++;
      const pct = ((price - currentPrice) / currentPrice) * 100;
      if (nearestBidPct === null || pct > nearestBidPct) nearestBidPct = pct;
    }

    const result: LargeBidsResult = { totalBidUsd, orderCount, nearestBidPct };
    cache.set(cacheKey, { result, ts: Date.now() });
    return result;
  } catch (err) {
    logger.debug(
      { err: String(err), symbol: cgSymbol },
      "getFuturesLargeBids: fetch error — fail-open",
    );
    return null;
  }
}

// ── Spot Large Limit Orders ────────────────────────────────────────────────────
// Тот же формат данных, что и фьючерсный endpoint, но спотовый стакан Binance.
// Применение: Layer 11 Whale Alert — подтверждение крупными спот-бидами.
const spotCache = new Map<
  string,
  { result: LargeBidsResult | null; ts: number }
>();

/**
 * Возвращает суммарные крупные СПОТ-биды под текущей ценой (Binance).
 * Fail-open: null при любой ошибке / отсутствии пары на Binance-споте.
 */
export async function getSpotLargeBids(
  bingxSymbol: string,
  currentPrice: number,
  exchange = "Binance",
): Promise<LargeBidsResult | null> {
  if (!Number.isFinite(currentPrice) || currentPrice <= 0) return null;

  const cgSymbol = toCgSymbol(bingxSymbol);
  const cacheKey = `${exchange}:${cgSymbol}`;
  const cached = spotCache.get(cacheKey);
  if (
    cached &&
    Date.now() - cached.ts <
      (cached.result === null ? NEG_CACHE_TTL : CACHE_TTL)
  ) {
    return cached.result;
  }

  const apiKey = getNextCgKey();
  if (!apiKey) return null;

  const url = new URL(
    "https://open-api-v4.coinglass.com/api/spot/orderbook/large-limit-order",
  );
  url.searchParams.set("symbol", cgSymbol);
  url.searchParams.set("exchange", exchange);

  try {
    const res = await fetch(url.toString(), {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(4000),
    });

    if (res.status === 429) {
      logCg429(apiKey, {
        symbol: cgSymbol,
        endpoint: "spot/orderbook/large-limit-order",
      });
      return null;
    }
    if (!res.ok) {
      logger.debug(
        { status: res.status, symbol: cgSymbol },
        "getSpotLargeBids: HTTP error — fail-open",
      );
      spotCache.set(cacheKey, { result: null, ts: Date.now() });
      return null;
    }

    const json = (await res.json()) as {
      code: string;
      data?: LargeOrderItem[];
    };
    if (json.code !== "0" || !Array.isArray(json.data)) {
      spotCache.set(cacheKey, { result: null, ts: Date.now() });
      return null;
    }

    const minPrice = currentPrice * (1 - BID_RANGE_PCT);
    let totalBidUsd = 0;
    let orderCount = 0;
    let nearestBidPct: number | null = null;

    for (const o of json.data) {
      const price = Number(o.limit_price);
      const usd = Number(o.current_usd_value) || 0;
      if (o.order_state !== 1) continue;
      if (!Number.isFinite(price) || price >= currentPrice) continue;
      if (price < minPrice) continue;
      totalBidUsd += usd;
      orderCount++;
      const pct = ((price - currentPrice) / currentPrice) * 100;
      if (nearestBidPct === null || pct > nearestBidPct) nearestBidPct = pct;
    }

    const result: LargeBidsResult = { totalBidUsd, orderCount, nearestBidPct };
    spotCache.set(cacheKey, { result, ts: Date.now() });
    return result;
  } catch (err) {
    logger.debug(
      { err: String(err), symbol: cgSymbol },
      "getSpotLargeBids: fetch error — fail-open",
    );
    return null;
  }
}

// ── Large Order History — absorption vs spoof detection ──────────────────────
// Endpoint: GET /api/futures/orderbook/large-limit-order/history
// Возвращает недавно исполненные / отменённые крупные ордера в стакане.
// order_state: 1 = active (не интересует), 2 = filled (поглощён рынком), 3+ = cancelled/spoof.
// absorbed = true если ≥50% суммарного объёма бидов исполнено (не отменено).
// Cache 10 мин. Fail-open: null при любой ошибке.

export interface LargeObHistoryResult {
  /** USD крупных бид-ордеров, исполненных рынком (absorbed by buyers) */
  filledBidUsd: number;
  /** USD крупных бид-ордеров, отменённых выставителем (spoof / pulled) */
  cancelledBidUsd: number;
  /** Суммарный USD исторических крупных бидов в диапазоне −6% от цены */
  totalBidVol: number;
  /** true если filledBidUsd ≥ 50% от totalBidVol (стена выкуплена, а не убрана) */
  absorbed: boolean;
}

const histCache = new Map<
  string,
  { result: LargeObHistoryResult | null; ts: number }
>();
const HIST_CACHE_TTL = 10 * 60 * 1000; // 10 мин

interface LargeOrderHistoryItem {
  limit_price: number;
  current_usd_value: number;
  order_state: number; // 1=active, 2=filled, 3+=cancelled
  order_side: number;
}

/**
 * Возвращает статистику исполненных vs отменённых крупных бид-ордеров.
 * absorbed=true → большинство крупных бидов выкуплено рынком (реальное поглощение),
 * absorbed=false → большинство отменено (спуф / уход маркетмейкера).
 * Fail-open: null при любой ошибке или отсутствии данных.
 */
export async function getLargeObHistory(
  bingxSymbol: string,
  currentPrice: number,
  exchange = "Binance",
): Promise<LargeObHistoryResult | null> {
  if (!(currentPrice > 0)) return null;

  const cgSymbol = toCgSymbol(bingxSymbol);
  const cacheKey = `hist:${exchange}:${cgSymbol}`;
  const cached = histCache.get(cacheKey);
  if (
    cached &&
    Date.now() - cached.ts <
      (cached.result === null ? NEG_CACHE_TTL : HIST_CACHE_TTL)
  ) {
    return cached.result;
  }

  const apiKey = getNextCgKey();
  if (!apiKey) return null;

  const url = new URL(
    "https://open-api-v4.coinglass.com/api/futures/orderbook/large-limit-order/history",
  );
  url.searchParams.set("symbol", cgSymbol);
  url.searchParams.set("exchange", exchange);

  try {
    const res = await fetch(url.toString(), {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(4000),
    });

    if (res.status === 429) {
      logCg429(apiKey, {
        symbol: cgSymbol,
        endpoint: "orderbook/large-limit-order/history",
      });
      return null;
    }
    if (!res.ok) {
      logger.debug(
        { status: res.status, symbol: cgSymbol },
        "getLargeObHistory: HTTP error — fail-open",
      );
      histCache.set(cacheKey, { result: null, ts: Date.now() });
      return null;
    }

    const json = (await res.json()) as {
      code: string;
      data?: LargeOrderHistoryItem[];
    };
    if (json.code !== "0" || !Array.isArray(json.data)) {
      histCache.set(cacheKey, { result: null, ts: Date.now() });
      return null;
    }

    let filledBidUsd = 0;
    let cancelledBidUsd = 0;
    let totalBidVol = 0;
    const minPrice = currentPrice * (1 - BID_RANGE_PCT);

    for (const o of json.data) {
      const price = Number(o.limit_price);
      const usd = Number(o.current_usd_value) || 0;
      if (!Number.isFinite(price) || price >= currentPrice) continue; // только биды
      if (price < minPrice) continue; // в пределах −6%
      // order_state=1 = всё ещё активен → пропускаем (не исторические данные)
      if (o.order_state === 1) continue;
      totalBidVol += usd; // только завершённые ордера (filled + cancelled)
      if (o.order_state === 2)
        filledBidUsd += usd; // исполнен рынком = поглощение
      else cancelledBidUsd += usd; // отменён/закрыт = возможный спуф
    }

    // absorbed: большинство завершённых бидов исполнено (не отменено)
    const absorbed = totalBidVol > 0 && filledBidUsd >= totalBidVol * 0.5;
    const result: LargeObHistoryResult = {
      filledBidUsd,
      cancelledBidUsd,
      totalBidVol,
      absorbed,
    };
    histCache.set(cacheKey, { result, ts: Date.now() });
    return result;
  } catch (err) {
    logger.debug(
      { err: String(err), symbol: cgSymbol },
      "getLargeObHistory: fetch error — fail-open",
    );
    return null;
  }
}

// ── Bid Wall Absorption — cross-cycle snapshot comparison ────────────────────
// Сохраняем снимок суммарных крупных бидов от предыдущего цикла (~10 мин).
// При следующем цикле: стена уменьшилась ≥35% при стабильной цене = поглощена.
const _prevBidSnapshot = new Map<
  string,
  { totalBidUsd: number; price: number; ts: number }
>();

export interface LargeObComparisonResult {
  current: LargeBidsResult;
  prevTotalBidUsd: number | null;
  prevPrice: number | null;
  /** true — стена уменьшилась ≥35% при стабильной или растущей цене */
  absorbed: boolean;
}

/**
 * Получает текущий снимок крупных бидов, сравнивает с предыдущим (из памяти),
 * обновляет снимок. absorbed = true если текущие биды ≤65% от prev И цена не упала ≥1%.
 * Fail-open: null при любой ошибке (getFuturesLargeBids недоступен).
 */
export async function getLargeObComparison(
  bingxSymbol: string,
  currentPrice: number,
): Promise<LargeObComparisonResult | null> {
  const current = await getFuturesLargeBids(bingxSymbol, currentPrice);
  if (!current) return null;

  const prev = _prevBidSnapshot.get(bingxSymbol);
  const prevTotalBidUsd = prev?.totalBidUsd ?? null;
  const prevPrice = prev?.price ?? null;

  let absorbed = false;
  if (prev && prevTotalBidUsd !== null && prevTotalBidUsd > 0) {
    const bidDeclined = current.totalBidUsd < prevTotalBidUsd * 0.65; // ≥35% уменьшение
    const priceStable = currentPrice >= prev.price * 0.99; // цена не упала ≥1%
    absorbed = bidDeclined && priceStable;
  }

  _prevBidSnapshot.set(bingxSymbol, {
    totalBidUsd: current.totalBidUsd,
    price: currentPrice,
    ts: Date.now(),
  });
  return { current, prevTotalBidUsd, prevPrice, absorbed };
}
