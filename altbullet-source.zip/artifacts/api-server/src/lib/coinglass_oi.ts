/**
 * CoinGlass — агрегированный OI по всем биржам (OHLC history).
 *
 * Endpoint: GET /api/futures/open-interest/aggregated-history
 *           ?symbol=BTC&interval=30m&limit=50
 * Header: CG-API-KEY: <API_KEY>
 * Plan: Professional (open-api-v4.coinglass.com)
 *
 * Из 50 × 30m свечей вычисляем:
 *   oiChange30m  — дельта последней свечи
 *   prevOi30m    — дельта предпредпоследней (candle[-2]) — без цикл-сдвига
 *   oiChange1h   — дельта за 2 свечи (1 час)
 *   oiChange4h   — дельта за 8 свечей (4 часа)
 *   oiChange24h  — дельта за 48 свечей (24 часа)
 *   positiveCandles6h   — кол-во 30m свечей с ростом за последние 6ч
 *   oiConsecutiveUp     — подряд идущих 30m свечей роста от конца
 *   oi4hConsecFromOhlc  — подряд 4h-периодов роста OI (из 30m свечей)
 *
 * Кэш: 5 мин на символ.
 */

import { logger } from "./logger.js";
import { reportApiSuccess, reportApiFailure } from "./apiHealth.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";
import { cgTimedFetch } from "./cg_latency.js";
import { getOpenInterest } from "./bingx.js";

/** Бросается когда circuit breaker срабатывает — CoinGlass явно недоступен */
export class CoinglassOutageError extends Error {
  constructor(public readonly skipped: number) {
    super(
      `CoinGlass API недоступен — circuit breaker сработал, пропущено ${skipped} токенов`,
    );
    this.name = "CoinglassOutageError";
  }
}

export interface CoinglassOIResult {
  /** Агрегированное изменение OI за 30 минут в % (последняя OHLC свеча) */
  oiChange30m: number | null;
  /** OI за ПРЕДЫДУЩИЙ 30m период (candle[-2]) — напрямую из OHLC, без цикл-сдвига */
  prevOi30m: number | null;
  /** Агрегированное изменение OI за 1 час в % */
  oiChange1h: number | null;
  /** Агрегированное изменение OI за 4 часа в % */
  oiChange4h: number | null;
  /** Агрегированное изменение OI за 24 часа в % */
  oiChange24h: number | null;
  /** Абсолютный OI в USD (close последней свечи) */
  oiUsd: number | null;
  /** Всегда null: OHLC endpoint не содержит volume-данных */
  cgVolUsd: number | null;
  /** Всегда null: OHLC агрегат без per-exchange breakdown */
  bingxOiChange30m: number | null;
  /** Кол-во 30m свечей с ростом OI за последние 6ч (из 12 свечей) */
  positiveCandles6h: number | null;
  /** Кол-во последовательных 30m свечей с ростом OI от конца ряда */
  oiConsecutiveUp: number | null;
  /** Кол-во последовательных 4h-периодов роста OI (вычисляется из 30m свечей) */
  oi4hConsecFromOhlc: number | null;
  available: boolean;
  /** true = запрос упал по таймауту */
  timedOut: boolean;
  /** true = available:false из-за подозрения на коллизию тикера в CoinGlass */
  collisionSuspected?: boolean;
  source: "coinglass" | "prescan_stale";
}

const cache = new Map<string, { result: CoinglassOIResult; ts: number }>();
const CACHE_TTL = 5 * 60 * 1000;

/**
 * Кросс-валидация против собственного OI на BingX (2026-07-09, US-USDT case).
 * Короткие/общие тикеры иногда коллизят с другим инструментом внутри CoinGlass.
 */
const bingxOiCache = new Map<string, { oiUsd: number | null; ts: number }>();
const BINGX_OI_CACHE_TTL = 5 * 60 * 1000;
const OI_MISMATCH_RATIO = 30;

async function getBingxOiUsdCached(symbol: string): Promise<number | null> {
  const cached = bingxOiCache.get(symbol);
  if (cached && Date.now() - cached.ts < BINGX_OI_CACHE_TTL)
    return cached.oiUsd;
  let oiUsd: number | null = null;
  try {
    const oi = await getOpenInterest(symbol);
    const amount =
      oi?.openInterest != null ? parseFloat(oi.openInterest) : null;
    if (amount != null && Number.isFinite(amount) && amount > 0) {
      oiUsd = amount;
    }
  } catch {
    /* недоступность BingX OI не блокирует основной путь */
  }
  bingxOiCache.set(symbol, { oiUsd, ts: Date.now() });
  return oiUsd;
}

/** BingX-символ → базовый тикер для CoinGlass */
export const CG_SYMBOL_ALIAS: Record<string, string> = {
  USELES: "USELESS",
};

function toBaseSymbol(bingxSymbol: string): string {
  const base = bingxSymbol.replace("-USDT", "");
  return CG_SYMBOL_ALIAS[base] ?? base;
}

/** Кандидаты: сначала base, затем base+USDT (некоторые токены в CG с суффиксом) */
function cgSymbolCandidates(base: string): string[] {
  const candidates = [base];
  if (!base.endsWith("USDT")) candidates.push(base + "USDT");
  return candidates;
}

interface OiHistoryCandle {
  time: number;
  close: string | number;
}

const CG_FETCH_TIMEOUT_MS = 5000;
const CG_RETRY_DELAY_MS = 250;

interface FetchOiHistoryResult {
  candles: OiHistoryCandle[] | null;
  timedOut: boolean;
}

/**
 * Один HTTP-запрос к CoinGlass aggregated-history (v4 Professional).
 * Retry при HTTP-ошибках (не при пустом массиве — символ просто не в CG).
 */
async function fetchOiOhlcHistory(
  cgSymbol: string,
  apiKey: string,
): Promise<FetchOiHistoryResult> {
  const url =
    `https://open-api-v4.coinglass.com/api/futures/open-interest/aggregated-history` +
    `?symbol=${encodeURIComponent(cgSymbol)}&interval=30m&limit=50`;

  async function doFetch(key: string): Promise<FetchOiHistoryResult> {
    try {
      const res = await cgTimedFetch(url, {
        headers: { "CG-API-KEY": key, Accept: "application/json" },
        signal: AbortSignal.timeout(CG_FETCH_TIMEOUT_MS),
      });
      if (res.status === 429) {
        logCg429(key, { symbol: cgSymbol });
        return { candles: null, timedOut: false };
      }
      if (!res.ok) return { candles: null, timedOut: false };
      const json = (await res.json()) as {
        code?: string;
        data?: OiHistoryCandle[];
      };
      if (
        json.code !== "0" ||
        !Array.isArray(json.data) ||
        json.data.length === 0
      ) {
        return { candles: null, timedOut: false };
      }
      return { candles: json.data, timedOut: false };
    } catch (err) {
      const timedOut =
        err instanceof Error &&
        (err.name === "TimeoutError" || err.name === "AbortError");
      return { candles: null, timedOut };
    }
  }

  const first = await doFetch(apiKey);
  if (first.candles || first.timedOut) return first;

  // HTTP-ошибка (не пустой массив) → retry с другим ключом
  await new Promise<void>((r) => setTimeout(r, CG_RETRY_DELAY_MS));
  const retryKey = getNextCgKey();
  if (!retryKey) return first;
  logger.warn(
    { symbol: cgSymbol, key: apiKey.slice(-4) },
    "CoinGlass OI OHLC: HTTP ошибка — retry с другим ключом",
  );
  return doFetch(retryKey);
}

/**
 * Вычисляет % изменение: (current - ref) / |ref| * 100.
 * Возвращает null если reference == 0 или null.
 */
function pct(current: number, ref: number | null | undefined): number | null {
  if (ref == null || ref === 0) return null;
  return ((current - ref) / Math.abs(ref)) * 100;
}

/**
 * Вычисляет все OI-метрики из массива OHLC свечей (отсортированных по времени, oldest first).
 * limit=50 × 30m = 25 часов сырых данных → 48 дельт для 24h.
 */
function computeOiMetrics(
  candles: OiHistoryCandle[],
): Omit<
  CoinglassOIResult,
  | "cgVolUsd"
  | "bingxOiChange30m"
  | "available"
  | "timedOut"
  | "source"
  | "collisionSuspected"
> {
  const sorted = [...candles].sort((a, b) => a.time - b.time);
  const closes = sorted.map((c) =>
    typeof c.close === "string" ? parseFloat(c.close) : c.close,
  );
  const n = closes.length;

  const nullResult = {
    oiChange30m: null,
    prevOi30m: null,
    oiChange1h: null,
    oiChange4h: null,
    oiChange24h: null,
    oiUsd: null,
    positiveCandles6h: null,
    oiConsecutiveUp: null,
    oi4hConsecFromOhlc: null,
  };

  if (n < 3) return nullResult;

  const latest = closes[n - 1];

  const oiChange30m = pct(latest, closes[n - 2]);
  const prevOi30m = pct(closes[n - 2] ?? 0, closes[n - 3]); // prev 30m period
  const oiChange1h = pct(latest, closes[n - 3]); // 2 × 30m
  const oiChange4h = n >= 9 ? pct(latest, closes[n - 9]) : null; // 8 × 30m
  const oiChange24h = n >= 49 ? pct(latest, closes[n - 49]) : null; // 48 × 30m

  // Кол-во 30m свечей роста в последних 6ч (12 свечей)
  let positiveCandles6h = 0;
  const from6h = Math.max(1, n - 12);
  for (let i = from6h; i < n; i++) {
    if (closes[i] > closes[i - 1]) positiveCandles6h++;
  }

  // Подряд идущих 30m свечей роста от конца
  let oiConsecutiveUp = 0;
  for (let i = n - 1; i >= 1; i--) {
    if (closes[i] > closes[i - 1]) oiConsecutiveUp++;
    else break;
  }

  // Подряд 4h-периодов роста OI (каждый период = 8 × 30m свечей)
  // Сравниваем close[n-1] vs close[n-9] (период 0), close[n-9] vs close[n-17] (период 1), ...
  let oi4hConsecFromOhlc = 0;
  const fourH = 8;
  for (let p = 0; p < 6; p++) {
    const hi = n - 1 - p * fourH;
    const lo = hi - fourH;
    if (lo < 0) break;
    if (closes[hi] > closes[lo]) oi4hConsecFromOhlc++;
    else break;
  }

  return {
    oiChange30m,
    prevOi30m,
    oiChange1h,
    oiChange4h,
    oiChange24h,
    oiUsd: latest,
    positiveCandles6h,
    oiConsecutiveUp,
    oi4hConsecFromOhlc,
  };
}

export async function getCoinglassOI(
  symbol: string,
  priceUsd?: number | null,
): Promise<CoinglassOIResult> {
  const apiKey = getNextCgKey();

  const noData: CoinglassOIResult = {
    oiChange30m: null,
    prevOi30m: null,
    oiChange1h: null,
    oiChange4h: null,
    oiChange24h: null,
    oiUsd: null,
    cgVolUsd: null,
    bingxOiChange30m: null,
    positiveCandles6h: null,
    oiConsecutiveUp: null,
    oi4hConsecFromOhlc: null,
    available: false,
    timedOut: false,
    source: "coinglass",
  };

  if (!apiKey) return noData;

  const base = toBaseSymbol(symbol);
  const cached = cache.get(base);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.result;

  try {
    const candidates = cgSymbolCandidates(base);
    let candles: OiHistoryCandle[] | null = null;
    let usedCgSymbol = base;
    let anyTimedOut = false;

    for (const cgSym of candidates) {
      const attempt = await fetchOiOhlcHistory(cgSym, apiKey).catch(
        (): FetchOiHistoryResult => ({ candles: null, timedOut: false }),
      );
      if (attempt.timedOut) anyTimedOut = true;
      if (attempt.candles) {
        candles = attempt.candles;
        usedCgSymbol = cgSym;
        break;
      }
    }

    if (!candles) {
      logger.info(
        { symbol, tried: candidates, timedOut: anyTimedOut },
        "CoinGlass OI OHLC: нет данных ни по одному кандидату символа",
      );
      reportApiFailure("coinglass", 0);
      return { ...noData, timedOut: anyTimedOut };
    }
    if (usedCgSymbol !== base) {
      logger.info(
        { symbol, base, usedCgSymbol },
        "CoinGlass OI OHLC: данные найдены по fallback-символу — добавь в CG_SYMBOL_ALIAS",
      );
    }

    const metrics = computeOiMetrics(candles);

    if (metrics.oiUsd == null) {
      logger.info(
        { symbol, candleCount: candles.length },
        "CoinGlass OI OHLC: < 3 свечей — нет данных",
      );
      reportApiFailure("coinglass", 0);
      return { ...noData, timedOut: anyTimedOut };
    }

    const result: CoinglassOIResult = {
      ...metrics,
      cgVolUsd: null,
      bingxOiChange30m: null,
      available: true,
      timedOut: false,
      source: "coinglass",
    };

    // Кросс-валидация магнитуды против прямого BingX OI (коллизия тикера).
    if (
      priceUsd != null &&
      priceUsd > 0 &&
      result.oiUsd != null &&
      result.oiUsd > 0
    ) {
      const bingxOiUsd = await getBingxOiUsdCached(symbol);
      if (bingxOiUsd != null && bingxOiUsd > 0) {
        const ratio = result.oiUsd / bingxOiUsd;
        if (ratio > OI_MISMATCH_RATIO || ratio < 1 / OI_MISMATCH_RATIO) {
          logger.debug(
            {
              symbol,
              base,
              usedCgSymbol,
              cgOiUsd: result.oiUsd.toFixed(0),
              bingxOiUsd: bingxOiUsd.toFixed(0),
              ratio: ratio.toFixed(1),
            },
            "CoinGlass OI OHLC: подозрение на коллизию тикера — данные отброшены",
          );
          reportApiFailure("coinglass", 0);
          const mismatch: CoinglassOIResult = {
            ...noData,
            source: "coinglass",
            collisionSuspected: true,
          };
          cache.set(usedCgSymbol, { result: mismatch, ts: Date.now() });
          return mismatch;
        }
      }
    }

    reportApiSuccess("coinglass");
    cache.set(usedCgSymbol, { result, ts: Date.now() });
    logger.debug(
      {
        symbol,
        oi30m: result.oiChange30m?.toFixed(2) + "%",
        prev30m: result.prevOi30m?.toFixed(2) + "%",
        oi1h: result.oiChange1h?.toFixed(2) + "%",
        oi4h:
          result.oiChange4h != null
            ? result.oiChange4h.toFixed(2) + "%"
            : "n/a",
        oi24h:
          result.oiChange24h != null
            ? result.oiChange24h.toFixed(2) + "%"
            : "n/a",
        pos6h: result.positiveCandles6h,
        consec: result.oiConsecutiveUp,
        consec4h: result.oi4hConsecFromOhlc,
        oiUsd: result.oiUsd?.toFixed(0),
      },
      "CoinGlass OI OHLC fetched",
    );
    return result;
  } catch (err) {
    logger.warn({ symbol, err }, "CoinGlass OI OHLC fetch error");
    reportApiFailure("coinglass");
    const isTimeout =
      err instanceof Error &&
      (err.name === "TimeoutError" || err.name === "AbortError");
    return { ...noData, timedOut: isTimeout };
  }
}

/**
 * Батч-получение CoinGlass OI для списка BingX-символов.
 * Возвращает Map<symbol, CoinglassOIResult> для всех запрошенных символов.
 *
 * Rate limit Professional: 600 req/min.
 * Стратегия: semaphore CONCURRENCY=5 + MIN_SLOT_DELAY_MS=400ms.
 * Rate math: ≤5 параллельных, старт не чаще 1 раз/400ms → ~2.5 req/s на процесс.
 * 2 воркера × 2.5 = ~5 req/s суммарно << 10 req/s лимита ✓
 *
 * Circuit breaker: 6 последовательных тайм-аутов → помечаем остаток как unavailable.
 */
export async function batchGetCoinglassOI(
  bingxSymbols: string[],
  priceMap?: Map<string, number>,
  skipSymbols?: Set<string>,
): Promise<Map<string, CoinglassOIResult>> {
  const results = new Map<string, CoinglassOIResult>();

  const emptyResult: CoinglassOIResult = {
    available: false,
    timedOut: false,
    oiChange30m: null,
    prevOi30m: null,
    oiChange1h: null,
    oiChange4h: null,
    oiChange24h: null,
    oiUsd: null,
    cgVolUsd: null,
    bingxOiChange30m: null,
    positiveCandles6h: null,
    oiConsecutiveUp: null,
    oi4hConsecFromOhlc: null,
    source: "coinglass" as const,
  };

  // Phase 1: return cached results immediately
  const toFetch: string[] = [];
  for (const symbol of bingxSymbols) {
    if (skipSymbols?.has(symbol)) {
      results.set(symbol, emptyResult);
      continue;
    }
    const base = toBaseSymbol(symbol);
    const cached = cache.get(base);
    if (cached && Date.now() - cached.ts < CACHE_TTL) {
      results.set(symbol, cached.result);
    } else {
      toFetch.push(symbol);
    }
  }

  if (toFetch.length === 0) return results;

  const CONCURRENCY = 5;
  const MIN_SLOT_DELAY_MS = 400;
  const CIRCUIT_BREAKER_THRESHOLD = 6;

  // Jitter: два воркера не стартуют синхронно
  await new Promise((r) => setTimeout(r, Math.floor(Math.random() * 2000)));

  let activeSlots = 0;
  let consecutiveTimeouts = 0;
  let circuitBroken = false;
  let lastStartAt = 0;
  const waiting: Array<() => void> = [];

  function acquireSlot(): Promise<void> {
    return new Promise((resolve) => {
      if (activeSlots < CONCURRENCY) {
        activeSlots++;
        resolve();
      } else waiting.push(resolve);
    });
  }

  function releaseSlot(): void {
    activeSlots--;
    const next = waiting.shift();
    if (next) {
      activeSlots++;
      next();
    }
  }

  async function fetchOne(sym: string): Promise<void> {
    if (circuitBroken) {
      results.set(sym, emptyResult);
      return;
    }
    await acquireSlot();
    if (circuitBroken) {
      results.set(sym, emptyResult);
      releaseSlot();
      return;
    }

    const gap = lastStartAt + MIN_SLOT_DELAY_MS - Date.now();
    if (gap > 0) await new Promise((r) => setTimeout(r, gap));
    lastStartAt = Date.now();

    try {
      const val = await getCoinglassOI(sym, priceMap?.get(sym));
      results.set(sym, val);
      if (val.timedOut) {
        consecutiveTimeouts++;
        if (consecutiveTimeouts >= CIRCUIT_BREAKER_THRESHOLD) {
          circuitBroken = true;
          logger.warn(
            { consecutiveTimeouts, pending: waiting.length },
            "CoinGlass OI OHLC circuit breaker сработал — API не отвечает, пропускаем остаток",
          );
        }
      } else {
        consecutiveTimeouts = 0;
      }
    } catch {
      results.set(sym, emptyResult);
    } finally {
      releaseSlot();
    }
  }

  await Promise.all(toFetch.map((sym) => fetchOne(sym)));
  return results;
}

/** Сброс кэша для тестов */
export function clearCoinglassOICache(): void {
  cache.clear();
}

// ── CG Supported Futures Coins whitelist ──────────────────────────────────────
// GET /api/futures/supported-coins → ["BTC","ETH","SOL",...]
// Используется как ЕДИНСТВЕННЫЙ источник истины для определения наличия токена в CG.
// Заменяет эвристику cgNoDataCount >= 3 как механизм классификации.
let _cgSupportedCoins: Set<string> | null = null;
let _cgSupportedCoinsTs = 0;
const CG_SUPPORTED_CACHE_TTL_MS = 12 * 60 * 60 * 1000; // 12 часов

/**
 * Загружает список всех фьючерсных монет, покрытых CoinGlass.
 * Вызывается при старте и раз в 12 часов.
 * Fail-open: при ошибке оставляет старый список (или null если первый запуск).
 */
export async function refreshCgSupportedCoins(): Promise<void> {
  const key = getNextCgKey();
  if (!key) return;
  try {
    const res = await cgTimedFetch(
      "https://open-api-v4.coinglass.com/api/futures/supported-coins",
      {
        headers: { "CG-API-KEY": key, Accept: "application/json" },
        signal: AbortSignal.timeout(10_000),
      },
    );
    if (!res.ok) {
      logger.warn({ status: res.status }, "CG supported-coins: HTTP error");
      return;
    }
    const json = (await res.json()) as { code?: string; data?: string[] };
    if (
      json.code !== "0" ||
      !Array.isArray(json.data) ||
      json.data.length === 0
    ) {
      logger.warn(
        { code: json.code, len: json.data?.length ?? 0 },
        "CG supported-coins: unexpected response",
      );
      return;
    }
    _cgSupportedCoins = new Set(json.data);
    _cgSupportedCoinsTs = Date.now();
    logger.info(
      { count: _cgSupportedCoins.size },
      "CoinGlass: supported-coins whitelist обновлён",
    );
  } catch (err) {
    logger.warn(
      { err },
      "CoinGlass: не удалось обновить supported-coins whitelist (non-critical)",
    );
  }
}

/**
 * Возвращает Set базовых символов, которые CoinGlass точно покрывает.
 * null = список ещё не загружен (используй cgNoDataCount как fallback).
 * Стале через 12ч → возвращает null (фоновый refresh должен обновить).
 */
export function getCgSupportedCoinsSet(): Set<string> | null {
  if (!_cgSupportedCoins) return null;
  if (Date.now() - _cgSupportedCoinsTs > CG_SUPPORTED_CACHE_TTL_MS) return null;
  return _cgSupportedCoins;
}
