/**
 * CoinGlass — кросс-биржевой Taker Buy/Sell Flow.
 *
 * Запрашивает объём агрессивных покупок и продаж за последние 4 свечи по 15m
 * по пяти биржам (Binance + Bybit + OKX + Bitget + BingX) и агрегирует их.
 *
 * Используется как РАННИЙ ПРЕ-ФИЛЬТР (до детекции паттерна):
 * оба цикла должны показывать нетто-покупки (покупки > продажи два периода подряд).
 * Если продавцы доминируют — рост OI скорее всего от шортов, не от покупателей.
 *
 * Endpoint: GET /api/futures/taker-buy-sell-volume/history
 *   ?symbol=<exchange-specific>&exchange=<name>&interval=15m&limit=4
 * Header: CG-API-KEY: <key>
 *
 * Каждая биржа использует свой формат instrument_id в CoinGlass:
 *   Binance / Bybit  → BTCUSDT        (без дефиса)
 *   BingX            → BTC-USDT       (с дефисом — оригинальный BingX формат)
 *   Bitget           → BTCUSDT_UMCBL  (без дефиса + суффикс _UMCBL)
 *   OKX              → BTC-USDT-SWAP  (с дефисом + суффикс -SWAP)
 *
 * План Standard: доступны интервалы 15m, 30m, 1h.
 * Используем 15m — 4 свечи = 1 час истории с детализацией по четвертям.
 * cvdRising2 проверяет что последние 2 свечи (30 мин) показывают устойчивый поток.
 * Кэш: 3 мин (15m свечи обновляются часто, нужна свежесть).
 */

import { logger } from "./logger.js";
import { reportApiSuccess, reportApiFailure } from "./apiHealth.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";

export interface TakerCycle {
  delta: number; // buy - sell (USD)
  netBuyPct: number; // (buy - sell) / (buy + sell) * 100
}

export interface TakerFlowResult {
  buyUsd: number;
  sellUsd: number;
  netBuyPct: number; // (buy - sell) / (buy + sell) * 100 — последний цикл (15m)
  dominance: "buy" | "sell" | "neutral";
  available: boolean;
  exchanges: string[]; // какие биржи ответили
  cycles: TakerCycle[]; // [более старый, более новый] — до 2 элементов
  cvdRising2: boolean; // оба цикла положительные И второй >= 50% первого
  /** Последняя свеча: net buy > 0. null если данные недоступны. */
  cvdShort: boolean | null;
  /**
   * Суммарный netBuyPct за 1 час: (buy1h - sell1h) / (buy1h + sell1h) * 100.
   * Per-symbol: агрегат 4 × 15m свечей. Batch: из netflow-list taker_*_1h напрямую.
   * null если данных нет.
   */
  takerNetBuy1h: number | null;
  /**
   * Суммарный 1h taker объём (buy + sell) по всем кросс-биржевым данным CG.
   * Только batch-mode (netflow-list); per-symbol: null.
   * Используется для кросс-биржевого подтверждения объёма (замена 4 per-exchange API).
   */
  volUsd1h?: number | null;
}

// Binance: покрывает все mainstream листинги.
// BingX: покрывает BingX-exclusive токены (EDGEX и подобные — данные только на BingX).
// Bybit / OKX / Bitget убраны: везде где они Y → Binance тоже Y (дублирование без прироста).
// Итог: 4 вызова вместо 10 при сохранении полного покрытия.
const EXCHANGES = ["Binance", "BingX"] as const;
type CgExchange = (typeof EXCHANGES)[number];

const CACHE_TTL = 3 * 60 * 1000; // 3 мин — 15m свечи обновляются часто

const cache = new Map<string, { result: TakerFlowResult; ts: number }>();

/**
 * Конвертирует BingX символ ("BTC-USDT") в instrument_id нужной биржи на CoinGlass.
 *   Binance → BTCUSDT  (remove hyphen)
 *   BingX   → BTC-USDT (original BingX format, keep hyphen)
 */
function toExchangeSymbol(bingxSymbol: string, exchange: CgExchange): string {
  switch (exchange) {
    case "Binance":
      return bingxSymbol.replace("-", "");
    case "BingX":
      return bingxSymbol;
  }
}

interface CgTakerCandle {
  time: number;
  taker_buy_volume_usd: string;
  taker_sell_volume_usd: string;
}

async function fetchOneExchange(
  bingxSymbol: string,
  exchange: CgExchange,
  apiKey: string,
  interval: "15m" = "15m",
  limit: number = 4,
): Promise<CgTakerCandle[] | null> {
  const symbol = toExchangeSymbol(bingxSymbol, exchange);
  const url = new URL(
    "https://open-api-v4.coinglass.com/api/futures/taker-buy-sell-volume/history",
  );
  url.searchParams.set("symbol", symbol);
  url.searchParams.set("exchange", exchange);
  url.searchParams.set("interval", interval);
  url.searchParams.set("limit", String(limit));

  let retryReason: string | null = null;

  try {
    const res = await fetch(url.toString(), {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(6000),
    });

    if (res.status === 429) {
      logCg429(apiKey, { symbol, exchange });
      reportApiFailure("coinglass", 429);
      return null;
    }
    if (!res.ok) {
      retryReason = `HTTP ${res.status}`;
    } else {
      const data = (await res.json()) as {
        code: string;
        data?: CgTakerCandle[];
      };
      if (data.code !== "0") return null;
      if (!data.data?.length) {
        retryReason = "пустой массив";
      } else {
        reportApiSuccess("coinglass");
        return data.data;
      }
    }
  } catch {
    return null;
  }

  // Единый retry-блок для !res.ok и пустого массива data
  logger.warn(
    { symbol, exchange, reason: retryReason, key: apiKey.slice(-4) },
    "CoinGlass Taker: ошибка ответа — retry с другим ключом через 300ms",
  );
  await new Promise<void>((r) => setTimeout(r, 300));
  const retryKey = getNextCgKey();
  if (!retryKey) return null;
  try {
    const retryRes = await fetch(url.toString(), {
      headers: { "CG-API-KEY": retryKey, Accept: "application/json" },
      signal: AbortSignal.timeout(6000),
    });
    if (!retryRes.ok) return null;
    const retryData = (await retryRes.json()) as {
      code: string;
      data?: CgTakerCandle[];
    };
    if (retryData.code !== "0") return null;
    if (retryData.data?.length) {
      logger.info(
        { symbol, exchange },
        "CoinGlass Taker: retry успешен — данные получены",
      );
      reportApiSuccess("coinglass");
      return retryData.data;
    }
  } catch {
    // retry failed
  }
  return null;
}

/**
 * Возвращает агрегированный Taker Buy/Sell Flow за последние 2 часа
 * по Binance + Bybit (2 свечи по 1h). Кэшируется 5 мин.
 *
 * cvdRising2 = true если оба часовых периода показывают нетто-покупки
 * И второй (более свежий) не слабее 50% от первого — устойчивый поток, не разовый всплеск.
 */
export async function getCoinglassTakerFlow(
  symbol: string,
): Promise<TakerFlowResult> {
  const apiKey = getNextCgKey();

  const noData: TakerFlowResult = {
    buyUsd: 0,
    sellUsd: 0,
    netBuyPct: 0,
    dominance: "neutral",
    available: false,
    exchanges: [],
    cycles: [],
    cvdRising2: false,
    cvdShort: null,
    takerNetBuy1h: null,
  };

  if (!apiKey) return noData;

  const cached = cache.get(symbol);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return cached.result;

  // Фетчим 15m (4 свечи = 1ч) по всем биржам
  const responses15m = await Promise.all(
    EXCHANGES.map((ex) => fetchOneExchange(symbol, ex, apiKey, "15m", 4)),
  );

  // ── 15m агрегат ──────────────────────────────────────────────────────────────
  const candleCount = 4;
  const aggregated: Array<{ buy: number; sell: number }> = Array.from(
    { length: candleCount },
    () => ({ buy: 0, sell: 0 }),
  );
  const responded: string[] = [];

  for (let ei = 0; ei < EXCHANGES.length; ei++) {
    const candles = responses15m[ei];
    if (!candles || candles.length === 0) continue;
    responded.push(EXCHANGES[ei]);
    const start = Math.max(0, candles.length - candleCount);
    for (let ci = start; ci < candles.length; ci++) {
      const slot = ci - start;
      const c = candles[ci]!;
      aggregated[slot]!.buy += parseFloat(c.taker_buy_volume_usd) || 0;
      aggregated[slot]!.sell += parseFloat(c.taker_sell_volume_usd) || 0;
    }
  }

  if (responded.length === 0) {
    cache.set(symbol, { result: noData, ts: Date.now() });
    return noData;
  }

  // Строим cycles (только те слоты где есть данные)
  const cycles: TakerCycle[] = aggregated
    .filter((a) => a.buy + a.sell > 0)
    .map((a) => {
      const total = a.buy + a.sell;
      const netPct = total > 0 ? ((a.buy - a.sell) / total) * 100 : 0;
      return { delta: a.buy - a.sell, netBuyPct: netPct };
    });

  // Итоговые цифры берём из последней (самой свежей) 15m свечи
  const last = aggregated[aggregated.length - 1]!;
  const total = last.buy + last.sell;
  const netBuyPct = total > 0 ? ((last.buy - last.sell) / total) * 100 : 0;

  const dominance: TakerFlowResult["dominance"] =
    netBuyPct > 2 ? "buy" : netBuyPct < -2 ? "sell" : "neutral";

  // CVD 2-цикла: оба положительные И новый >= 50% от старого (поток устойчив, не ослаб)
  let cvdRising2 = false;
  if (cycles.length >= 2) {
    const older = cycles[cycles.length - 2]!;
    const newer = cycles[cycles.length - 1]!;
    cvdRising2 =
      older.delta > 0 && newer.delta > 0 && newer.delta >= older.delta * 0.5;
  } else if (cycles.length === 1) {
    cvdRising2 = cycles[0]!.delta > 0;
  }

  // cvdShort: последняя 15m свеча — net buy > 0
  const cvdShort: boolean | null =
    last.buy + last.sell > 0 ? last.buy > last.sell : null;

  // 1h aggregate: сумма всех 4 × 15m слотов
  let buy1h = 0,
    sell1h = 0;
  for (const slot of aggregated) {
    buy1h += slot.buy;
    sell1h += slot.sell;
  }
  const total1h = buy1h + sell1h;
  const takerNetBuy1h: number | null =
    total1h > 0 ? ((buy1h - sell1h) / total1h) * 100 : null;

  const result: TakerFlowResult = {
    buyUsd: last.buy,
    sellUsd: last.sell,
    netBuyPct,
    dominance,
    available: true,
    exchanges: responded,
    cycles,
    cvdRising2,
    cvdShort,
    takerNetBuy1h,
  };

  logger.debug(
    {
      symbol,
      netBuyPct: netBuyPct.toFixed(1) + "%",
      dominance,
      cvdRising2,
      cvdShort,
      cycles: cycles.map((c) => `${c.netBuyPct.toFixed(1)}%`).join(" → "),
      exchanges: responded,
    },
    "CoinGlass taker flow (15m × 4 + 5m × 1 candles)",
  );

  cache.set(symbol, { result, ts: Date.now() });
  return result;
}

// ── Netflow-list batch cache ──────────────────────────────────────────────────
// GET /api/futures/netflow-list — один запрос на все ~100 символов.
// Используется как замена per-symbol getCoinglassTakerFlow для токенов из топ-100.
// Сохраняет 10 HTTP-вызовов на символ (5 бирж × 15m + 5m).

interface NetflowItem {
  symbol: string;
  taker_buy_volume_usd_5m: number;
  taker_sell_volume_usd_5m: number;
  taker_buy_volume_usd_15m: number;
  taker_sell_volume_usd_15m: number;
  taker_buy_volume_usd_30m: number;
  taker_sell_volume_usd_30m: number;
  taker_buy_volume_usd_1h: number;
  taker_sell_volume_usd_1h: number;
  net_flow_usd_5m: number;
  net_flow_usd_15m: number;
  net_flow_usd_30m: number;
}

const netflowBatch = new Map<string, TakerFlowResult>();
let netflowBatchTs = 0;
const NETFLOW_BATCH_TTL = 5 * 60 * 1000; // совпадает с TTL per-symbol кэша CG OI

// Телеметрия за текущий скан (сбрасывается resetNetflowTelemetry)
let _batchHits = 0;
let _batchMisses = 0;

export function resetNetflowTelemetry(): void {
  _batchHits = 0;
  _batchMisses = 0;
}

export function getNetflowTelemetry(): {
  hits: number;
  misses: number;
  batchSize: number;
} {
  return {
    hits: _batchHits,
    misses: _batchMisses,
    batchSize: netflowBatch.size,
  };
}

/**
 * Синхронное чтение из netflow batch кэша (без fallback на per-symbol HTTP).
 * Используется в scanner.ts после prefetchNetflowBatch() — batch уже заполнен.
 * bingxSymbol — формат "BTC-USDT".
 */
export function getNetflowBatchEntry(
  bingxSymbol: string,
): TakerFlowResult | undefined {
  const base = bingxSymbol.replace(/-USDT$/i, "");
  return netflowBatch.get(base);
}

/**
 * Один HTTP-запрос за весь скан — заполняет батч-кэш для ~100 топ-символов.
 * Вызывать в начале performScan() рядом с batchGetCoinglassOI().
 */
export async function prefetchNetflowBatch(): Promise<{ fetched: number }> {
  const apiKey = getNextCgKey();
  if (!apiKey) return { fetched: 0 };
  if (
    Date.now() - netflowBatchTs < NETFLOW_BATCH_TTL &&
    netflowBatch.size > 0
  ) {
    return { fetched: netflowBatch.size };
  }

  try {
    const res = await fetch(
      "https://open-api-v4.coinglass.com/api/futures/netflow-list",
      {
        headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
        signal: AbortSignal.timeout(15000),
      },
    );
    if (!res.ok) {
      logger.warn(
        { status: res.status },
        "CoinGlass netflow-list: request failed",
      );
      return { fetched: 0 };
    }
    const data = (await res.json()) as { code: string; data?: NetflowItem[] };
    if (data.code !== "0" || !data.data?.length) {
      logger.warn(
        { code: data.code },
        "CoinGlass netflow-list: unexpected response",
      );
      return { fetched: 0 };
    }

    netflowBatch.clear();
    for (const item of data.data) {
      const buy15 = item.taker_buy_volume_usd_15m;
      const sell15 = item.taker_sell_volume_usd_15m;
      const buy30 = item.taker_buy_volume_usd_30m;
      const sell30 = item.taker_sell_volume_usd_30m;
      const buy5 = item.taker_buy_volume_usd_5m;
      const sell5 = item.taker_sell_volume_usd_5m;
      const buy1h = item.taker_buy_volume_usd_1h;
      const sell1h = item.taker_sell_volume_usd_1h;

      const total15 = buy15 + sell15;
      const netBuyPct = total15 > 0 ? ((buy15 - sell15) / total15) * 100 : 0;

      // Старший 15m-слой = окно 30m минус последние 15m
      const olderBuy = buy30 - buy15;
      const olderSell = sell30 - sell15;
      const olderTotal = olderBuy + olderSell;
      const olderDelta = olderBuy - olderSell;
      const newerDelta = buy15 - sell15;
      const olderNetPct = olderTotal > 0 ? (olderDelta / olderTotal) * 100 : 0;
      const newerNetPct = netBuyPct;

      // cvdRising2: оба 15m-окна в плюсе, новый >= 50% старого — устойчивый поток
      const cvdRising2 =
        olderDelta > 0 && newerDelta > 0 && newerDelta >= olderDelta * 0.5;
      const total5 = buy5 + sell5;
      const cvdShort: boolean | null = total5 > 0 ? buy5 - sell5 > 0 : null;

      const dominance: TakerFlowResult["dominance"] =
        netBuyPct > 2 ? "buy" : netBuyPct < -2 ? "sell" : "neutral";

      const total1h = buy1h + sell1h;
      const takerNetBuy1h: number | null =
        total1h > 0 ? ((buy1h - sell1h) / total1h) * 100 : null;

      netflowBatch.set(item.symbol, {
        buyUsd: buy15,
        sellUsd: sell15,
        netBuyPct,
        dominance,
        available: true,
        exchanges: ["netflow-batch"],
        cycles: [
          { delta: olderDelta, netBuyPct: olderNetPct },
          { delta: newerDelta, netBuyPct: newerNetPct },
        ],
        cvdRising2,
        cvdShort,
        takerNetBuy1h,
        volUsd1h: total1h > 0 ? total1h : null,
      });
    }
    netflowBatchTs = Date.now();
    reportApiSuccess("coinglass");
    logger.info(
      { count: netflowBatch.size },
      "CoinGlass netflow-list: batch fetched",
    );
    return { fetched: netflowBatch.size };
  } catch (err) {
    logger.warn(
      { err },
      "CoinGlass netflow-list: fetch failed, will use per-symbol fallback",
    );
    return { fetched: 0 };
  }
}

/**
 * Замена getCoinglassTakerFlow() с батч-кэшем.
 * Для топ-100 символов (из netflow-list) — 0 HTTP-вызовов.
 * Для остальных — fallback на 10-вызовный per-symbol запрос.
 * bingxSymbol — формат "BTC-USDT".
 */
export async function getTakerFlowCached(
  bingxSymbol: string,
): Promise<TakerFlowResult> {
  const base = bingxSymbol.replace("-USDT", "").replace("-USDT", "");
  const batchHit = netflowBatch.get(base);
  if (batchHit) {
    _batchHits++;
    return batchHit;
  }
  _batchMisses++;
  return getCoinglassTakerFlow(bingxSymbol);
}
