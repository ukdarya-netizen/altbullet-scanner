/**
 * Whale Alert Monitor — Layer 11 (Hyperliquid Whale Alerts).
 *
 * Запускается каждые 3 мин независимо от основного scan-цикла.
 * Опрашивает CoinGlass /hyperliquid/whale-alert: киты открывающие крупные
 * позиции на Hyperliquid DEX. Действуем ТОЛЬКО на:
 *   • position_action = 1 (открытие)
 *   • position_size > 0 (лонг — бот long-only)
 *   • position_value_usd ≥ $500K
 *   • токен торгуется на BingX (маппинг HL base → BingX pair)
 *   • не BTC/ETH (мейджоры двигаются от китов слабо)
 *
 * Кандидаты персистятся в whale_alert_pool (24ч, status=watching) и
 * инжектируются в основной скан через getWhaleAlertLayer11Candidates().
 * Подтверждение крупными лимитниками: futures + spot large-limit-order.
 * Это ГЕЙТ в сканере: false (данные есть, лимитников нет) блокирует fire;
 * null (данные недоступны) = контролируемый fail-open. Флаги хранятся в пуле
 * и освежаются при повторных китах.
 *
 * Повторные алерты по активному символу агрегируются:
 * whaleCount++, totalWhaleUsd += usd; снапшот обновляется если позиция крупнее.
 *
 * Live-метрики (OI/спот/CVD по ТФ) обновляет logWhaleAlertPoolCycle() в
 * scanner.ts каждый скан-цикл; история — в whale_alert_watch_log.
 *
 * НЕ создаёт сигналы напрямую — паттерн whale_alert в scanner.ts решает.
 */

import { logger } from "./logger.js";
import { db, whaleAlertPoolTable, whaleAlertSeenTable } from "@workspace/db";
import { eq, and, lt, gt, isNotNull } from "drizzle-orm";
import { getFutureTickers } from "./bingx.js";
import {
  fetchHyperliquidWhaleAlerts,
  mapHlSymbolToBingx,
} from "./hyperliquid_whale.js";
import {
  getFuturesLargeBids,
  getSpotLargeBids,
} from "./coinglass_large_orders.js";
import { dbWriteBestEffort } from "./dbWriteFast.js";

// ── Параметры ─────────────────────────────────────────────────────────────────
const LAYER11_WINDOW_MS = 24 * 60 * 60 * 1000; // пул 24ч
const MIN_POSITION_USD = 500_000; // минимальный размер позиции кита
const EXCLUDED_BASES = new Set(["BTC", "ETH"]); // мейджоры — исключены
/** После рестарта обрабатываем только алерты свежее этого окна (защита от реплея ленты) */
const FRESH_WINDOW_MS = 30 * 60 * 1000;
/** TTL ключей дедупа обработанных алертов */
const SEEN_TTL_MS = 6 * 60 * 60 * 1000;
/**
 * Per-symbol cooldown после fire — следующая запись в пул не ранее чем через 24ч.
 * ДАННЫЕ: HYPE-USDT ×9 отмен за 6 дней, SOL-USDT ×5 — вместе 56% всех отмен паттерна.
 */
const SYMBOL_FIRE_COOLDOWN_MS = 24 * 60 * 60 * 1000;

// ── Состояние ─────────────────────────────────────────────────────────────────
let _running = false;
let _loaded = false;
/** Дедуп обработанных алертов: `${user}:${symbol}:${createTime}` → ts обработки */
const _seenAlerts = new Map<string, number>();
/** Отметка старта процесса — после рестарта не реплеим старую ленту */
const _startedAt = Date.now();
/** Per-symbol fire cooldown: symbol → unix ms последнего fire. Прогревается из БД при старте. */
const _symbolFiredAt = new Map<string, number>();

/** Кэш множества BingX символов (обновление раз в 30 мин) */
let _bingxSymbols: {
  set: Set<string>;
  priceMap: Map<string, number>;
  ts: number;
} | null = null;
const BINGX_SYMBOLS_TTL = 30 * 60 * 1000;

// ── In-memory зеркало активного пула (sync-доступ из скана) ───────────────────
export interface WhalePoolMirrorEntry {
  id: number; // 0 = DB insert ещё в полёте
  symbol: string;
  hlSymbol: string;
  detectedAt: number;
  expiresAt: number;
  positionValueUsd: number;
  whaleCount: number;
  totalWhaleUsd: number;
  whaleAddress: string | null;
  futLargeOrderConfirmed: boolean | null;
  spotLargeOrderConfirmed: boolean | null;
  /** Цена BingX в момент первого обнаружения кита — для расчёта priceChange в Path B. */
  entryPrice: number | null;
  /** Unix ms: create_time алерта на Hyperliquid — для расчёта detect lag (detectedAt − hlCreateTime). */
  hlCreateTime: number | null;
  /** Цена ликвидации кита на HL (null = нет данных → gate не применяется). */
  liqPrice: number | null;
  /**
   * Количество fire-циклов (3 мин каждый), за которые запись побывала в watching до выстрела.
   * Инкрементируется в _runWhaleAlertFireCycle при каждом проходе символа.
   * Передаётся в trackSignal как prescanCycles при выстреле.
   */
  fireCycleCount: number;
}
const _pool = new Map<string, WhalePoolMirrorEntry>();

/** Загружает активные (watching, не истёкшие) записи пула из БД в зеркало. */
export async function loadWhaleAlertPoolFromDb(): Promise<void> {
  try {
    const rows = await db
      .select()
      .from(whaleAlertPoolTable)
      .where(eq(whaleAlertPoolTable.status, "watching"));

    const now = Date.now();
    _pool.clear();
    for (const r of rows) {
      const exp = r.expiresAt.getTime();
      if (exp <= now) continue;
      _pool.set(r.symbol, {
        id: r.id,
        symbol: r.symbol,
        hlSymbol: r.hlSymbol,
        detectedAt: r.detectedAt.getTime(),
        expiresAt: exp,
        positionValueUsd: r.positionValueUsd ?? 0,
        whaleCount: r.whaleCount,
        totalWhaleUsd: r.totalWhaleUsd ?? r.positionValueUsd ?? 0,
        whaleAddress: r.whaleAddress,
        futLargeOrderConfirmed: r.futLargeOrderConfirmed,
        spotLargeOrderConfirmed: r.spotLargeOrderConfirmed,
        entryPrice: r.entryPrice ?? null,
        hlCreateTime: r.alertTime?.getTime() ?? null,
        liqPrice: r.liqPrice ?? null,
        fireCycleCount: r.cycleCount ?? 0,
      });
    }
    _loaded = true;
    logger.info(
      { count: _pool.size },
      "WhaleAlert: пул Layer 11 загружен из БД",
    );
  } catch (err) {
    logger.warn(
      { err },
      "WhaleAlert: загрузка пула из БД не удалась — зеркало пустое до следующего цикла",
    );
  }

  // ── Персистентный дедуп: восстанавливаем seen-ключи после рестарта ────────
  // Без этого job заново агрегирует те же алерты CoinGlass за последние часы
  // → whaleCount/totalWhaleUsd задваиваются.
  try {
    const cutoff = new Date(Date.now() - SEEN_TTL_MS);
    const seenRows = await db
      .select({
        seenKey: whaleAlertSeenTable.seenKey,
        ts: whaleAlertSeenTable.ts,
      })
      .from(whaleAlertSeenTable)
      .where(gt(whaleAlertSeenTable.ts, cutoff));
    for (const r of seenRows) {
      if (!_seenAlerts.has(r.seenKey))
        _seenAlerts.set(r.seenKey, r.ts.getTime());
    }
    logger.info(
      { count: seenRows.length },
      "WhaleAlert: seen-ключи дедупа восстановлены из БД",
    );
  } catch (err) {
    logger.warn(
      { err },
      "WhaleAlert: загрузка seen-ключей из БД не удалась (риск задвоения статистики до TTL)",
    );
  }

  // ── Прогрев per-symbol cooldown из БД ─────────────────────────────────────
  // Защита от burst-on-restart: если символ файрился за последние 24ч — не создаём
  // новую запись пула до истечения кулдауна.
  try {
    const cutoffFired = new Date(Date.now() - SYMBOL_FIRE_COOLDOWN_MS);
    const firedRows = await db
      .select({
        symbol: whaleAlertPoolTable.symbol,
        firedAt: whaleAlertPoolTable.firedAt,
      })
      .from(whaleAlertPoolTable)
      .where(
        and(
          eq(whaleAlertPoolTable.status, "fired"),
          isNotNull(whaleAlertPoolTable.firedAt),
          gt(whaleAlertPoolTable.firedAt, cutoffFired),
        ),
      );
    for (const r of firedRows) {
      if (r.firedAt) {
        const ts = r.firedAt.getTime();
        const existing = _symbolFiredAt.get(r.symbol) ?? 0;
        if (ts > existing) _symbolFiredAt.set(r.symbol, ts);
      }
    }
    logger.info(
      { count: _symbolFiredAt.size },
      "WhaleAlert: per-symbol cooldown восстановлен из БД",
    );
  } catch (err) {
    logger.warn(
      { err },
      "WhaleAlert: загрузка per-symbol cooldown из БД не удалась (только in-memory до первого цикла)",
    );
  }
}

// ── Public API (sync, из зеркала) ─────────────────────────────────────────────

/** Активные записи пула с DB id — для logWhaleAlertPoolCycle() в scanner.ts. */
export function getActiveWhaleAlertPoolEntries(): {
  id: number;
  symbol: string;
}[] {
  const now = Date.now();
  const result: { id: number; symbol: string }[] = [];
  for (const e of _pool.values()) {
    if (e.expiresAt > now && e.id > 0)
      result.push({ id: e.id, symbol: e.symbol });
  }
  return result;
}

/** Запись пула по символу — для гейта/текста паттерна whale_alert. */
export function getWhaleAlertPoolEntry(
  symbol: string,
): WhalePoolMirrorEntry | null {
  const e = _pool.get(symbol);
  if (!e || e.expiresAt <= Date.now()) return null;
  return e;
}

/** Паттерн whale_alert сработал → помечаем запись fired и убираем из зеркала. */
export function markWhaleAlertFired(symbol: string): void {
  const e = _pool.get(symbol);
  if (!e) return;
  _pool.delete(symbol);
  _symbolFiredAt.set(symbol, Date.now()); // per-symbol cooldown
  if (e.id > 0) {
    void dbWriteBestEffort("whaleAlertPoolFired", () =>
      db
        .update(whaleAlertPoolTable)
        .set({
          status: "fired",
          firedAt: new Date(),
          cycleCount: e.fireCycleCount,
        })
        .where(eq(whaleAlertPoolTable.id, e.id)),
    );
  }
  logger.info(
    { symbol, poolId: e.id, fireCycles: e.fireCycleCount },
    "🐋 WhaleAlert: запись пула → fired",
  );
}

/**
 * Инкрементирует fireCycleCount записи в зеркале пула.
 * Вызывается из _runWhaleAlertFireCycle при каждом проходе символа.
 * Возвращает новое значение счётчика (для передачи в trackSignal).
 */
export function incrementWhalePoolCycleCount(symbol: string): number {
  const e = _pool.get(symbol);
  if (!e) return 0;
  e.fireCycleCount++;
  return e.fireCycleCount;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

async function getBingxSymbolData(): Promise<{
  set: Set<string>;
  priceMap: Map<string, number>;
} | null> {
  if (_bingxSymbols && Date.now() - _bingxSymbols.ts < BINGX_SYMBOLS_TTL) {
    return _bingxSymbols;
  }
  try {
    const tickers = await getFutureTickers();
    if (!tickers.length) return _bingxSymbols; // стейл лучше чем ничего
    const set = new Set<string>();
    const priceMap = new Map<string, number>();
    for (const t of tickers) {
      if (!t.symbol.endsWith("-USDT")) continue;
      set.add(t.symbol);
      const p = parseFloat(t.lastPrice);
      if (Number.isFinite(p) && p > 0) priceMap.set(t.symbol, p);
    }
    _bingxSymbols = { set, priceMap, ts: Date.now() };
    return _bingxSymbols;
  } catch (err) {
    logger.warn({ err }, "WhaleAlert: getFutureTickers failed");
    return _bingxSymbols;
  }
}

function pruneSeenAlerts(): void {
  const cutoff = Date.now() - SEEN_TTL_MS;
  for (const [key, ts] of _seenAlerts.entries()) {
    if (ts < cutoff) _seenAlerts.delete(key);
  }
  // Чистим и персистентную таблицу (best-effort, не блокирует цикл)
  void dbWriteBestEffort("whaleAlertSeenPrune", () =>
    db
      .delete(whaleAlertSeenTable)
      .where(lt(whaleAlertSeenTable.ts, new Date(cutoff))),
  );
}

/** Best-effort персист новых seen-ключей (батч, ON CONFLICT DO NOTHING). */
function persistSeenKeys(keys: string[]): void {
  if (keys.length === 0) return;
  const now = new Date();
  void dbWriteBestEffort("whaleAlertSeenInsert", () =>
    db
      .insert(whaleAlertSeenTable)
      .values(keys.map((seenKey) => ({ seenKey, ts: now })))
      .onConflictDoNothing(),
  );
}

// ── Main job ──────────────────────────────────────────────────────────────────

export async function runWhaleAlertJob(): Promise<void> {
  if (_running) {
    logger.warn("WhaleAlert: предыдущий цикл ещё не завершён — пропуск");
    return;
  }
  _running = true;
  const t0 = Date.now();

  try {
    if (!_loaded) await loadWhaleAlertPoolFromDb();

    // ── Expiry sweep: watching + истёк срок → expired ───────────────────────
    try {
      const expired = await db
        .update(whaleAlertPoolTable)
        .set({ status: "expired" })
        .where(
          and(
            eq(whaleAlertPoolTable.status, "watching"),
            lt(whaleAlertPoolTable.expiresAt, new Date()),
          ),
        )
        .returning({ symbol: whaleAlertPoolTable.symbol });
      if (expired.length > 0) {
        logger.info(
          { symbols: expired.map((r) => r.symbol) },
          "WhaleAlert: записи пула истекли (24ч без сигнала)",
        );
      }
    } catch (err) {
      logger.warn({ err }, "WhaleAlert: expiry sweep failed (non-critical)");
    }
    const nowMs = Date.now();
    for (const [sym, e] of _pool.entries()) {
      if (e.expiresAt <= nowMs) _pool.delete(sym);
    }
    pruneSeenAlerts();

    // ── Лента whale-алертов ─────────────────────────────────────────────────
    const alerts = await fetchHyperliquidWhaleAlerts();
    if (!alerts) {
      logger.debug("WhaleAlert: лента недоступна (fail-open) — пропуск цикла");
      return;
    }

    // ── Action=2: кит закрыл позицию ──────────────────────────────────────────
    // Сканируем активный пул по hlSymbol + адресу кита (in-memory, без DB-запроса).
    // Выполняется до early-return по candidates, чтобы закрытия обрабатывались всегда.
    {
      const closeAlerts = alerts.filter(
        (a) =>
          a.positionAction === 2 &&
          !EXCLUDED_BASES.has(a.symbol.toUpperCase()) &&
          !_seenAlerts.has(`close:${a.user}:${a.symbol}:${a.createTime}`),
      );
      for (const a of closeAlerts) {
        _seenAlerts.set(
          `close:${a.user}:${a.symbol}:${a.createTime}`,
          Date.now(),
        );
        for (const [bingxSymbol, entry] of _pool.entries()) {
          if (entry.hlSymbol !== a.symbol) continue;
          if (entry.whaleAddress !== a.user) continue;
          _pool.delete(bingxSymbol);
          void dbWriteBestEffort("whaleAlertCloseExpire", () =>
            db
              .update(whaleAlertPoolTable)
              .set({ status: "expired" })
              .where(
                and(
                  eq(whaleAlertPoolTable.symbol, bingxSymbol),
                  eq(whaleAlertPoolTable.status, "watching"),
                ),
              ),
          );
          logger.info(
            {
              symbol: bingxSymbol,
              hlSymbol: a.symbol,
              positionUsdM: (a.positionValueUsd / 1e6).toFixed(1),
              whaleAddress: a.user,
            },
            "🐋⚠️ WhaleAlert action=2: кит ЗАКРЫЛ позицию → пул истёк",
          );
          break;
        }
      }
    }

    // Фильтр: только свежие лонг-открытия ≥$500K, не мейджоры
    const freshCutoff = Math.max(
      _startedAt - FRESH_WINDOW_MS,
      Date.now() - LAYER11_WINDOW_MS,
    );
    const candidates = alerts.filter(
      (a) =>
        a.positionAction === 1 &&
        a.positionSize > 0 &&
        a.positionValueUsd >= MIN_POSITION_USD &&
        a.createTime >= freshCutoff &&
        !EXCLUDED_BASES.has(a.symbol.toUpperCase()) &&
        !_seenAlerts.has(`${a.user}:${a.symbol}:${a.createTime}`),
    );

    if (candidates.length === 0) {
      logger.debug(
        { feedSize: alerts.length, activeInPool: _pool.size },
        "WhaleAlert: новых лонг-алертов нет",
      );
      return;
    }

    const symbolData = await getBingxSymbolData();
    if (!symbolData) {
      logger.warn("WhaleAlert: нет данных BingX тикеров — пропуск цикла");
      return;
    }

    let added = 0,
      aggregated = 0,
      unmapped = 0;
    const newSeenKeys: string[] = [];

    for (const a of candidates) {
      const seenKey = `${a.user}:${a.symbol}:${a.createTime}`;
      _seenAlerts.set(seenKey, Date.now());
      newSeenKeys.push(seenKey);

      const bingxSymbol = mapHlSymbolToBingx(a.symbol, symbolData.set);
      if (!bingxSymbol) {
        unmapped++;
        logger.debug(
          { hlSymbol: a.symbol, usd: Math.round(a.positionValueUsd) },
          "WhaleAlert: токен не торгуется на BingX — пропуск",
        );
        continue;
      }

      const existing = _pool.get(bingxSymbol);
      if (existing && existing.expiresAt > Date.now()) {
        // ── Агрегация повторного алерта ────────────────────────────────────
        existing.whaleCount += 1;
        existing.totalWhaleUsd += a.positionValueUsd;
        const isBigger = a.positionValueUsd > existing.positionValueUsd;
        if (isBigger) {
          existing.positionValueUsd = a.positionValueUsd;
          existing.whaleAddress = a.user;
          // Обновить snapshot-поля зеркала — fire gates (liqPrice, entryPrice, hlCreateTime)
          // должны видеть данные самого крупного кита, а не исходного.
          existing.liqPrice = Number.isFinite(a.liqPrice) ? a.liqPrice : null;
          existing.entryPrice =
            a.entryPrice != null && Number.isFinite(a.entryPrice)
              ? a.entryPrice
              : existing.entryPrice;
          existing.hlCreateTime = a.createTime ?? existing.hlCreateTime;
        }
        aggregated++;
        // Повторный кит → освежаем подтверждение лимитниками (это ГЕЙТ в сканере:
        // false блокирует fire, null = fail-open). Данные с момента insert могли
        // устареть или отсутствовать (entryPrice был null / API fail).
        let aggFutBidUsd: number | null = null,
          aggSpotBidUsd: number | null = null;
        let aggLoUpdated = false;
        const aggPrice = symbolData.priceMap.get(bingxSymbol) ?? null;
        if (aggPrice != null) {
          try {
            const [fut, spot] = await Promise.all([
              getFuturesLargeBids(bingxSymbol, aggPrice),
              getSpotLargeBids(bingxSymbol, aggPrice),
            ]);
            if (fut) {
              existing.futLargeOrderConfirmed = fut.totalBidUsd > 0;
              aggFutBidUsd = fut.totalBidUsd;
              aggLoUpdated = true;
            }
            if (spot) {
              existing.spotLargeOrderConfirmed = spot.totalBidUsd > 0;
              aggSpotBidUsd = spot.totalBidUsd;
              aggLoUpdated = true;
            }
          } catch {
            /* fail-open: оставляем прежние флаги */
          }
        }
        if (existing.id > 0) {
          const poolId = existing.id;
          const upd: Record<string, unknown> = {
            whaleCount: existing.whaleCount,
            totalWhaleUsd: existing.totalWhaleUsd,
          };
          if (aggLoUpdated) {
            if (aggFutBidUsd !== null) {
              upd.futLargeOrderConfirmed = existing.futLargeOrderConfirmed;
              upd.futLargeOrderBidUsd = aggFutBidUsd;
            }
            if (aggSpotBidUsd !== null) {
              upd.spotLargeOrderConfirmed = existing.spotLargeOrderConfirmed;
              upd.spotLargeOrderBidUsd = aggSpotBidUsd;
            }
          }
          if (isBigger) {
            upd.whaleAddress = a.user;
            upd.positionValueUsd = a.positionValueUsd;
            upd.positionSizeTokens = Math.abs(a.positionSize);
            upd.whaleEntryPrice = a.entryPrice;
            upd.liqPrice = a.liqPrice;
            upd.alertTime = new Date(a.createTime);
          }
          void dbWriteBestEffort("whaleAlertPoolAggregate", () =>
            db
              .update(whaleAlertPoolTable)
              .set(upd)
              .where(eq(whaleAlertPoolTable.id, poolId)),
          );
        }
        logger.info(
          {
            symbol: bingxSymbol,
            whaleCount: existing.whaleCount,
            totalWhaleUsdM: Math.round(existing.totalWhaleUsd / 1e5) / 10,
            newAlertUsdM: Math.round(a.positionValueUsd / 1e5) / 10,
          },
          "🐋 WhaleAlert: повторный кит по активному символу — агрегирован",
        );
        continue;
      }

      // ── Per-symbol fire cooldown ───────────────────────────────────────────
      // Если символ уже файрился за последние 24ч — не создаём новую запись пула.
      // ДАННЫЕ: HYPE-USDT ×9 отмен и SOL-USDT ×5 отмен за 6 дней = 56% всех отмен паттерна.
      {
        const _waCooldownUntil =
          (_symbolFiredAt.get(bingxSymbol) ?? 0) + SYMBOL_FIRE_COOLDOWN_MS;
        if (Date.now() < _waCooldownUntil) {
          const cooldownMinLeft = Math.round(
            (_waCooldownUntil - Date.now()) / 60_000,
          );
          logger.info(
            { symbol: bingxSymbol, cooldownMinLeft },
            "WhaleAlert: новый кит — символ на per-symbol кулдауне 24ч, пропуск",
          );
          continue;
        }
      }

      // ── Новая запись пула ──────────────────────────────────────────────────
      const entryPrice = symbolData.priceMap.get(bingxSymbol) ?? null;

      // Подтверждение крупными лимитниками фьюч + спот. Это ГЕЙТ в сканере:
      // false (данные есть, лимитников нет) блокирует fire; null (данные
      // недоступны) = контролируемый fail-open — кита не режем из-за отсутствия
      // данных стакана. Флаги освежаются при повторных китах (агрегация выше).
      let futConfirmed: boolean | null = null,
        futBidUsd: number | null = null;
      let spotConfirmed: boolean | null = null,
        spotBidUsd: number | null = null;
      if (entryPrice != null) {
        try {
          const [fut, spot] = await Promise.all([
            getFuturesLargeBids(bingxSymbol, entryPrice),
            getSpotLargeBids(bingxSymbol, entryPrice),
          ]);
          if (fut) {
            futConfirmed = fut.totalBidUsd > 0;
            futBidUsd = fut.totalBidUsd;
          }
          if (spot) {
            spotConfirmed = spot.totalBidUsd > 0;
            spotBidUsd = spot.totalBidUsd;
          }
        } catch {
          /* fail-open */
        }
      }

      const detectedAtMs = Date.now();
      const expiresAtMs = detectedAtMs + LAYER11_WINDOW_MS;
      const mirror: WhalePoolMirrorEntry = {
        id: 0,
        symbol: bingxSymbol,
        hlSymbol: a.symbol,
        detectedAt: detectedAtMs,
        expiresAt: expiresAtMs,
        positionValueUsd: a.positionValueUsd,
        whaleCount: 1,
        totalWhaleUsd: a.positionValueUsd,
        whaleAddress: a.user,
        futLargeOrderConfirmed: futConfirmed,
        spotLargeOrderConfirmed: spotConfirmed,
        entryPrice: entryPrice ?? null,
        hlCreateTime: a.createTime,
        liqPrice: Number.isFinite(a.liqPrice) ? a.liqPrice : null,
        fireCycleCount: 0,
      };
      _pool.set(bingxSymbol, mirror);
      added++;

      try {
        const inserted = await db
          .insert(whaleAlertPoolTable)
          .values({
            symbol: bingxSymbol,
            hlSymbol: a.symbol,
            expiresAt: new Date(expiresAtMs),
            whaleAddress: a.user,
            positionValueUsd: a.positionValueUsd,
            positionSizeTokens: Math.abs(a.positionSize),
            whaleEntryPrice: a.entryPrice,
            liqPrice: a.liqPrice,
            alertTime: new Date(a.createTime),
            totalWhaleUsd: a.positionValueUsd,
            entryPrice,
            currentPrice: entryPrice,
            futLargeOrderConfirmed: futConfirmed,
            futLargeOrderBidUsd: futBidUsd,
            spotLargeOrderConfirmed: spotConfirmed,
            spotLargeOrderBidUsd: spotBidUsd,
          })
          .returning({ id: whaleAlertPoolTable.id });
        if (inserted[0]) mirror.id = inserted[0].id;
      } catch (err) {
        // Unique violation (2 прод-воркера, partial unique index symbol WHERE status='watching')
        // или timeout — пробуем принять id существующей watching-записи другого воркера.
        try {
          const existingRow = await db
            .select({ id: whaleAlertPoolTable.id })
            .from(whaleAlertPoolTable)
            .where(
              and(
                eq(whaleAlertPoolTable.symbol, bingxSymbol),
                eq(whaleAlertPoolTable.status, "watching"),
              ),
            )
            .limit(1);
          if (existingRow[0]) {
            mirror.id = existingRow[0].id;
            logger.info(
              { symbol: bingxSymbol, poolId: mirror.id },
              "WhaleAlert: insert конфликт — принят id записи другого воркера",
            );
          } else {
            logger.error(
              { err, symbol: bingxSymbol },
              "WhaleAlert: whale_alert_pool insert failed (зеркало активно)",
            );
          }
        } catch {
          logger.error(
            { err, symbol: bingxSymbol },
            "WhaleAlert: whale_alert_pool insert failed (зеркало активно)",
          );
        }
      }

      logger.info(
        {
          symbol: bingxSymbol,
          hlSymbol: a.symbol,
          positionUsdM: Math.round(a.positionValueUsd / 1e5) / 10,
          whaleEntry: a.entryPrice,
          bingxPrice: entryPrice,
          futLO: futConfirmed,
          spotLO: spotConfirmed,
        },
        "🐋 WhaleAlert: ✅ кит открыл лонг → пул Layer 11 (24ч)",
      );
    }

    persistSeenKeys(newSeenKeys);

    const elapsed = ((Date.now() - t0) / 1000).toFixed(1);
    logger.info(
      {
        feedSize: alerts.length,
        newAlerts: candidates.length,
        added,
        aggregated,
        unmapped,
        activeInPool: _pool.size,
        elapsed: `${elapsed}s`,
      },
      "WhaleAlert: цикл завершён",
    );
  } finally {
    _running = false;
  }
}
