/**
 * growthLeaderBackfill.ts
 *
 * Заполняет v2-поля growth_leader_log для строк где они NULL:
 *
 *  Spot-тейкер бэкфилл (runGrowthLeaderSpotBackfill):
 *   spot_taker_buy_usd, spot_taker_sell_usd, spot_fp_buy_pct
 *   spot_taker_net_buy_pct, cvd_strength_1h, cvd_delta_4h
 *
 *  OI-суточный бэкфилл (runGrowthLeaderOi24hBackfill):
 *   oi_24h_d1, oi_24h_d2 — из oi_daily_snapshots (без API, чистый DB-запрос)
 *
 * Принципы:
 *  - Батчи по 5 символов, пауза 2с между батчами → Neon pool не захлёбывается
 *  - Одна DB-транзакция на символ (raw SQL VALUES batch) → минимум round-trips
 *  - CG вызовы: 400мс между taker-запросами одного символа
 *  - Идемпотентен: повторный запуск трогает только оставшиеся NULL строки
 */
import { db, growthLeaderLogTable, oiDailySnapshotsTable } from "@workspace/db";
import { eq, and, isNull, or, gte, inArray, sql } from "drizzle-orm";
import { logger } from "./logger.js";

type TakerCandle = {
  time: number;
  taker_buy_volume_usd: string;
  taker_sell_volume_usd: string;
};
const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** Retry-обёртка для начальных DB-запросов (уязвимы к Neon pool timeout при старте). */
async function withDbRetry<T>(
  fn: () => Promise<T>,
  attempts = 4,
  delayMs = 8_000,
): Promise<T> {
  let lastErr: unknown;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      logger.warn({ err, attempt: i + 1 }, "growthLeaderBackfill: DB retry");
      await delay(delayMs);
    }
  }
  throw lastErr;
}

async function _cgFetch<T>(url: string): Promise<T[] | null> {
  const key = process.env.COINGLASS_API_KEY ?? "";
  if (!key) return null;
  try {
    const res = await fetch(url, {
      headers: { "CG-API-KEY": key },
      signal: AbortSignal.timeout(10_000),
    });
    const json = (await res.json()) as { code?: string; data?: T[] };
    if (
      json.code !== "0" ||
      !Array.isArray(json.data) ||
      json.data.length === 0
    )
      return null;
    return json.data;
  } catch {
    return null;
  }
}

/** Один символ → taker данные. Агрегатный эндпоинт CoinGlass (без exchange=).
 *  symbol — базовый токен без суффикса USDT (напр. "BANK", не "BANKUSDT").
 *  Агрегирует по всем биржам — не даёт null для токенов, которых нет на конкретной бирже.
 */
async function _fetchSymbolData(
  base: string,
  startMs: number,
): Promise<{
  takerData: TakerCandle[] | null;
}> {
  const takerData = await _cgFetch<TakerCandle>(
    `https://open-api-v4.coinglass.com/api/spot/taker-buy-sell-volume/history?symbol=${base}&interval=1h&start_time=${startMs}&limit=96`,
  );
  return { takerData };
}

interface ComputedRow {
  buyUsd: number | null;
  sellUsd: number | null;
  spotTakerNetBuyPct: number | null;
  cvdStrength1h: number | null;
  cvdDelta4h: number | null;
}

/** Вычисляет значения для одной строки из уже скачанных свечей. */
function _computeRow(
  entry: { loggedAt: Date },
  takerData: TakerCandle[] | null,
): ComputedRow {
  const windowEnd = entry.loggedAt.getTime();
  const window2hStart = windowEnd - 2 * 3_600_000;
  const window1hStart = windowEnd - 1 * 3_600_000;
  const window4hStart = windowEnd - 4 * 3_600_000;

  let buy2h = 0,
    sell2h = 0;
  let buy1h = 0,
    sell1h = 0;
  let buy4h = 0,
    sell4h = 0;

  for (const c of takerData ?? []) {
    const t = c.time;
    const b = parseFloat(c.taker_buy_volume_usd) || 0;
    const s = parseFloat(c.taker_sell_volume_usd) || 0;
    if (t >= window2hStart && t <= windowEnd) {
      buy2h += b;
      sell2h += s;
    }
    if (t >= window1hStart && t <= windowEnd) {
      buy1h += b;
      sell1h += s;
    }
    if (t >= window4hStart && t <= windowEnd) {
      buy4h += b;
      sell4h += s;
    }
  }

  const buyUsd = buy2h > 0 ? buy2h : null;
  const sellUsd = sell2h > 0 ? sell2h : null;

  const spotTakerNetBuyPct =
    buy2h + sell2h > 0 ? ((buy2h - sell2h) / (buy2h + sell2h)) * 100 : null;

  const cvdStrength1h =
    buy1h + sell1h > 0 ? (buy1h - sell1h) / (buy1h + sell1h) : null;

  const cvdDelta4h =
    buy4h + sell4h > 0 ? (buy4h - sell4h) / (buy4h + sell4h) : null;

  return {
    buyUsd,
    sellUsd,
    spotTakerNetBuyPct,
    cvdStrength1h,
    cvdDelta4h,
  };
}

type UpdateRow = {
  id: number;
  buyUsd: number | null;
  sellUsd: number | null;
  spotTakerNetBuyPct: number | null;
  cvdStrength1h: number | null;
  cvdDelta4h: number | null;
};

/** Batch UPDATE одним SQL для всех строк символа. */
async function _batchUpdate(updates: UpdateRow[]) {
  if (updates.length === 0) return 0;

  const v = (x: number | null) => (x == null ? "NULL" : String(x));

  const values = updates
    .map(
      (u) =>
        `(${u.id}, ${v(u.buyUsd)}, ${v(u.sellUsd)}, ${v(u.spotTakerNetBuyPct)}, ${v(u.cvdStrength1h)}, ${v(u.cvdDelta4h)})`,
    )
    .join(", ");

  await db.execute(
    sql.raw(`
    UPDATE growth_leader_log AS t
    SET
      spot_taker_buy_usd      = v.buy::real,
      spot_taker_sell_usd     = v.sell::real,
      spot_taker_net_buy_pct  = v.net::real,
      cvd_strength_1h         = v.cvd1::real,
      cvd_delta_4h            = v.cvd4::real
    FROM (VALUES ${values}) AS v(id, buy, sell, net, cvd1, cvd4)
    WHERE t.id = v.id::int
  `),
  );

  return updates.length;
}

export interface BackfillOpts {
  maxAgeHours?: number; // смотреть только строки моложе N часов (default: 720 = 30 дней)
  batchSize?: number; // символов в одном батче (default: 5)
  batchDelayMs?: number; // пауза между батчами мс (default: 2000)
}

export async function runGrowthLeaderSpotBackfill(
  opts: BackfillOpts = {},
): Promise<{
  updated: number;
  symbols: number;
  skipped: number;
  errors: number;
}> {
  const { maxAgeHours = 720, batchSize = 5, batchDelayMs = 2000 } = opts;

  const cutoff = new Date(Date.now() - maxAgeHours * 3_600_000);

  const nullRows = await withDbRetry(() =>
    db
      .select({
        id: growthLeaderLogTable.id,
        symbol: growthLeaderLogTable.symbol,
        loggedAt: growthLeaderLogTable.loggedAt,
      })
      .from(growthLeaderLogTable)
      .where(
        and(
          eq(growthLeaderLogTable.source, "scan"),
          or(
            isNull(growthLeaderLogTable.spotTakerBuyUsd),
            isNull(growthLeaderLogTable.cvdStrength1h),
          ),
          gte(growthLeaderLogTable.loggedAt, cutoff),
        ),
      )
      .orderBy(growthLeaderLogTable.loggedAt),
  );

  if (nullRows.length === 0) {
    logger.info(
      { maxAgeHours },
      "growthLeaderSpotBackfill: нет NULL строк, пропускаем",
    );
    return { updated: 0, symbols: 0, skipped: 0, errors: 0 };
  }

  const bySymbol = new Map<string, Array<{ id: number; loggedAt: Date }>>();
  for (const row of nullRows) {
    const base = row.symbol.replace("-USDT", "");
    if (!bySymbol.has(base)) bySymbol.set(base, []);
    bySymbol.get(base)!.push({ id: row.id, loggedAt: row.loggedAt });
  }

  const symbolList = [...bySymbol.entries()];
  logger.info(
    {
      rows: nullRows.length,
      symbols: symbolList.length,
      batchSize,
      batchDelayMs,
      maxAgeHours,
    },
    "growthLeaderSpotBackfill: старт",
  );

  let totalUpdated = 0,
    totalSkipped = 0,
    totalErrors = 0;
  let batchIdx = 0;

  for (let i = 0; i < symbolList.length; i += batchSize) {
    const batch = symbolList.slice(i, i + batchSize);
    batchIdx++;

    for (const [base, entries] of batch) {
      const startMs =
        Math.min(...entries.map((e) => e.loggedAt.getTime())) - 4 * 3_600_000;

      let takerData: TakerCandle[] | null = null;
      try {
        const data = await _fetchSymbolData(base, startMs);
        takerData = data.takerData;
      } catch (err) {
        logger.warn({ err, base }, "growthLeaderSpotBackfill: CG fetch error");
        totalErrors++;
        continue;
      }

      if (takerData == null) {
        totalSkipped++;
        continue;
      }

      const updates: UpdateRow[] = entries
        .map((entry) => ({
          id: entry.id,
          ..._computeRow(entry, takerData),
        }))
        .filter(
          (u) =>
            u.buyUsd != null ||
            u.sellUsd != null ||
            u.spotTakerNetBuyPct != null ||
            u.cvdStrength1h != null ||
            u.cvdDelta4h != null,
        );

      if (updates.length === 0) {
        totalSkipped++;
        continue;
      }

      try {
        const n = await _batchUpdate(updates);
        totalUpdated += n;
      } catch (err) {
        logger.warn(
          { err, base, ids: updates.map((u) => u.id) },
          "growthLeaderSpotBackfill: DB update error",
        );
        await delay(1000);
        try {
          const n = await _batchUpdate(updates);
          totalUpdated += n;
        } catch (err2) {
          logger.error(
            { err: err2, base },
            "growthLeaderSpotBackfill: DB update retry failed",
          );
          totalErrors += updates.length;
        }
      }
    }

    if (i + batchSize < symbolList.length) {
      logger.debug(
        {
          batch: batchIdx,
          processed: Math.min(i + batchSize, symbolList.length),
          total: symbolList.length,
          updated: totalUpdated,
        },
        "growthLeaderSpotBackfill: батч завершён",
      );
      await delay(batchDelayMs);
    }
  }

  logger.info(
    {
      updated: totalUpdated,
      symbols: symbolList.length,
      skipped: totalSkipped,
      errors: totalErrors,
      maxAgeHours,
    },
    "growthLeaderSpotBackfill: завершён",
  );
  return {
    updated: totalUpdated,
    symbols: symbolList.length,
    skipped: totalSkipped,
    errors: totalErrors,
  };
}

/**
 * Бэкфилл oi_24h_d1 / oi_24h_d2 из oi_daily_snapshots.
 * Нет API-вызовов — только DB. Работает на всех строках (не только 100%+ муверах).
 *
 * D1 = oiChange24h последнего снапшота чьи дата <= date(loggedAt)
 * D2 = oiChange24h предпоследнего снапшота
 */
export async function runGrowthLeaderOi24hBackfill(): Promise<{
  updated: number;
  skipped: number;
}> {
  // Берём все строки без oi_24h_d1 (без ограничения по дате — DB-only операция)
  const nullRows = await withDbRetry(() =>
    db
      .select({
        id: growthLeaderLogTable.id,
        symbol: growthLeaderLogTable.symbol,
        loggedAt: growthLeaderLogTable.loggedAt,
      })
      .from(growthLeaderLogTable)
      .where(
        and(
          eq(growthLeaderLogTable.source, "scan"),
          isNull(growthLeaderLogTable.oi24hD1),
        ),
      )
      .orderBy(growthLeaderLogTable.loggedAt),
  );

  if (nullRows.length === 0) {
    logger.info("growthLeaderOi24hBackfill: нет NULL строк, пропускаем");
    return { updated: 0, skipped: 0 };
  }

  const symbols = [...new Set(nullRows.map((r) => r.symbol))];

  // Нижняя граница даты — самая ранняя loggedAt в выборке (YYYY-MM-DD строка для сравнения)
  const oldestDate = nullRows[0]!.loggedAt.toISOString().slice(0, 10);

  // Читаем снапшоты: фильтр по date-строке (не по takenAt) для точного сравнения
  const snapshotRows = await db
    .select({
      symbol: oiDailySnapshotsTable.symbol,
      date: oiDailySnapshotsTable.date,
      oiChange24h: oiDailySnapshotsTable.oiChange24h,
    })
    .from(oiDailySnapshotsTable)
    .where(
      and(
        inArray(oiDailySnapshotsTable.symbol, symbols),
        gte(oiDailySnapshotsTable.date, oldestDate),
      ),
    )
    .orderBy(oiDailySnapshotsTable.symbol, oiDailySnapshotsTable.date);

  const snapshotsBySymbol = new Map<
    string,
    Array<{ date: string; oiChange24h: number | null }>
  >();
  for (const row of snapshotRows) {
    if (!snapshotsBySymbol.has(row.symbol))
      snapshotsBySymbol.set(row.symbol, []);
    snapshotsBySymbol
      .get(row.symbol)!
      .push({ date: row.date, oiChange24h: row.oiChange24h });
  }

  const updates: Array<{ id: number; d1: number | null; d2: number | null }> =
    [];
  for (const row of nullRows) {
    const snaps = snapshotsBySymbol.get(row.symbol);
    if (!snaps || snaps.length === 0) continue;
    const rowDate = row.loggedAt.toISOString().slice(0, 10);
    const eligible = snaps
      .filter((s) => s.date <= rowDate)
      .sort((a, b) => b.date.localeCompare(a.date));
    if (eligible.length === 0) continue;
    const d1 = eligible[0]?.oiChange24h ?? null;
    const d2 = eligible[1]?.oiChange24h ?? null;
    if (d1 == null && d2 == null) continue;
    updates.push({ id: row.id, d1, d2 });
  }

  if (updates.length === 0) {
    logger.info(
      { nullRows: nullRows.length, symbols: symbols.length },
      "growthLeaderOi24hBackfill: нет данных в oi_daily_snapshots",
    );
    return { updated: 0, skipped: nullRows.length };
  }

  const CHUNK = 500;
  let totalUpdated = 0;
  for (let i = 0; i < updates.length; i += CHUNK) {
    const chunk = updates.slice(i, i + CHUNK);
    const v = (x: number | null) => (x == null ? "NULL" : String(x));
    const values = chunk
      .map((u) => `(${u.id}, ${v(u.d1)}, ${v(u.d2)})`)
      .join(", ");
    await db.execute(
      sql.raw(`
      UPDATE growth_leader_log AS t
      SET oi_24h_d1 = v.d1::real, oi_24h_d2 = v.d2::real
      FROM (VALUES ${values}) AS v(id, d1, d2)
      WHERE t.id = v.id::int
    `),
    );
    totalUpdated += chunk.length;
  }

  logger.info(
    {
      updated: totalUpdated,
      skipped: nullRows.length - totalUpdated,
      symbols: symbols.length,
    },
    "growthLeaderOi24hBackfill: завершён",
  );
  return { updated: totalUpdated, skipped: nullRows.length - totalUpdated };
}
