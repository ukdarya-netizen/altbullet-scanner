// ── Scanner pattern detection ─────────────────────────────────────────────────
// Pure functions: sentiment detection, alpha scoring, pattern evaluation.
// No side effects, no DB calls, no in-memory state.

import type { CgAskBidsResult } from "./coinglass_orderbook.js";

// ══════════════════════════════════════════════════════════════════════════════
// PATTERN REFERENCE (все условия выверены против кода scanner.ts / watcher.ts)
//
// Обозначения:
//   anyOiPass  — CoinGlass OI прошёл хотя бы один стандартный порог (см. Layer 3)
//   vol/volMult — BingX 30m volume / 7-day avg
//   vol4h       — BingX 4h volume / 7-day avg
//   FutTaker    — CoinGlass aggregated Futures Taker netBuyPct (Binance+Bybit+OKX+Bitget+BingX)
//   SpotCVD     — CoinGlass Spot CVD multi-TF (cvd30m/cvd1h/cvd4h)
//   cycleCount  — сколько раз подряд токен был в prescan top-N пуле
//   price3h     — % изменение цены за последние 3 часа
//   price4h     — % изменение цены за последние 4 часа
//   price24h    — % изменение цены за 24 часа
//
// ── Паттерны через detectSentiment() — требуют anyOiPass (OI прошёл пороги Layer 3): ─
//
//  1. trend_accumulation — OI30m ≥3.5% + prevOI ≥1% (два цикла) | price ≥1% | p24h ≤15% | vol ≥0.5x | cycleCount ≥3
//  2. bullish_accumulation (fallback/standard) — OI ≥2% | price >1% | vol ≥1.0x (с OI) | p24h ≤10% | oi30m ≤2.5% | cycleCount ≤25
//
// ── Specialist patterns — scanner.ts, bypass anyOiPass / detectSentiment(): ──
//
//  3. spot_vol_accumulation (спот-driven) — обновлено 19.07.2026
//       prescan: spotVolMult ≥2.5x, ≥3 цикла со спот-данными, prescan cycles ≥10 (19.07)
//       OI: fail-open (только OI4h < -3% блокирует — дистрибуция)
//       SpotCVD: cvd1h = обязателен; cvd4h = fail-open
//       SpotVol24h ≥1.5% MCap; p24h −10%..+40%
//       4h cooldown; блок 12ч после недавнего stop_loss
//       → прямой сигнал, стоп -5%
//
//  7. whale_watch (3-этапный) — ужесточено 2026-07-15
//       Blacklist: BTC/ETH/SOL/LINK/APT/NEAR/TONCOIN/FARTCOIN/1000PEPE/XMR
//       Каждый этап: OI30m ≥3.0% + FutTaker ≥25% (основной путь)
//         Фолбэк (нет spot-данных): OI30m ≥5.0% + |price| ≤0.5%
//         OI нарастание между стейджами: каждый следующий ≥ предыдущего −1%
//       При fire: CVD gate cvd1h === false → блок | OI1h ≥1.5% gate | SpotVol24h ≥1.0% MCap
//       → прямой сигнал; выход: whale-профиль 8/12/7
//
// 10. liquidation_cascade — РЕДИЗАЙН 2026-07-15 (ЭКСПЕРИМЕНТ)
//       Layer 10 pool ≥30 мин + liqExhausted=true (fail-closed) + price1h≥-1% + oi30m≥0
//       SpotTaker не sell (fail-open) + CVD1h не медвежий (fail-open) + толпа <75% long
//       → OI Watch 6ч (+2%), стоп -8%
//
// ── OI Watch — пути срабатывания в watcher.ts (каждые 2 мин): ────────────────
//  PATH A (vol confirmed): vol ≥2x при сканировании → payload сохранён в БД
//       Выстрел: price от entry +1.5–2% (по паттерну) | CVD pos | SpotVol ≥0.15% MCap
//       Окно: 360 мин (6ч); exchange_outflow_accum — 180 мин (3ч)
//  PATH B (unconfirmed): vol <2x при сканировании
//       CG turnover ≥15% ИЛИ BingX vol ≥1.5x | SpotCVD(cvd15m_3of4 ИЛИ cvd1h)
//       OI при entry ≤20% | price -4%..+20% от entry | SpotVol ≥0.15% MCap
//       Окно: 360 мин (6ч)
//  cg_timeout: topN-active + CG timeout + vol ≥1.3x + price -5..25% + cycleCount ≥3 → 12ч
//  cg_building: 2+ TF с OI 2–5% (ниже порога) + vol ≥1.5x → 12ч
//  dark_flow: CG есть, но OI не растёт + cycleCount ≥3 + vol ≥2x + price24h <15% → 6ч
//  tSteady (steady accum): |price| ≤0.5% + OI30m ≥2.0% → 6ч PATH B
//  Все паттерны: единое окно 6ч (360 мин).
// ══════════════════════════════════════════════════════════════════════════════

// ── Sentiment types ───────────────────────────────────────────────────────────

export type SentimentKey =
  | "trend_accumulation"
  | "bullish_accumulation"
  | "spot_vol_accumulation"
  | "whale_alert"
  | "4h_pullback_continuation"
  | "price_led_momentum"
  | "balanced_grind"
  | "stealth_breakout"
  | "liquidation_cascade"
  | "demark";

export interface SentimentResult {
  key: SentimentKey;
  label: string;
  traderAction: string;
  /** Does this pattern require OI to be FALLING instead of rising? */
  oiFalling: boolean;
}

// ── Alpha signal result ───────────────────────────────────────────────────────

export interface AlphaResult {
  symbol: string;
  grade: "alpha" | "super_alpha";
  price: number;
  priceChange30m: number;
  currentVolume: number;
  avgVolume: number;
  volumeMultiplier: number;
  oiChangePercent: number;
  openInterest: number;
  cmcRank: number | null;
  cmcSource: string | null;
  cmcAvailable: boolean;
  liquidationsUsd: number | null;
  liquidationsMultiple: number | null;
  coinglassAvailable: boolean;
  /** Кросс-биржевое OI изменение от Coinalyze (30m) */
  globalOiChange: number | null;
  /** Coinalyze подтвердил OI-рост кросс-биржево */
  globalOiConfirmed: boolean;
  /** Новый листинг (< 24ч на фьючерсах BingX) */
  isNewListing: boolean;
  /** Сигнал с высоким OI — выдавливание могло уже завершиться */
  isExhaustedSqueeze: boolean;
  /** % рост цены от первого открытия фьючерса */
  pumpFromOpen: number | null;
  /** Количество 30м свечей (< 48 = новый) */
  candleCount: number;
  sentiment: string;
  sentimentKey: SentimentKey;
  traderAction: string;
  alphaScore: number;
  isContinuing: boolean;
  cumulativeOiChange: number;
  tradingViewUrl: string;
  bingxUrl: string;
  /** Какой ТФ OI сработал: "30m", "1h" или комбинация */
  oiTriggerTf: string;
  /** Значение 1h OI изменения (для отображения в сигнале) */
  oiChange1h: number | null;
  /** Значение 4h OI изменения (для отображения в сигнале) */
  oiChange4h: number | null;
  /** Значение 24h OI изменения (для отображения в сигнале) */
  oiChange24h: number | null;
  /** Проскальзывание цены с момента kline до fresh price (%) */
  klineSlippage?: number;
  /** Символ уже был в отслеживаемых сигналах за последние 24ч */
  isRepeatSignal?: boolean;
  /** Фандинг рейт в процентах (напр. -0.04 = -0.04% за 8ч; источник: CoinGlass aggregate) */
  fundingRate?: number | null;
  /** Mark price BingX перп */
  markPrice?: number | null;
  /** Index price (спотовый агрегат) */
  indexPrice?: number | null;
  /** Анализ стакана (CoinGlass/Binance): bidAskRatio, bias, scoreBonus */
  obImbalance?: CgAskBidsResult | null;
  /** Bear Trap CVD дивергенция: цена падает, но покупатели перевешивают → подтверждённая ловушка */
  cvdDivergence?: boolean;
  /** MTF Spot CVD: старшие ТФ (1h/4h) не подтверждают — только скальп */
  isScalpOnly?: boolean;
  /** BingX spot market 24h volume (USDT) — ориентир для сравнения с futures */
  spotVol24h?: number | null;
  /** Market cap токена (CoinGecko, USD) — для расчёта % оборачиваемости */
  marketCapUsd?: number | null;
  /** Предстоящий разлок токена (CoinGlass): daysUntil 4-7 (≤3 заблокированы на входе, watchlist exempt) */
  upcomingUnlock?: { daysUntil: number; pctSupply: number } | null;
  /** Свежий мувер: <3 циклов в прескане + цена уже ≥5% за 24ч на момент обнаружения.
   *  Статистика 30д: 43% отмен в этом сегменте (growth-leader анализ 2026-07-15). */
  freshMoverRisk?: { cycles: number; price24h: number } | null;
  /** Через какой OI Watch путь прошёл сигнал перед отправкой (A = price gate, B = vol/CVD gate).
   *  Undefined = прямой сигнал (без OI Watch). Используется для мониторинга в Telegram #path_a/#path_b. */
  _oiWatchPath?: "A" | "B";
  /** Краткая расшифровка Bullet Score для Telegram: OI/Vol/CVD/Taker/FR/ctx компоненты */
  scoreBreakdown?: string;
  /** Источник стопа: heatmap кластер / паттерн-стоп / стандартный */
  liqStopSource?: "liq_heatmap" | "pattern" | "standard";
}

// ── Internal detection result ─────────────────────────────────────────────────

export interface DetectionResult {
  passes: boolean;
  oiChangePercent: number;
  openInterest: number;
  sentiment: SentimentResult;
}

// ── OI caps by timeframe ──────────────────────────────────────────────────────

/**
 * OI кепы зависят от таймфрейма который сработал.
 * 30m OI = 14% это поздно (памп уже идёт). 4h OI = 14% это тихое накопление за часы.
 *
 * triggerTf примеры: "30m", "1h", "4h", "24h", "steady"
 */
export function getOiCaps(triggerTf: string): {
  hiddenMax: number;
  bullishMax: number;
} {
  if (/\b24h\b/.test(triggerTf)) return { hiddenMax: 30, bullishMax: 50 };
  if (/\b4h\b/.test(triggerTf)) return { hiddenMax: 25, bullishMax: 35 };
  if (/\b1h\b/.test(triggerTf)) return { hiddenMax: 15, bullishMax: 20 };
  // 30m, steady, confirm — жёсткий кеп
  return { hiddenMax: 10, bullishMax: 15 };
}

// ── Sentiment detection ───────────────────────────────────────────────────────

/**
 * Determine sentiment pattern based on price, OI change direction/magnitude and volume.
 * Used for standard scanner signals (impulse/OI-based). Specialist patterns
 * (whale_alert, 4h_pullback_continuation,
 * price_led_momentum, balanced_grind, stealth_breakout)
 * are evaluated directly in scanner.ts / watcher.ts and bypass this function.
 *
 * Pattern priority (first match wins):
 * 1. trend_accumulation — OI30m ≥3.5% + prevOI ≥1% (два цикла), price ≥1%, p24h ≤15%, vol ≥0.5x, cycleCount ≥3
 * 3. dip_accumulation   — OI ≥4%, price -0.5–-3%, volMult ≥2x
 * 4. bullish_accumulation (OI ≤ bullishMax cap) — standard rising OI
 * 5. bullish_accumulation fallback
 */
export function detectSentiment(
  priceChange: number,
  oiChange: number,
  volumeMultiplier: number,
  liquidationsMultiple: number | null,
  triggerTf: string = "30m",
  prevOi30m: number | null = null,
  price24hChange: number = 999,
  _cycleCount: number = 0,
): SentimentResult {
  const { bullishMax } = getOiCaps(triggerTf);

  // 1. Трендовое накопление: двухцикловое OI накопление на не перегретом токене.
  //   ИСТОРИЯ: условия были завышены (OI≥6%, vol≥1.5x), что убило все срабатывания.
  //   Реальные прибыльные сигналы (SLX +26%, RPL +10%, RIF +9%, KGEN +5%):
  //     OI 3.4–5.9% (все ниже 6%), vol 0.5–1.1x (все ниже 1.5x).
  //   Восстановленные пороги (2026-07-14) + добавлен priceChange ≥ 1%:
  //     OI ≥3.5% + prevOI ≥1% (два цикла подряд) + price ≥1% (тренд вверх)
  //     price24h ≤20% + vol ≥0.5x + cycleCount ≥5
  //   prevOi30m null = fail-open (2026-07-27): CG-таймаут предыдущего цикла не должен
  //   блокировать TA — у нас нет данных, а не доказательства слабости OI.
  //   Текущий OI ≥3.5% остаётся обязательным фильтром качества.
  if (
    oiChange >= 3.5 &&
    (prevOi30m === null || prevOi30m >= 0.3) &&
    priceChange >= 1.0 &&
    price24hChange <= 20.0 &&
    volumeMultiplier >= 0.5
  ) {
    return {
      key: "trend_accumulation",
      label: "🔥 Трендовое накопление",
      traderAction: "LONG (вход в начале движения)",
      oiFalling: false,
    };
  }

  // 3. Bullish Accumulation — кеп зависит от ТФ (bullishMax)
  if (oiChange > 3 && oiChange <= bullishMax) {
    return {
      key: "bullish_accumulation",
      label: "Бычье накопление",
      traderAction: "LONG",
      oiFalling: false,
    };
  }

  return {
    key: "bullish_accumulation",
    label: "Бычье накопление",
    traderAction: "LONG",
    oiFalling: false,
  };
}

// ── Alpha score v2 ────────────────────────────────────────────────────────────

/**
 * Bullet Score v2 — base=1 (паттерн сработал) + независимые подтверждения.
 *
 * Каждый сигнал оценивается отдельно; архетипный бонус добавляется снаружи
 * (scanner.ts). Все поля fail-open: null → 0 баллов.
 *
 * Диапазон: 1–10 (cap 10, floor 1).
 *
 * Компоненты v3 (max без архетипа ≈ 9.0):
 *   Base            1.0         паттерн прошёл все гейты
 *   OI conviction   0..2.0      30m ≥5/10% + 1h ≥2% + 4h ≥2% + OI acceleration
 *   Spot Volume     0..1.5      по spotVolMult
 *   CVD 1h+4h       0..1.0      SpotCVD булеаны
 *   Taker flow      -0.5..1.0   netBuyPct покупатели/продавцы
 *   SNF 1h/4h       -0.5..0.75  spot netflow %
 *   Funding 7d      -0.5..1.0   шорты/лонги перегреты
 *   Market context  -0.25..0.75 p24h sweet spot + cycleCount + growthCycles
 */
export function calcBulletScore(params: {
  sentimentKey: SentimentKey;
  // OI multi-TF
  oi30m: number;
  oi1h: number | null;
  oi4h: number | null;
  prevOi30m: number | null; // OI 30m прошлого цикла — для расчёта ускорения
  // Volume
  spotVolMult: number;
  // CVD directional
  spotCvd1h: boolean | null;
  spotCvd4h: boolean | null;
  // Taker
  takerNetBuyPct: number | null;
  takerAvailable: boolean;
  // Spot netflow %
  snfNetPct1h: number | null;
  snfNetPct4h: number | null;
  // Funding rate 7d (%)
  fundingRate: number | null;
  // Market context
  p24h: number | null; // price 24h % — не перегрет, не холодный старт
  cycleCount: number | null; // зрелость в прескане (SVA: ≥10 циклов → 4x лучше)
  growthCycles: number | null; // L8 steady climber: циклов роста подряд
}): number {
  let score = 1; // base: паттерн прошёл все гейты

  // ── OI multi-TF conviction (max +2.0) ────────────────────────────────────
  // Ступенчатый бонус за силу OI30m; выше — сильнее сигнал
  if (params.oi30m >= 10) score += 0.5;
  else if (params.oi30m >= 5) score += 0.25;
  if (params.oi1h != null && params.oi1h >= 2.0) score += 0.5;
  if (params.oi4h != null && params.oi4h >= 2.0) score += 0.5;
  // OI acceleration: текущий цикл значимо сильнее предыдущего → импульс нарастает
  if (
    params.prevOi30m != null &&
    params.prevOi30m > 0 &&
    params.oi30m > params.prevOi30m * 1.5
  ) {
    score += 0.5;
  }

  // ── Spot Volume (max +1.5) ────────────────────────────────────────────────
  score +=
    params.spotVolMult >= 5
      ? 1.5
      : params.spotVolMult >= 3
        ? 1.0
        : params.spotVolMult >= 1.5
          ? 0.5
          : 0;

  // ── CVD directional (max +1.0) ────────────────────────────────────────────
  if (params.spotCvd1h === true) score += 0.5;
  if (params.spotCvd4h === true) score += 0.5;

  // ── Spot Taker flow (-0.5..+1.0) ─────────────────────────────────────────
  if (params.takerAvailable && params.takerNetBuyPct != null) {
    if (params.takerNetBuyPct >= 60) score += 1.0;
    else if (params.takerNetBuyPct >= 55) score += 0.5;
    else if (params.takerNetBuyPct < 45) score -= 0.5;
  }

  // ── SNF 1h (-0.5..+0.5) + 4h secondary (+0.25) ───────────────────────────
  if (params.snfNetPct1h != null) {
    if (params.snfNetPct1h >= 5) score += 0.5;
    else if (params.snfNetPct1h <= -5) score -= 0.5;
  }
  if (params.snfNetPct4h != null && params.snfNetPct4h >= 3) score += 0.25;

  // ── Funding rate (-0.5..+1.0) ─────────────────────────────────────────────
  // Отрицательный фандинг = шорты платят лонгам → squeeze-потенциал
  if (params.fundingRate != null) {
    const fr = params.fundingRate;
    if (fr <= -0.03) score += 1.0;
    else if (fr <= -0.01) score += 0.5;
    else if (fr >= 0.05) score -= 0.5;
  }

  // ── Market context (max +0.75, min -0.25) ────────────────────────────────
  // p24h sweet spot: уже идёт движение, но не перегрет
  if (params.p24h != null) {
    if (params.p24h >= 3 && params.p24h <= 15) score += 0.25;
    else if (params.p24h > 25) score -= 0.25;
  }
  // Зрелость в прескане: SVA backtest — ≥10 циклов в 4× лучше новичков
  if (params.cycleCount != null && params.cycleCount >= 10) score += 0.25;
  // L8 steady climber: 3+ циклов роста подряд = устойчивый тренд без откатов
  if (params.growthCycles != null && params.growthCycles >= 3) score += 0.25;

  return Math.min(10, Math.max(1, Math.round(score)));
}

// ── Pattern evaluation (pipeline gate) ───────────────────────────────────────

export function evaluatePattern(
  oiChange: number,
  priceChange: number,
  volumeMultiplier: number,
  liquidationsMultiple: number | null,
  settings: { volumeMultiplier: number; oiChangePercent: number },
  triggerTf: string = "30m",
  prevOi30m: number | null = null,
  price24hChange: number = 999,
  _cycleCount: number = 0,
): DetectionResult | null {
  // NOTE: At this point CoinGlass global OI ≥ 5% and Volume ≥ 2x are already
  // confirmed upstream (Steps 1 & 3 of v3.0 pipeline). Pattern evaluation
  // here only assigns the pattern type and applies pattern-specific thresholds.
  const { bullishMax: _bullishMax } = getOiCaps(triggerTf);
  const sent = detectSentiment(
    priceChange,
    oiChange,
    volumeMultiplier,
    liquidationsMultiple,
    triggerTf,
    prevOi30m,
    price24hChange,
  );

  // Path A: Rising OI patterns (LONG сигналы)
  if (!sent.oiFalling) {
    // B1 (2026-07-19): bullish_accumulation добавлен в bypass-список.
    // Ранее использовал settings.oiChangePercent(5%) + settings.volumeMultiplier(3x) —
    // глобальные настройки, которые блокировали лучший ретро-бакет vol 1.0-2.0x
    // (avg_p3h=6.53%, hit_10%=17 из 70 событий).
    // Реальная фильтрация вынесена в scanner.ts: oi_too_low / vol_low / prev_oi_not_building
    // / cycle_too_late / oi1h_negative / oi4h_unwinding / price24h_too_high / fut_vol_low.
    if (["trend_accumulation", "bullish_accumulation"].includes(sent.key)) {
      return {
        passes: true,
        oiChangePercent: oiChange,
        openInterest: 0,
        sentiment: sent,
      };
    }
  }

  return null;
}
