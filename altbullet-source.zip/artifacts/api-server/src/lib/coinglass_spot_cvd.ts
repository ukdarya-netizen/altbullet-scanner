/**
 * CoinGlass — Multi-TimeFrame (MTF) Spot CVD + 24h Spot Volume (unified).
 *
 * Endpoint: GET /api/spot/aggregated-cvd/history
 *   ?symbol=BTC&exchange_list=Binance,Bybit,Bitget,OKX&interval=15m&limit=96
 * Header: CG-API-KEY: <key>
 * Plan: Standard+ required.
 *
 * ЕДИНЫЙ вызов на символ с limit=96 (96 × 15m = 24ч):
 *   • CVD использует последние 16 свечей из 96 (= 4ч окно)
 *   • 24h spot volume суммирует все 96 свечей
 *   • Оба результата кэшируются вместе — 1 API-запрос на символ на 3 мин
 *
 * MTF логика (CVD):
 *   30m — последние 2 × 15m свечей:       суммарно buy > sell
 *   1h  — последние 4 свечи (60 мин):     суммарно net buy > sell
 *   4h  — последние 16 свечей (4ч):       cum_vol_delta последней свечи > 0
 *
 * Trend gate (scalp flag): 1h или 4h отрицательные → scalpOnly.
 * Golden: 30m + 1h + 4h положительные → isGolden.
 *
 * Cache: 3 min (единый для CVD и SpotVol). Fallback: available=false —
 * сигналы НЕ блокируются.
 *
 * Backward-compatible exports:
 *   getSpotCvdMtf()          — возвращает SpotCvdResult (тонкая обёртка)
 *   getCoinglassSpotVolume24h() — возвращает number|null (тонкая обёртка)
 *   getSpotCvdAndVolume()    — возвращает { cvd, spotVol24h } за 1 вызов
 */

import { logger } from "./logger.js";
import { reportApiSuccess, reportApiFailure } from "./apiHealth.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";
import { cgTimedFetch } from "./cg_latency.js";

export interface SpotCvdResult {
  // ── Бинарные флаги (backward-compatible) ─────────────────────────────────
  /** Последние 2 × 15m свечей (= 30m): суммарно buy > sell */
  cvd30m: boolean | null;
  /** Последние 4 × 15m (= 1h): суммарно buy > sell */
  cvd1h: boolean | null;
  /** Последние 16 × 15m (= 4h): cum_vol_delta > 0 */
  cvd4h: boolean | null;
  /** 30m и 1h оба отрицательные → блокируем сигнал полностью */
  hardBlocked: boolean;
  /** 1h или 4h отрицательные (30m ок) → сигнал помечается Scalp Only */
  scalpOnly: boolean;
  /** Все 4 TF положительные → сильнейшее подтверждение */
  isGolden: boolean;
  available: boolean;

  // ── Числовые метрики силы ─────────────────────────────────────────────────
  /**
   * Нормализованный перевес за последний час (4 × 15m): (buy-sell)/(buy+sell).
   * Сглаживает noise отдельных свечей. null если нет данных.
   */
  cvdStrength1h: number | null;
  /**
   * Нормализованный running CVD за полное окно (16 × 15m = 4h):
   * cum_vol_delta[last] / total_volume. Показывает накопленное направление.
   * null если нет данных.
   */
  cvdStrength4h: number | null;
  /**
   * Абсолютный running CVD последней свечи (USD). null если нет данных.
   */
  cvdDelta4h: number | null;
}

// ─── Константы ────────────────────────────────────────────────────────────────

const EXCHANGES = "Binance,Bybit,Bitget,OKX";
const CVD_CANDLES = 16; // последние 16 × 15m = 4ч окно для CVD
const UNIFIED_LIMIT = 96; // 96 × 15m = 24ч — единый размер запроса
const UNIFIED_CACHE_TTL = 3 * 60 * 1000; // 3 мин — CVD нужна свежесть

// ─── Единый кэш ───────────────────────────────────────────────────────────────

interface UnifiedCacheEntry {
  cvd: SpotCvdResult;
  spotVol24h: number | null;
  ts: number;
}
const unifiedCache = new Map<string, UnifiedCacheEntry>();

// ─── Circuit breaker ──────────────────────────────────────────────────────────
/**
 * При массовом сбое CoinGlass (все запросы таймаутят/фейлят) функция вызывается
 * последовательно на 250+ символов в основном цикле скана без concurrency-защиты.
 * Раньше каждый вызов «жёг» до ~16с (8с основной + retry), что растягивало цикл
 * до 40+ минут. Circuit breaker обрывает лавину после 6 подряд неудач.
 */
const CIRCUIT_BREAKER_THRESHOLD = 6;
const CIRCUIT_BREAKER_COOLDOWN_MS = 2 * 60 * 1000; // 2 мин
let consecutiveFailures = 0;
let circuitBrokenUntil = 0;

function isCircuitBroken(): boolean {
  return circuitBrokenUntil > Date.now();
}

function recordFailure(cgSymbol: string): void {
  consecutiveFailures++;
  if (consecutiveFailures >= CIRCUIT_BREAKER_THRESHOLD && !isCircuitBroken()) {
    circuitBrokenUntil = Date.now() + CIRCUIT_BREAKER_COOLDOWN_MS;
    logger.warn(
      { consecutiveFailures, cooldownMs: CIRCUIT_BREAKER_COOLDOWN_MS },
      "CoinGlass SpotCVD circuit breaker сработал — API не отвечает, пропускаем остаток",
    );
  }
  void cgSymbol;
}

function recordSuccess(): void {
  consecutiveFailures = 0;
  circuitBrokenUntil = 0;
}

// ─── Типы и helpers ───────────────────────────────────────────────────────────

interface AggCvdCandle {
  time: number;
  agg_taker_buy_vol: number;
  agg_taker_sell_vol: number;
  cum_vol_delta: number;
}

/** BingX-символ → базовый тикер CoinGlass: BTC-USDT → BTC */
function toCgSymbol(bingxSymbol: string): string {
  return bingxSymbol.replace("-USDT", "");
}

const NO_CVD: SpotCvdResult = {
  cvd30m: null,
  cvd1h: null,
  cvd4h: null,
  hardBlocked: false,
  scalpOnly: false,
  isGolden: false,
  available: false,
  cvdStrength1h: null,
  cvdStrength4h: null,
  cvdDelta4h: null,
};

// ─── Низкоуровневый HTTP-fetch ────────────────────────────────────────────────

async function fetchAggCvd(
  cgSymbol: string,
  apiKey: string,
  limit: number = UNIFIED_LIMIT,
): Promise<AggCvdCandle[] | null> {
  const url = new URL(
    "https://open-api-v4.coinglass.com/api/spot/aggregated-cvd/history",
  );
  url.searchParams.set("symbol", cgSymbol);
  url.searchParams.set("exchange_list", EXCHANGES);
  url.searchParams.set("interval", "15m");
  url.searchParams.set("limit", String(limit));

  let retryReason: string | null = null;

  try {
    const res = await cgTimedFetch(url.toString(), {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(8000),
    });
    if (res.status === 429) {
      logCg429(apiKey, { symbol: cgSymbol });
      reportApiFailure("coinglass", 429);
      return null;
    }
    if (!res.ok) {
      retryReason = `HTTP ${res.status}`;
    } else {
      const data = (await res.json()) as {
        code: string;
        data?: AggCvdCandle[];
      };
      if (data.code !== "0") return null;
      if (!data.data?.length) {
        retryReason = "пустой массив";
      } else {
        reportApiSuccess("coinglass");
        return data.data;
      }
    }
  } catch {
    return null;
  }

  // Единый retry-блок для !res.ok и пустого массива
  logger.warn(
    { symbol: cgSymbol, reason: retryReason, key: apiKey.slice(-4) },
    "CoinGlass SpotCVD: ошибка ответа — retry с другим ключом через 300ms",
  );
  await new Promise<void>((r) => setTimeout(r, 300));
  const retryKey = getNextCgKey();
  if (!retryKey) return null;
  try {
    const retryRes = await cgTimedFetch(url.toString(), {
      headers: { "CG-API-KEY": retryKey, Accept: "application/json" },
      signal: AbortSignal.timeout(8000),
    });
    if (!retryRes.ok) return null;
    const retryData = (await retryRes.json()) as {
      code: string;
      data?: AggCvdCandle[];
    };
    if (retryData.code !== "0") return null;
    if (retryData.data?.length) {
      logger.info(
        { symbol: cgSymbol },
        "CoinGlass SpotCVD: retry успешен — данные получены",
      );
      reportApiSuccess("coinglass");
      return retryData.data;
    }
  } catch {
    // retry failed
  }
  return null;
}

// ─── Единый внутренний вычислитель ───────────────────────────────────────────

/**
 * 1 HTTP-вызов с limit=96; вычисляет CVD (последние 16 свечей) и
 * 24h spot volume (все 96 свечей); результат кладётся в unifiedCache.
 */
async function fetchAndComputeUnified(
  cgSymbol: string,
  apiKey: string,
): Promise<UnifiedCacheEntry> {
  const failEntry: UnifiedCacheEntry = {
    cvd: { ...NO_CVD },
    spotVol24h: null,
    ts: Date.now(),
  };

  const candles = await fetchAggCvd(cgSymbol, apiKey, UNIFIED_LIMIT);

  if (!candles || candles.length === 0) {
    recordFailure(cgSymbol);
    unifiedCache.set(cgSymbol, failEntry);
    return failEntry;
  }

  recordSuccess();

  // ── SpotVol 24h: сумма по всем 96 свечам ─────────────────────────────────
  let totalVol = 0;
  for (const c of candles) {
    totalVol += c.agg_taker_buy_vol + c.agg_taker_sell_vol;
  }
  const spotVol24h = totalVol > 0 ? totalVol : null;

  // ── CVD: последние CVD_CANDLES (16) из полученного массива ───────────────
  const agg: Array<{ buy: number; sell: number; cumDelta: number }> =
    Array.from({ length: CVD_CANDLES }, () => ({
      buy: 0,
      sell: 0,
      cumDelta: 0,
    }));
  const start = Math.max(0, candles.length - CVD_CANDLES);
  const offset = CVD_CANDLES - (candles.length - start);
  for (let ci = start; ci < candles.length; ci++) {
    const slot = offset + (ci - start);
    const c = candles[ci]!;
    agg[slot]!.buy = c.agg_taker_buy_vol;
    agg[slot]!.sell = c.agg_taker_sell_vol;
    agg[slot]!.cumDelta = c.cum_vol_delta;
  }

  const validCount = agg.filter((s) => s.buy + s.sell > 0).length;

  let cvd30m: boolean | null = null;
  let cvd1h: boolean | null = null;
  let cvdStrength1h: number | null = null;
  let cvd4h: boolean | null = null;
  let cvdStrength4h: number | null = null;
  let cvdDelta4h: number | null = null;

  if (validCount >= 2) {
    let buy30 = 0,
      sell30 = 0;
    for (let i = CVD_CANDLES - 2; i < CVD_CANDLES; i++) {
      buy30 += agg[i]!.buy;
      sell30 += agg[i]!.sell;
    }
    if (buy30 + sell30 > 0) cvd30m = buy30 > sell30;
  }

  if (validCount >= 4) {
    let buy1h = 0,
      sell1h = 0;
    for (let i = CVD_CANDLES - 4; i < CVD_CANDLES; i++) {
      buy1h += agg[i]!.buy;
      sell1h += agg[i]!.sell;
    }
    if (buy1h + sell1h > 0) {
      cvd1h = buy1h > sell1h;
      cvdStrength1h = (buy1h - sell1h) / (buy1h + sell1h);
    }
  }

  if (validCount >= 8) {
    const lastCumDelta = agg[CVD_CANDLES - 1]!.cumDelta;
    const totalVolCvd = agg.reduce((s, c) => s + c.buy + c.sell, 0);
    cvd4h = lastCumDelta > 0;
    cvdDelta4h = lastCumDelta;
    cvdStrength4h = totalVolCvd > 0 ? lastCumDelta / totalVolCvd : null;
  }

  const hardBlocked = false;
  const scalpOnly = cvd1h === false || cvd4h === false;
  const isGolden = cvd30m === true && cvd1h === true && cvd4h === true;

  const cvd: SpotCvdResult = {
    cvd30m,
    cvd1h,
    cvd4h,
    hardBlocked,
    scalpOnly,
    isGolden,
    available: validCount > 0,
    cvdStrength1h,
    cvdStrength4h,
    cvdDelta4h,
  };

  const entry: UnifiedCacheEntry = { cvd, spotVol24h, ts: Date.now() };
  unifiedCache.set(cgSymbol, entry);
  return entry;
}

// ─── Публичные API ────────────────────────────────────────────────────────────

/**
 * Возвращает CVD-вердикт + 24h spot volume за ОДИН API-вызов (limit=96).
 * Оба результата разделяют единый 3-мин кэш.
 * Используй вместо раздельных вызовов getSpotCvdMtf + getCoinglassSpotVolume24h,
 * если нужны оба значения для одного символа.
 */
export async function getSpotCvdAndVolume(
  symbol: string,
): Promise<{ cvd: SpotCvdResult; spotVol24h: number | null }> {
  const apiKey = getNextCgKey();
  if (!apiKey) return { cvd: { ...NO_CVD }, spotVol24h: null };

  const cgSymbol = toCgSymbol(symbol);
  const cached = unifiedCache.get(cgSymbol);
  if (cached && Date.now() - cached.ts < UNIFIED_CACHE_TTL) {
    return { cvd: cached.cvd, spotVol24h: cached.spotVol24h };
  }

  if (isCircuitBroken()) return { cvd: { ...NO_CVD }, spotVol24h: null };

  const entry = await fetchAndComputeUnified(cgSymbol, apiKey);
  return { cvd: entry.cvd, spotVol24h: entry.spotVol24h };
}

/**
 * Backward-compatible: возвращает только SpotCvdResult.
 * Внутри использует единый кэш — тот же HTTP-запрос обслуживает и getCoinglassSpotVolume24h.
 */
export async function getSpotCvdMtf(symbol: string): Promise<SpotCvdResult> {
  const { cvd } = await getSpotCvdAndVolume(symbol);

  logger.debug(
    {
      symbol,
      cvd30m: cvd.cvd30m,
      cvd1h: cvd.cvd1h,
      cvd4h: cvd.cvd4h,
      hardBlocked: cvd.hardBlocked,
      scalpOnly: cvd.scalpOnly,
      isGolden: cvd.isGolden,
      str1h:
        cvd.cvdStrength1h != null
          ? (cvd.cvdStrength1h * 100).toFixed(1) + "%"
          : "n/a",
      str4h:
        cvd.cvdStrength4h != null
          ? (cvd.cvdStrength4h * 100).toFixed(1) + "%"
          : "n/a",
      delta4h: cvd.cvdDelta4h != null ? cvd.cvdDelta4h.toFixed(0) : "n/a",
    },
    "Spot CVD MTF",
  );

  return cvd;
}

/**
 * Backward-compatible: возвращает только 24h spot volume (USD).
 * Внутри использует единый 3-мин кэш — тот же HTTP-запрос обслуживает и getSpotCvdMtf.
 * Прежний TTL 30 мин заменён на 3 мин (управляется свежестью CVD-данных).
 */
export async function getCoinglassSpotVolume24h(
  bingxSymbol: string,
): Promise<number | null> {
  const { spotVol24h } = await getSpotCvdAndVolume(bingxSymbol);
  if (spotVol24h != null) {
    logger.debug(
      { symbol: bingxSymbol, spotVol24h: spotVol24h.toFixed(0) },
      "CoinGlass Spot Vol 24h",
    );
  }
  return spotVol24h;
}

// ─── Кумулятивный Funding Rate 7d (CoinGlass) ────────────────────────────────
// Endpoint: GET /api/futures/funding-rate/accumulated-exchange-list?symbol=X&range=7d
// Возвращает СУММУ всех funding settlements за 7 дней (~21 период × 8h).
// Пример BTC: +0.116% за 7д = ~+0.0055%/период (нейтрально-позитивный лонг-перевес).
// Это принципиально лучше текущей ставки (снимок 1 периода), т.к. показывает
// устойчивость позиционирования, а не шум последнего расчёта.
//
// Endpoint возвращает данные только по одному символу — батч невозможен.
// Используем per-symbol кэш с TTL 15 мин (7d кумул. меняется медленно).
// Интерпретация порогов (7d, %):
//   > +0.30%  — лонги перегреты (сильный long bias)
//   > +0.10%  — лонги незначительно платят
//   < -0.05%  — шорты платят, позитивно для лонга
//   < -0.15%  — глубоко отрицательный, сквиз-давление

interface CgFundingExchangeEntry {
  exchange: string;
  funding_rate?: number;
}
interface CgFundingSymbolEntry {
  symbol: string;
  stablecoin_margin_list?: CgFundingExchangeEntry[];
  token_margin_list?: CgFundingExchangeEntry[];
}

const FUNDING_CACHE_MS = 15 * 60 * 1000;
const FUNDING_EXCHANGES = ["Binance", "Bybit", "OKX", "Bingx"];

const _fundingCache = new Map<string, { value: number; ts: number }>();

function computeMedianFunding(
  entries: CgFundingExchangeEntry[],
): number | null {
  const rates = entries
    .filter((e) =>
      FUNDING_EXCHANGES.some((ex) =>
        e.exchange.toLowerCase().includes(ex.toLowerCase()),
      ),
    )
    .map((e) => e.funding_rate)
    .filter((r): r is number => typeof r === "number" && isFinite(r));
  if (rates.length === 0) return null;
  rates.sort((a, b) => a - b);
  const mid = rates.length / 2;
  return rates.length % 2 === 0
    ? (rates[mid - 1]! + rates[mid]!) / 2
    : rates[Math.floor(mid)]!;
}

export async function getCoinglassAggregateFunding(
  bingxSymbol: string,
): Promise<number | null> {
  const cgSymbol = bingxSymbol.replace("-USDT", "");

  const cached = _fundingCache.get(cgSymbol);
  if (cached && Date.now() - cached.ts < FUNDING_CACHE_MS) return cached.value;

  const apiKey = getNextCgKey();
  if (!apiKey) return null;

  try {
    const url = `https://open-api-v4.coinglass.com/api/futures/funding-rate/accumulated-exchange-list?symbol=${cgSymbol}&range=7d`;
    const res = await fetch(url, {
      headers: { "CG-API-KEY": apiKey, Accept: "application/json" },
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return null;

    const data = (await res.json()) as {
      code: string;
      data?: CgFundingSymbolEntry[];
    };
    if (
      data.code !== "0" ||
      !Array.isArray(data.data) ||
      data.data.length === 0
    )
      return null;

    const symEntry = data.data[0]!;
    const entries = [
      ...(symEntry.stablecoin_margin_list ?? []),
      ...(symEntry.token_margin_list ?? []),
    ];
    const median = computeMedianFunding(entries);
    if (median !== null) {
      _fundingCache.set(cgSymbol, { value: median, ts: Date.now() });
      reportApiSuccess("coinglass");
    }
    return median;
  } catch {
    return null;
  }
}
