/**
 * growthLeaderRetro.ts — v2
 *
 * Расширенный ретроспективный сборщик для growth_leader_log (retro=true).
 *
 * Новые поля vs v1:
 *  - Реальный OI 30m (не аппроксимация oi1h/2); также OI 4h из отдельного запроса
 *  - prevOi30m/1h/4h — данные предыдущего цикла (t-30m/1h/4h)
 *  - oi24hD1/D2 — суточный OI за 1-2 дня до пампа
 *  - spotCvd4h — SpotCVD 4h бычий (CG aggregated-cvd/history)
 *  - cvd30m — реальный (не аппроксимация), из CG SpotCVD 30m endpoint
 *  - cvdStrength1h — (spotBuy1h-spotSell1h)/(buy+sell) [-1..1]
 *  - cvdDelta4h — Δ cum_vol_delta за 4h в USD
 *  - spotTakerNetBuyPct — спот taker net buy% за 1h
 *  - prevSpotVolMult, prevPrice30m — из BingX 30m klines
 *  - cgOiAvailable — было ли CG OI покрытие
 *
 * При force=true: удаляет все retro=true строки перед вставкой (clean re-run).
 *
 * Rate limits:
 *  - BingX 1h+30m: семафор 8 параллельных символов
 *  - CoinGlass: 5 ключей round-robin, семафор 6, задержки 150мс между запросами символа
 */
import { db, growthLeaderLogTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  getFutureTickers,
  getKlines,
  getFundingRate,
  type BingXKline,
} from "./bingx.js";
import { getNextCgKey, logCg429 } from "./coinglass_keys.js";
import { logger } from "./logger.js";

const delay = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

// ─── Семафор ─────────────────────────────────────────────────────────────────

async function withSemaphore<T>(
  sem: { used: number; max: number },
  fn: () => Promise<T>,
): Promise<T> {
  while (sem.used >= sem.max) await delay(50);
  sem.used++;
  try {
    return await fn();
  } finally {
    sem.used--;
  }
}

// ─── CoinGlass generic fetch ──────────────────────────────────────────────────

async function cgFetch<T>(url: string, context: string): Promise<T[] | null> {
  const key = getNextCgKey();
  if (!key) return null;
  try {
    const res = await fetch(url, {
      headers: { "CG-API-KEY": key, Accept: "application/json" },
      signal: AbortSignal.timeout(12_000),
    });
    if (res.status === 429) {
      logCg429(key, { context });
      return null;
    }
    const json = (await res.json()) as { code?: string; data?: T[] };
    if (
      json.code !== "0" ||
      !Array.isArray(json.data) ||
      json.data.length === 0
    )
      return null;
    return json.data;
  } catch {
    return null;
  }
}

// ─── Типы ────────────────────────────────────────────────────────────────────

interface CgOiPoint {
  time: number;
  open: number;
  close: number;
}
interface CgTakerCandle {
  time: number;
  taker_buy_volume_usd: string;
  taker_sell_volume_usd: string;
}
interface CgCvdCandle {
  time: number;
  cum_vol_delta: number;
}

interface KlineBar {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volUsd: number;
}

// ─── BingX klines ─────────────────────────────────────────────────────────────

async function fetchKlines(
  symbol: string,
  interval: string,
  limit: number,
): Promise<KlineBar[]> {
  try {
    const raw = await Promise.race([
      getKlines(symbol, interval, limit),
      new Promise<never>((_, reject) =>
        setTimeout(() => reject(new Error("BingX klines timeout")), 15_000),
      ),
    ]);
    return (raw as BingXKline[])
      .map((k: BingXKline) => ({
        time: k.time,
        open: parseFloat(k.open),
        high: parseFloat(k.high),
        low: parseFloat(k.low),
        close: parseFloat(k.close),
        volUsd: parseFloat(k.volume) * parseFloat(k.close),
      }))
      .filter((k) => k.close > 0);
  } catch {
    return [];
  }
}

// ─── Поиск памп-точек ─────────────────────────────────────────────────────────

interface RetroPoint {
  atMs: number;
  price: number;
  price24h: number;
  price1h: number | null;
  price3h: number | null;
  price4h: number | null;
  volMult: number | null;
  spotVolMult: number | null;
  futVolUsd24h: number | null;
}

function findRetroPoints(bars: KlineBar[], minPrice24h: number): RetroPoint[] {
  if (bars.length < 25) return [];
  const avgVol = bars.reduce((s, b) => s + b.volUsd, 0) / bars.length;
  const results: RetroPoint[] = [];
  let inPump = false;

  for (let i = 24; i < bars.length; i++) {
    const cur = bars[i],
      ref = bars[i - 24];
    if (ref.close <= 0) continue;
    const p24h = ((cur.close - ref.close) / ref.close) * 100;
    if (p24h < minPrice24h) {
      inPump = false;
      continue;
    }
    if (inPump) continue;
    inPump = true;

    const vol24h = bars
      .slice(Math.max(0, i - 23), i + 1)
      .reduce((s, b) => s + b.volUsd, 0);
    const volMult = avgVol > 0 ? cur.volUsd / avgVol : null;
    const avgVol24hWindow = vol24h / 24;
    const spotVolMult =
      avgVol > 0 && avgVol24hWindow > 0 ? avgVol24hWindow / avgVol : null;

    results.push({
      atMs: cur.time,
      price: cur.close,
      price24h: p24h,
      price1h:
        i >= 1 && bars[i - 1].close > 0
          ? ((cur.close - bars[i - 1].close) / bars[i - 1].close) * 100
          : null,
      price3h:
        i >= 3 && bars[i - 3].close > 0
          ? ((cur.close - bars[i - 3].close) / bars[i - 3].close) * 100
          : null,
      price4h:
        i >= 4 && bars[i - 4].close > 0
          ? ((cur.close - bars[i - 4].close) / bars[i - 4].close) * 100
          : null,
      volMult,
      spotVolMult,
      futVolUsd24h: vol24h > 0 ? vol24h : null,
    });
  }
  return results;
}

// ─── OI % из истории ───────────────────────────────────────────────────────────

function calcOiPct(
  pts: CgOiPoint[],
  atMs: number,
  windowMs: number,
): number | null {
  const target = pts.reduce<CgOiPoint | null>(
    (b, p) => (!b || Math.abs(p.time - atMs) < Math.abs(b.time - atMs) ? p : b),
    null,
  );
  if (!target) return null;
  const prevT = atMs - windowMs;
  const prev = pts.reduce<CgOiPoint | null>((b, p) => {
    if (p.time > atMs - windowMs / 2) return b;
    if (!b) return Math.abs(p.time - prevT) < 3_600_000 * 2 ? p : null;
    return Math.abs(p.time - prevT) < Math.abs(b.time - prevT) ? p : b;
  }, null);
  if (!prev || prev.close <= 0) return null;
  return ((target.close - prev.close) / prev.close) * 100;
}

// ─── CVD helpers ──────────────────────────────────────────────────────────────

function calcCvdDelta(
  pts: CgCvdCandle[],
  atMs: number,
  windowMs: number,
): number | null {
  const endPt = pts.reduce<CgCvdCandle | null>(
    (b, p) => (!b || Math.abs(p.time - atMs) < Math.abs(b.time - atMs) ? p : b),
    null,
  );
  if (!endPt) return null;
  const startMs = atMs - windowMs;
  const startPt = pts.reduce<CgCvdCandle | null>((b, p) => {
    if (p.time > startMs + windowMs / 2) return b;
    return !b || Math.abs(p.time - startMs) < Math.abs(b.time - startMs)
      ? p
      : b;
  }, null);
  if (!startPt) return null;
  return endPt.cum_vol_delta - startPt.cum_vol_delta;
}

function isCvdBullish(
  pts: CgCvdCandle[],
  atMs: number,
  windowMs: number,
): boolean | null {
  const delta = calcCvdDelta(pts, atMs, windowMs);
  return delta === null ? null : delta > 0;
}

// ─── 30m klines: prev candle metrics ─────────────────────────────────────────

function getPrev30mMetrics(
  bars: KlineBar[],
  atMs: number,
  avgVol: number,
): { prevPriceChange30m: number | null; prevSpotVolMult: number | null } {
  if (bars.length < 3 || avgVol <= 0)
    return { prevPriceChange30m: null, prevSpotVolMult: null };
  let curIdx = -1;
  for (let i = bars.length - 1; i >= 0; i--) {
    if (bars[i].time <= atMs) {
      curIdx = i;
      break;
    }
  }
  if (curIdx < 2) return { prevPriceChange30m: null, prevSpotVolMult: null };
  const prevBar = bars[curIdx - 1];
  const prevPrevBar = bars[curIdx - 2];
  return {
    prevPriceChange30m:
      prevPrevBar.close > 0
        ? ((prevBar.close - prevPrevBar.close) / prevPrevBar.close) * 100
        : null,
    prevSpotVolMult: prevBar.volUsd / avgVol,
  };
}

// ─── Taker данные за окно ─────────────────────────────────────────────────────

function sumTakerWindow(
  candles: CgTakerCandle[],
  atMs: number,
  windowMs: number,
) {
  let buy = 0,
    sell = 0;
  const from = atMs - windowMs,
    to = atMs + 3_600_000;
  for (const c of candles) {
    if (c.time >= from && c.time <= to) {
      buy += parseFloat(c.taker_buy_volume_usd) || 0;
      sell += parseFloat(c.taker_sell_volume_usd) || 0;
    }
  }
  return { buy, sell };
}

// ─── Обработчик одного символа ────────────────────────────────────────────────

async function processSymbol(
  symbol: string,
  minPrice24h: number,
  daysBack: number,
  nowMs: number,
  cgSem: { used: number; max: number },
): Promise<number> {
  try {
    const base = symbol.replace(/-USDT$/, "");
    const cgLimit1h = daysBack * 24 + 10;
    const cgLimit30m = Math.min(daysBack * 48 + 20, 1500);
    const cgLimit4h = daysBack * 6 + 10;
    const cgLimitCvd4h = daysBack * 6 + 10;

    // ── BingX klines: 1h + 30m параллельно ──────────────────────────────────
    const [bars1h, bars30m] = await Promise.all([
      fetchKlines(symbol, "1h", Math.min(daysBack * 24, 1000)),
      fetchKlines(symbol, "30m", Math.min(daysBack * 48, 1000)),
    ]);

    const points = findRetroPoints(bars1h, minPrice24h);
    if (points.length === 0) return 0;

    // ── CoinGlass Phase 1: OI 1h + SpotTaker + FutTaker + CVD 4h ────────────
    // delay() вынесен ДО withSemaphore — чтобы не держать слот во время ожидания
    const [oi1hHist, spotTaker, futTaker, cvd4hHist] = await Promise.all([
      withSemaphore(cgSem, () =>
        cgFetch<CgOiPoint>(
          `https://open-api-v4.coinglass.com/api/futures/open-interest/aggregated-history?symbol=${encodeURIComponent(base)}&interval=1h&limit=${cgLimit1h}`,
          `OI1h ${base}`,
        ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
      ),
      delay(150).then(() =>
        withSemaphore(cgSem, () =>
          cgFetch<CgTakerCandle>(
            `https://open-api-v4.coinglass.com/api/spot/taker-buy-sell-volume/history?exchange=Binance&symbol=${base}USDT&interval=1h&limit=${cgLimit1h}`,
            `SpotTaker ${base}`,
          ),
        ),
      ),
      delay(300).then(() =>
        withSemaphore(cgSem, () =>
          cgFetch<CgTakerCandle>(
            `https://open-api-v4.coinglass.com/api/futures/taker-buy-sell-volume/history?exchange=Binance&symbol=${base}USDT&interval=1h&limit=${cgLimit1h}`,
            `FutTaker ${base}`,
          ),
        ),
      ),
      delay(450).then(() =>
        withSemaphore(cgSem, () =>
          cgFetch<CgCvdCandle>(
            `https://open-api-v4.coinglass.com/api/spot/aggregated-cvd/history?symbol=${encodeURIComponent(base)}&interval=4h&limit=${cgLimitCvd4h}`,
            `CVD4h ${base}`,
          ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
        ),
      ),
    ]);

    const cgOiAvailable = oi1hHist !== null;

    // ── CoinGlass Phase 2: только если есть CG-покрытие ─────────────────────
    let oi30mHist: CgOiPoint[] | null = null;
    let oi4hHist: CgOiPoint[] | null = null;
    let oi1dHist: CgOiPoint[] | null = null;
    let cvd30mHist: CgCvdCandle[] | null = null;

    if (cgOiAvailable) {
      [oi30mHist, oi4hHist, oi1dHist, cvd30mHist] = await Promise.all([
        withSemaphore(cgSem, () =>
          cgFetch<CgOiPoint>(
            `https://open-api-v4.coinglass.com/api/futures/open-interest/aggregated-history?symbol=${encodeURIComponent(base)}&interval=30m&limit=${cgLimit30m}`,
            `OI30m ${base}`,
          ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
        ),
        delay(150).then(() =>
          withSemaphore(cgSem, () =>
            cgFetch<CgOiPoint>(
              `https://open-api-v4.coinglass.com/api/futures/open-interest/aggregated-history?symbol=${encodeURIComponent(base)}&interval=4h&limit=${cgLimit4h}`,
              `OI4h ${base}`,
            ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
          ),
        ),
        delay(300).then(() =>
          withSemaphore(cgSem, () =>
            cgFetch<CgOiPoint>(
              `https://open-api-v4.coinglass.com/api/futures/open-interest/aggregated-history?symbol=${encodeURIComponent(base)}&interval=1d&limit=${daysBack + 5}`,
              `OI1d ${base}`,
            ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
          ),
        ),
        delay(450).then(() =>
          withSemaphore(cgSem, () =>
            cgFetch<CgCvdCandle>(
              `https://open-api-v4.coinglass.com/api/spot/aggregated-cvd/history?symbol=${encodeURIComponent(base)}&interval=30m&limit=${cgLimit30m}`,
              `CVD30m ${base}`,
            ).then((d) => d?.sort((a, b) => a.time - b.time) ?? null),
          ),
        ),
      ]);
    }

    // ── Funding rate (BingX, только для свежих точек) ────────────────────────
    let currentFundingRate: number | null = null;
    const hasRecentPoint = points.some((p) => nowMs - p.atMs < 6 * 3_600_000);
    if (hasRecentPoint) {
      try {
        const fr = await getFundingRate(symbol);
        if (fr?.lastFundingRate != null) {
          const v = parseFloat(String(fr.lastFundingRate));
          if (isFinite(v)) currentFundingRate = v;
        }
      } catch {
        /* best-effort */
      }
    }

    const avg30mVol =
      bars30m.length > 0
        ? bars30m.reduce((s, b) => s + b.volUsd, 0) / bars30m.length
        : 0;

    const rows = points.map((pt) => {
      // ── OI ──────────────────────────────────────────────────────────────────
      const oi30m = oi30mHist
        ? calcOiPct(oi30mHist, pt.atMs, 30 * 60_000)
        : null;
      const prevOi30m = oi30mHist
        ? calcOiPct(oi30mHist, pt.atMs - 30 * 60_000, 30 * 60_000)
        : null;

      const oi1h = oi1hHist ? calcOiPct(oi1hHist, pt.atMs, 60 * 60_000) : null;
      const prevOi1h = oi1hHist
        ? calcOiPct(oi1hHist, pt.atMs - 60 * 60_000, 60 * 60_000)
        : null;

      const oi4h = oi4hHist ? calcOiPct(oi4hHist, pt.atMs, 240 * 60_000) : null;
      const prevOi4h = oi4hHist
        ? calcOiPct(oi4hHist, pt.atMs - 240 * 60_000, 240 * 60_000)
        : null;

      const nearest = oi1hHist?.reduce<CgOiPoint | null>(
        (b, p) =>
          !b || Math.abs(p.time - pt.atMs) < Math.abs(b.time - pt.atMs) ? p : b,
        null,
      );
      const oiUsdAbs = nearest?.close ?? null;

      // Daily OI (1 и 2 дня до начала пампа)
      const oi24hD1 = oi1dHist
        ? calcOiPct(oi1dHist, pt.atMs - 24 * 3600_000, 24 * 3600_000)
        : null;
      const oi24hD2 = oi1dHist
        ? calcOiPct(oi1dHist, pt.atMs - 48 * 3600_000, 24 * 3600_000)
        : null;

      // ── Spot Taker 1h ────────────────────────────────────────────────────────
      let spotBuyUsd: number | null = null,
        spotSellUsd: number | null = null;
      let cvd1h: boolean | null = null;
      let cvdStrength1h: number | null = null;
      let spotTakerNetBuyPct: number | null = null;

      if (spotTaker) {
        const w = sumTakerWindow(spotTaker, pt.atMs, 60 * 60_000);
        const total = w.buy + w.sell;
        if (total > 0) {
          spotBuyUsd = w.buy > 0 ? w.buy : null;
          spotSellUsd = w.sell > 0 ? w.sell : null;
          cvd1h = w.buy > w.sell;
          cvdStrength1h = (w.buy - w.sell) / total; // [-1..1]
          spotTakerNetBuyPct = ((w.buy - w.sell) / total) * 100;
        }
      }

      // ── SpotCVD 30m (реальный эндпоинт, заменяет аппроксимацию) ─────────────
      const cvd30m = cvd30mHist
        ? isCvdBullish(cvd30mHist, pt.atMs, 30 * 60_000)
        : null;

      // ── SpotCVD 4h ────────────────────────────────────────────────────────────
      const spotCvd4h = cvd4hHist
        ? isCvdBullish(cvd4hHist, pt.atMs, 240 * 60_000)
        : null;
      const cvdDelta4h = cvd4hHist
        ? calcCvdDelta(cvd4hHist, pt.atMs, 240 * 60_000)
        : null;

      // ── Futures Taker 1h ──────────────────────────────────────────────────────
      let netBuyPct: number | null = null;
      if (futTaker) {
        const w = sumTakerWindow(futTaker, pt.atMs, 60 * 60_000);
        if (w.buy + w.sell > 0)
          netBuyPct = ((w.buy - w.sell) / (w.buy + w.sell)) * 100;
      }

      // ── BingX 30m klines: предыдущая свеча ────────────────────────────────────
      const { prevPriceChange30m, prevSpotVolMult } = getPrev30mMetrics(
        bars30m,
        pt.atMs,
        avg30mVol,
      );

      const isRecent = nowMs - pt.atMs < 6 * 3_600_000;

      return {
        loggedAt: new Date(pt.atMs),
        symbol,
        rank: null,
        price: pt.price,
        price24h: pt.price24h,
        price1h: pt.price1h,
        price3h: pt.price3h,
        price4h: pt.price4h,
        growthFromEntry: null,
        cycleCount: null, // не восстанавливается из истории
        firstSeenAt: null,
        layers: [],
        // OI: реальный 30m если доступен, иначе аппроксимация oi1h/2
        oi30m: oi30m ?? (oi1h != null ? oi1h / 2 : null),
        oi1h,
        oi4h,
        oiUsdAbs,
        cvd1h,
        cvd30m, // реальный из SpotCVD 30m endpoint (если доступен)
        spotVolMult: pt.spotVolMult,
        volMult: pt.volMult,
        futVolUsd24h: pt.futVolUsd24h,
        fundingRate: isRecent ? currentFundingRate : null,
        source: "retrospective",
        retro: true,
        netBuyPct,
        spotTakerBuyUsd: spotBuyUsd,
        spotTakerSellUsd: spotSellUsd,
        entryPrice: null,
        entryPrice24h: null,
        entryOi30m: null,
        entryOi1h: null,
        entryOi4h: null,
        // ── v2 новые поля ──────────────────────────────────────────────────────
        prevOi30m,
        prevOi1h,
        prevOi4h,
        oi24hD1,
        oi24hD2,
        spotCvd4h,
        cvdStrength1h,
        cvdDelta4h,
        spotTakerNetBuyPct,
        prevSpotVolMult,
        prevPrice30m: prevPriceChange30m,
        cgOiAvailable,
      };
    });

    if (rows.length === 0) return 0;

    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        await db
          .insert(growthLeaderLogTable)
          .values(rows as (typeof growthLeaderLogTable.$inferInsert)[])
          .onConflictDoNothing();
        return rows.length;
      } catch (insertErr: unknown) {
        if (attempt < 2) {
          logger.warn({ symbol, attempt }, "growthLeaderRetro: INSERT retry");
          await delay(8_000);
        } else {
          throw insertErr;
        }
      }
    }
    return 0;
  } catch (err) {
    logger.warn({ err, symbol }, "growthLeaderRetro: символ пропущен");
    return 0;
  }
}

// ─── Публичный entry point ────────────────────────────────────────────────────

export interface RetroOpts {
  minPrice24h?: number; // % порог роста (default: 30)
  daysBack?: number; // глубина истории в днях (default: 7, max: 41 для BingX 1h)
  batchSize?: number; // символов в батче (default: 5)
  batchDelayMs?: number; // пауза между батчами мс (default: 600)
  force?: boolean; // если true — удаляет retro=true строки перед вставкой
}

export async function runGrowthLeaderRetro(
  opts: RetroOpts = {},
): Promise<{ inserted: number; symbols: number }> {
  const minPrice24h = opts.minPrice24h ?? 30;
  const daysBack = Math.min(opts.daysBack ?? 7, 41);
  const batchSize = opts.batchSize ?? 5;
  const batchDelayMs = opts.batchDelayMs ?? 600;
  const force = opts.force ?? false;

  logger.info(
    { minPrice24h, daysBack, batchSize, force },
    "growthLeaderRetro v2: старт",
  );

  // force=true → удаляем старые ретро-строки для чистого пересбора с v2 полями
  if (force) {
    try {
      await db
        .delete(growthLeaderLogTable)
        .where(eq(growthLeaderLogTable.retro, true));
      logger.info("growthLeaderRetro: старые ретро-строки удалены (force)");
    } catch (delErr) {
      logger.warn(
        { err: delErr },
        "growthLeaderRetro: не удалось удалить ретро-строки, продолжаем",
      );
    }
  }

  const tickers = await getFutureTickers();
  const allSymbols = tickers
    .map((t: { symbol: string }) => t.symbol)
    .filter((s: string) => s.endsWith("-USDT"));

  logger.info(
    { total: allSymbols.length },
    "growthLeaderRetro: символов получено",
  );

  const nowMs = Date.now();
  const cgSem = { used: 0, max: 6 };
  let totalInserted = 0;

  for (let i = 0; i < allSymbols.length; i += batchSize) {
    const batch = allSymbols.slice(i, i + batchSize);

    const results = await Promise.allSettled(
      batch.map((sym) =>
        processSymbol(sym, minPrice24h, daysBack, nowMs, cgSem),
      ),
    );

    for (const r of results) {
      if (r.status === "fulfilled") totalInserted += r.value;
    }

    if (i % (batchSize * 8) === 0 && i > 0) {
      logger.info(
        {
          processed: Math.min(i + batchSize, allSymbols.length),
          total: allSymbols.length,
          inserted: totalInserted,
        },
        "growthLeaderRetro: прогресс",
      );
    }

    if (i + batchSize < allSymbols.length) await delay(batchDelayMs);
  }

  logger.info(
    {
      inserted: totalInserted,
      symbols: allSymbols.length,
      minPrice24h,
      daysBack,
    },
    "growthLeaderRetro v2: завершён",
  );
  return { inserted: totalInserted, symbols: allSymbols.length };
}
