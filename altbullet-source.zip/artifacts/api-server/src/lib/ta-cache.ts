// ── TA Cache: shared bridge between watcher.ts and scanner.ts ─────────────────
// watcher.ts (runTaScannerCycle) populates this every 5 min via setTdAtrEntry().
// scanner.ts reads it per-symbol via getTdAtrEntry() during the scan loop.
// Avoids circular dependency: neither imports the other.

export interface TdAtrCacheEntry {
  td1h: number | null;
  td4h: number | null;
  atr1h: number | null;
  updatedAt: number;
}

// Key = cgBase format (e.g. "BTC", "ETH") — same as CoinGlass symbol keys.
// Scanner looks up using: symbol.replace("-USDT", "")
const _map = new Map<string, TdAtrCacheEntry>();

export function setTdAtrEntry(symbol: string, entry: TdAtrCacheEntry): void {
  _map.set(symbol, entry);
}

export function getTdAtrEntry(symbol: string): TdAtrCacheEntry | undefined {
  return _map.get(symbol);
}

export function getTdAtrMapSize(): number {
  return _map.size;
}
