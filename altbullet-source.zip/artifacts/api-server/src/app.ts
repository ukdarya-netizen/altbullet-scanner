import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

// Disable ETag — prevents 304 Not Modified caching of API responses in the dashboard
app.set("etag", false);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Force no-cache on all API responses so the dashboard always gets fresh data
app.use("/api", (_, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  next();
});

app.use("/api", router);

// Временный эндпоинт для скачивания исходного кода (удалить после скачивания)
import { createReadStream, existsSync } from "fs";
import { resolve } from "path";
app.get("/api/download", (_req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Скачать исходники</title>
<style>body{font-family:sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#0f172a;color:#e2e8f0;}
a{display:inline-block;padding:18px 40px;background:#3b82f6;color:#fff;text-decoration:none;border-radius:10px;font-size:1.2rem;font-weight:bold;margin-top:24px;}
a:hover{background:#2563eb;}p{color:#94a3b8;margin-top:12px;font-size:.9rem;}</style></head>
<body><h2>AltBullet — исходный код</h2>
<a href="/api/download/source" download="altbullet-source.zip">⬇ Скачать altbullet-source.zip</a>
<p>scanner.ts · watcher.ts · liq-cascade-watcher.ts · схема Drizzle · роуты Express · фронтенд</p>
</body></html>`);
});
app.get("/api/download/source", (_req, res) => {
  const zipPath = resolve(process.cwd(), "../../altbullet-source.zip");
  if (!existsSync(zipPath)) {
    res.status(404).send("File not found");
    return;
  }
  res.setHeader("Content-Disposition", "attachment; filename=altbullet-source.zip");
  res.setHeader("Content-Type", "application/zip");
  createReadStream(zipPath).pipe(res);
});

export default app;
