import type { Request, Response, NextFunction } from "express";
import crypto from "node:crypto";
import { logger } from "../lib/logger.js";

// ── Admin auth middleware ────────────────────────────────────────────────
// Защита чувствительных/тяжёлых эндпоинтов (bulk-import, ручные триггеры,
// массовые broadcast, heavy debug-запросы) секретным токеном в заголовке
// X-Admin-Token. Сравнение через crypto.timingSafeEqual, чтобы не давать
// атакующему возможность подобрать токен по времени ответа.
export function requireAdminToken(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  const expected = process.env.ADMIN_TOKEN;
  if (!expected) {
    logger.error("ADMIN_TOKEN not configured — refusing admin request");
    res.status(500).json({ error: "Server misconfiguration" });
    return;
  }

  const provided = req.header("X-Admin-Token");
  if (!provided) {
    res.status(401).json({ error: "Missing X-Admin-Token header" });
    return;
  }

  const expectedBuf = Buffer.from(expected);
  const providedBuf = Buffer.from(provided);

  const isValid =
    expectedBuf.length === providedBuf.length &&
    crypto.timingSafeEqual(expectedBuf, providedBuf);

  if (!isValid) {
    res.status(403).json({ error: "Invalid admin token" });
    return;
  }

  next();
}
