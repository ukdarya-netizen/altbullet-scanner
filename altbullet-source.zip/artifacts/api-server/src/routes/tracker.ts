import { Router } from "express";
import { PDB_HIDDEN_PATTERN_KEYS } from "../lib/dead-patterns.js";
import {
  db,
  trackedSignalsTable,
  prescanTrackerTable,
  patternDebugLogTable,
} from "@workspace/db";
import type { TrackedSignal } from "@workspace/db";
import {
  desc,
  asc,
  eq,
  gte,
  and,
  inArray,
  not,
  isNull,
  ilike,
  sql,
} from "drizzle-orm";
import {
  runWatcherCycle,
  sendWeeklyDigest,
  sendDailyReport,
  adminBroadcast,
  broadcastPhoto,
  broadcastPhotoWithText,
} from "../lib/watcher.js";
import { msgMilestone } from "../lib/watcher-formatters.js";
import {
  getLiveMarketData,
  lastPatternDebug,
  stopScanner,
  startScanner,
} from "../lib/scanner.js";
import {
  buildPositionsStatusText,
  POSITIONS_IMG,
} from "../lib/positionsReport.js";
import { getFutureTickers } from "../lib/bingx.js";
import { getFsVolume } from "../lib/coinglass_fs_volume.js";
import { batchFetchMarketCap } from "../lib/whale_watch_v2.js";
import { logger } from "../lib/logger.js";
import { getExitProfile } from "../lib/watcher-config.js";
import { backfillOiHistoryAfterCollisionCleanup } from "../lib/oiHistoryBackfill.js";
import {
  runGrowthLeaderSpotBackfill,
  runGrowthLeaderOi24hBackfill,
} from "../lib/growthLeaderBackfill.js";
import {
  runEnrichJob,
  getEnrichJobStatus,
  getCsvPath,
} from "../lib/growthLeaderEnrich.js";
import { requireAdminToken } from "../middleware/adminAuth.js";

const router = Router();

const OPEN_STATUSES = ["active", "in_run", "accumulation", "re_entry"] as const;

// GET /api/tracker — list tracked signals
router.get("/tracker", async (req, res) => {
  try {
    const status = req.query.status as string | undefined;
    const limit = Math.min(
      parseInt((req.query.limit as string) ?? "100") || 100,
      200,
    );

    const where =
      status && status !== "all"
        ? eq(trackedSignalsTable.status, status as any)
        : undefined;

    const signals = await db
      .select()
      .from(trackedSignalsTable)
      .where(where)
      .orderBy(desc(trackedSignalsTable.detectedAt))
      .limit(limit);

    // For open positions fetch live prices from BingX to compute real-time PnL
    const priceMap = new Map<string, number>();
    const openSignals = signals.filter((s) =>
      OPEN_STATUSES.includes(s.status as any),
    );
    if (openSignals.length > 0) {
      try {
        const tickers = (await getFutureTickers()) as {
          symbol: string;
          lastPrice: string;
        }[];
        for (const t of tickers)
          priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
      } catch {
        /* non-critical — show without live price */
      }
    }

    // Enrich open positions with live OI + CVD data from scanner prescan tracker
    const liveMarket = getLiveMarketData(openSignals.map((s) => s.symbol));

    res.json({
      signals: signals.map((s) => {
        const base = {
          ...s,
          detectedAt: s.detectedAt.toISOString(),
          updatedAt: s.updatedAt.toISOString(),
          closedAt: s.closedAt?.toISOString() ?? null,
        };
        if (OPEN_STATUSES.includes(s.status as any) && s.entryPrice != null) {
          const currentPrice = priceMap.get(s.symbol) ?? null;
          const entry = Number(s.entryPrice);
          const livePnl =
            currentPrice && entry > 0
              ? Math.round(((currentPrice - entry) / entry) * 10000) / 100
              : null;
          // Live peak = max(current price, stored peak) so dashboard always reflects reality
          const dbPeak = s.peakPrice != null ? Number(s.peakPrice) : null;
          const livePeak = currentPrice
            ? dbPeak && dbPeak > currentPrice
              ? dbPeak
              : currentPrice
            : dbPeak;
          const peakPnl =
            livePeak && entry > 0 ? ((livePeak - entry) / entry) * 100 : 0;
          // Trailing stop: activated once peak PnL >= trailingActivation (per-pattern profile)
          const exitProfile = getExitProfile(s.sentimentKey);
          const liveTrailingStop =
            peakPnl >= exitProfile.trailingActivation && livePeak
              ? Math.round(
                  livePeak * (1 - exitProfile.trailingGap / 100) * 1e8,
                ) / 1e8
              : null;
          const live = liveMarket[s.symbol];
          return {
            ...base,
            pnlPercent: livePnl,
            currentPrice,
            peakPrice: livePeak,
            trailingStopLevel: liveTrailingStop,
            // Per-field fallback: live prescan value → entry-time DB value → null.
            // This handles tokens in prescanTracker with newly-added null columns
            // (e.g. last_cvd_30m added but not yet written by scanner after restart).
            oi30m: live?.oi30m ?? s.entryOi30m ?? null,
            oi1h: live?.oi1h ?? s.entryOi1h ?? null,
            oi4h: live?.oi4h ?? s.entryOi4h ?? null,
            oi24h: live?.oi24h ?? s.entryOi24h ?? null,
            cvd30m: live?.cvd30m ?? s.entryCvd30m ?? null,
            cvd1h: live?.cvd1h ?? s.entryCvd1h ?? null,
            cvd4h: live?.cvd4h ?? s.entryCvd4h ?? null,
            netBuyPct: live?.netBuyPct ?? s.entryFutTakerNetBuy ?? null,
            price1h: live?.price1h ?? s.entryPrice1h ?? null,
            spotTakerNetBuy:
              live?.spotTakerNetBuy ?? s.entrySpotTakerNetBuy ?? null,
            spotTakerDominance: live?.spotTakerDominance ?? null,
            // WI доступен из prescanTracker (lastWhaleIndex) через live.whaleIndex;
            // OB не в prescan — появляется только через backfill job.
            entryWhaleIndex: live?.whaleIndex ?? s.entryWhaleIndex ?? null,
            entryObRatio: live?.obRatio ?? s.entryObRatio ?? null,
          };
        }
        return base;
      }),
      total: signals.length,
    });
  } catch (_err) {
    res.status(500).json({ error: "Failed to fetch tracked signals" });
  }
});

// GET /api/tracker/journal — full trading journal data
// Optional query param: ?from=YYYY-MM-DD
//   - Open signals (active/accumulation/in_run/re_entry): always counted without date filter
//   - Closed signals (profit/stop_loss/cancelled/breakeven): filtered by detected_at >= from
//     (detectedAt, NOT closedAt — prevents stale-cancel of old signals polluting current month)
router.get("/tracker/journal", async (req, res) => {
  try {
    const fromParam = req.query.from as string | undefined;
    const fromDate = fromParam ? new Date(fromParam) : null;
    // Filter closed signals by detectedAt (when the signal was found), NOT closedAt.
    // Using closedAt causes stale-cancel of old signals to pollute the current month's stats
    // (e.g. June signals stale-cancelled on July 1 appear as July cancellations).
    const closedFilter = fromDate
      ? gte(trackedSignalsTable.detectedAt, fromDate)
      : undefined;

    // 1a. Open signals — always count ALL open regardless of period filter
    const openStatusRows = await db
      .select({
        status: trackedSignalsTable.status,
        count: sql<number>`count(*)::int`,
      })
      .from(trackedSignalsTable)
      .where(
        and(
          inArray(trackedSignalsTable.status, [
            "active",
            "accumulation",
            "in_run",
            "re_entry",
          ]),
        ),
      )
      .groupBy(trackedSignalsTable.status);

    const byOpen: Record<string, number> = {};
    for (const row of openStatusRows) {
      byOpen[row.status ?? "unknown"] = row.count;
    }
    const active =
      (byOpen["active"] ?? 0) +
      (byOpen["accumulation"] ?? 0) +
      (byOpen["in_run"] ?? 0) +
      (byOpen["re_entry"] ?? 0);

    // 1b. Closed signals — filter by closedAt >= from
    const closedStatusRows = await db
      .select({
        status: trackedSignalsTable.status,
        count: sql<number>`count(*)::int`,
        avgPnl: sql<number>`round(avg(pnl_percent)::numeric, 2)`,
      })
      .from(trackedSignalsTable)
      .where(
        and(
          inArray(trackedSignalsTable.status, [
            "profit",
            "stop_loss",
            "cancelled",
            "breakeven",
            "bu_stop",
          ]),
          closedFilter,
        ),
      )
      .groupBy(trackedSignalsTable.status);

    const byStatus: Record<string, { count: number; avgPnl: number | null }> =
      {};
    for (const row of closedStatusRows) {
      byStatus[row.status ?? "unknown"] = {
        count: row.count,
        avgPnl: row.avgPnl != null ? Number(row.avgPnl) : null,
      };
    }

    const profit = byStatus["profit"]?.count ?? 0;
    const stopLoss = byStatus["stop_loss"]?.count ?? 0;
    const cancelled = byStatus["cancelled"]?.count ?? 0;
    const breakeven = byStatus["breakeven"]?.count ?? 0;
    const buStop = byStatus["bu_stop"]?.count ?? 0;
    const total = active + profit + stopLoss + cancelled + breakeven + buStop;
    const _closed = profit + stopLoss + breakeven + buStop;
    // Win rate = (profit + buStop) / (profit + buStop + stopLoss) — buStop считается как выигрыш (защищённая позиция)
    const winRateDenominator = profit + buStop + stopLoss;
    const winRate =
      winRateDenominator > 0
        ? Math.round(((profit + buStop) / winRateDenominator) * 100)
        : null;
    const avgProfit = byStatus["profit"]?.avgPnl ?? null;
    const avgLoss = byStatus["stop_loss"]?.avgPnl ?? null;
    const breakevenAvgPnl = byStatus["breakeven"]?.avgPnl ?? null;

    // 2. Best / worst trade — filter by closedAt >= from
    const bestRows = await db
      .select({
        symbol: trackedSignalsTable.symbol,
        pnl: trackedSignalsTable.pnlPercent,
        sentimentKey: trackedSignalsTable.sentimentKey,
      })
      .from(trackedSignalsTable)
      .where(and(eq(trackedSignalsTable.status, "profit"), closedFilter))
      .orderBy(desc(trackedSignalsTable.pnlPercent))
      .limit(1);

    const worstRows = await db
      .select({
        symbol: trackedSignalsTable.symbol,
        pnl: trackedSignalsTable.pnlPercent,
        sentimentKey: trackedSignalsTable.sentimentKey,
      })
      .from(trackedSignalsTable)
      .where(and(eq(trackedSignalsTable.status, "stop_loss"), closedFilter))
      .orderBy(trackedSignalsTable.pnlPercent)
      .limit(1);

    // 3. Per-pattern breakdown — closed signals only, filtered by closedAt >= from
    const patternRows = await db
      .select({
        sentimentKey: trackedSignalsTable.sentimentKey,
        status: trackedSignalsTable.status,
        count: sql<number>`count(*)::int`,
        avgPnl: sql<number>`round(avg(pnl_percent)::numeric, 2)`,
        avgPeak: sql<number>`round(avg((peak_price - entry_price) / nullif(entry_price, 0) * 100)::numeric, 2)`,
        lastSignalAt: sql<string>`max(detected_at)`,
      })
      .from(trackedSignalsTable)
      .where(
        and(
          inArray(trackedSignalsTable.status, [
            "profit",
            "stop_loss",
            "cancelled",
            "breakeven",
            "bu_stop",
          ]),
          closedFilter,
        ),
      )
      .groupBy(trackedSignalsTable.sentimentKey, trackedSignalsTable.status);

    const patternMap = new Map<
      string,
      {
        profit: number;
        stopLoss: number;
        cancelled: number;
        breakeven: number;
        buStop: number;
        totalPnl: number;
        pnlCount: number;
        totalPeak: number;
        peakCount: number;
        lastSignalAt: string | null;
      }
    >();
    for (const row of patternRows) {
      const key = row.sentimentKey ?? "unknown";
      if (!patternMap.has(key))
        patternMap.set(key, {
          profit: 0,
          stopLoss: 0,
          cancelled: 0,
          breakeven: 0,
          buStop: 0,
          totalPnl: 0,
          pnlCount: 0,
          totalPeak: 0,
          peakCount: 0,
          lastSignalAt: null,
        });
      const p = patternMap.get(key)!;
      if (row.status === "profit") p.profit += row.count;
      else if (row.status === "stop_loss") p.stopLoss += row.count;
      else if (row.status === "cancelled") p.cancelled += row.count;
      else if (row.status === "breakeven") p.breakeven += row.count;
      else if (row.status === "bu_stop") p.buStop += row.count;
      if (row.avgPnl != null) {
        p.totalPnl += Number(row.avgPnl) * row.count;
        p.pnlCount += row.count;
      }
      if (row.avgPeak != null) {
        p.totalPeak += Number(row.avgPeak) * row.count;
        p.peakCount += row.count;
      }
      if (
        row.lastSignalAt != null &&
        (p.lastSignalAt == null || row.lastSignalAt > p.lastSignalAt)
      ) {
        p.lastSignalAt = row.lastSignalAt as string;
      }
    }

    const byPattern = Array.from(patternMap.entries())
      .map(([key, p]) => {
        const patTotal =
          p.profit + p.stopLoss + p.cancelled + p.breakeven + p.buStop;
        const patWrDenom = p.profit + p.buStop + p.stopLoss;
        return {
          sentimentKey: key,
          total: patTotal,
          profit: p.profit,
          stopLoss: p.stopLoss,
          cancelled: p.cancelled,
          buStop: p.buStop,
          winRate:
            patWrDenom > 0
              ? Math.round(((p.profit + p.buStop) / patWrDenom) * 100)
              : null,
          avgPnl:
            p.pnlCount > 0
              ? Math.round((p.totalPnl / p.pnlCount) * 10) / 10
              : null,
          avgPeak:
            p.peakCount > 0
              ? Math.round((p.totalPeak / p.peakCount) * 10) / 10
              : null,
          lastSignalAt: p.lastSignalAt,
        };
      })
      .sort((a, b) => b.total - a.total);

    // 4. Per-token breakdown — closed signals only, filtered by closedAt >= from
    const tokenRows = await db.execute(
      fromDate
        ? sql`
          SELECT
            symbol,
            COUNT(*)::int                                                                         AS total,
            COUNT(*) FILTER (WHERE status = 'profit')::int                                       AS profit,
            COUNT(*) FILTER (WHERE status = 'stop_loss')::int                                    AS stop_loss,
            COUNT(*) FILTER (WHERE status = 'cancelled')::int                                    AS cancelled,
            COUNT(*) FILTER (WHERE status = 'breakeven')::int                                    AS breakeven,
            ROUND(AVG(pnl_percent)::numeric, 2)                                                  AS avg_pnl,
            ROUND(MAX(pnl_percent) FILTER (WHERE status = 'profit')::numeric, 2)                AS best_pnl,
            ROUND(AVG((peak_price - entry_price) / NULLIF(entry_price, 0) * 100)::numeric, 2)   AS avg_peak,
            MODE() WITHIN GROUP (ORDER BY sentiment_key)                                         AS main_pattern,
            MAX(detected_at)                                                                      AS last_signal_at
          FROM tracked_signals
          WHERE status IN ('profit', 'stop_loss', 'cancelled', 'breakeven')
            AND closed_at >= ${fromDate}
          GROUP BY symbol
          ORDER BY total DESC
        `
        : sql`
          SELECT
            symbol,
            COUNT(*)::int                                                                         AS total,
            COUNT(*) FILTER (WHERE status = 'profit')::int                                       AS profit,
            COUNT(*) FILTER (WHERE status = 'stop_loss')::int                                    AS stop_loss,
            COUNT(*) FILTER (WHERE status = 'cancelled')::int                                    AS cancelled,
            COUNT(*) FILTER (WHERE status = 'breakeven')::int                                    AS breakeven,
            ROUND(AVG(pnl_percent)::numeric, 2)                                                  AS avg_pnl,
            ROUND(MAX(pnl_percent) FILTER (WHERE status = 'profit')::numeric, 2)                AS best_pnl,
            ROUND(AVG((peak_price - entry_price) / NULLIF(entry_price, 0) * 100)::numeric, 2)   AS avg_peak,
            MODE() WITHIN GROUP (ORDER BY sentiment_key)                                         AS main_pattern,
            MAX(detected_at)                                                                      AS last_signal_at
          FROM tracked_signals
          WHERE status IN ('profit', 'stop_loss', 'cancelled', 'breakeven')
          GROUP BY symbol
          ORDER BY total DESC
        `,
    );

    const byToken = (tokenRows.rows as Record<string, unknown>[]).map((r) => {
      const tok_profit = Number(r.profit) || 0;
      const tok_stop = Number(r.stop_loss) || 0;
      const tok_wrDenom = tok_profit + tok_stop;
      return {
        symbol: r.symbol as string,
        total: Number(r.total),
        profit: tok_profit,
        stopLoss: tok_stop,
        cancelled: Number(r.cancelled) || 0,
        winRate:
          tok_wrDenom > 0 ? Math.round((tok_profit / tok_wrDenom) * 100) : null,
        avgPnl: r.avg_pnl != null ? Number(r.avg_pnl) : null,
        bestPnl: r.best_pnl != null ? Number(r.best_pnl) : null,
        avgPeak: r.avg_peak != null ? Number(r.avg_peak) : null,
        mainPattern: (r.main_pattern as string) ?? null,
        lastSignalAt:
          r.last_signal_at != null ? String(r.last_signal_at) : null,
      };
    });

    // 5. Recent closed trades (last 50) with entry conditions
    const tradeRows = await db.execute(
      fromDate
        ? sql`
          SELECT
            ts.id, ts.symbol, ts.status, ts.sentiment_key,
            ts.entry_price, ts.exit_price,
            ROUND(ts.pnl_percent::numeric, 2)                                               AS pnl_percent,
            ROUND(((ts.peak_price - ts.entry_price)/NULLIF(ts.entry_price,0)*100)::numeric, 2) AS peak_pct,
            ts.detected_at, ts.closed_at,
            ROUND(EXTRACT(EPOCH FROM (COALESCE(ts.closed_at, NOW()) - ts.detected_at))/3600, 1) AS hours_held,
            s.oi_change_percent,
            s.cumulative_oi_change,
            ROUND((s.volume_24h / NULLIF(s.avg_volume, 0))::numeric, 1) AS vol_mult,
            s.alpha_score,
            s.price_change_percent AS px_24h
          FROM tracked_signals ts
          LEFT JOIN signals s ON ts.signal_id = s.id
          WHERE ts.status IN ('profit', 'stop_loss', 'cancelled', 'breakeven')
            AND ts.closed_at >= ${fromDate}
          ORDER BY ts.closed_at DESC
          LIMIT 50
        `
        : sql`
          SELECT
            ts.id, ts.symbol, ts.status, ts.sentiment_key,
            ts.entry_price, ts.exit_price,
            ROUND(ts.pnl_percent::numeric, 2)                                               AS pnl_percent,
            ROUND(((ts.peak_price - ts.entry_price)/NULLIF(ts.entry_price,0)*100)::numeric, 2) AS peak_pct,
            ts.detected_at, ts.closed_at,
            ROUND(EXTRACT(EPOCH FROM (COALESCE(ts.closed_at, NOW()) - ts.detected_at))/3600, 1) AS hours_held,
            s.oi_change_percent,
            s.cumulative_oi_change,
            ROUND((s.volume_24h / NULLIF(s.avg_volume, 0))::numeric, 1) AS vol_mult,
            s.alpha_score,
            s.price_change_percent AS px_24h
          FROM tracked_signals ts
          LEFT JOIN signals s ON ts.signal_id = s.id
          WHERE ts.status IN ('profit', 'stop_loss', 'cancelled', 'breakeven')
          ORDER BY ts.closed_at DESC NULLS LAST
          LIMIT 50
        `,
    );

    const trades = (tradeRows.rows as Record<string, unknown>[]).map((r) => ({
      id: r.id,
      symbol: r.symbol,
      status: r.status,
      sentimentKey: r.sentiment_key,
      entryPrice: r.entry_price != null ? Number(r.entry_price) : null,
      exitPrice: r.exit_price != null ? Number(r.exit_price) : null,
      pnlPercent: r.pnl_percent != null ? Number(r.pnl_percent) : null,
      peakPct: r.peak_pct != null ? Number(r.peak_pct) : null,
      detectedAt: r.detected_at,
      closedAt: r.closed_at ?? null,
      hoursHeld: r.hours_held != null ? Number(r.hours_held) : null,
      oiChangePct:
        r.oi_change_percent != null ? Number(r.oi_change_percent) : null,
      cumulativeOi:
        r.cumulative_oi_change != null ? Number(r.cumulative_oi_change) : null,
      volMult: r.vol_mult != null ? Number(r.vol_mult) : null,
      alphaScore: r.alpha_score != null ? Number(r.alpha_score) : null,
      px24h: r.px_24h != null ? Number(r.px_24h) : null,
    }));

    res.json({
      summary: {
        total,
        profit,
        stopLoss,
        cancelled,
        breakeven,
        buStop,
        active,
        winRate,
        avgProfit,
        avgLoss,
        breakevenAvgPnl,
        bestTrade: bestRows[0]
          ? {
              symbol: bestRows[0].symbol,
              pnl: Number(bestRows[0].pnl),
              sentimentKey: bestRows[0].sentimentKey ?? null,
            }
          : null,
        worstTrade: worstRows[0]
          ? {
              symbol: worstRows[0].symbol,
              pnl: Number(worstRows[0].pnl),
              sentimentKey: worstRows[0].sentimentKey ?? null,
            }
          : null,
      },
      byPattern,
      byToken,
      trades,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch journal");
    res.status(500).json({ error: "Failed to fetch journal" });
  }
});

// GET /api/tracker/monthly-stats — stats grouped by calendar month
router.get("/tracker/monthly-stats", async (req, res) => {
  try {
    const rows = await db.execute(sql`
      SELECT
        TO_CHAR(detected_at, 'YYYY-MM') AS month,
        COUNT(*)::int                                                                     AS total,
        COUNT(*) FILTER (WHERE status = 'profit')::int                                   AS profit,
        COUNT(*) FILTER (WHERE status = 'stop_loss')::int                                AS stop_loss,
        COUNT(*) FILTER (WHERE status = 'cancelled')::int                                AS cancelled,
        COUNT(*) FILTER (WHERE status = 'breakeven')::int                                AS breakeven,
        COUNT(*) FILTER (WHERE status = 'bu_stop')::int                                  AS bu_stop,
        ROUND(AVG(pnl_percent) FILTER (WHERE status = 'profit')::numeric, 2)             AS avg_profit,
        ROUND(AVG(pnl_percent) FILTER (WHERE status = 'stop_loss')::numeric, 2)          AS avg_loss,
        ROUND(AVG(pnl_percent) FILTER (WHERE status = 'breakeven')::numeric, 1)          AS breakeven_avg_pnl,
        ROUND(AVG((peak_price - entry_price) / NULLIF(entry_price, 0) * 100)
              FILTER (WHERE status IN ('profit','stop_loss'))::numeric, 2)               AS avg_peak,
        MAX(pnl_percent) FILTER (WHERE status = 'profit')                                AS best_pnl,
        MIN(pnl_percent) FILTER (WHERE status = 'stop_loss')                             AS worst_pnl
      FROM tracked_signals
      WHERE status IN ('profit','stop_loss','cancelled','breakeven','bu_stop')
      GROUP BY TO_CHAR(detected_at, 'YYYY-MM')
      ORDER BY month DESC
    `);

    const months = (rows.rows as Record<string, unknown>[]).map((r) => {
      const profit = Number(r.profit ?? 0);
      const stopLoss = Number(r.stop_loss ?? 0);
      const buStopM = Number(r.bu_stop ?? 0);
      const _closed = profit + stopLoss + Number(r.breakeven ?? 0) + buStopM;
      const winRateDenom = profit + buStopM + stopLoss;
      const winRate =
        winRateDenom > 0
          ? Math.round(((profit + buStopM) / winRateDenom) * 100)
          : null;

      const [year, mon] = String(r.month).split("-");
      const monthLabel = new Date(
        Number(year),
        Number(mon) - 1,
        1,
      ).toLocaleDateString("ru-RU", {
        month: "long",
        year: "numeric",
      });

      return {
        month: r.month as string,
        label: monthLabel,
        total: Number(r.total ?? 0),
        profit,
        stopLoss,
        cancelled: Number(r.cancelled ?? 0),
        breakeven: Number(r.breakeven ?? 0),
        winRate,
        avgProfit: r.avg_profit != null ? Number(r.avg_profit) : null,
        avgLoss: r.avg_loss != null ? Number(r.avg_loss) : null,
        breakevenAvgPnl:
          r.breakeven_avg_pnl != null ? Number(r.breakeven_avg_pnl) : null,
        avgPeak: r.avg_peak != null ? Number(r.avg_peak) : null,
        bestPnl: r.best_pnl != null ? Number(r.best_pnl) : null,
        worstPnl: r.worst_pnl != null ? Number(r.worst_pnl) : null,
      };
    });

    res.json({ months });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch monthly stats");
    res.status(500).json({ error: "Failed to fetch monthly stats" });
  }
});

// GET /api/tracker/stats — summary stats (all-time + current month)
router.get("/tracker/stats", async (req, res) => {
  try {
    const monthStart = new Date();
    monthStart.setDate(1);
    monthStart.setHours(0, 0, 0, 0);

    const [rows, monthRows] = await Promise.all([
      db
        .select({
          status: trackedSignalsTable.status,
          count: sql<number>`count(*)::int`,
          avgPnl: sql<number>`round(avg(pnl_percent)::numeric, 2)`,
        })
        .from(trackedSignalsTable)
        .groupBy(trackedSignalsTable.status),

      db
        .select({
          status: trackedSignalsTable.status,
          count: sql<number>`count(*)::int`,
          avgPnl: sql<number>`round(avg(pnl_percent)::numeric, 2)`,
        })
        .from(trackedSignalsTable)
        // detectedAt: сигналы ОБНАРУЖЁННЫЕ в этом месяце, не закрытые.
        // closedAt вызывал баг: stale-cancel июньских сигналов 1 июля → 111 отмен "за июль".
        .where(gte(trackedSignalsTable.detectedAt, monthStart))
        .groupBy(trackedSignalsTable.status),
    ]);

    const stats: Record<string, { count: number; avgPnl: number | null }> = {};
    for (const row of rows)
      stats[row.status] = { count: row.count, avgPnl: row.avgPnl };

    const monthStats: Record<string, { count: number; avgPnl: number | null }> =
      {};
    for (const row of monthRows)
      monthStats[row.status] = { count: row.count, avgPnl: row.avgPnl };

    const total = rows.reduce((s, r) => s + r.count, 0);
    const profits = stats["profit"]?.count ?? 0;
    const buStops = stats["bu_stop"]?.count ?? 0;
    const stops = stats["stop_loss"]?.count ?? 0;
    // bu_stop считается выигрышем (защищённая позиция) — единая формула с /journal и Telegram дайджестом
    const winRate =
      profits + buStops + stops > 0
        ? Math.round(((profits + buStops) / (profits + buStops + stops)) * 100)
        : null;
    const avgProfit =
      stats["profit"]?.avgPnl != null ? Number(stats["profit"].avgPnl) : null;
    const avgLoss =
      stats["stop_loss"]?.avgPnl != null
        ? Number(stats["stop_loss"].avgPnl)
        : null;

    // Month-only derived stats
    const mProfits = monthStats["profit"]?.count ?? 0;
    const mBuStops = monthStats["bu_stop"]?.count ?? 0;
    const mStops = monthStats["stop_loss"]?.count ?? 0;
    const monthWinRate =
      mProfits + mBuStops + mStops > 0
        ? Math.round(
            ((mProfits + mBuStops) / (mProfits + mBuStops + mStops)) * 100,
          )
        : null;
    const monthAvgProfit =
      monthStats["profit"]?.avgPnl != null
        ? Number(monthStats["profit"].avgPnl)
        : null;
    const monthAvgLoss =
      monthStats["stop_loss"]?.avgPnl != null
        ? Number(monthStats["stop_loss"].avgPnl)
        : null;

    res.json({
      stats,
      total,
      winRate,
      avgProfit,
      avgLoss,
      monthStats,
      monthWinRate,
      monthAvgProfit,
      monthAvgLoss,
    });
  } catch (_err) {
    res.status(500).json({ error: "Failed to fetch tracker stats" });
  }
});

// POST /api/tracker/import — bulk-insert tracked positions (migration/admin tool)
// Body: { positions: Array<{ symbol, sentimentKey, isShort?, entryPrice, detectedAt, status? }> }
router.post("/tracker/import", requireAdminToken, async (req, res) => {
  try {
    const { positions } = req.body as {
      positions: Array<{
        symbol: string;
        sentimentKey: string;
        isShort?: boolean;
        entryPrice: number;
        detectedAt: string;
        status?: string;
      }>;
    };
    if (!Array.isArray(positions) || positions.length === 0) {
      res.status(400).json({ error: "positions array required" });
      return;
    }
    const now = new Date();
    const inserted: string[] = [];
    const skipped: string[] = [];
    for (const p of positions) {
      // Skip if already open for this symbol
      const existing = await db
        .select({ id: trackedSignalsTable.id })
        .from(trackedSignalsTable)
        .where(
          and(
            eq(trackedSignalsTable.symbol, p.symbol),
            inArray(trackedSignalsTable.status, [
              "active",
              "in_run",
              "accumulation",
              "re_entry",
            ]),
          ),
        )
        .limit(1);
      if (existing.length > 0) {
        skipped.push(p.symbol);
        continue;
      }
      await db.insert(trackedSignalsTable).values({
        symbol: p.symbol,
        signalType: "strict_alpha",
        sentimentKey: p.sentimentKey,
        isShort: p.isShort ?? false,
        entryPrice: p.entryPrice,
        status: (p.status ?? "active") as any,
        detectedAt: new Date(p.detectedAt),
        updatedAt: now,
      });
      inserted.push(p.symbol);
    }
    req.log.info({ inserted, skipped }, "tracker/import: positions imported");
    res.json({ ok: true, inserted, skipped });
  } catch (err) {
    req.log.error({ err }, "tracker/import failed");
    res.status(500).json({ error: "Import failed" });
  }
});

// POST /api/tracker/run-cycle — manually trigger watcher cycle
router.post("/tracker/run-cycle", requireAdminToken, async (req, res) => {
  try {
    const result = await runWatcherCycle();
    res.json({ ok: true, ...result });
  } catch (_err) {
    res.status(500).json({ error: "Watcher cycle failed" });
  }
});

// POST /api/tracker/notify — admin broadcast custom message to all subscribers
router.post("/tracker/notify", requireAdminToken, async (req, res) => {
  try {
    const { text } = req.body as { text?: string };
    if (!text) {
      res.status(400).json({ error: "text required" });
      return;
    }
    await adminBroadcast(text);
    res.json({ ok: true });
  } catch (_err) {
    res.status(500).json({ error: "Broadcast failed" });
  }
});

// POST /api/tracker/weekly-digest — send weekly digest now (manual, bypass dedupe)
router.post("/tracker/weekly-digest", async (req, res) => {
  try {
    await sendWeeklyDigest(undefined, true);
    res.json({ ok: true });
  } catch (_err) {
    res.status(500).json({ error: "Weekly digest failed" });
  }
});

// POST /api/tracker/daily-digest — send daily report now (manual, bypass dedupe)
router.post("/tracker/daily-digest", async (req, res) => {
  try {
    await sendDailyReport(undefined, true);
    res.json({ ok: true });
  } catch (_err) {
    res.status(500).json({ error: "Daily report failed" });
  }
});

// POST /api/tracker/positions-update — send positions status to all subscribers now
router.post("/tracker/positions-update", async (req, res) => {
  try {
    const text = await buildPositionsStatusText();
    await broadcastPhotoWithText(POSITIONS_IMG, text);
    res.json({ ok: true });
  } catch (_err) {
    res.status(500).json({ error: "Positions update failed" });
  }
});

// ── POST /api/tracker/spot-audit ──────────────────────────────────────────────
// Прогоняет все открытые сигналы через спот-фильтр (% от MCap).
// Отменяет те, где данные есть и объём ниже порога.
// Отправляет сводку в Telegram и возвращает JSON с результатами.
router.post("/tracker/spot-audit", async (req, res) => {
  try {
    const OPEN_STATUSES = [
      "active",
      "in_run",
      "accumulation",
      "re_entry",
    ] as const;
    // Спот-объём >= MIN_PCT * MCap — только процентный порог, без фиксированной суммы.
    // Нет MCap данных → блок.
    const MIN_PCT_ALPHA = 0.0005; // 0.05% MCap — стандартные паттерны

    // 1. Все открытые позиции
    const open = await db
      .select()
      .from(trackedSignalsTable)
      .where(inArray(trackedSignalsTable.status, [...OPEN_STATUSES]));

    if (open.length === 0) {
      await adminBroadcast(
        `🔍 <b>Аудит спот-фильтра</b>\n\nОткрытых позиций нет — нечего проверять.`,
      );
      res.json({ ok: true, total: 0, cancelled: 0, passed: 0, noData: 0 });
      return;
    }

    // 2. Получаем текущие цены для P&L
    const priceMap = new Map<string, number>();
    try {
      const tickers = (await getFutureTickers()) as {
        symbol: string;
        lastPrice: string;
      }[];
      for (const t of tickers)
        priceMap.set(t.symbol, parseFloat(t.lastPrice) || 0);
    } catch {
      /* skip */
    }

    // 3. Спот-объёмы — параллельно (BingX, без rate limit проблем)
    //    MCap — одним батч-запросом к CoinGecko (экономим rate limit)
    type AuditRow = {
      sig: TrackedSignal;
      spotVol24h: number | null;
      marketCapUsd: number | null;
      spotPct: number | null;
      minPct: number;
      verdict: "cancel" | "pass" | "no_data";
    };

    const symbols = open.map((s) => s.symbol);

    // Параллельно: все spot vol + один батч mcap запрос
    const [spotVolMap, mcapMap] = await Promise.all([
      Promise.all(
        symbols.map((sym) =>
          getFsVolume(sym)
            .then((r) => r.spotVolUsd24h ?? null)
            .catch(() => null)
            .then((vol) => [sym, vol] as [string, number | null]),
        ),
      ).then((entries) => new Map(entries)),
      batchFetchMarketCap(symbols),
    ]);

    const rows: AuditRow[] = open.map((sig) => {
      const minPct = MIN_PCT_ALPHA;
      const spotVol24h = spotVolMap.get(sig.symbol) ?? null;
      const mcapData = mcapMap.get(sig.symbol) ?? null;
      const marketCapUsd = mcapData?.mcap ?? null;
      const spotPct =
        spotVol24h != null && marketCapUsd != null && marketCapUsd > 0
          ? (spotVol24h / marketCapUsd) * 100
          : null;

      // Только процентный порог от MCap — нет MCap данных → no_data (не отменяем).
      let verdict: AuditRow["verdict"] = "no_data";
      if (spotVol24h !== null && marketCapUsd !== null) {
        const pctOk = spotPct !== null && spotPct >= minPct * 100;
        verdict = pctOk ? "pass" : "cancel";
      }

      return { sig, spotVol24h, marketCapUsd, spotPct, minPct, verdict };
    });

    // 4. Отмена: массовый UPDATE
    const toCancel = rows.filter((r) => r.verdict === "cancel");
    if (toCancel.length > 0) {
      await db
        .update(trackedSignalsTable)
        .set({
          status: "cancelled",
          cancelReason: "spot_audit_low_vol",
          closedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(
          inArray(
            trackedSignalsTable.id,
            toCancel.map((r) => r.sig.id),
          ),
        );
      logger.info(
        { cancelled: toCancel.map((r) => r.sig.symbol) },
        "spot-audit: принудительно отменены сигналы с низким спот-объёмом",
      );
    }

    // 5. Telegram сводка
    const now = new Date();
    const moscowTime = now.toLocaleString("ru-RU", {
      timeZone: "Europe/Moscow",
      day: "2-digit",
      month: "long",
      hour: "2-digit",
      minute: "2-digit",
    });

    function fmtP(p: number): string {
      if (p >= 1) return `$${p.toFixed(3)}`;
      if (p >= 0.01) return `$${p.toFixed(4)}`;
      return `$${p.toFixed(5)}`;
    }
    function computePnl(sig: TrackedSignal, curPrice: number): number {
      if (!sig.entryPrice || sig.entryPrice === 0) return 0;
      const diff = curPrice - sig.entryPrice;
      return ((sig.isShort ? -diff : diff) / sig.entryPrice) * 100;
    }

    const lines: string[] = [
      `🔍 <b>Аудит спот-фильтра</b> — <i>${moscowTime} МСК</i>`,
      ``,
      `Проверено позиций: <b>${open.length}</b>`,
      ``,
    ];

    // Отменённые
    if (toCancel.length > 0) {
      lines.push(`❌ <b>Закрыты принудительно — ${toCancel.length}</b>`);
      for (const r of toCancel) {
        const coin = r.sig.symbol.replace("-USDT", "");
        const pctStr =
          r.spotPct != null ? `${r.spotPct.toFixed(1)}% MCap` : "?% MCap";
        const reqStr = `${(r.minPct * 100).toFixed(0)}%`;
        const curPrice = priceMap.get(r.sig.symbol);
        const pnl = curPrice ? computePnl(r.sig, curPrice) : null;
        const pnlStr =
          pnl != null ? ` | P&L: ${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%` : "";
        lines.push(
          `  • <b>${coin}</b> — спот ${pctStr} (нужно ≥${reqStr})${pnlStr}`,
        );
      }
      lines.push(``);
    }

    // Прошли фильтр
    const passed = rows.filter((r) => r.verdict === "pass");
    if (passed.length > 0) {
      lines.push(`✅ <b>Прошли фильтр — ${passed.length}</b>`);
      for (const r of passed) {
        const coin = r.sig.symbol.replace("-USDT", "");
        const pctStr = r.spotPct != null ? `${r.spotPct.toFixed(1)}% MCap` : "";
        const curPrice = priceMap.get(r.sig.symbol);
        const pnl = curPrice ? computePnl(r.sig, curPrice) : null;
        const pnlStr =
          pnl != null ? ` | ${pnl >= 0 ? "+" : ""}${pnl.toFixed(1)}%` : "";
        const priceStr = curPrice
          ? ` | ${fmtP(r.sig.entryPrice ?? 0)} → ${fmtP(curPrice)}`
          : "";
        lines.push(`  • <b>${coin}</b> — ${pctStr}${priceStr}${pnlStr}`);
      }
      lines.push(``);
    }

    // Нет данных (не блокировали — но сообщаем)
    const noData = rows.filter((r) => r.verdict === "no_data");
    if (noData.length > 0) {
      lines.push(`⚠️ <b>Нет данных MCap — ${noData.length} (не тронуты)</b>`);
      for (const r of noData) {
        const coin = r.sig.symbol.replace("-USDT", "");
        lines.push(`  • <b>${coin}</b>`);
      }
      lines.push(``);
    }

    lines.push(
      `📋 Итог: закрыто <b>${toCancel.length}</b>, активно <b>${passed.length + noData.length}</b>`,
    );

    await adminBroadcast(lines.join("\n"));

    // После аудита — сразу отправить актуальный список позиций
    try {
      const posText = await buildPositionsStatusText();
      await adminBroadcast(posText);
    } catch (err) {
      logger.warn(
        { err },
        "spot-audit: не удалось отправить список позиций после аудита",
      );
    }

    res.json({
      ok: true,
      total: open.length,
      cancelled: toCancel.length,
      passed: passed.length,
      noData: noData.length,
      cancelledSymbols: toCancel.map((r) => r.sig.symbol),
      passedSymbols: passed.map((r) => r.sig.symbol),
      noDataSymbols: noData.map((r) => r.sig.symbol),
    });
  } catch (err) {
    logger.error({ err }, "spot-audit: ошибка");
    res.status(500).json({ error: "Spot audit failed" });
  }
});

// Немедленно отправляет актуальный список открытых позиций в Telegram.
router.post("/tracker/send-positions", async (req, res) => {
  try {
    const text = await buildPositionsStatusText();
    await adminBroadcast(text);
    res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "send-positions: ошибка");
    res.status(500).json({ error: "Send positions failed" });
  }
});

// GET /api/debug/signal-metrics — diagnostic endpoint, three modes:
//   ?ids=441,452,...          — by tracked_signal IDs (ts.id)
//   ?signal_ids=427,426,...   — by signals table IDs (ts.signal_id)
//   ?by_pattern=dip_accumulation&status=cancelled&days=60  — by sentimentKey+status
router.get("/debug/signal-metrics", requireAdminToken, async (req, res) => {
  try {
    const COLS = sql`
        ts.id,
        ts.symbol,
        ts.signal_type,
        ts.status,
        ts.cancel_reason,
        to_char(ts.detected_at, 'YYYY-MM-DD HH24:MI') AS detected_at,
        to_char(ts.closed_at,   'YYYY-MM-DD HH24:MI') AS closed_at,
        EXTRACT(EPOCH FROM ts.closed_at) * 1000        AS closed_at_ms,
        ROUND(ts.entry_price::numeric, 6)              AS entry_price,
        ROUND(ts.exit_price::numeric, 6)               AS exit_price,
        ts.prescan_cycles,
        ROUND(ts.price_24h_at_fire::numeric, 1)        AS price_24h,
        ROUND(ts.pnl_percent::numeric, 2)              AS pnl,
        ts.entry_cvd_30m                               AS cvd_30m,
        ts.entry_cvd_1h                                AS cvd_1h,
        ts.entry_cvd_4h                                AS cvd_4h,
        ts.alpha_score,
        ROUND((s.volume_24h / NULLIF(s.avg_volume, 0))::numeric, 2) AS vol_mult_signal,
        ROUND(s.oi_change_percent::numeric, 2)         AS oi_30m_signal,
        ROUND(s.price_change_percent::numeric, 2)      AS price_pct_signal,
        NULL::numeric                                  AS oi_short,
        ROUND(ow.oi_30m::numeric, 2)                   AS oi_30m,
        ROUND(ow.oi_1h::numeric, 2)                    AS oi_1h,
        ROUND(ow.oi_24h::numeric, 2)                   AS oi_24h,
        ROUND(ow.entry_vol_mult::numeric, 2)           AS oi_watch_vol_mult,
        ROUND(ow.volume_multiplier::numeric, 2)        AS oi_watch_vol_at_fire,
        ow.vol_status_reason,
        ow.sentiment_key                               AS oi_watch_pattern,
        ROUND(ow.price_24h_change::numeric, 1)         AS oi_watch_p24h`;

    const JOINS = sql`
      FROM tracked_signals ts
      LEFT JOIN signals s ON ts.signal_id = s.id
      LEFT JOIN LATERAL (
        SELECT * FROM oi_watch
        WHERE symbol = ts.symbol
          AND fired_at IS NOT NULL
          AND fired_at <= ts.detected_at + INTERVAL '5 minutes'
          AND fired_at >= ts.detected_at - INTERVAL '60 minutes'
        ORDER BY fired_at DESC
        LIMIT 1
      ) ow ON true`;

    let rows: Awaited<ReturnType<typeof db.execute>>;

    // Mode 1: by tracked_signal IDs
    const rawIds = req.query.ids as string | undefined;
    // Mode 2: by signals table IDs
    const rawSignalIds = req.query.signal_ids as string | undefined;
    // Mode 3: by sentimentKey + status + days
    const byPattern = req.query.by_pattern as string | undefined;

    if (rawIds) {
      const ids = rawIds
        .split(",")
        .map((s) => parseInt(s.trim(), 10))
        .filter((n) => !isNaN(n));
      if (!ids.length) return res.status(400).json({ error: "no valid ids" });
      rows = await db.execute(
        sql`SELECT ${COLS} ${JOINS} WHERE ts.id IN (${sql.raw(ids.join(","))}) ORDER BY ts.detected_at DESC`,
      );
    } else if (rawSignalIds) {
      const sids = rawSignalIds
        .split(",")
        .map((s) => parseInt(s.trim(), 10))
        .filter((n) => !isNaN(n));
      if (!sids.length)
        return res.status(400).json({ error: "no valid signal_ids" });
      rows = await db.execute(
        sql`SELECT ${COLS} ${JOINS} WHERE ts.signal_id IN (${sql.raw(sids.join(","))}) ORDER BY ts.detected_at DESC`,
      );
    } else if (byPattern) {
      const status = (req.query.status as string | undefined) ?? "cancelled";
      const days = Math.min(
        parseInt((req.query.days as string | undefined) ?? "90", 10),
        180,
      );
      const statuses = status
        .split(",")
        .map((s) => `'${s.trim().replace(/'/g, "")}'`)
        .join(",");
      rows = await db.execute(sql`SELECT ${COLS} ${JOINS}
        WHERE ts.sentiment_key = ${byPattern}
          AND ts.status IN (${sql.raw(statuses)})
          AND ts.detected_at >= NOW() - INTERVAL '${sql.raw(String(days))} days'
        ORDER BY ts.detected_at DESC LIMIT 100`);
    } else {
      return res
        .status(400)
        .json({ error: "ids, signal_ids, or by_pattern param required" });
    }

    // Fetch BingX post-exit price deltas (+1h / +4h / +24h after closed_at)
    const BX_BASE = "https://open-api.bingx.com";
    async function bxKlinesFrom(
      symbol: string,
      startMs: number,
    ): Promise<{
      p1h: number | null;
      p4h: number | null;
      p24h: number | null;
    }> {
      try {
        const url = `${BX_BASE}/openApi/swap/v3/quote/klines?symbol=${encodeURIComponent(symbol)}&interval=1h&limit=26&startTime=${startMs}`;
        const r = await fetch(url, { signal: AbortSignal.timeout(6000) });
        const j = (await r.json()) as {
          code: number;
          data?: Array<{ open: string; close: string; time: number }>;
        };
        if (j.code !== 0 || !Array.isArray(j.data) || j.data.length === 0)
          return { p1h: null, p4h: null, p24h: null };
        const klines = j.data.sort((a, b) => a.time - b.time);
        const get = (idx: number) =>
          klines[idx] ? parseFloat(klines[idx].close) : null;
        return { p1h: get(1), p4h: get(4), p24h: get(24) };
      } catch {
        return { p1h: null, p4h: null, p24h: null };
      }
    }

    function pctChange(from: number | null, to: number | null): number | null {
      if (from == null || to == null || from === 0) return null;
      return Math.round(((to - from) / from) * 1000) / 10; // 1dp
    }

    // Enrich rows with post-exit price data (parallel, max 5 at a time)
    const dbRows = rows.rows as Record<string, unknown>[];
    const enriched = await Promise.all(
      dbRows.map(async (row) => {
        const closedMs =
          row.closed_at_ms != null ? Number(row.closed_at_ms) : null;
        const exitPrice =
          row.exit_price != null ? Number(row.exit_price) : null;
        const entryPrice =
          row.entry_price != null ? Number(row.entry_price) : null;
        const symbol = String(row.symbol);

        let postExit: {
          p1h: number | null;
          p4h: number | null;
          p24h: number | null;
        } = {
          p1h: null,
          p4h: null,
          p24h: null,
        };
        if (closedMs && closedMs > 0) {
          postExit = await bxKlinesFrom(symbol, closedMs);
        }

        return {
          ...row,
          closed_at_ms: undefined, // remove raw ms from output
          post_exit: {
            ref_price: exitPrice ?? entryPrice, // price at exit point
            price_1h: postExit.p1h,
            price_4h: postExit.p4h,
            price_24h: postExit.p24h,
            pct_1h: pctChange(exitPrice ?? entryPrice, postExit.p1h),
            pct_4h: pctChange(exitPrice ?? entryPrice, postExit.p4h),
            pct_24h: pctChange(exitPrice ?? entryPrice, postExit.p24h),
          },
        };
      }),
    );

    return res.json({ count: enriched.length, data: enriched });
  } catch (err) {
    req.log.error({ err }, "debug/signal-metrics: query failed");
    return res.status(500).json({ error: String(err) });
  }
});

// ── Debug: prescan tracker live data ─────────────────────────────────────────
router.get("/tracker/prescan-debug", async (req, res) => {
  const raw = String(req.query.symbols ?? "");
  if (!raw) {
    res.status(400).json({ error: "symbols param required (comma-separated)" });
    return;
  }
  const symbols = raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 50);
  try {
    const rows = await db
      .select({
        symbol: prescanTrackerTable.symbol,
        cycleCount: prescanTrackerTable.cycleCount,
        lastOi30m: prescanTrackerTable.lastOi30m,
        lastOi1h: prescanTrackerTable.lastOi1h,
        lastOi4h: prescanTrackerTable.lastOi4h,
        cvdPositiveCycles: prescanTrackerTable.cvdPositiveCycles,
        lastCgTimedOut: prescanTrackerTable.lastCgTimedOut,
        updatedAt: prescanTrackerTable.updatedAt,
      })
      .from(prescanTrackerTable)
      .where(inArray(prescanTrackerTable.symbol, symbols));
    res.json(rows);
  } catch (err) {
    req.log.error({ err }, "prescan-debug: DB error");
    res.status(500).json({ error: "DB error" });
  }
});

// GET /api/tracker/cancelled-today — отменённые за последние 24ч
router.get("/tracker/cancelled-today", async (req, res) => {
  try {
    const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const rows = await db
      .select()
      .from(trackedSignalsTable)
      .where(
        sql`
        ${trackedSignalsTable.status} = 'cancelled'
        AND ${trackedSignalsTable.closedAt} >= ${since}
      `,
      )
      .orderBy(desc(trackedSignalsTable.closedAt));
    // Map entry* field names to the same aliases used by /api/tracker so the
    // UI can use consistent field names across all tables without branching.
    res.json({
      signals: rows.map((r) => ({
        ...r,
        oi30m: r.entryOi30m,
        oi1h: r.entryOi1h,
        oi4h: r.entryOi4h,
        oi24h: r.entryOi24h,
        cvd30m: r.entryCvd30m,
        cvd1h: r.entryCvd1h,
        cvd4h: r.entryCvd4h,
        netBuyPct: r.entryFutTakerNetBuy,
        spotTakerNetBuy: r.entrySpotTakerNetBuy,
        price1h: r.entryPrice1h,
      })),
    });
  } catch (err) {
    req.log.error({ err }, "cancelled-today error");
    res.status(500).json({ error: String(err) });
  }
});

// POST /api/admin/fix-bustop-history — migrate misclassified stop_loss → bu_stop for signals with last_milestone >= 5
router.post("/admin/fix-bustop-history", async (req, res) => {
  try {
    const result = await db.execute(sql`
      UPDATE tracked_signals
      SET status = 'bu_stop', updated_at = NOW()
      WHERE status = 'stop_loss'
        AND last_milestone IS NOT NULL
        AND last_milestone >= 5
    `);
    const count = (result as any).rowCount ?? (result as any).count ?? "?";
    req.log.info(
      { count },
      "admin/fix-bustop-history: migrated stop_loss → bu_stop",
    );
    res.json({ ok: true, updated: count });
  } catch (err) {
    req.log.error({ err }, "admin/fix-bustop-history error");
    res.status(500).json({ error: String(err) });
  }
});

// POST /api/admin/rerun-oi-backfill — manually re-trigger OI history backfill for remaining NULL rows
router.post("/admin/rerun-oi-backfill", requireAdminToken, async (req, res) => {
  try {
    backfillOiHistoryAfterCollisionCleanup().catch((err) => {
      req.log.error({ err }, "admin/rerun-oi-backfill background error");
    });
    res.json({ ok: true, started: true });
  } catch (err) {
    req.log.error({ err }, "admin/rerun-oi-backfill error");
    res.status(500).json({ error: String(err) });
  }
});

// POST /api/admin/resend-milestone — resend milestone photo for a signal
router.post("/admin/resend-milestone", requireAdminToken, async (req, res) => {
  const { symbol, milestone } = req.body as {
    symbol?: string;
    milestone?: number;
  };
  if (!symbol || !milestone) {
    res.status(400).json({ error: "symbol and milestone required" });
    return;
  }
  try {
    const rows = await db
      .select()
      .from(trackedSignalsTable)
      .where(
        and(
          eq(trackedSignalsTable.symbol, symbol.toUpperCase()),
          inArray(trackedSignalsTable.status, ["in_run", "active"] as any[]),
        ),
      )
      .limit(1);
    if (rows.length === 0) {
      res
        .status(404)
        .json({ error: `No active/in_run signal found for ${symbol}` });
      return;
    }
    const tracked = rows[0]!;
    const MILESTONE_IMGS: Record<number, string> = {
      10: new URL("../../assets/milestone10.png", import.meta.url).pathname,
      15: new URL("../../assets/milestone15.png", import.meta.url).pathname,
      25: new URL("../../assets/moonshot.png", import.meta.url).pathname,
      50: new URL("../../assets/milestone50.png", import.meta.url).pathname,
      100: new URL("../../assets/milestone100.png", import.meta.url).pathname,
    };
    const imgPath = MILESTONE_IMGS[milestone];
    const trailingStop = tracked.trailingStopLevel ?? tracked.entryPrice * 0.9;
    const currentPrice =
      tracked.exitPrice ?? tracked.peakPrice ?? tracked.entryPrice;
    const text = msgMilestone(tracked, milestone, currentPrice, trailingStop);
    if (imgPath) {
      await broadcastPhoto(imgPath, text);
    } else {
      await adminBroadcast(text);
    }
    req.log.info({ symbol, milestone }, "admin/resend-milestone sent");
    res.json({ ok: true, symbol, milestone, withPhoto: !!imgPath });
  } catch (err) {
    req.log.error({ err }, "admin/resend-milestone error");
    res.status(500).json({ error: String(err) });
  }
});

// GET /api/tracker/signal-history — полная история из trackedSignalsTable со всеми entry metrics
router.get("/tracker/signal-history", async (req, res) => {
  try {
    const limit = Math.min(
      parseInt((req.query.limit as string) ?? "50") || 50,
      200,
    );
    const offset = Math.max(
      parseInt((req.query.offset as string) ?? "0") || 0,
      0,
    );
    const status = req.query.status as string | undefined;
    const pattern = req.query.pattern as string | undefined;
    const symbol = ((req.query.symbol as string) || "").trim().toUpperCase();

    const conditions: ReturnType<typeof eq>[] = [];

    if (symbol) {
      const searchTerm = symbol.includes("-") ? symbol : `%${symbol}%`;
      conditions.push(
        ilike(
          trackedSignalsTable.symbol,
          searchTerm.includes("%") ? searchTerm : `%${searchTerm}%`,
        ) as any,
      );
    }

    if (status && status !== "all") {
      if (status === "open") {
        conditions.push(
          inArray(trackedSignalsTable.status, [
            "active",
            "in_run",
            "accumulation",
            "re_entry",
          ]) as any,
        );
      } else if (status === "closed") {
        conditions.push(
          inArray(trackedSignalsTable.status, [
            "profit",
            "stop_loss",
            "cancelled",
            "breakeven",
            "bu_stop",
          ]) as any,
        );
      } else {
        conditions.push(eq(trackedSignalsTable.status, status as any));
      }
    }

    if (pattern && pattern !== "all") {
      conditions.push(eq(trackedSignalsTable.sentimentKey, pattern));
    }

    const where = conditions.length > 0 ? and(...conditions) : undefined;

    const [countRow, rows] = await Promise.all([
      db
        .select({ count: sql<number>`count(*)::int` })
        .from(trackedSignalsTable)
        .where(where),
      db
        .select({
          id: trackedSignalsTable.id,
          symbol: trackedSignalsTable.symbol,
          signalType: trackedSignalsTable.signalType,
          sentimentKey: trackedSignalsTable.sentimentKey,
          alphaScore: trackedSignalsTable.alphaScore,
          isShort: trackedSignalsTable.isShort,
          status: trackedSignalsTable.status,
          entryPrice: trackedSignalsTable.entryPrice,
          exitPrice: trackedSignalsTable.exitPrice,
          pnlPercent: trackedSignalsTable.pnlPercent,
          peakPrice: trackedSignalsTable.peakPrice,
          detectedAt: trackedSignalsTable.detectedAt,
          closedAt: trackedSignalsTable.closedAt,
          cancelReason: trackedSignalsTable.cancelReason,
          price24hAtFire: trackedSignalsTable.price24hAtFire,
          prescanCycles: trackedSignalsTable.prescanCycles,
          entrySource: trackedSignalsTable.entrySource,
          stopLossPct: trackedSignalsTable.stopLossPct,
          stopSource: trackedSignalsTable.stopSource,
          // OI entry metrics
          entryOi30m: trackedSignalsTable.entryOi30m,
          entryOi1h: trackedSignalsTable.entryOi1h,
          entryOi4h: trackedSignalsTable.entryOi4h,
          entryOi24h: trackedSignalsTable.entryOi24h,
          // CVD entry metrics
          entryCvd30m: trackedSignalsTable.entryCvd30m,
          entryCvd1h: trackedSignalsTable.entryCvd1h,
          entryCvd4h: trackedSignalsTable.entryCvd4h,
          // Volume entry metrics
          entrySpotVolMult: trackedSignalsTable.entrySpotVolMult,
          entryFutVolMult: trackedSignalsTable.entryFutVolMult,
          entrySpotVol24h: trackedSignalsTable.entrySpotVol24h,
          entrySpotMcapPct: trackedSignalsTable.entrySpotMcapPct,
          entryFutTakerNetBuy: trackedSignalsTable.entryFutTakerNetBuy,
          entrySpotTakerNetBuy: trackedSignalsTable.entrySpotTakerNetBuy,
          entrySpotNetBuy1h: trackedSignalsTable.entrySpotNetBuy1h,
          entrySpotNetBuy4h: trackedSignalsTable.entrySpotNetBuy4h,
          entrySpotNetBuy24h: trackedSignalsTable.entrySpotNetBuy24h,
          entryPrice1h: trackedSignalsTable.entryPrice1h,
          // Universal entry metrics
          entryRsi1h: trackedSignalsTable.entryRsi1h,
          entryFundingRate: trackedSignalsTable.entryFundingRate,
          entryBtc24h: trackedSignalsTable.entryBtc24h,
          entryWhaleIndex: trackedSignalsTable.entryWhaleIndex,
          // Market context
          marketCapUsd: trackedSignalsTable.marketCapUsd,
          // Liquidation Cascade specific
          entryLiqLong1h: trackedSignalsTable.entryLiqLong1h,
          entryLiqLong24h: trackedSignalsTable.entryLiqLong24h,
          entryLiqRatio: trackedSignalsTable.entryLiqRatio,
          entryLiqReason: trackedSignalsTable.entryLiqReason,
          // Orderbook
          entryObRatio: trackedSignalsTable.entryObRatio,
        })
        .from(trackedSignalsTable)
        .where(where)
        .orderBy(desc(trackedSignalsTable.detectedAt))
        .limit(limit)
        .offset(offset),
    ]);

    res.json({
      total: countRow[0]?.count ?? 0,
      signals: rows.map((r) => ({
        ...r,
        detectedAt: r.detectedAt.toISOString(),
        closedAt: r.closedAt?.toISOString() ?? null,
        peakPct:
          r.peakPrice && r.entryPrice && r.entryPrice > 0
            ? ((r.peakPrice - r.entryPrice) / r.entryPrice) * 100
            : null,
        entryFundingRate:
          r.entryFundingRate != null
            ? r.entryFundingRate * 100 // raw decimal → percent
            : null,
      })),
    });
  } catch (err) {
    req.log.error({ err }, "signal-history error");
    res.status(500).json({ error: "Failed to get signal history" });
  }
});

// GET /api/admin/backtest-spot-mcap — backtest: сколько сигналов заблокировал бы гейт spotVol < 1% MCap
// Целевые паттерны — те, где нет никакого spot vol условия (только они получат новый гейт)
router.get("/admin/backtest-spot-mcap", requireAdminToken, async (req, res) => {
  try {
    const { sql } = await import("drizzle-orm");
    // Паттерны с существующим spot vol gate — НЕ трогаем
    const WITH_SPOT_VOL = ["spot_vol_accumulation"];
    // Целевые паттерны (без spot vol) — им добавим 1% MCap
    const TARGET = ["trend_accumulation", "bullish_accumulation"];

    const byPattern = await db.execute(sql`
      SELECT
        sentiment_key,
        COUNT(*)::int                                                                        AS total,
        COUNT(*) FILTER (WHERE entry_spot_mcap_pct IS NULL)::int                            AS no_data,
        COUNT(*) FILTER (WHERE entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct < 1.0)::int   AS would_block,
        COUNT(*) FILTER (WHERE entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct >= 1.0)::int  AS would_pass,
        ROUND(MIN(entry_spot_mcap_pct)::numeric, 3)                                         AS min_pct,
        ROUND(AVG(entry_spot_mcap_pct)::numeric, 2)                                         AS avg_pct,
        COUNT(*) FILTER (WHERE status = 'stop_loss' AND entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct < 1.0)::int AS stops_below,
        COUNT(*) FILTER (WHERE status = 'profit'    AND entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct < 1.0)::int AS profits_below,
        COUNT(*) FILTER (WHERE status = 'stop_loss' AND entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct >= 1.0)::int AS stops_above,
        COUNT(*) FILTER (WHERE status = 'profit'    AND entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct >= 1.0)::int AS profits_above,
        ROUND(AVG(pnl_percent) FILTER (WHERE status IN ('profit','stop_loss','bu_stop','breakeven') AND entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct < 1.0)::numeric, 2) AS avg_closed_pnl_below,
        ROUND(AVG(pnl_percent) FILTER (WHERE status IN ('profit','stop_loss','bu_stop','breakeven') AND entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct >= 1.0)::numeric, 2) AS avg_closed_pnl_above
      FROM tracked_signals
      WHERE sentiment_key = ANY(${TARGET})
      GROUP BY sentiment_key
      ORDER BY total DESC
    `);

    const summary = await db.execute(sql`
      SELECT
        COUNT(*)::int                                                                        AS total,
        COUNT(*) FILTER (WHERE entry_spot_mcap_pct IS NULL)::int                            AS no_data,
        COUNT(*) FILTER (WHERE entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct < 1.0)::int   AS would_block,
        COUNT(*) FILTER (WHERE entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct >= 1.0)::int  AS would_pass,
        COUNT(*) FILTER (WHERE status = 'stop_loss' AND entry_spot_mcap_pct < 1.0)::int    AS stops_blocked,
        COUNT(*) FILTER (WHERE status = 'profit'    AND entry_spot_mcap_pct < 1.0)::int    AS profits_blocked,
        ROUND(AVG(pnl_percent) FILTER (WHERE status IN ('profit','stop_loss','bu_stop','breakeven') AND entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct < 1.0)::numeric, 2) AS avg_pnl_blocked,
        ROUND(AVG(pnl_percent) FILTER (WHERE status IN ('profit','stop_loss','bu_stop','breakeven') AND entry_spot_mcap_pct IS NOT NULL AND entry_spot_mcap_pct >= 1.0)::numeric, 2) AS avg_pnl_passed
      FROM tracked_signals
      WHERE sentiment_key = ANY(${TARGET})
    `);

    res.json({
      ok: true,
      targetPatterns: TARGET,
      withSpotVolAlready: WITH_SPOT_VOL,
      summary: summary.rows[0],
      byPattern: byPattern.rows,
    });
  } catch (err) {
    req.log.error({ err }, "admin/backtest-spot-mcap error");
    res.status(500).json({ error: String(err) });
  }
});

// GET /api/scanner/pattern-debug/aggregate — агрегат по паттернам: checked/passed/topRejections за последние N циклов
router.get(
  "/scanner/pattern-debug/aggregate",
  requireAdminToken,
  async (req, res) => {
    const cycles = Math.min(Number(req.query.cycles ?? 20), 200);
    try {
      // Паттерны удалённые из активного скоринга — фильтруются из агрегата.
      // ВАЖНО: определяем ДО запросов — latestRow query использует этот список
      // чтобы найти последний цикл с РЕАЛЬНЫМИ (не удалёнными) паттернами.
      // Если брать просто MAX(cycleNumber), можно попасть на цикл где только
      // исторические/удалённые паттерны → fromCycle смотрит не туда → patterns=[].
      const DELETED_PATTERNS_ARRAY = PDB_HIDDEN_PATTERN_KEYS;
      const DELETED_PATTERNS = new Set(DELETED_PATTERNS_ARRAY);

      // Находим последний cycleNumber где есть хотя бы один НЕ-удалённый паттерн.
      // NULLS LAST — в PostgreSQL NULL сортируется первым при DESC, что ломает LIMIT 1.
      const latestRow = await db
        .select({ cycleNumber: patternDebugLogTable.cycleNumber })
        .from(patternDebugLogTable)
        .where(
          and(
            isNull(patternDebugLogTable.symbol),
            not(inArray(patternDebugLogTable.pattern, DELETED_PATTERNS_ARRAY)),
            sql`${patternDebugLogTable.pattern} not like 'liqgate_%'`,
          ),
        )
        .orderBy(sql`${patternDebugLogTable.cycleNumber} DESC NULLS LAST`)
        .limit(1);

      const latestCycle = latestRow[0]?.cycleNumber ?? 0;
      const fromCycle = (latestCycle ?? 0) - cycles;

      // Читаем aggregate-строки (symbol IS NULL) за последние N циклов
      const rows = await db
        .select({
          pattern: patternDebugLogTable.pattern,
          cycleNumber: patternDebugLogTable.cycleNumber,
          checked: patternDebugLogTable.checked,
          passed: patternDebugLogTable.passed,
          rejectedAt: patternDebugLogTable.rejectedAt,
        })
        .from(patternDebugLogTable)
        .where(
          and(
            isNull(patternDebugLogTable.symbol),
            gte(patternDebugLogTable.cycleNumber, fromCycle),
          ),
        )
        .orderBy(asc(patternDebugLogTable.cycleNumber));

      // Агрегируем по паттерну
      const byPattern = new Map<
        string,
        {
          checked: number;
          passed: number;
          rejectedAt: Record<string, number>;
          cycles: number;
        }
      >();
      for (const row of rows) {
        if (DELETED_PATTERNS.has(row.pattern)) continue;
        const e = byPattern.get(row.pattern) ?? {
          checked: 0,
          passed: 0,
          rejectedAt: {},
          cycles: 0,
        };
        e.checked += row.checked;
        e.passed += row.passed;
        e.cycles += 1;
        if (row.rejectedAt) {
          try {
            const gates = JSON.parse(row.rejectedAt) as Record<string, number>;
            for (const [gate, count] of Object.entries(gates)) {
              e.rejectedAt[gate] =
                (e.rejectedAt[gate] ?? 0) + (count as number);
            }
          } catch {
            /* ignore */
          }
        }
        byPattern.set(row.pattern, e);
      }

      const toPatternRow = (
        pattern: string,
        e: {
          checked: number;
          passed: number;
          rejectedAt: Record<string, number>;
          cycles: number;
        },
      ) => {
        const totalRejections = Object.values(e.rejectedAt).reduce(
          (s, v) => s + v,
          0,
        );
        const topRejections = Object.entries(e.rejectedAt)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 7)
          .map(([gate, count]) => ({
            gate,
            count,
            pct:
              totalRejections > 0
                ? +((count / totalRejections) * 100).toFixed(1)
                : 0,
          }));
        const topRejectCoverage = +topRejections
          .reduce((s, r) => s + r.pct, 0)
          .toFixed(1);
        const totalGates = Object.keys(e.rejectedAt).length;
        return {
          pattern,
          checked: e.checked,
          passed: e.passed,
          passRate:
            e.checked > 0 ? +((e.passed / e.checked) * 100).toFixed(1) : 0,
          cycles: e.cycles,
          topRejections,
          topRejectCoverage,
          totalGates,
        };
      };

      const patterns = [...byPattern.entries()]
        .filter(([p]) => !p.startsWith("liqgate_")) // pseudo-keys — отдельно
        .map(([pattern, e]) => toPatternRow(pattern, e))
        .sort((a, b) => b.checked - a.checked);

      for (const [pattern, live] of Object.entries(lastPatternDebug)) {
        if (pattern.startsWith("liqgate_")) continue;
        if (DELETED_PATTERNS.has(pattern)) continue;
        if (!byPattern.has(pattern)) {
          patterns.push(toPatternRow(pattern, { ...live, cycles: 1 }));
        }
      }

      res.json({
        cyclesRequested: cycles,
        latestCycle,
        liveSnapshot: lastPatternDebug,
        patterns,
      });
    } catch (err) {
      req.log.error({ err }, "pattern-debug/aggregate: DB error");
      res.status(500).json({ error: String(err) });
    }
  },
);

// POST /api/admin/backfill-growth-leader-spot — заполнить spot_taker_buy_usd/sell/fp_buy_pct + CVD из CG истории
router.post(
  "/admin/backfill-growth-leader-spot",
  requireAdminToken,
  async (req, res) => {
    res.json({ ok: true, started: true });
    runGrowthLeaderSpotBackfill().catch((err) =>
      logger.error({ err }, "admin/backfill-growth-leader-spot error"),
    );
  },
);

// POST /api/admin/backfill-growth-leader-oi24h — заполнить oi_24h_d1/d2 из oi_daily_snapshots (без API)
router.post(
  "/admin/backfill-growth-leader-oi24h",
  requireAdminToken,
  async (req, res) => {
    res.json({ ok: true, started: true });
    runGrowthLeaderOi24hBackfill().catch((err) =>
      logger.error({ err }, "admin/backfill-growth-leader-oi24h error"),
    );
  },
);

// POST /api/admin/enrich-growth-leaders — запускает async обогащение NULL-полей (price24h>=20%)
router.post(
  "/admin/enrich-growth-leaders",
  requireAdminToken,
  async (_req, res) => {
    const status = getEnrichJobStatus();
    if (status.running) {
      res
        .status(409)
        .json({ ok: false, message: "Job already running", status });
      return;
    }
    res.status(202).json({ ok: true, message: "Enrich job started" });
    runEnrichJob().catch((err) =>
      logger.error({ err }, "enrich-growth-leaders: unexpected error"),
    );
  },
);

// GET /api/admin/enrich-growth-leaders-status
router.get(
  "/admin/enrich-growth-leaders-status",
  requireAdminToken,
  (_req, res) => {
    res.json(getEnrichJobStatus());
  },
);

// GET /api/admin/enrich-growth-leaders-csv — скачать результат
router.get(
  "/admin/enrich-growth-leaders-csv",
  requireAdminToken,
  (_req, res) => {
    import("fs").then(({ existsSync, createReadStream }) => {
      const csvPath = getCsvPath();
      if (!existsSync(csvPath)) {
        res.status(404).json({
          error:
            "CSV не готов — сначала запустите POST /admin/enrich-growth-leaders",
        });
        return;
      }
      res.setHeader("Content-Type", "text/csv");
      res.setHeader(
        "Content-Disposition",
        'attachment; filename="growth-leaders-enriched.csv"',
      );
      createReadStream(csvPath).pipe(res);
    });
  },
);

// POST /api/admin/stop-scanner — останавливает основной скан-цикл
router.post("/admin/stop-scanner", requireAdminToken, async (_req, res) => {
  await stopScanner();
  res.json({ ok: true, message: "Scanner stopped" });
});

// POST /api/admin/start-scanner — возобновляет основной скан-цикл
router.post("/admin/start-scanner", requireAdminToken, async (_req, res) => {
  startScanner().catch((err) =>
    logger.error({ err }, "admin/start-scanner error"),
  );
  res.json({ ok: true, message: "Scanner starting" });
});

// POST /api/admin/backfill-growth-leader-full
// Останавливает сканер → запускает оба бэкфилла последовательно → перезапускает сканер.
// Отвечает 202 сразу; прогресс — в логах prod сервера.
router.post(
  "/admin/backfill-growth-leader-full",
  requireAdminToken,
  async (_req, res) => {
    res.status(202).json({
      ok: true,
      started: true,
      message: "Scanner paused, full backfill started (check prod logs)",
    });

    (async () => {
      logger.info("backfill-growth-leader-full: останавливаем сканер");
      await stopScanner();

      logger.info("backfill-growth-leader-full: запуск spot бэкфилла");
      try {
        const spotResult = await runGrowthLeaderSpotBackfill({
          batchSize: 5,
          batchDelayMs: 2000,
        });
        logger.info(
          { ...spotResult },
          "backfill-growth-leader-full: spot завершён",
        );
      } catch (err) {
        logger.error({ err }, "backfill-growth-leader-full: spot error");
      }

      logger.info("backfill-growth-leader-full: запуск OI24h бэкфилла");
      try {
        const oi24hResult = await runGrowthLeaderOi24hBackfill();
        logger.info(
          { ...oi24hResult },
          "backfill-growth-leader-full: OI24h завершён",
        );
      } catch (err) {
        logger.error({ err }, "backfill-growth-leader-full: OI24h error");
      }

      logger.info("backfill-growth-leader-full: перезапускаем сканер");
      startScanner().catch((err) =>
        logger.error(
          { err },
          "backfill-growth-leader-full: scanner restart error",
        ),
      );
    })().catch((err) =>
      logger.error({ err }, "backfill-growth-leader-full: unexpected error"),
    );
  },
);

// GET /api/admin/export-growth-leaders — CSV-выгрузка всей таблицы growth_leader_log
// Поля: все запрошенные + market_cap_usd из market_cap_cache (LEFT JOIN)
// Примечания:
//   price_peak_pct = price_24h (изменение цены за 24ч НА МОМЕНТ логирования — прокси пика)
//   growth_from_entry = рост от первого попадания в prescan (альтернативный пик)
//   price24h_duration = не хранится → null
//   market_cap_usd = из market_cap_cache (покрытие ~60-70%)
//   funding_rate = raw decimal (умножить на 100 для %)
router.get(
  "/admin/export-growth-leaders",
  requireAdminToken,
  async (req, res) => {
    try {
      const rows = await db.execute(
        sql.raw(`
      SELECT
        g.logged_at                  AS "timestamp",
        g.symbol,
        g.source,
        g.cg_oi_available            AS cg_available,
        g.price_24h                  AS price_peak_pct,
        g.growth_from_entry,
        NULL::real                   AS price24h_duration,
        g.price_3h                   AS price_3h_pct,
        g.price_4h                   AS price_4h_pct,
        g.prev_price_30m             AS price_prev30m_pct,
        g.oi_30m                     AS oi_30m_pct,
        g.oi_1h                      AS oi_1h_pct,
        g.oi_4h                      AS oi_4h_pct,
        g.entry_oi_30m,
        g.entry_oi_1h,
        g.entry_oi_4h,
        g.prev_oi_30m                AS oi_prev_30m_pct,
        g.prev_oi_1h                 AS oi_prev_1h_pct,
        g.prev_oi_4h                 AS oi_prev_4h_pct,
        g.oi_24h_d1                  AS oi_d1_pct,
        g.oi_24h_d2                  AS oi_d2_pct,
        g.vol_mult                   AS vol_mult_fut,
        g.spot_vol_mult              AS vol_mult_spot,
        g.prev_spot_vol_mult         AS vol_mult_prev,
        g.cvd_30m,
        g.cvd_1h,
        g.spot_cvd_4h                AS cvd_4h,
        g.cvd_strength_1h            AS cvd_strength,
        g.cvd_delta_4h               AS cvd_delta_4h_usd,
        g.spot_taker_net_buy_pct     AS spot_taker_net_pct,
        g.spot_taker_buy_usd,
        g.spot_taker_sell_usd,
        g.net_buy_pct                AS bingx_taker_net_pct,
        g.funding_rate,
        g.oi_usd_abs,
        g.fut_vol_usd_24h            AS vol_24h_usd,
        m.mcap_usd                   AS market_cap_usd,
        g.cycle_count,
        g.rank,
        g.price_1h,
        g.entry_price_24h,
        g.layers,
        g.retro
      FROM growth_leader_log g
      LEFT JOIN market_cap_cache m ON m.symbol = REPLACE(g.symbol, '-USDT', '')
      ORDER BY g.logged_at DESC
    `),
      );

      const data = rows.rows as Record<string, unknown>[];

      const format = (req.query.format as string | undefined) ?? "csv";

      if (format === "json") {
        res.setHeader("Content-Type", "application/json");
        res.setHeader(
          "Content-Disposition",
          `attachment; filename="growth-leaders-${Date.now()}.json"`,
        );
        res.end(JSON.stringify(data, null, 2));
        return;
      }

      if (data.length === 0) {
        res.setHeader("Content-Type", "text/csv");
        res.end("no data");
        return;
      }

      const headers = Object.keys(data[0]!);

      const escapeCell = (v: unknown): string => {
        if (v === null || v === undefined) return "";
        if (Array.isArray(v))
          return `"${(v as unknown[]).join(";").replace(/"/g, '""')}"`;
        const s = String(v);
        if (s.includes(",") || s.includes('"') || s.includes("\n"))
          return `"${s.replace(/"/g, '""')}"`;
        return s;
      };

      const lines: string[] = [headers.join(",")];
      for (const row of data) {
        lines.push(headers.map((h) => escapeCell(row[h])).join(","));
      }

      res.setHeader("Content-Type", "text/csv; charset=utf-8");
      res.setHeader(
        "Content-Disposition",
        `attachment; filename="growth-leaders-${Date.now()}.csv"`,
      );
      res.end(lines.join("\n"));
    } catch (err) {
      logger.error({ err }, "admin/export-growth-leaders error");
      res.status(500).json({ ok: false, error: String(err) });
    }
  },
);

export default router;
