import { Router, type IRouter } from "express";
import healthRouter from "./health";
import scannerRouter from "./scanner.js";
import signalsRouter from "./signals.js";
import settingsRouter from "./settings.js";
import subscribersRouter from "./subscribers.js";
import trackerRouter from "./tracker.js";
import liqCascadeRouter from "./liq-cascade.js";
import taScannerRouter from "./ta-scanner.js";
import whaleAlertRouter from "./whale-alert.js";
const router: IRouter = Router();

router.use(healthRouter);
router.use(scannerRouter);
router.use(signalsRouter);
router.use(settingsRouter);
router.use(subscribersRouter);
router.use(trackerRouter);
router.use(liqCascadeRouter);
router.use(taScannerRouter);
router.use(whaleAlertRouter);

export default router;
