import { Router } from "express";
import {
  getScannerState,
  startScanner,
  stopScanner,
  performScan,
  getScannerCandidates,
  getLastCycleCandidates,
  getLastCycleAt,
  lastLayerDebug,
  lastPatternDebug,
  getPrescanEntry,
  getLiveMarketData,
  getCachedPrice,
} from "../lib/scanner.js";
import { PDB_HIDDEN_PATTERN_KEYS } from "../lib/dead-patterns.js";
import { getCached, setCached } from "../lib/routeCache.js";
import {
  sendDailyReport,
  sendWeeklyDigest,
  runAuditReport,
  getWatcherJobTimings,
} from "../lib/watcher.js";
import { getApiConnected } from "../lib/apiHealth.js";
import {
  db,
  prescanHistoryTable,
  oiWatchTable,
  prescanTrackerTable,
  patternDebugLogTable,
  trackedSignalsTable,
  signalsTable,
  whaleAlertPoolTable,
  growthLeaderLogTable,
  inflowOutflowL14PoolTable,
  scanRejectLogTable,
} from "@workspace/db";
import {
  eq,
  desc,
  inArray,
  and,
  gte,
  isNotNull,
  sql,
  notInArray,
} from "drizzle-orm";
import { broadcastBatchAlert, type AlphaResult } from "../lib/telegram.js";
import { requireAdminToken } from "../middleware/adminAuth.js";

const router = Router();

router.get("/scanner/status", async (req, res) => {
  try {
    const cacheKey = "scanner:status";
    const hit = getCached<object>(cacheKey);
    if (hit) {
      res.json(hit);
      return;
    }

    const state = await getScannerState();
    const result = {
      running: state.running,
      lastScanAt: state.lastScanAt?.toISOString() ?? null,
      nextScanAt: state.nextScanAt?.toISOString() ?? null,
      totalSignals: state.totalSignals,
      signalsToday: state.signalsToday,
      marketsScanned: state.marketsScanned,
      telegramConnected: state.telegramConnected,
      bingxConnected: state.bingxConnected,
      coinglassConnected: getApiConnected("coinglass"),
      coinalyzeConnected: getApiConnected("coinalyze"),
      coinGeckoConnected: getApiConnected("coingecko"),
      coinPaprikaConnected: getApiConnected("coinpaprika"),
      scanIntervalMs: state.scanIntervalMs,
      isScanning: state.isScanning,
      lastScanDurationMs: state.lastScanDurationMs,
      oiWatch: {
        lastInsertAt: state.oiWatchLastInsertAt?.toISOString() ?? null,
        insertErrors: state.oiWatchInsertErrors,
        lastInsertError: state.oiWatchLastInsertError,
        insertsLastScan: state.oiWatchInsertsLastScan,
        cgTimeoutsLastScan: state.cgTimeoutsLastScan,
      },
      cgLatency: state.lastCgTelemetry
        ? {
            timeoutPct: state.lastCgTelemetry.cgTimeoutPct,
            p50Ms: state.lastCgTelemetry.cgP50Ms,
            p95Ms: state.lastCgTelemetry.cgP95Ms,
            maxMs: state.lastCgTelemetry.cgMaxMs,
            req: state.lastCgTelemetry.cgReq,
            reqPerMin: state.lastCgTelemetry.cgReqPerMin,
            elLagP95Ms: state.lastCgTelemetry.elLagP95Ms,
            windowMin: state.lastCgTelemetry.windowMin,
          }
        : null,
    };
    setCached(cacheKey, result, 15_000);
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to get scanner status");
    res.status(500).json({ error: "Failed to get scanner status" });
  }
});

router.get("/scanner/prescan-debug", async (req, res) => {
  const raw = String(req.query.symbols ?? "");
  if (!raw) {
    res.status(400).json({ error: "symbols param required (comma-separated)" });
    return;
  }
  const symbols = raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 50);
  try {
    const rows = await db
      .select({
        symbol: prescanTrackerTable.symbol,
        cycleCount: prescanTrackerTable.cycleCount,
        lastOi30m: prescanTrackerTable.lastOi30m,
        lastOi1h: prescanTrackerTable.lastOi1h,
        lastOi4h: prescanTrackerTable.lastOi4h,
        cvdPositiveCycles: prescanTrackerTable.cvdPositiveCycles,
        lastCgTimedOut: prescanTrackerTable.lastCgTimedOut,
        updatedAt: prescanTrackerTable.updatedAt,
      })
      .from(prescanTrackerTable)
      .where(inArray(prescanTrackerTable.symbol, symbols));
    res.json(rows);
  } catch (err) {
    req.log.error({ err }, "prescan-debug: DB error");
    res.status(500).json({ error: "DB error" });
  }
});

router.post("/scanner/start", async (req, res) => {
  try {
    await startScanner();
    res.json({ success: true, message: "Scanner started" });
  } catch (err) {
    req.log.error({ err }, "Failed to start scanner");
    res
      .status(500)
      .json({ success: false, message: "Failed to start scanner" });
  }
});

router.post("/scanner/stop", async (req, res) => {
  try {
    await stopScanner();
    res.json({ success: true, message: "Scanner stopped" });
  } catch (err) {
    req.log.error({ err }, "Failed to stop scanner");
    res.status(500).json({ success: false, message: "Failed to stop scanner" });
  }
});

router.post("/scanner/scan-now", async (req, res) => {
  try {
    const result = await performScan();
    res.json({
      success: true,
      signalsFound: result.signalsFound,
      marketsScanned: result.marketsScanned,
      durationMs: result.durationMs,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to run scan");
    res.status(500).json({
      success: false,
      signalsFound: 0,
      marketsScanned: 0,
      durationMs: 0,
    });
  }
});

router.get("/scanner/candidates", async (req, res) => {
  try {
    const cacheKey = "scanner:candidates";
    const hit = getCached<object>(cacheKey);
    if (hit) {
      res.json(hit);
      return;
    }
    const data = await getScannerCandidates();
    setCached(cacheKey, data, 20_000);
    res.json(data);
  } catch (err) {
    req.log.error({ err }, "Failed to get scanner candidates");
    res.status(500).json({ error: "Failed to get scanner candidates" });
  }
});

router.get("/scanner/symbol-history", async (req, res) => {
  const symbol = String(req.query.symbol ?? "");
  if (!symbol) {
    res.status(400).json({ error: "symbol is required" });
    return;
  }
  try {
    const [prescanHistory, oiWatchHistory] = await Promise.all([
      db
        .select()
        .from(prescanHistoryTable)
        .where(eq(prescanHistoryTable.symbol, symbol))
        .orderBy(desc(prescanHistoryTable.ts))
        .limit(120),
      db
        .select({
          id: oiWatchTable.id,
          triggerTf: oiWatchTable.triggerTf,
          oiChange: oiWatchTable.oiChange,
          priceAtEntry: oiWatchTable.priceAtEntry,
          volumeMultiplier: oiWatchTable.volumeMultiplier,
          sentimentKey: oiWatchTable.sentimentKey,
          status: oiWatchTable.status,
          addedAt: oiWatchTable.addedAt,
          expiresAt: oiWatchTable.expiresAt,
          firedAt: oiWatchTable.firedAt,
          oi30m: oiWatchTable.oi30mChange,
          oi1h: oiWatchTable.oi1hChange,
          oi24h: oiWatchTable.oi24hChange,
          price1hChange: oiWatchTable.price1hChange,
          price24hChange: oiWatchTable.price24hChange,
          volStatusReason: oiWatchTable.volStatusReason,
        })
        .from(oiWatchTable)
        .where(eq(oiWatchTable.symbol, symbol))
        .orderBy(desc(oiWatchTable.addedAt))
        .limit(50),
    ]);

    res.json({
      symbol,
      prescanHistory: prescanHistory.map((r) => ({
        ts: r.ts.toISOString(),
        cycleCount: r.cycleCount,
        rank: r.rank,
        score: r.score,
        price24h: r.price24h,
        price1h: r.price1h,
        oi30m: r.oi30m,
        oi1h: r.oi1h,
        oi4h: r.oi4h,
        oi24h: r.oi24h,
        volMult: r.volMult,
        cvd30m: r.cvd30m,
        cvd1h: r.cvd1h,
        netBuyPct: r.netBuyPct,
        spotTakerNetBuy: r.spotTakerNetBuy,
        oiAccel30m: r.oiAccel30m,
        futSpotRatio: r.futSpotRatio,
      })),
      oiWatchHistory: oiWatchHistory.map((r) => ({
        id: r.id,
        triggerTf: r.triggerTf,
        oiChange: r.oiChange,
        priceAtEntry: r.priceAtEntry,
        volumeMultiplier: r.volumeMultiplier,
        sentimentKey: r.sentimentKey ?? null,
        status: r.status,
        addedAt: r.addedAt.toISOString(),
        expiresAt: r.expiresAt.toISOString(),
        firedAt: r.firedAt?.toISOString() ?? null,
        oi30m: r.oi30m ?? null,
        oi1h: r.oi1h ?? null,
        oi24h: r.oi24h ?? null,
        price1hChange: r.price1hChange ?? null,
        price24hChange: r.price24hChange ?? null,
        volStatusReason: r.volStatusReason ?? null,
      })),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get symbol history");
    res.status(500).json({ error: "Failed to get symbol history" });
  }
});

// GET /api/scanner/inspect?symbols=SOL-USDT,ETH-USDT
// Ручная инспекция символов для виджета "Инспектор" на дашборде: собирает
// текущий срез live-метрик (OI/CVD/volMult/taker) + активный OI Watch + активный
// tracked signal, чтобы пользователь мог проверить конкретную открытую позицию.
router.get("/scanner/inspect", async (req, res) => {
  const raw = String(req.query.symbols ?? "");
  if (!raw) {
    res.status(400).json({ error: "symbols param required (comma-separated)" });
    return;
  }
  const symbols = Array.from(
    new Set(
      raw
        .split(",")
        .map((s) => s.trim().toUpperCase())
        .filter(Boolean),
    ),
  ).slice(0, 20);
  if (symbols.length === 0) {
    res.json({ symbols: [] });
    return;
  }

  try {
    const liveData = getLiveMarketData(symbols);

    const [oiWatchRows, trackedRows] = await Promise.all([
      db
        .select({
          id: oiWatchTable.id,
          symbol: oiWatchTable.symbol,
          status: oiWatchTable.status,
          sentimentKey: oiWatchTable.sentimentKey,
          triggerTf: oiWatchTable.triggerTf,
          expiresAt: oiWatchTable.expiresAt,
          addedAt: oiWatchTable.addedAt,
        })
        .from(oiWatchTable)
        .where(
          and(
            inArray(oiWatchTable.symbol, symbols),
            inArray(oiWatchTable.status, ["watching", "confirming"]),
          ),
        ),
      db
        .select({
          id: trackedSignalsTable.id,
          symbol: trackedSignalsTable.symbol,
          status: trackedSignalsTable.status,
          signalType: trackedSignalsTable.signalType,
          sentimentKey: trackedSignalsTable.sentimentKey,
          entryPrice: trackedSignalsTable.entryPrice,
          peakPrice: trackedSignalsTable.peakPrice,
          pnlPercent: trackedSignalsTable.pnlPercent,
          isShort: trackedSignalsTable.isShort,
          detectedAt: trackedSignalsTable.detectedAt,
        })
        .from(trackedSignalsTable)
        .where(
          and(
            inArray(trackedSignalsTable.symbol, symbols),
            notInArray(trackedSignalsTable.status, [
              "profit",
              "stop_loss",
              "cancelled",
              "breakeven",
              "bu_stop",
            ]),
          ),
        )
        .orderBy(desc(trackedSignalsTable.detectedAt)),
    ]);

    const result = symbols.map((symbol) => {
      const pe = getPrescanEntry(symbol);
      const lm = liveData[symbol];
      const oiWatch = oiWatchRows.find((r) => r.symbol === symbol) ?? null;
      const tracked = trackedRows.find((r) => r.symbol === symbol) ?? null;

      return {
        symbol,
        inPrescan: !!pe,
        currentPrice: getCachedPrice(symbol),
        price24h: pe?.lastPrice24h ?? null,
        price1h: lm?.price1h ?? pe?.lastPrice1h ?? null,
        cycleCount: pe?.cycleCount ?? null,
        oi30m: lm?.oi30m ?? pe?.lastOi30m ?? null,
        oi1h: lm?.oi1h ?? pe?.lastOi1h ?? null,
        oi4h: lm?.oi4h ?? pe?.lastOi4h ?? null,
        oi24h: lm?.oi24h ?? pe?.lastOi24h ?? null,
        volMult: pe?.lastVolMult ?? null,
        cvd30m: lm?.cvd30m ?? pe?.lastCvd30m ?? null,
        cvd1h: lm?.cvd1h ?? pe?.lastCvd1h ?? null,
        cvd4h: lm?.cvd4h ?? pe?.lastCvd4h ?? null,
        futureTakerNetBuy: lm?.netBuyPct ?? pe?.lastNetBuyPct ?? null,
        spotTakerNetBuy: lm?.spotTakerNetBuy ?? pe?.lastSpotTakerNetBuy ?? null,
        spotTakerDominance:
          lm?.spotTakerDominance ?? pe?.lastSpotTakerDominance ?? null,
        lastSkipReason: pe?.lastSkipReason ?? null,
        lastCgTimedOut: pe?.lastCgTimedOut ?? null,
        oiWatch: oiWatch
          ? {
              id: oiWatch.id,
              status: oiWatch.status,
              sentimentKey: oiWatch.sentimentKey ?? null,
              triggerTf: oiWatch.triggerTf,
              expiresAt: oiWatch.expiresAt.toISOString(),
              addedAt: oiWatch.addedAt.toISOString(),
            }
          : null,
        trackedSignal: tracked
          ? {
              id: tracked.id,
              status: tracked.status,
              signalType: tracked.signalType,
              sentimentKey: tracked.sentimentKey ?? null,
              entryPrice: tracked.entryPrice,
              peakPrice: tracked.peakPrice ?? null,
              pnlPercent: tracked.pnlPercent ?? null,
              isShort: tracked.isShort,
              detectedAt: tracked.detectedAt.toISOString(),
            }
          : null,
      };
    });

    res.json({ symbols: result });
  } catch (err) {
    req.log.error({ err }, "Failed to inspect symbols");
    res.status(500).json({ error: "Failed to inspect symbols" });
  }
});

// POST /api/scanner/resend-signal { signalId: number }
// Одноразовый ручной ресенд уже сохранённого сигнала в Telegram (например, если
// исходная рассылка упала из-за бага в шаблоне). Реконструирует AlphaResult из
// строки signals и вызывает тот же broadcastBatchAlert, что и обычный цикл.
router.post("/scanner/resend-signal", async (req, res) => {
  const signalId = Number(req.body?.signalId);
  if (!Number.isFinite(signalId)) {
    res.status(400).json({ error: "signalId (number) required in body" });
    return;
  }
  try {
    const rows = await db
      .select()
      .from(signalsTable)
      .where(eq(signalsTable.id, signalId))
      .limit(1);
    const row = rows[0];
    if (!row) {
      res.status(404).json({ error: "signal not found" });
      return;
    }

    const bingxUrl = `https://bingx.com/en-us/perpetual/${row.symbol}/`;
    const alphaResult: AlphaResult = {
      symbol: row.symbol,
      grade: row.type === "super_alpha" ? "super_alpha" : "alpha",
      price: row.price,
      priceChange30m: row.priceChangePercent,
      currentVolume: row.volume24h,
      avgVolume: row.avgVolume,
      volumeMultiplier: row.value,
      oiChangePercent: row.oiChangePercent ?? 0,
      openInterest: row.openInterest,
      cmcRank: row.cmcRank,
      cmcSource: row.cmcSource,
      cmcAvailable: false,
      liquidationsUsd: row.liquidationsUsd,
      liquidationsMultiple: row.liquidationsMultiple,
      coinglassAvailable: false,
      sentiment: row.sentiment ?? "",
      sentimentKey: row.sentimentKey ?? "",
      traderAction: "LONG (кит — спот, розница — фьючи, стоп -5%)",
      alphaScore: row.alphaScore ?? 7,
      isContinuing: row.isContinuing ?? false,
      cumulativeOiChange: row.cumulativeOiChange ?? 0,
      tradingViewUrl: row.tradingViewUrl,
      bingxUrl,
      fundingRate: row.fundingRate,
    };

    await broadcastBatchAlert([alphaResult]);
    req.log.info(
      { signalId, symbol: row.symbol },
      "Manual resend-signal broadcast complete",
    );
    res.json({ ok: true, symbol: row.symbol, sentimentKey: row.sentimentKey });
  } catch (err) {
    req.log.error({ err, signalId }, "resend-signal failed");
    res.status(500).json({ error: "resend-signal failed" });
  }
});

// Ручная отправка отчётов (для восстановления пропущенных)
router.post("/reports/send-daily", async (req, res) => {
  try {
    await sendDailyReport();
    res.json({ success: true, message: "Daily report sent" });
  } catch (err) {
    req.log.error({ err }, "Failed to send daily report");
    res
      .status(500)
      .json({ success: false, message: "Failed to send daily report" });
  }
});

router.post("/reports/send-weekly", async (req, res) => {
  try {
    await sendWeeklyDigest();
    res.json({ success: true, message: "Weekly digest sent" });
  } catch (err) {
    req.log.error({ err }, "Failed to send weekly digest");
    res
      .status(500)
      .json({ success: false, message: "Failed to send weekly digest" });
  }
});

router.post("/scanner/audit", async (req, res) => {
  try {
    res.json({
      success: true,
      message: "Audit started — отчёт придёт в канал через ~1-2 мин",
    });
    // Запускаем после ответа клиенту (не блокируем HTTP)
    runAuditReport().catch((err: unknown) => {
      req.log.error({ err }, "Audit report failed");
    });
  } catch (err) {
    req.log.error({ err }, "Failed to trigger audit");
    res
      .status(500)
      .json({ success: false, message: "Failed to trigger audit" });
  }
});

// ── DEV: Ретроспективный анализ — исторические данные OI/CVD/Volume ──────────
// GET /api/scanner/debug/retro?symbol=SENT-USDT&fromSec=1749434400&toSec=1749456000
// Возвращает: Coinalyze OI history (30min) + BingX klines (30m) + CG OI snapshot + CG taker
router.get("/scanner/debug/retro", async (req, res) => {
  const symbol = String(req.query.symbol ?? "SENT-USDT");
  const fromSec = Number(
    req.query.fromSec ?? Math.floor(Date.now() / 1000) - 7200,
  );
  const toSec = Number(req.query.toSec ?? Math.floor(Date.now() / 1000));
  const interval = String(req.query.interval ?? "30min");

  const CA_KEY = process.env.COINALYZE_API_KEY ?? "";
  const CG_KEY = process.env.COINGLASS_API_KEY ?? "";
  const base = symbol.replace("-USDT", "");

  // 1. Coinalyze OI history (30min candles, from/to in unix seconds)
  let oiHistory: { t: string; tSec: number; oi: number; oiChange: number }[] =
    [];
  try {
    const cgSym = `${base}USDT_PERP.A`;
    const url = new URL("https://api.coinalyze.net/v1/open-interest-history");
    url.searchParams.set("symbols", cgSym);
    url.searchParams.set("interval", interval);
    url.searchParams.set("from", String(fromSec));
    url.searchParams.set("to", String(toSec));
    url.searchParams.set("api_key", CA_KEY);
    const r = await fetch(url.toString(), {
      signal: AbortSignal.timeout(12000),
    });
    const j = (await r.json()) as {
      symbol: string;
      history: { t: number; o: number; h: number; l: number; c: number }[];
    }[];
    const rows = j?.[0]?.history ?? [];
    oiHistory = rows.map((c, i) => {
      const prev = i > 0 ? rows[i - 1].c : c.o;
      const changePct = prev > 0 ? ((c.c - prev) / prev) * 100 : 0;
      return {
        t: new Date(c.t * 1000).toUTCString().slice(5, 22),
        tSec: c.t,
        oi: Math.round(c.c),
        oiChange: parseFloat(changePct.toFixed(3)),
      };
    });
  } catch (err) {
    req.log.warn({ err }, "retro: Coinalyze failed");
  }

  // 2. CoinGlass OI snapshot (current multi-TF, public v2)
  let cgOI: {
    allRow: Record<string, unknown> | null;
    exchanges: { name: string; oiM: string; oi30m: number | null }[];
  } = { allRow: null, exchanges: [] };
  try {
    const r = await fetch(
      `https://open-api.coinglass.com/public/v2/open_interest?symbol=${base}`,
      {
        headers: { coinglassSecret: CG_KEY },
        signal: AbortSignal.timeout(8000),
      },
    );
    const j = (await r.json()) as {
      data?: {
        exchangeName: string;
        openInterestAmount: number;
        m5OIChangePercent?: number;
        m30OIChangePercent?: number;
        h1OIChangePercent?: number;
        h4OIChangePercent?: number;
        oichangePercent?: number;
      }[];
    };
    const rows = j?.data ?? [];
    const all = rows.find((x) => x.exchangeName === "All") ?? null;
    const exch = rows.filter(
      (x) => x.exchangeName !== "All" && x.openInterestAmount > 0,
    );
    cgOI = {
      allRow: all as Record<string, unknown> | null,
      exchanges: exch.map((x) => ({
        name: x.exchangeName,
        oiM: (x.openInterestAmount / 1e6).toFixed(2),
        oi30m: x.m30OIChangePercent ?? null,
      })),
    };
  } catch (err) {
    req.log.warn({ err }, "retro: CoinGlass OI failed");
  }

  // 3. CoinGlass Taker flow — исторические свечи 15m по Binance+Bybit+OKX+Bitget
  // startTime/endTime в миллисекундах — получаем реальные исторические данные
  const cgTaker: {
    exch: string;
    candles: {
      t: string;
      tMs: number;
      buy: number;
      sell: number;
      net: number;
      netPct: number;
    }[];
  }[] = [];
  const takerExchanges = ["Binance", "Bybit", "OKX", "Bitget"] as const;
  const takerSymMap: Record<string, string> = {
    Binance: `${base}USDT`,
    Bybit: `${base}USDT`,
    OKX: `${base}-USDT-SWAP`,
    Bitget: `${base}USDT_UMCBL`,
  };
  // limit=64 → до 16 часов @ 15m
  const takerLimit = Math.min(64, Math.ceil((toSec - fromSec) / 900) + 4);
  await Promise.all(
    takerExchanges.map(async (exch) => {
      try {
        const url = new URL(
          "https://open-api-v4.coinglass.com/api/futures/taker-buy-sell-volume/history",
        );
        url.searchParams.set("symbol", takerSymMap[exch]);
        url.searchParams.set("exchange", exch);
        url.searchParams.set("interval", "15m");
        url.searchParams.set("limit", String(takerLimit));
        url.searchParams.set("startTime", String(fromSec * 1000));
        url.searchParams.set("endTime", String(toSec * 1000));
        const r = await fetch(url.toString(), {
          headers: { "CG-API-KEY": CG_KEY },
          signal: AbortSignal.timeout(8000),
        });
        const j = (await r.json()) as {
          code: string;
          data?: {
            time: number;
            taker_buy_volume_usd: string;
            taker_sell_volume_usd: string;
          }[];
        };
        if (j.code === "0" && j.data?.length) {
          const candles = j.data
            .filter((c) => c.time >= fromSec * 1000 && c.time <= toSec * 1000)
            .map((c) => {
              const buy = parseFloat(c.taker_buy_volume_usd);
              const sell = parseFloat(c.taker_sell_volume_usd);
              const net = buy - sell;
              const tot = buy + sell;
              return {
                t: new Date(c.time).toUTCString().slice(5, 22),
                tMs: c.time,
                buy: Math.round(buy / 1000),
                sell: Math.round(sell / 1000),
                net: Math.round(net / 1000),
                netPct:
                  tot > 0 ? parseFloat(((net / tot) * 100).toFixed(1)) : 0,
              };
            });
          if (candles.length) cgTaker.push({ exch, candles });
        }
      } catch {
        /* non-critical */
      }
    }),
  );

  // 4. BingX klines (30m)
  let bxKlines: {
    t: string;
    tMs: number;
    o: number;
    h: number;
    l: number;
    c: number;
    vol: number;
    priceChg: number;
  }[] = [];
  try {
    const startMs = fromSec * 1000;
    const endMs = toSec * 1000;
    const url = `https://open-api.bingx.com/openApi/swap/v3/quote/klines?symbol=${symbol}&interval=30m&startTime=${startMs}&endTime=${endMs}&limit=100`;
    const r = await fetch(url, { signal: AbortSignal.timeout(10000) });
    const j = (await r.json()) as {
      data?: {
        time: number;
        open: string;
        high: string;
        low: string;
        close: string;
        volume: string;
      }[];
    };
    bxKlines = (j?.data ?? [])
      .sort((a, b) => a.time - b.time)
      .map((k) => ({
        t: new Date(k.time).toUTCString().slice(5, 22),
        tMs: k.time,
        o: parseFloat(k.open),
        h: parseFloat(k.high),
        l: parseFloat(k.low),
        c: parseFloat(k.close),
        vol: parseFloat(k.volume),
        priceChg: parseFloat(
          (
            ((parseFloat(k.close) - parseFloat(k.open)) / parseFloat(k.open)) *
            100
          ).toFixed(2),
        ),
      }));
  } catch (err) {
    req.log.warn({ err }, "retro: BingX klines failed");
  }

  res.json({ symbol, fromSec, toSec, oiHistory, cgOI, cgTaker, bxKlines });
});

router.get("/scanner/debug-cg-spot-vol", async (req, res) => {
  const symbol = (req.query.symbol as string) || "SAHARA";
  const key = process.env.COINGLASS_API_KEY!;
  const results: Record<string, any> = {};

  const endpoints = [
    `/api/spot/volume/history?symbol=${symbol}USDT&exchange=Binance&interval=1h&limit=6`,
    `/api/spot/volume/history?symbol=${symbol}USDT&interval=1h&limit=6`,
    `/api/spot/volume/history?symbol=${symbol}&interval=1h&limit=6`,
    `/api/spot/pairs-markets?symbol=${symbol}USDT`,
    `/api/spot/pairs-markets?symbol=${symbol}`,
    `/api/spot/coins-markets?symbol=${symbol}`,
    `/api/spot/aggregated-taker-volume/history?symbol=${symbol}&interval=1h&limit=6`,
  ];

  for (const path of endpoints) {
    try {
      const r = await fetch(`https://open-api-v4.coinglass.com${path}`, {
        headers: { "CG-API-KEY": key },
        signal: AbortSignal.timeout(5000),
      });
      const body = await r.json();
      results[path] = { status: r.status, data: body };
    } catch (e: any) {
      results[path] = { error: e.message };
    }
  }

  res.json(results);
});

// GET /api/scanner/layer-stats
router.get("/scanner/layer-stats", async (_req, res) => {
  const cacheKey = "scanner:layer-stats";
  const hit = getCached<object>(cacheKey);
  if (hit) {
    res.json(hit);
    return;
  }

  const candidates = getLastCycleCandidates();
  const stats: Record<string, number> = {};
  for (const c of candidates) {
    for (const l of c.layers) {
      stats[l] = (stats[l] ?? 0) + 1;
    }
  }

  let l4ReadyTokens = 0;
  try {
    const result = await db
      .select({ count: sql<number>`count(*)` })
      .from(prescanTrackerTable)
      .where(
        and(
          gte(prescanTrackerTable.spotVolCycles, 2),
          isNotNull(prescanTrackerTable.spotVolAvg1h),
        ),
      );
    l4ReadyTokens = Number(result[0]?.count ?? 0);
  } catch {
    /* non-critical */
  }

  const result = {
    cycleAt: getLastCycleAt(),
    cycleNumber: lastLayerDebug.cycleNumber,
    totalBatch: candidates.length,
    byLayer: stats,
    l4ReadyTokens,
    debug: lastLayerDebug,
  };
  setCached(cacheKey, result, 30_000);
  res.json(result);
});

// GET /api/scanner/pattern-debug
router.get("/scanner/pattern-debug", (_req, res) => {
  res.json(lastPatternDebug);
});

// Паттерны удалённые из кода — не показываем в PDB-истории (из dead-patterns.ts)
const DELETED_PATTERN_KEYS = new Set(PDB_HIDDEN_PATTERN_KEYS);

// GET /api/scanner/pattern-debug/history — weekly aggregation from pattern_debug_log
// (accumulated across cycles, unlike /scanner/pattern-debug which is the current-cycle snapshot)
router.get("/scanner/pattern-debug/history", async (req, res) => {
  const days = Math.min(Math.max(Number(req.query.days) || 7, 1), 30);
  try {
    const since = new Date(Date.now() - days * 24 * 3600_000);
    const raw = await db
      .select()
      .from(patternDebugLogTable)
      .where(gte(patternDebugLogTable.loggedAt, since));
    const byPattern = new Map<
      string,
      { checked: number; passed: number; rejectedAt: Record<string, number> }
    >();
    for (const row of raw) {
      if (DELETED_PATTERN_KEYS.has(row.pattern)) continue;
      const e = byPattern.get(row.pattern) ?? {
        checked: 0,
        passed: 0,
        rejectedAt: {},
      };
      e.checked += row.checked;
      e.passed += row.passed;
      if (row.rejectedAt) {
        try {
          const parsed = JSON.parse(row.rejectedAt) as Record<string, number>;
          for (const [gate, count] of Object.entries(parsed)) {
            e.rejectedAt[gate] = (e.rejectedAt[gate] ?? 0) + count;
          }
        } catch {
          /* skip malformed row */
        }
      }
      byPattern.set(row.pattern, e);
    }
    res.json({
      days,
      since: since.toISOString(),
      byPattern: Object.fromEntries(byPattern),
    });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// GET /api/scanner/prescan-stats
router.get("/scanner/prescan-stats", async (_req, res) => {
  try {
    const result = await db.execute(sql`
      SELECT
        COUNT(*) as total,
        COUNT(CASE WHEN spot_vol_cycles >= 2 THEN 1 END) as vol_cycles_ge2,
        COUNT(CASE WHEN spot_vol_avg_1h IS NOT NULL THEN 1 END) as avg_not_null,
        COUNT(CASE WHEN spot_vol_cycles >= 2 AND spot_vol_avg_1h IS NOT NULL THEN 1 END) as ready_for_spot,
        MAX(spot_vol_cycles) as max_cycles,
        ROUND(AVG(spot_vol_cycles)::numeric, 2) as avg_cycles
      FROM prescan_tracker
    `);
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// GET /api/scanner/whale-alerts — Layer 11: Whale Alert pool (Hyperliquid киты)
// Возвращает записи whale_alert_pool: watching первыми, затем fired/expired
// (последние 100 по detectedAt), с live-метриками обновляемыми каждый скан-цикл.
router.get("/scanner/whale-alerts", async (_req, res) => {
  try {
    const rows = await db
      .select()
      .from(whaleAlertPoolTable)
      .orderBy(desc(whaleAlertPoolTable.detectedAt))
      .limit(100);

    // watching первыми, внутри группы — свежие сверху
    const statusRank = (s: string) =>
      s === "watching" ? 0 : s === "fired" ? 1 : 2;
    rows.sort((a, b) => {
      if (a.status !== b.status)
        return statusRank(a.status) - statusRank(b.status);
      return b.detectedAt.getTime() - a.detectedAt.getTime();
    });

    const dayAgo = Date.now() - 24 * 60 * 60 * 1000;
    res.json({
      pool: rows.map((r) => ({
        id: r.id,
        symbol: r.symbol,
        hlSymbol: r.hlSymbol,
        status: r.status,
        detectedAt: r.detectedAt.toISOString(),
        expiresAt: r.expiresAt.toISOString(),
        firedAt: r.firedAt ? r.firedAt.toISOString() : null,
        whaleAddress: r.whaleAddress,
        positionValueUsd: r.positionValueUsd,
        positionSizeTokens: r.positionSizeTokens,
        whaleEntryPrice: r.whaleEntryPrice,
        liqPrice: r.liqPrice,
        alertTime: r.alertTime ? r.alertTime.toISOString() : null,
        whaleCount: r.whaleCount,
        totalWhaleUsd: r.totalWhaleUsd,
        entryPrice: r.entryPrice,
        futLargeOrderConfirmed: r.futLargeOrderConfirmed,
        futLargeOrderBidUsd: r.futLargeOrderBidUsd,
        spotLargeOrderConfirmed: r.spotLargeOrderConfirmed,
        spotLargeOrderBidUsd: r.spotLargeOrderBidUsd,
        currentPrice: r.currentPrice,
        priceChangePct: r.priceChangePct,
        oi30m: r.oi30m,
        oi1h: r.oi1h,
        oi4h: r.oi4h,
        oi24h: r.oi24h,
        spotVol1h: r.spotVol1h,
        spotVol4h: r.spotVol4h,
        spotVol24h: r.spotVol24h,
        spotVolMult: r.spotVolMult,
        spotVolMcapPct: r.spotVolMcapPct,
        cvd30m: r.cvd30m,
        cvd1h: r.cvd1h,
        cvd4h: r.cvd4h,
        cycleCount: r.cycleCount,
        lastCycleAt: r.lastCycleAt ? r.lastCycleAt.toISOString() : null,
      })),
      stats: {
        activeWatching: rows.filter((r) => r.status === "watching").length,
        fired24h: rows.filter(
          (r) =>
            r.status === "fired" && r.firedAt && r.firedAt.getTime() >= dayAgo,
        ).length,
        detected24h: rows.filter((r) => r.detectedAt.getTime() >= dayAgo)
          .length,
      },
    });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// GET /api/scanner/inflow-outflow — Layer 14: Exchange Inflow/Outflow pool
// Возвращает активные watching-записи из inflow_outflow_l14_pool с вычисленным cycleCount.
router.get("/scanner/inflow-outflow", async (_req, res) => {
  try {
    const rows = await db
      .select()
      .from(inflowOutflowL14PoolTable)
      .where(eq(inflowOutflowL14PoolTable.status, "watching"))
      .orderBy(desc(inflowOutflowL14PoolTable.detectedAt));

    const now = Date.now();
    const JOB_INTERVAL_MS = 30 * 60 * 1000;
    const day24 = 24 * 60 * 60 * 1000;

    res.json({
      pool: rows.map((r) => ({
        id: r.id,
        symbol: r.symbol,
        coinSymbol: r.coinSymbol,
        status: r.status,
        detectedAt: r.detectedAt.toISOString(),
        expiresAt: r.expiresAt.toISOString(),
        entryPrice: r.entryPrice ?? null,
        txCount: r.txCount ?? null,
        totalOutflowUsd: r.totalOutflowUsd ?? null,
        exchangeName: r.exchangeName ?? null,
        transferType: r.transferType ?? null,
        cycleCount: Math.max(
          1,
          Math.floor((now - r.detectedAt.getTime()) / JOB_INTERVAL_MS) + 1,
        ),
      })),
      transparency: [],
      stats: {
        activeWatching: rows.length,
        detected24h: rows.filter((r) => now - r.detectedAt.getTime() < day24)
          .length,
      },
    });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// GET /api/scanner/growth-leader-history?symbols=BTC-USDT,ETH-USDT&hours=24
// Ретроактивный анализ топ-гейнеров: prescan_history + Coinalyze OI history за последние N часов.
// Если symbols не указан — берёт текущий топ-30 из growth_leader_log (последний снимок).
router.get("/scanner/growth-leader-history", async (req, res) => {
  try {
    const hoursBack = Math.min(Number(req.query.hours ?? 24), 168); // max 7 дней
    const fromTs = new Date(Date.now() - hoursBack * 3600 * 1000);
    const fromSec = Math.floor(fromTs.getTime() / 1000);
    const toSec = Math.floor(Date.now() / 1000);

    // Список символов: из параметра или из последнего growth_leader_log снимка
    let symbols: string[] = [];
    const symParam = String(req.query.symbols ?? "").trim();
    if (symParam) {
      symbols = symParam
        .split(",")
        .map((s) => s.trim().toUpperCase())
        .filter(Boolean);
    } else {
      // Берём топ-30 из последнего снимка growth_leader_log
      const lastSnap = await db
        .select({
          symbol: growthLeaderLogTable.symbol,
          price24h: growthLeaderLogTable.price24h,
        })
        .from(growthLeaderLogTable)
        .where(
          gte(
            growthLeaderLogTable.loggedAt,
            new Date(Date.now() - 30 * 60 * 1000),
          ),
        )
        .orderBy(desc(growthLeaderLogTable.price24h))
        .limit(30);
      symbols = lastSnap.map((r) => r.symbol);

      // Фолбэк: если growth_leader_log ещё пуст — берём из prescan_tracker
      if (symbols.length === 0) {
        const pt = await db
          .select({ symbol: prescanTrackerTable.symbol })
          .from(prescanTrackerTable)
          .orderBy(sql`last_price_1h DESC NULLS LAST`)
          .limit(30);
        symbols = pt.map((r) => r.symbol);
      }
    }

    if (symbols.length === 0) {
      res.json({ symbols: [], snapshots: {}, coinalyze: {} });
      return;
    }

    // 1. prescan_history — исторические снимки OI/CVD каждые ~10 мин
    const histRows = await db
      .select()
      .from(prescanHistoryTable)
      .where(
        and(
          inArray(prescanHistoryTable.symbol, symbols),
          gte(prescanHistoryTable.ts, fromTs),
        ),
      )
      .orderBy(prescanHistoryTable.symbol, prescanHistoryTable.ts);

    // Группируем по символу
    const snapshots: Record<string, typeof histRows> = {};
    for (const row of histRows) {
      if (!snapshots[row.symbol]) snapshots[row.symbol] = [];
      snapshots[row.symbol].push(row);
    }

    // 2. growth_leader_log — снимки growth leader log если уже есть
    const growthRows = await db
      .select()
      .from(growthLeaderLogTable)
      .where(
        and(
          inArray(growthLeaderLogTable.symbol, symbols),
          gte(growthLeaderLogTable.loggedAt, fromTs),
        ),
      )
      .orderBy(growthLeaderLogTable.symbol, growthLeaderLogTable.loggedAt);

    const growthSnapshots: Record<string, typeof growthRows> = {};
    for (const row of growthRows) {
      if (!growthSnapshots[row.symbol]) growthSnapshots[row.symbol] = [];
      growthSnapshots[row.symbol].push(row);
    }

    // 3. Coinalyze OI history (30m candles) — батч из первых 10 символов
    const CA_KEY = process.env.COINALYZE_API_KEY ?? "";
    const coinalyze: Record<
      string,
      { t: string; oi: number; oiChange: number }[]
    > = {};
    const caSymbols = symbols.slice(0, 10); // Coinalyze лимит запроса
    try {
      const cgSymStr = caSymbols
        .map((s) => `${s.replace("-USDT", "")}USDT_PERP.A`)
        .join(",");
      const url = new URL("https://api.coinalyze.net/v1/open-interest-history");
      url.searchParams.set("symbols", cgSymStr);
      url.searchParams.set("interval", "30min");
      url.searchParams.set("from", String(fromSec));
      url.searchParams.set("to", String(toSec));
      url.searchParams.set("api_key", CA_KEY);
      const r = await fetch(url.toString(), {
        signal: AbortSignal.timeout(15000),
      });
      const j = (await r.json()) as {
        symbol: string;
        history: { t: number; o: number; c: number }[];
      }[];
      for (const entry of j ?? []) {
        const sym = entry.symbol.replace("USDT_PERP.A", "-USDT");
        const rows = entry.history ?? [];
        coinalyze[sym] = rows.map((c, i) => {
          const prev = i > 0 ? rows[i - 1].c : c.o;
          return {
            t: new Date(c.t * 1000)
              .toISOString()
              .slice(5, 16)
              .replace("T", " "),
            oi: Math.round(c.c),
            oiChange:
              prev > 0
                ? parseFloat((((c.c - prev) / prev) * 100).toFixed(3))
                : 0,
          };
        });
      }
    } catch (err) {
      req.log.warn({ err }, "growth-leader-history: Coinalyze failed");
    }

    // 4. Текущее состояние из prescan_tracker
    const current = await db
      .select({
        symbol: prescanTrackerTable.symbol,
        cycleCount: prescanTrackerTable.cycleCount,
        firstSeenAt: prescanTrackerTable.firstSeenAt,
        firstPrice: prescanTrackerTable.firstPrice,
        firstPrice24h: prescanTrackerTable.firstPrice24h,
        lastPrice: prescanTrackerTable.lastPrice,
        lastOi30m: prescanTrackerTable.lastOi30m,
        lastOi1h: prescanTrackerTable.lastOi1h,
        lastOi4h: prescanTrackerTable.lastOi4h,
        firstOi30m: prescanTrackerTable.firstOi30m,
        firstOi1h: prescanTrackerTable.firstOi1h,
        firstOi4h: prescanTrackerTable.firstOi4h,
        layers: prescanTrackerTable.layers,
      })
      .from(prescanTrackerTable)
      .where(inArray(prescanTrackerTable.symbol, symbols));

    const currentMap: Record<string, (typeof current)[0]> = {};
    for (const row of current) currentMap[row.symbol] = row;

    res.json({
      symbols,
      hoursBack,
      fromTs: fromTs.toISOString(),
      current: currentMap,
      snapshots, // prescan_history (top-30 scored, ~10 min intervals)
      growthSnapshots, // growth_leader_log (top-50 p24h, ~10 min intervals — если уже есть)
      coinalyze, // Coinalyze OI 30m candles (первые 10 символов)
    });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// ── GET /api/scanner/growth-leaders ──────────────────────────────────────────
// Возвращает последний снимок growth_leader_log (топ-гейнеры BingX p24h>3%).
// ?hours=N — история за N часов (по умолчанию 24, макс 168; макс 720 при retro=true).
// ?snapshot=latest — только последний снимок (по умолчанию: да)
// ?retro=true — ретроспективные данные (retro=true строки, до 30 дней)
router.get("/scanner/growth-leaders", async (req, res) => {
  try {
    const retroMode = req.query.retro === "true";

    if (retroMode) {
      const hours = Math.min(Number(req.query.hours ?? 720), 720);
      const from = new Date(Date.now() - hours * 3600_000);
      const rows = await db
        .select()
        .from(growthLeaderLogTable)
        .where(
          and(
            eq(growthLeaderLogTable.retro, true),
            gte(growthLeaderLogTable.loggedAt, from),
          ),
        )
        .orderBy(
          desc(growthLeaderLogTable.loggedAt),
          desc(growthLeaderLogTable.price24h),
        )
        .limit(1000);
      res.json({ snapshotAt: null, entries: rows });
      return;
    }

    const hours = Math.min(Number(req.query.hours ?? 24), 168);
    const from = new Date(Date.now() - hours * 3600_000);
    const snapshotOnly = req.query.snapshot !== "all";

    if (snapshotOnly) {
      // Берём метку последнего снимка
      const latest = await db
        .select({ ts: growthLeaderLogTable.loggedAt })
        .from(growthLeaderLogTable)
        .orderBy(desc(growthLeaderLogTable.loggedAt))
        .limit(1);

      if (latest.length === 0) {
        res.json({ snapshotAt: null, entries: [] });
        return;
      }

      const snapTs = latest[0].ts;
      const snapMin = new Date(snapTs.getTime() - 5 * 60_000); // окно ±5 мин

      // DISTINCT ON (symbol): берём последнюю строку на символ (защита от dual-process дублей).
      // Внешний ORDER BY price_24h DESC — итоговая сортировка для UI.
      const raw = await db.execute(sql`
        SELECT * FROM (
          SELECT DISTINCT ON (symbol) *
          FROM growth_leader_log
          WHERE logged_at >= ${snapMin}
          ORDER BY symbol, logged_at DESC
        ) sub
        ORDER BY price_24h DESC NULLS LAST
        LIMIT 100
      `);
      const entries = raw.rows;

      res.json({ snapshotAt: snapTs.toISOString(), entries });
    } else {
      // История за N часов — все снимки
      const entries = await db
        .select()
        .from(growthLeaderLogTable)
        .where(gte(growthLeaderLogTable.loggedAt, from))
        .orderBy(
          desc(growthLeaderLogTable.loggedAt),
          desc(growthLeaderLogTable.price24h),
        )
        .limit(2000);

      res.json({ snapshotAt: null, entries });
    }
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// ── GET /api/scanner/overheat-log ─────────────────────────────────────────────
// Возвращает токены из prescan которые были выкинуты фильтром перегрева (p24h > 40%).
// ?days=N — история за N дней (по умолчанию 7, макс 30).
// Показывает: entry-метрики (что было при входе в prescan) + момент перегрева + текущее состояние.
router.get("/scanner/overheat-log", async (req, res) => {
  try {
    const rawDays = Number(req.query.days ?? 7);
    const days =
      Number.isFinite(rawDays) && rawDays > 0 ? Math.min(rawDays, 3650) : 7;
    const from = new Date(Date.now() - days * 86_400_000);
    const from24h = new Date(Date.now() - 24 * 3_600_000);

    // Одним CTE-запросом: агрегат по символу + последний kick + текущее состояние из growth_leader_log
    const raw = await db.execute(sql`
      WITH agg AS (
        SELECT
          symbol,
          COUNT(*)::integer        AS kick_count,
          MAX(price_24h)           AS peak_price24h,
          MIN(kicked_at)           AS first_kicked_at
        FROM overheat_log
        WHERE kicked_at >= ${from}
        GROUP BY symbol
      ),
      latest AS (
        SELECT DISTINCT ON (symbol) *
        FROM overheat_log
        WHERE kicked_at >= ${from}
        ORDER BY symbol, kicked_at DESC
      ),
      gll AS (
        SELECT DISTINCT ON (symbol)
          symbol,
          price_24h  AS current_price24h,
          price      AS current_price
        FROM growth_leader_log
        WHERE logged_at >= ${from24h}
        ORDER BY symbol, logged_at DESC
      )
      SELECT
        l.symbol,
        l.kicked_at          AS last_kicked_at,
        l.price_24h          AS last_price24h,
        l.price              AS last_price,
        l.entry_price,
        l.entry_price_24h,
        l.entry_oi_30m,
        l.entry_oi_1h,
        l.entry_oi_4h,
        l.cycle_count,
        l.layers,
        l.matched_pattern,
        l.entry_vol_24h,
        l.first_seen_at,
        l.snapshot_price,
        l.snapshot_at,
        l.retro,
        a.kick_count,
        a.peak_price24h,
        a.first_kicked_at,
        g.current_price24h,
        g.current_price,
        pt.last_whale_index          AS whale_index,
        pt.last_oi_30m               AS current_oi_30m,
        pt.last_oi_1h                AS current_oi_1h,
        pt.last_oi_4h                AS current_oi_4h,
        pt.last_price                AS current_price_live,
        pt.last_oi_24h               AS current_oi_24h,
        pt.last_price_1h             AS current_price_1h,
        pt.last_spot_taker_net_buy   AS current_spot_taker,
        pt.last_spot_taker_dominance AS current_spot_dominance,
        pt.last_net_buy_pct          AS current_net_buy_pct,
        pt.last_cvd_1h               AS current_cvd_1h,
        pt.last_spot_vol_1h          AS current_spot_vol_1h,
        pt.spot_vol_avg_1h           AS current_spot_vol_avg_1h,
        pt.last_cvd_30m              AS current_cvd_30m,
        pt.last_cvd_4h               AS current_cvd_4h,
        pt.oi_accel_30m              AS current_oi_accel,
        pt.fut_spot_ratio            AS current_fut_spot_ratio,
        pt.cvd_positive_cycles       AS current_cvd_pos_cycles,
        pt.taker_positive_cycles     AS current_taker_pos_cycles,
        (pt.symbol IS NOT NULL)      AS in_prescan
      FROM latest l
      JOIN agg a ON a.symbol = l.symbol
      LEFT JOIN gll g ON g.symbol = l.symbol
      LEFT JOIN prescan_tracker pt ON pt.symbol = l.symbol
      ORDER BY l.kicked_at DESC
      LIMIT 200
    `);

    const entries = (raw.rows as Record<string, unknown>[]).map((r) => ({
      symbol: r.symbol,
      lastKickedAt: r.last_kicked_at ?? null,
      firstKickedAt: r.first_kicked_at ?? null,
      lastPrice24h: r.last_price24h ?? null,
      peakPrice24h: r.peak_price24h ?? null,
      lastPrice: r.last_price ?? null,
      entryPrice: r.entry_price ?? null,
      entryPrice24h: r.entry_price_24h ?? null,
      entryOi30m: r.entry_oi_30m ?? null,
      entryOi1h: r.entry_oi_1h ?? null,
      entryOi4h: r.entry_oi_4h ?? null,
      cycleCount: r.cycle_count ?? null,
      layers: r.layers ?? [],
      matchedPattern: r.matched_pattern ?? null,
      kickCount: r.kick_count ?? 0,
      entryVol24h: r.entry_vol_24h ?? null,
      firstSeenAt: r.first_seen_at ?? null,
      snapshotPrice: r.snapshot_price ?? null,
      snapshotAt: r.snapshot_at ?? null,
      currentPrice24h: r.current_price24h ?? null,
      currentPrice: r.current_price ?? null,
      whaleIndex: r.whale_index ?? null,
      currentOi30m: r.current_oi_30m ?? null,
      currentOi1h: r.current_oi_1h ?? null,
      currentOi4h: r.current_oi_4h ?? null,
      currentPriceLive: r.current_price_live ?? null,
      currentOi24h: r.current_oi_24h ?? null,
      currentPrice1h: r.current_price_1h ?? null,
      currentSpotTaker: r.current_spot_taker ?? null,
      currentNetBuyPct: r.current_net_buy_pct ?? null,
      currentCvd1h: r.current_cvd_1h ?? null,
      currentSpotVol1h: r.current_spot_vol_1h ?? null,
      currentSpotVolAvg1h: r.current_spot_vol_avg_1h ?? null,
      currentCvd30m: r.current_cvd_30m ?? null,
      currentCvd4h: r.current_cvd_4h ?? null,
      currentOiAccel: r.current_oi_accel ?? null,
      currentFutSpotRatio: r.current_fut_spot_ratio ?? null,
      currentCvdPosCycles: r.current_cvd_pos_cycles ?? null,
      currentTakerPosCycles: r.current_taker_pos_cycles ?? null,
      inPrescan: r.in_prescan ?? false,
      retro: r.retro ?? false,
    }));

    res.json({ entries, count: entries.length });
  } catch (err) {
    req.log.error({ err }, "GET /scanner/overheat-log failed");
    res.status(500).json({ error: String(err) });
  }
});

// POST /api/admin/collect-pre-growth
// Собирает исторические метрики за T-2/3/4/6/12h до retro-логирования по 774 токенам.
// Останавливает сканер на время сбора, затем перезапускает.
// Требует ADMIN_TOKEN заголовок. Параметр ?force=true — очищает таблицу перед вставкой.
router.post("/admin/collect-pre-growth", async (req, res) => {
  const token = req.headers["x-admin-token"] ?? req.headers["authorization"];
  if (token !== process.env.ADMIN_TOKEN) {
    res.status(403).json({ error: "forbidden" });
    return;
  }
  const force = req.query.force === "true";
  const { runCollectPreGrowth } =
    await import("../lib/growthLeaderPreGrowth.js");
  const { stopScanner, startScanner } = await import("../lib/scanner.js");

  (async () => {
    try {
      req.log.info("collect-pre-growth: останавливаем сканер");
      await stopScanner();
      req.log.info("collect-pre-growth: сканер остановлен, начинаем сбор");
      await runCollectPreGrowth({ batchSize: 5, batchDelayMs: 1500, force });
      req.log.info("collect-pre-growth: сбор завершён, перезапускаем сканер");
    } catch (err) {
      req.log.warn({ err }, "collect-pre-growth error");
    } finally {
      startScanner().catch((err: unknown) =>
        req.log.warn({ err }, "collect-pre-growth: restart scanner failed"),
      );
    }
  })();

  res.json({
    ok: true,
    force,
    message:
      "Сбор pre-growth данных запущен в фоне (~25-30 мин). Сканер остановлен на время сбора.",
  });
});

// POST /api/admin/collect-signal-pre-growth
// Бэкфилл signal_pre_growth по историческим tracked_signals.
// Для каждого сигнала собирает T-1/2/4/12h снимки из BingX klines + CG OI/taker.
// Также вызывает archetype-detector с entry-метриками из tracked_signals (fail-open).
// Параметр ?days=90 — окно в прошлое (макс 180). Требует ADMIN_TOKEN.
router.post("/admin/collect-signal-pre-growth", async (req, res) => {
  const token = req.headers["x-admin-token"] ?? req.headers["authorization"];
  if (token !== process.env.ADMIN_TOKEN) {
    res.status(403).json({ error: "forbidden" });
    return;
  }
  const days = Math.min(Number(req.query.days ?? 90), 180);
  const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  (async () => {
    const { collectSingleSignalPreGrowth } =
      await import("../lib/growthLeaderPreGrowth.js");
    const { fetchArchetype } = await import("../lib/archetypeClient.js");
    const { stopScanner, startScanner } = await import("../lib/scanner.js");
    try {
      req.log.info("collect-signal-pre-growth: останавливаем сканер");
      await stopScanner();

      const signals = await db
        .select({
          symbol: trackedSignalsTable.symbol,
          detectedAt: trackedSignalsTable.detectedAt,
          sentimentKey: trackedSignalsTable.sentimentKey,
          entryOi30m: trackedSignalsTable.entryOi30m,
          entryOi1h: trackedSignalsTable.entryOi1h,
          entryOi4h: trackedSignalsTable.entryOi4h,
          entryFutVolMult: trackedSignalsTable.entryFutVolMult,
          entrySpotVolMult: trackedSignalsTable.entrySpotVolMult,
          entryCvd1h: trackedSignalsTable.entryCvd1h,
          entryCvd30m: trackedSignalsTable.entryCvd30m,
          price24hAtFire: trackedSignalsTable.price24hAtFire,
          entryFundingRate: trackedSignalsTable.entryFundingRate,
          entrySpotTakerNetBuy: trackedSignalsTable.entrySpotTakerNetBuy,
        })
        .from(trackedSignalsTable)
        .where(gte(trackedSignalsTable.detectedAt, cutoff))
        .orderBy(trackedSignalsTable.detectedAt);

      req.log.info(
        { total: signals.length, days },
        "collect-signal-pre-growth: сканер остановлен, начинаем бэкфилл",
      );

      const BATCH = 5; // без конкуренции со сканером → можно 5 параллельных
      let done = 0,
        inserted = 0;
      for (let i = 0; i < signals.length; i += BATCH) {
        const batch = signals.slice(i, i + BATCH);
        const results = await Promise.allSettled(
          batch.map(async (s) => {
            const firedAtMs = s.detectedAt.getTime();
            const arch = await fetchArchetype(s.symbol, {
              oi_30m: s.entryOi30m,
              oi_1h: s.entryOi1h,
              oi_4h: s.entryOi4h,
              vol_mult: s.entryFutVolMult,
              spot_vol_mult: s.entrySpotVolMult,
              cvd_1h: s.entryCvd1h,
              cvd_30m: s.entryCvd30m,
              price_24h: s.price24hAtFire,
              funding: s.entryFundingRate,
              net_buy_pct: s.entrySpotTakerNetBuy,
            }).catch(() => null);
            return collectSingleSignalPreGrowth(
              s.symbol,
              firedAtMs,
              arch?.archetype ?? null,
              arch?.confidence_score ?? null,
              s.sentimentKey,
            );
          }),
        );
        for (const r of results) {
          if (r.status === "fulfilled") inserted += r.value;
        }
        done += batch.length;
        if (done % 25 === 0 || done === signals.length) {
          req.log.info(
            { done, total: signals.length, inserted },
            "collect-signal-pre-growth: прогресс",
          );
        }
        if (i + BATCH < signals.length)
          await new Promise((r) => setTimeout(r, 1500));
      }
      req.log.info(
        { done, inserted },
        "collect-signal-pre-growth: завершён, перезапускаем сканер",
      );
    } catch (err) {
      req.log.warn({ err }, "collect-signal-pre-growth error");
    } finally {
      startScanner().catch((e: unknown) =>
        req.log.warn(
          { err: e },
          "collect-signal-pre-growth: restart scanner failed",
        ),
      );
    }
  })();

  res.json({
    ok: true,
    days,
    message: `Бэкфилл signal_pre_growth за ${days} дней запущен в фоне. Сканер остановлен на время сбора, перезапустится автоматически. Смотри логи.`,
  });
});

// POST /api/admin/rerun-growth-leader-retro
// Ручной запуск ретроспективного сборщика (7 дней BingX klines + CG OI).
// Требует ADMIN_TOKEN заголовок.
router.post("/admin/rerun-growth-leader-retro", async (req, res) => {
  const token = req.headers["x-admin-token"] ?? req.headers["authorization"];
  if (token !== process.env.ADMIN_TOKEN) {
    res.status(403).json({ error: "forbidden" });
    return;
  }
  const minPrice24h = Number(req.query.minPrice24h ?? 30);
  const { runGrowthLeaderRetro } = await import("../lib/growthLeaderRetro.js");
  // fire-and-forget
  runGrowthLeaderRetro({ minPrice24h, batchSize: 8, batchDelayMs: 600 }).catch(
    (err: unknown) => req.log.warn({ err }, "rerun-growth-leader-retro error"),
  );
  res.json({
    ok: true,
    minPrice24h,
    message: "Ретро-сборщик запущен в фоне, результат в логах через ~10 мин",
  });
});

// GET /api/scanner/growth-leader-stats  (v2)
// Статистика growth_leader_log за последние 24ч: разбивка по source (scan vs bingx_only).
// Не использует entry_* колонки — работает даже если prod Neon ещё не получил ALTER.
router.get("/scanner/growth-leader-stats", async (req, res) => {
  try {
    const hours = Math.min(Number(req.query.hours ?? 24), 168);
    const fromTs = new Date(Date.now() - hours * 3600 * 1000);

    const rows = await db
      .select({
        source: growthLeaderLogTable.source,
        cnt: sql<number>`COUNT(*)::int`,
        uniqSymbols: sql<number>`COUNT(DISTINCT ${growthLeaderLogTable.symbol})::int`,
        latest: sql<string>`MAX(${growthLeaderLogTable.loggedAt})`,
      })
      .from(growthLeaderLogTable)
      .where(gte(growthLeaderLogTable.loggedAt, fromTs))
      .groupBy(growthLeaderLogTable.source);

    // Примеры bingx_only токенов (вне prescan)
    const bingxSample = await db
      .select({
        symbol: growthLeaderLogTable.symbol,
        price24h: growthLeaderLogTable.price24h,
        rank: growthLeaderLogTable.rank,
        loggedAt: growthLeaderLogTable.loggedAt,
      })
      .from(growthLeaderLogTable)
      .where(
        and(
          gte(growthLeaderLogTable.loggedAt, fromTs),
          eq(growthLeaderLogTable.source, "bingx_only"),
        ),
      )
      .orderBy(desc(growthLeaderLogTable.price24h))
      .limit(10);

    res.json({
      hoursBack: hours,
      fromTs,
      bySource: rows,
      bingxOnlySample: bingxSample,
    });
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
});

// GET /api/scanner/spot-netflow — batch spot taker netflow (1h/4h/24h/7d) для всех кэшированных символов
// Ключи — CoinGlass base ticker (BTC, ETH, PEPE). Кэш обновляется каждые 5 мин.
router.get("/scanner/spot-netflow", (_req, res) => {
  import("../lib/spot-netflow-cache.js")
    .then(({ getAllSpotNetflow, getCacheUpdatedAt }) => {
      const data = getAllSpotNetflow();
      res.json({
        updatedAt: getCacheUpdatedAt(),
        count: Object.keys(data).length,
        data,
      });
    })
    .catch((err) => res.status(500).json({ error: String(err) }));
});

// GET /api/scanner/bot-health — агрегированный статус работоспособности бота
router.get("/scanner/bot-health", async (req, res) => {
  try {
    const state = await getScannerState();
    const jobs = getWatcherJobTimings();

    // DB ping — простой SELECT 1
    let dbPingMs: number | null = null;
    let dbOk = false;
    try {
      const t0 = Date.now();
      await db.execute(sql`SELECT 1`);
      dbPingMs = Date.now() - t0;
      dbOk = true;
    } catch {
      dbOk = false;
    }

    const result = {
      scanner: {
        running: state.running,
        isScanning: state.isScanning,
        lastScanAt: state.lastScanAt?.toISOString() ?? null,
        nextScanAt: state.nextScanAt?.toISOString() ?? null,
        lastScanDurationMs: state.lastScanDurationMs,
        marketsScanned: state.marketsScanned,
        scanIntervalMs: state.scanIntervalMs,
      },
      cgLatency: state.lastCgTelemetry
        ? {
            timeoutPct: state.lastCgTelemetry.cgTimeoutPct,
            p50Ms: state.lastCgTelemetry.cgP50Ms,
            p95Ms: state.lastCgTelemetry.cgP95Ms,
            maxMs: state.lastCgTelemetry.cgMaxMs,
            req: state.lastCgTelemetry.cgReq,
            reqPerMin: state.lastCgTelemetry.cgReqPerMin,
            elLagP95Ms: state.lastCgTelemetry.elLagP95Ms,
            windowMin: state.lastCgTelemetry.windowMin,
          }
        : null,
      connections: {
        bingx: state.bingxConnected,
        telegram: state.telegramConnected,
        coinglass: getApiConnected("coinglass"),
        coinalyze: getApiConnected("coinalyze"),
        coinGecko: getApiConnected("coingecko"),
        coinPaprika: getApiConnected("coinpaprika"),
      },
      jobs,
      db: { ok: dbOk, pingMs: dbPingMs },
      oiWatch: {
        insertErrors: state.oiWatchInsertErrors,
        cgTimeoutsLastScan: state.cgTimeoutsLastScan,
      },
    };
    res.json(result);
  } catch (err) {
    req.log.error({ err }, "Failed to get bot health");
    res.status(500).json({ error: "Failed to get bot health" });
  }
});

// GET /api/admin/reject-log?days=7&patterns=BA,TA,SVA
// Топ-причины отказов scan_reject_log за период, сгруппированные по (pattern, reason).
// Использует индекс (pattern, cycle_at DESC) — ответ < 200ms.
router.get("/admin/reject-log", requireAdminToken, async (req, res) => {
  try {
    const rawDays = Number(req.query.days ?? 7);
    const days = Number.isFinite(rawDays)
      ? Math.min(Math.max(Math.floor(rawDays), 1), 30)
      : 7;
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const patternsParam =
      typeof req.query.patterns === "string" ? req.query.patterns.trim() : "";
    const patterns = patternsParam
      ? patternsParam
          .split(",")
          .map((p) => p.trim())
          .filter(Boolean)
      : [];

    const rows = await db
      .select({
        pattern: scanRejectLogTable.pattern,
        reason: scanRejectLogTable.reason,
        count: sql<number>`cast(count(*) as int)`,
      })
      .from(scanRejectLogTable)
      .where(
        patterns.length > 0
          ? and(
              gte(scanRejectLogTable.cycleAt, cutoff),
              inArray(scanRejectLogTable.pattern, patterns),
            )
          : gte(scanRejectLogTable.cycleAt, cutoff),
      )
      .groupBy(scanRejectLogTable.pattern, scanRejectLogTable.reason)
      .orderBy(desc(sql`count(*)`));

    res.json(rows);
  } catch (err) {
    req.log.error({ err }, "GET /admin/reject-log failed");
    res.status(500).json({ error: String(err) });
  }
});

export default router;
