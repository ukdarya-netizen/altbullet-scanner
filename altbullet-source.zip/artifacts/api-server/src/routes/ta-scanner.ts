import { Router } from "express";
import { getTaSnapshot } from "../lib/watcher.js";
import { logger } from "../lib/logger.js";

const router = Router();

type SortKey = "td1h_abs" | "td4h_abs" | "td1d_abs" | "atr1h_desc";

type FilterKey = "all" | "td_buy" | "td_sell" | "td_reversal";

/**
 * GET /api/ta-scanner
 * Возвращает мульти-TF TA данные (MA/EMA/MACD/TD/ATR) для всех токенов.
 * Обновляется каждые 5 мин фоновым циклом.
 *
 * Query params:
 *   sort — td1h_abs | td4h_abs | td1d_abs | atr1h_desc
 *   filter — all | td_buy | td_sell | td_reversal
 *   q — текстовый поиск по символу (case-insensitive)
 *   limit — max записей (default 500)
 */
router.get("/ta-scanner", (req, res) => {
  try {
    const { entries, updatedAt } = getTaSnapshot();

    const sortParam = (req.query.sort as string) || "td1h_abs";
    const filterParam = (req.query.filter as string) || "all";
    const q = ((req.query.q as string) || "").toUpperCase().trim();
    const limit = Math.min(
      parseInt((req.query.limit as string) ?? "500") || 500,
      1000,
    );

    let result = [...entries];

    // ── Text search ──────────────────────────────────────────────────────────
    if (q) {
      result = result.filter((e) => e.symbol.toUpperCase().includes(q));
    }

    // ── Filter ───────────────────────────────────────────────────────────────
    const filter = filterParam as FilterKey;
    if (filter === "td_buy") {
      result = result.filter(
        (e) => (e.td1h != null && e.td1h > 0) || (e.td4h != null && e.td4h > 0),
      );
    } else if (filter === "td_sell") {
      result = result.filter(
        (e) => (e.td1h != null && e.td1h < 0) || (e.td4h != null && e.td4h < 0),
      );
    } else if (filter === "td_reversal") {
      result = result.filter(
        (e) =>
          Math.abs(e.td1h ?? 0) >= 9 ||
          Math.abs(e.td4h ?? 0) >= 9 ||
          Math.abs(e.td1d ?? 0) >= 9,
      );
    }

    // ── Sort ─────────────────────────────────────────────────────────────────
    const sort = sortParam as SortKey;
    if (sort === "td4h_abs") {
      result.sort((a, b) => Math.abs(b.td4h ?? 0) - Math.abs(a.td4h ?? 0));
    } else if (sort === "td1d_abs") {
      result.sort((a, b) => Math.abs(b.td1d ?? 0) - Math.abs(a.td1d ?? 0));
    } else if (sort === "atr1h_desc") {
      result.sort((a, b) => (b.atr1h ?? 0) - (a.atr1h ?? 0));
    } else {
      // default: td1h_abs
      result.sort((a, b) => Math.abs(b.td1h ?? 0) - Math.abs(a.td1h ?? 0));
    }

    res.json({
      entries: result.slice(0, limit),
      count: result.length,
      updatedAt,
    });
  } catch (err) {
    logger.error({ err }, "GET /ta-scanner failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
