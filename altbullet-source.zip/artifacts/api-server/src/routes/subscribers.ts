import { Router } from "express";
import {
  db,
  subscribersTable,
  settingsTable,
  trackedSignalsTable,
  signalsTable,
} from "@workspace/db";
import { eq, gte, inArray, sql } from "drizzle-orm";
import {
  handleWebhookUpdate,
  sendMessage,
  sendPhotoCaption,
  answerCallbackQuery,
} from "../lib/telegram.js";
import {
  sendDailyReport,
  sendWeeklyDigest,
  sendMonthlyDigest,
} from "../lib/watcher.js";
import {
  buildPositionsStatusText,
  POSITIONS_IMG,
} from "../lib/positionsReport.js";
import { sendPositionBatchUpdate } from "../lib/position-batch-update.js";
import {
  getWhaleWatchlist,
  expireStaleWatchlist,
} from "../lib/whale_watch_v2.js";
import { getWhaleWatchState } from "../lib/scanner.js";

const router = Router();

router.post("/telegram/webhook", async (req, res) => {
  try {
    const body = req.body as {
      callback_query?: {
        id: string;
        data?: string;
        message?: { chat?: { id?: number } };
        from?: { id?: number };
      };
    };

    if (body.callback_query) {
      const cq = body.callback_query;
      const chatId = cq.message?.chat?.id ?? cq.from?.id;
      const data = cq.data ?? "";

      await answerCallbackQuery(cq.id);

      if (chatId) {
        if (data === "payment_pending") {
          await sendMessage(
            chatId,
            [
              `⏳ <b>Оплата скоро будет доступна</b>`,
              ``,
              `Мы настраиваем систему оплаты — совсем скоро!`,
              `Следите за обновлениями.`,
            ].join("\n"),
          );
        } else if (data === "menu:open_trades") {
          // Единый форматтер — тот же что в daily report, рестарт-уведомлении и 4ч апдейте
          const text = await buildPositionsStatusText();
          await sendPhotoCaption(chatId, POSITIONS_IMG, "");
          await sendMessage(chatId, text);
        } else if (data === "digest:daily") {
          await sendDailyReport(chatId);
        } else if (data === "digest:weekly") {
          await sendWeeklyDigest(chatId);
        } else if (data === "digest:monthly") {
          await sendMonthlyDigest(chatId);
        } else if (data === "whale_tracker") {
          await sendMessage(chatId, `🐋 Whale Watch 2.0 — анализирую...`);
          try {
            await expireStaleWatchlist();
            const watchlist = await getWhaleWatchlist();
            if (watchlist.length === 0) {
              await sendMessage(
                chatId,
                [
                  `🐋 <b>Whale Watch 2.0</b>`,
                  ``,
                  `Активных накоплений не обнаружено.`,
                  `Мониторинг работает в реальном времени — как только кит начнёт закупаться, токен появится здесь.`,
                  ``,
                  `Полный отчёт — каждую субботу в 10:00 МСК.`,
                ].join("\n"),
              );
            } else {
              const top5 = watchlist.slice(0, 5);
              const lines: string[] = [
                `🐋 <b>Whale Watch 2.0 — ${watchlist.length} токенов</b>`,
                ``,
              ];
              for (const e of top5) {
                const coin = e.symbol.replace("-USDT", "");
                const cvdStr =
                  e.accumulatedCvdUsd >= 1_000_000
                    ? `$${(e.accumulatedCvdUsd / 1_000_000).toFixed(1)}M`
                    : `$${(e.accumulatedCvdUsd / 1_000).toFixed(0)}K`;
                const accumPct =
                  e.accumPct != null ? ` (${e.accumPct.toFixed(2)}% mcap)` : "";
                const emoji = e.status === "breakout" ? "🚀" : "🔵";
                lines.push(
                  `${emoji} <b>${coin}</b> — CVD: ${cvdStr}${accumPct} | ${e.accumPeriods} периодов`,
                );
              }
              if (watchlist.length > 5)
                lines.push(``, `...и ещё ${watchlist.length - 5} токенов`);
              lines.push(``, `🕒 Полный отчёт — Сб 10:00 МСК`);
              await sendMessage(chatId, lines.join("\n"));
            }
          } catch (err) {
            req.log.error({ err }, "whale_tracker callback error");
            await sendMessage(chatId, `❌ Ошибка при анализе. Попробуй позже.`);
          }
        } else if (data === "settings") {
          try {
            const rows = await db.select().from(settingsTable).limit(1);
            const s = rows[0];
            if (!s) {
              await sendMessage(
                chatId,
                `⚙️ <b>Настройки</b>\n\nНастройки не найдены в базе данных.`,
              );
            } else {
              const intervalMin = Math.round(s.scanIntervalMs / 60000);
              const watchlistStr = s.watchlist
                ? s.watchlist.split(",").slice(0, 5).join(", ") +
                  (s.watchlist.split(",").length > 5 ? " ..." : "")
                : "не задан";
              await sendMessage(
                chatId,
                [
                  `⚙️ <b>Текущие настройки сканера</b>`,
                  ``,
                  `📊 <b>Фильтры сигналов:</b>`,
                  `  Мин. объём: <b>${s.volumeMultiplier}x</b>`,
                  `  Мин. OI: <b>+${s.oiChangePercent}%</b>`,
                  `  Интервал скана: <b>${intervalMin} мин</b>`,
                  `  Макс. символов: <b>${s.maxSymbols}</b>`,
                  ``,
                  `🚀 <b>Moonshot Momentum:</b>`,
                  `  Объём ≥ ${s.moonshotVolMult ?? 5}x | Цена ≥ ${s.moonshotPriceChange ?? 15}% | OI ≥ ${s.moonshotOiChange ?? 10}%`,
                  `  Блокировка стеной: $${((s.moonshotAskWallUsd ?? 50000) / 1000).toFixed(0)}k`,
                  ``,
                  `🛡 <b>Smart Cancel:</b>`,
                  `  Мин. OI 4h для блокировки: ${s.smartCancelOiPct ?? 5}%`,
                  ``,
                  `📢 Telegram: <b>${s.telegramEnabled ? "включён ✅" : "выключен ❌"}</b>`,
                  s.channelId
                    ? `📡 Канал: <code>${s.channelId}</code>`
                    : `📡 Канал: <i>не настроен</i>`,
                  s.watchlist
                    ? `📋 Watchlist: <code>${watchlistStr}</code>`
                    : ``,
                  ``,
                  `Изменить настройки: <b>bingx-trader.replit.app</b> → Settings`,
                ]
                  .filter(Boolean)
                  .join("\n"),
              );
            }
          } catch (err) {
            req.log.error({ err }, "settings callback error");
            await sendMessage(
              chatId,
              `❌ Ошибка при загрузке настроек. Попробуй позже.`,
            );
          }
        }
      }

      return res.json({ ok: true });
    }

    // ── /whalewatch — текущий watchlist Whale Watch 2.0 ──────────────────────
    const msgText = (
      req.body as { message?: { text?: string; chat?: { id?: number } } }
    )?.message;
    if (msgText?.text?.toLowerCase().startsWith("/whalewatch")) {
      const chatId = msgText.chat?.id;
      if (chatId) {
        await sendMessage(chatId, `🐋 Whale Watch 2.0 — загружаю watchlist...`);
        try {
          await expireStaleWatchlist();
          const watchlist = await getWhaleWatchlist();
          if (watchlist.length === 0) {
            await sendMessage(
              chatId,
              [
                `🐋 <b>Whale Watch 2.0</b>`,
                ``,
                `Активных накоплений не обнаружено.`,
                `Мониторинг работает в реальном времени.`,
              ].join("\n"),
            );
          } else {
            const lines = [
              `🐋 <b>Whale Watch 2.0 — ${watchlist.length} токенов</b>`,
              ``,
            ];
            for (const e of watchlist.slice(0, 10)) {
              const coin = e.symbol.replace("-USDT", "");
              const cvdStr =
                e.accumulatedCvdUsd >= 1_000_000
                  ? `$${(e.accumulatedCvdUsd / 1_000_000).toFixed(1)}M`
                  : `$${(e.accumulatedCvdUsd / 1_000).toFixed(0)}K`;
              const pct =
                e.accumPct != null ? ` (${e.accumPct.toFixed(2)}% mcap)` : "";
              const emoji = e.status === "breakout" ? "🚀" : "🔵";
              lines.push(
                `${emoji} <b>${coin}</b> — ${cvdStr}${pct} | ${e.accumPeriods}п`,
              );
            }
            if (watchlist.length > 10)
              lines.push(``, `...ещё ${watchlist.length - 10}`);
            await sendMessage(chatId, lines.join("\n"));
          }
        } catch (err) {
          req.log.error({ err }, "/whalewatch error");
          await sendMessage(chatId, `❌ Ошибка. Попробуй позже.`);
        }
        return res.json({ ok: true });
      }
    }

    // ── /update — батч-апдейт по всем открытым позициям с обогащением ───────
    if (msgText?.text?.toLowerCase().startsWith("/update")) {
      const chatId = msgText.chat?.id;
      if (chatId) {
        await sendMessage(chatId, `🔄 Собираю данные по позициям...`);
        try {
          await sendPositionBatchUpdate(chatId);
        } catch (err) {
          req.log.error({ err }, "/update error");
          await sendMessage(
            chatId,
            `❌ Ошибка при загрузке апдейта. Попробуй позже.`,
          );
        }
        return res.json({ ok: true });
      }
    }

    // ── /addsignal — ручной импорт позиции прямо из Telegram ────────────────
    // Формат: /addsignal SYMBOL PRICE STATUS
    // STATUS: active | in_run | re_entry
    // Только для владельца (проверка по TELEGRAM_CHAT_ID)
    if (msgText?.text?.toLowerCase().startsWith("/addsignal")) {
      const chatId = msgText.chat?.id;
      if (!chatId) return res.json({ ok: true });

      const ownerRaw = process.env.TELEGRAM_CHAT_ID?.trim();
      const isOwner =
        ownerRaw && !ownerRaw.startsWith("@") && String(chatId) === ownerRaw;
      if (!isOwner) {
        await sendMessage(chatId, `❌ Команда доступна только владельцу бота.`);
        return res.json({ ok: true });
      }

      try {
        const parts = msgText.text.trim().split(/\s+/);
        if (parts.length < 4) {
          await sendMessage(
            chatId,
            [
              `📥 <b>/addsignal — ручной импорт сигнала</b>`,
              ``,
              `<b>Формат:</b> <code>/addsignal SYMBOL PRICE STATUS</code>`,
              ``,
              `<b>Примеры:</b>`,
              `<code>/addsignal EPIC-USDT 0.45 in_run</code>`,
              `<code>/addsignal SUSHI-USDT 0.84 active</code>`,
              `<code>/addsignal ZBT-USDT 0.127 active</code>`,
              ``,
              `<b>STATUS:</b> active | in_run | re_entry`,
            ].join("\n"),
          );
          return res.json({ ok: true });
        }

        let symbol = parts[1].toUpperCase();
        if (!symbol.endsWith("-USDT")) symbol = `${symbol}-USDT`;
        const price = parseFloat(parts[2]);
        const status = parts[3].toLowerCase() as
          | "active"
          | "in_run"
          | "re_entry";

        if (isNaN(price) || price <= 0) {
          await sendMessage(
            chatId,
            `❌ Неверная цена: <code>${parts[2]}</code>\nОжидается число > 0.`,
          );
          return res.json({ ok: true });
        }

        const validStatuses = ["active", "in_run", "re_entry"];
        if (!validStatuses.includes(status)) {
          await sendMessage(
            chatId,
            `❌ Неверный статус: <code>${parts[3]}</code>\nДоступные: active | in_run | re_entry`,
          );
          return res.json({ ok: true });
        }

        // Проверяем нет ли уже активного сигнала по этому символу
        const allOpen = await db
          .select()
          .from(trackedSignalsTable)
          .where(
            inArray(trackedSignalsTable.status, [
              "active",
              "in_run",
              "accumulation",
              "re_entry",
            ]),
          );
        const existing = allOpen.filter((r) => r.symbol === symbol);
        if (existing.length > 0) {
          const e = existing[0];
          await sendMessage(
            chatId,
            [
              `⚠️ <b>${symbol}</b> уже отслеживается`,
              ``,
              `ID: ${e.id} | Статус: <b>${e.status}</b> | Вход: $${e.entryPrice}`,
              `Создан: ${e.detectedAt.toLocaleDateString("ru-RU")}`,
              ``,
              `Если нужно добавить заново — сначала дождись закрытия или напиши мне.`,
            ].join("\n"),
          );
          return res.json({ ok: true });
        }

        // Создаём строку в signals (как «anchor» для внешнего ключа)
        const tvSymbol = symbol.replace("-", "");
        const [sig] = await db
          .insert(signalsTable)
          .values({
            symbol,
            type: "alpha",
            value: 0,
            threshold: 0,
            price,
            priceChangePercent: 0,
            volume24h: 0,
            avgVolume: 0,
            tradingViewUrl: `https://www.tradingview.com/chart/?symbol=BINGX:${tvSymbol}`,
            sentiment: "manual",
            sentimentKey: "manual_import",
          })
          .returning();

        // Создаём строку в tracked_signals
        const [tracked] = await db
          .insert(trackedSignalsTable)
          .values({
            symbol,
            signalId: sig.id,
            signalType: "alpha",
            sentimentKey: "manual_import",
            entryPrice: price,
            peakPrice: price,
            status,
          })
          .returning();

        req.log.info(
          { symbol, price, status, signalId: sig.id, trackedId: tracked.id },
          "/addsignal: manual import via Telegram",
        );

        const statusEmoji: Record<string, string> = {
          active: "🟡",
          in_run: "🚀",
          accumulation: "🔵",
          re_entry: "🔄",
        };
        await sendMessage(
          chatId,
          [
            `✅ <b>Сигнал добавлен в базу</b>`,
            ``,
            `${statusEmoji[status] ?? "⚪"} <b>${symbol}</b>`,
            `💰 Вход: <b>$${price}</b>`,
            `📊 Статус: <b>${status}</b>`,
            ``,
            `signal_id: <code>${sig.id}</code> | tracked_id: <code>${tracked.id}</code>`,
            ``,
            `Вотчер подхватит позицию в следующем цикле (~2 мин).`,
          ].join("\n"),
        );
      } catch (err) {
        req.log.error({ err }, "/addsignal error");
        await sendMessage(
          chatId,
          `❌ Ошибка при добавлении сигнала. Детали в логах сервера.`,
        );
      }
      return res.json({ ok: true });
    }

    await handleWebhookUpdate(req.body);
    return res.json({ ok: true });
  } catch (err) {
    req.log.error({ err }, "Webhook processing error");
    return res.json({ ok: true });
  }
});

router.get("/subscribers", async (req, res) => {
  try {
    const subscribers = await db
      .select()
      .from(subscribersTable)
      .orderBy(subscribersTable.subscribedAt);

    const activeCount = subscribers.filter((s) => s.active).length;

    res.json({
      subscribers: subscribers.map((s) => ({
        chatId: s.chatId,
        username: s.username,
        firstName: s.firstName,
        lastName: s.lastName,
        active: s.active,
        subscribedAt: s.subscribedAt.toISOString(),
        unsubscribedAt: s.unsubscribedAt?.toISOString() ?? null,
      })),
      total: subscribers.length,
      active: activeCount,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get subscribers");
    res.status(500).json({ error: "Failed to get subscribers" });
  }
});

router.delete("/subscribers/:chatId", async (req, res) => {
  try {
    const chatId = Number(req.params.chatId);
    if (isNaN(chatId)) {
      res.status(400).json({ error: "Invalid chatId" });
      return;
    }
    await db
      .update(subscribersTable)
      .set({ active: false, unsubscribedAt: new Date() })
      .where(eq(subscribersTable.chatId, chatId));
    req.log.info({ chatId }, "Subscriber removed via admin API");
    res.json({ ok: true, chatId });
  } catch (err) {
    req.log.error({ err }, "Failed to remove subscriber");
    res.status(500).json({ error: "Failed to remove subscriber" });
  }
});

router.get("/subscribers/stats", async (req, res) => {
  try {
    const [totalResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(subscribersTable);
    const [activeResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(subscribersTable)
      .where(eq(subscribersTable.active, true));

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const [todayResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(subscribersTable)
      .where(gte(subscribersTable.subscribedAt, today));

    const weekAgo = new Date(Date.now() - 7 * 24 * 3600_000);
    const [weekResult] = await db
      .select({ count: sql<number>`count(*)` })
      .from(subscribersTable)
      .where(gte(subscribersTable.subscribedAt, weekAgo));

    const total = Number(totalResult.count);
    const active = Number(activeResult.count);

    res.json({
      total,
      active,
      inactive: total - active,
      newToday: Number(todayResult.count),
      newThisWeek: Number(weekResult.count),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get subscriber stats");
    res.status(500).json({ error: "Failed to get subscriber stats" });
  }
});

// ── Whale Watch 2.0 API ───────────────────────────────────────────────────────
router.get("/whale-watch", async (req, res) => {
  try {
    const { stages, pathA } = getWhaleWatchState();
    await expireStaleWatchlist();
    const watchlist = await getWhaleWatchlist();

    res.json({ stages, pathA, watchlist });
  } catch (err) {
    req.log.error({ err }, "Failed to get whale watch data");
    res.status(500).json({ error: "Failed to get whale watch data" });
  }
});

// ── Channel test ─────────────────────────────────────────────────────────────
router.post("/telegram/test-channel", async (req, res) => {
  try {
    const rows = await db
      .select({ channelId: settingsTable.channelId })
      .from(settingsTable)
      .limit(1);
    const channelId = rows[0]?.channelId ?? null;

    if (!channelId) {
      res.json({
        success: false,
        message: "Channel ID не настроен в Settings",
      });
      return;
    }

    const testText = [
      `✅ <b>Тест канала BingX AltBullet</b>`,
      ``,
      `Канал: <code>${channelId}</code>`,
      `Время: ${new Date().toUTCString()}`,
      ``,
      `Если видишь это — бот корректно пересылает сигналы в этот канал.`,
    ].join("\n");

    const ok = await sendMessage(channelId, testText);

    if (ok) {
      res.json({
        success: true,
        message: `Тестовое сообщение отправлено в ${channelId}`,
      });
    } else {
      res.json({
        success: false,
        message:
          "Не удалось отправить. Проверь: бот добавлен в канал как Admin с правом 'Post Messages'",
      });
    }
  } catch (err) {
    req.log.error({ err }, "Channel test error");
    res.status(500).json({ success: false, message: "Ошибка сервера" });
  }
});

export default router;
