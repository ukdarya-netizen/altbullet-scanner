/**
 * Whale Alert Stats API — ретроспектива + аудит скорости Layer 11.
 *
 * GET /api/whale-alert/stats
 *   poolEntries  — последние 60 записей whale_alert_pool с lag-метриками
 *   summary      — средние лаги, распределение статусов
 *   recentSignals — последние 30 tracked_signals для whale_alert с exit-данными
 */

import { Router } from "express";
import { db, whaleAlertPoolTable, trackedSignalsTable } from "@workspace/db";
import { desc, eq } from "drizzle-orm";

const router = Router();

router.get("/whale-alert/stats", async (_req, res) => {
  try {
    // ── 1. Pool entries (последние 60) ──────────────────────────────────────
    const poolRows = await db
      .select()
      .from(whaleAlertPoolTable)
      .orderBy(desc(whaleAlertPoolTable.detectedAt))
      .limit(60);

    const poolEntries = poolRows.map((r) => {
      const alertTimeMs = r.alertTime?.getTime() ?? null;
      const detectedAtMs = r.detectedAt.getTime();
      const firedAtMs = r.firedAt?.getTime() ?? null;

      const detectLagMin =
        alertTimeMs != null
          ? Math.round((detectedAtMs - alertTimeMs) / 60_000)
          : null;
      const confirmLagMin =
        firedAtMs != null
          ? Math.round((firedAtMs - detectedAtMs) / 60_000)
          : null;
      const totalLagMin =
        alertTimeMs != null && firedAtMs != null
          ? Math.round((firedAtMs - alertTimeMs) / 60_000)
          : null;

      return {
        id: r.id,
        symbol: r.symbol,
        hlSymbol: r.hlSymbol,
        status: r.status,
        detectedAt: r.detectedAt.toISOString(),
        expiresAt: r.expiresAt.toISOString(),
        firedAt: r.firedAt?.toISOString() ?? null,
        alertTime: r.alertTime?.toISOString() ?? null,
        positionValueUsdM:
          r.positionValueUsd != null
            ? +(r.positionValueUsd / 1e6).toFixed(2)
            : null,
        whaleCount: r.whaleCount,
        totalWhaleUsdM:
          r.totalWhaleUsd != null ? +(r.totalWhaleUsd / 1e6).toFixed(2) : null,
        entryPrice: r.entryPrice,
        currentPrice: r.currentPrice,
        priceChangePct: r.priceChangePct,
        oi30m: r.oi30m,
        oi1h: r.oi1h,
        futLargeOrderConfirmed: r.futLargeOrderConfirmed,
        spotLargeOrderConfirmed: r.spotLargeOrderConfirmed,
        detectLagMin,
        confirmLagMin,
        totalLagMin,
        price72hPct: r.price72hPct,
      };
    });

    // ── 2. Summary stats (только fired) ────────────────────────────────────
    const fired = poolEntries.filter((e) => e.status === "fired");
    const watching = poolEntries.filter((e) => e.status === "watching").length;
    const expired = poolEntries.filter((e) => e.status === "expired").length;

    const avgDetectLagMin =
      fired.length > 0
        ? +(
            fired.reduce((s, e) => s + (e.detectLagMin ?? 0), 0) / fired.length
          ).toFixed(1)
        : null;
    const avgConfirmLagMin =
      fired.length > 0
        ? +(
            fired.reduce((s, e) => s + (e.confirmLagMin ?? 0), 0) / fired.length
          ).toFixed(1)
        : null;
    const avgTotalLagMin =
      fired.length > 0
        ? +(
            fired.reduce((s, e) => s + (e.totalLagMin ?? 0), 0) / fired.length
          ).toFixed(1)
        : null;

    // p50 confirm lag
    const confirmLags = fired
      .map((e) => e.confirmLagMin ?? 0)
      .sort((a, b) => a - b);
    const p50ConfirmLagMin =
      confirmLags.length > 0
        ? confirmLags[Math.floor(confirmLags.length / 2)]!
        : null;

    // ── 3. Recent tracked_signals for whale_alert ───────────────────────────
    const signalRows = await db
      .select({
        id: trackedSignalsTable.id,
        symbol: trackedSignalsTable.symbol,
        status: trackedSignalsTable.status,
        entryPrice: trackedSignalsTable.entryPrice,
        exitPrice: trackedSignalsTable.exitPrice,
        pnlPercent: trackedSignalsTable.pnlPercent,
        peakPrice: trackedSignalsTable.peakPrice,
        cancelReason: trackedSignalsTable.cancelReason,
        detectedAt: trackedSignalsTable.detectedAt,
        closedAt: trackedSignalsTable.closedAt,
        price72hAfterExitPct: trackedSignalsTable.price72hAfterExitPct,
        entryOi30m: trackedSignalsTable.entryOi30m,
        entryOi1h: trackedSignalsTable.entryOi1h,
        alphaScore: trackedSignalsTable.alphaScore,
      })
      .from(trackedSignalsTable)
      .where(eq(trackedSignalsTable.sentimentKey, "whale_alert"))
      .orderBy(desc(trackedSignalsTable.detectedAt))
      .limit(30);

    const recentSignals = signalRows.map((r) => ({
      id: r.id,
      symbol: r.symbol,
      status: r.status,
      entryPrice: r.entryPrice,
      exitPrice: r.exitPrice,
      pnlPercent: r.pnlPercent,
      peakPrice: r.peakPrice,
      cancelReason: r.cancelReason,
      detectedAt: r.detectedAt.toISOString(),
      closedAt: r.closedAt?.toISOString() ?? null,
      price72hAfterExitPct: r.price72hAfterExitPct,
      entryOi30m: r.entryOi30m,
      entryOi1h: r.entryOi1h,
      alphaScore: r.alphaScore,
    }));

    res.json({
      poolEntries,
      summary: {
        firedCount: fired.length,
        watchingCount: watching,
        expiredCount: expired,
        avgDetectLagMin,
        avgConfirmLagMin,
        avgTotalLagMin,
        p50ConfirmLagMin,
      },
      recentSignals,
    });
  } catch (err) {
    console.error("whale-alert stats error", err);
    res.status(500).json({ error: "internal" });
  }
});

export default router;
