import app from "./app";
import { logger } from "./lib/logger";
import {
  pool,
  db,
  settingsTable,
  subscribersTable,
  trackedSignalsTable,
} from "@workspace/db";
import {
  setWebhook,
  registerBotCommands,
  warmChannelIdCache,
} from "./lib/telegram.js";
import {
  startScanner,
  stopScanner,
  getLastScanAt,
  getIsScanning,
} from "./lib/scanner.js";
import { startWatcher, startWatchdog } from "./lib/watcher.js";
import { refreshCgSupportedCoins } from "./lib/coinglass_oi.js";
import { startMarketCapPreloader } from "./lib/whale_watch_v2.js";
import { lt, sql as drizzleSql, eq, and } from "drizzle-orm";

async function runStartupMigration() {
  try {
    // Добавляем колонки scanner_last_scan_at / scanner_scan_started_at если ещё нет (идемпотентно)
    await db.execute(
      drizzleSql`ALTER TABLE settings ADD COLUMN IF NOT EXISTS scanner_last_scan_at TIMESTAMP`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE settings ADD COLUMN IF NOT EXISTS scanner_scan_started_at TIMESTAMP`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE settings ADD COLUMN IF NOT EXISTS last_watchdog_alert_at TIMESTAMP`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE settings ADD COLUMN IF NOT EXISTS last_manual_check_sent_at TIMESTAMP`,
    );

    // CoinGlass liquidation-данные для liq_cascade_watch (идемпотентно)
    await db.execute(
      drizzleSql`ALTER TABLE liq_cascade_watch ADD COLUMN IF NOT EXISTS cycle_count_at_detect integer`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE liq_cascade_watch ADD COLUMN IF NOT EXISTS long_liq1h_at_detect real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE liq_cascade_watch ADD COLUMN IF NOT EXISTS long_liq4h_at_detect real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE liq_cascade_watch ADD COLUMN IF NOT EXISTS long_liq24h_at_detect real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE liq_cascade_watch ADD COLUMN IF NOT EXISTS current_long_liq1h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE liq_cascade_watch ADD COLUMN IF NOT EXISTS liq_exhausted boolean`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE liq_cascade_watch ADD COLUMN IF NOT EXISTS global_long_pct real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE liq_cascade_watch ADD COLUMN IF NOT EXISTS large_bid_usd real`,
    );

    // Индивидуальные стоп/тейки по Liquidation Heatmap (идемпотентно)
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS stop_loss_price real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS stop_loss_pct real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS stop_source text`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS take_targets jsonb`,
    );

    // Универсальные метрики входа (2026-07-15) + пер-токенный Whale Index (идемпотентно)
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_rsi_1h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_funding_rate real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_btc_24h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_whale_index real`,
    );

    // Spot taker / net-buy метрики (2026-07-15) — пишутся для ВСЕХ паттернов (идемпотентно)
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_spot_taker_net_buy real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_spot_net_buy_1h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_spot_net_buy_4h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_spot_net_buy_24h real`,
    );

    // growth_leader_log — создаём таблицу если не существует (продакшн Neon не получал drizzle push)
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS growth_leader_log (
      id              serial PRIMARY KEY,
      logged_at       timestamp NOT NULL DEFAULT now(),
      symbol          text NOT NULL,
      rank            integer,
      price           real,
      price_24h       real,
      price_1h        real,
      growth_from_entry real,
      cycle_count     integer,
      first_seen_at   real,
      layers          text[],
      oi_30m          real,
      oi_1h           real,
      oi_4h           real,
      cvd_1h          boolean,
      cvd_30m         boolean,
      spot_vol_mult   real,
      vol_mult        real,
      source          text NOT NULL DEFAULT 'scan',
      entry_price     real,
      entry_price_24h real,
      entry_oi_30m    real,
      entry_oi_1h     real,
      entry_oi_4h     real
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS growth_leader_log_logged_at_idx ON growth_leader_log (logged_at)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS growth_leader_log_symbol_idx   ON growth_leader_log (symbol)`,
    );
    // Колонки entry_* — добавляем если таблица уже существовала без них
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS entry_price real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS entry_price_24h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS entry_oi_30m real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS entry_oi_1h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS entry_oi_4h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS net_buy_pct real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS spot_taker_buy_usd real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS spot_taker_sell_usd real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS spot_fp_buy_pct real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS matched_pattern text`,
    );
    // ПРИМЕЧАНИЕ: колонки growth_leader_log v1/v2 управляются через Drizzle migration 0002.

    // Pre-growth snapshots: исторические метрики за T-2/3/4/6/12h до retro-логирования
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS retro_pre_growth (
      id            serial PRIMARY KEY,
      retro_log_id  integer NOT NULL,
      symbol        text    NOT NULL,
      retro_time    timestamp NOT NULL,
      hours_before  integer NOT NULL,
      snapshot_time timestamp NOT NULL,
      price         real,
      price_1h      real,
      price_3h      real,
      price_4h      real,
      price_24h     real,
      oi_30m        real,
      oi_prev_30m   real,
      oi_1h         real,
      oi_prev_1h    real,
      oi_4h         real,
      vol_mult      real,
      cvd_1h        boolean,
      cvd_1h_ratio  real,
      cvd_30m       boolean,
      cvd_30m_ratio real,
      net_buy_pct   real,
      spot_net_pct  real,
      spot_buy_usd  real,
      spot_sell_usd real,
      funding       real,
      notes         text,
      created_at    timestamp NOT NULL DEFAULT now(),
      UNIQUE (retro_log_id, hours_before)
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS retro_pre_growth_symbol_idx ON retro_pre_growth (symbol)`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE retro_pre_growth ADD COLUMN IF NOT EXISTS price_4h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE retro_pre_growth ADD COLUMN IF NOT EXISTS oi_prev_30m real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE retro_pre_growth ADD COLUMN IF NOT EXISTS oi_prev_1h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE retro_pre_growth ADD COLUMN IF NOT EXISTS oi_4h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE retro_pre_growth ADD COLUMN IF NOT EXISTS cvd_1h_ratio real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE retro_pre_growth ADD COLUMN IF NOT EXISTS cvd_30m boolean`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE retro_pre_growth ADD COLUMN IF NOT EXISTS cvd_30m_ratio real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE retro_pre_growth ADD COLUMN IF NOT EXISTS spot_net_pct real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE retro_pre_growth ADD COLUMN IF NOT EXISTS spot_buy_usd real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE retro_pre_growth ADD COLUMN IF NOT EXISTS spot_sell_usd real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE retro_pre_growth ADD COLUMN IF NOT EXISTS funding real`,
    );

    // signal_pre_growth — ретроснимки T-1/2/4/12ч ДО момента выстрела сигнала.
    // Заполняется автоматически при каждом trackSignal "new" (fire-and-forget).
    // archetype / archetype_conf — результат archetype-detector FastAPI на момент выстрела.
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS signal_pre_growth (
      id            serial PRIMARY KEY,
      symbol        text    NOT NULL,
      fire_time     timestamptz NOT NULL,
      hours_before  integer NOT NULL,
      snapshot_time timestamptz NOT NULL,
      sentiment_key  text,
      archetype     text,
      archetype_conf integer,
      price         real,
      price_1h      real,
      price_3h      real,
      price_4h      real,
      price_24h     real,
      oi_30m        real,
      oi_prev_30m   real,
      oi_1h         real,
      oi_prev_1h    real,
      oi_4h         real,
      vol_mult      real,
      cvd_1h        boolean,
      cvd_1h_ratio  real,
      cvd_30m       boolean,
      cvd_30m_ratio real,
      net_buy_pct   real,
      spot_net_pct  real,
      spot_buy_usd  real,
      spot_sell_usd real,
      funding       real,
      created_at    timestamptz NOT NULL DEFAULT now(),
      UNIQUE (symbol, fire_time, hours_before)
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS signal_pre_growth_symbol_idx ON signal_pre_growth (symbol)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS signal_pre_growth_fire_time_idx ON signal_pre_growth (fire_time DESC)`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE signal_pre_growth ADD COLUMN IF NOT EXISTS sentiment_key text`,
    );

    // Одноразовый фикс: заполняем alpha_score для открытых позиций где он NULL.
    // whale_alert = 8, остальные = 6 (консервативный дефолт).
    // Идемпотентно: WHERE alpha_score IS NULL — повторный запуск no-op.
    await db.execute(drizzleSql`
      UPDATE tracked_signals
      SET alpha_score = CASE
        WHEN sentiment_key = 'whale_alert' THEN 8
        ELSE 6
      END
      WHERE alpha_score IS NULL
        AND status IN ('active', 'in_run', 'accumulation', 're_entry')
    `);

    // Growth Leader Log: снимки топ-50 гейнеров каждый скан-цикл (идемпотентно)
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS growth_leader_log (
      id serial PRIMARY KEY,
      logged_at timestamp NOT NULL DEFAULT now(),
      symbol text NOT NULL,
      rank integer,
      price real,
      price_24h real,
      price_1h real,
      growth_from_entry real,
      cycle_count integer,
      first_seen_at real,
      layers text[],
      oi_30m real,
      oi_1h real,
      oi_4h real,
      cvd_1h boolean,
      cvd_30m boolean,
      spot_vol_mult real,
      vol_mult real,
      source text NOT NULL DEFAULT 'scan'
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS growth_leader_log_logged_at_idx ON growth_leader_log (logged_at)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS growth_leader_log_symbol_idx ON growth_leader_log (symbol)`,
    );

    // first_oi_* в prescan_tracker: снимок OI при первом входе токена в prescan (идемпотентно)
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS first_oi_30m real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS first_oi_1h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS first_oi_4h real`,
    );

    // Layer 11 Whale Alerts (Hyperliquid киты) + история метрик по циклам (идемпотентно)
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS whale_alert_pool (
      id serial PRIMARY KEY,
      symbol text NOT NULL,
      hl_symbol text NOT NULL,
      status text NOT NULL DEFAULT 'watching',
      detected_at timestamp NOT NULL DEFAULT now(),
      expires_at timestamp NOT NULL,
      fired_at timestamp,
      whale_address text,
      position_value_usd double precision,
      position_size_tokens double precision,
      whale_entry_price double precision,
      liq_price double precision,
      alert_time timestamp,
      whale_count integer NOT NULL DEFAULT 1,
      total_whale_usd double precision,
      entry_price real,
      fut_large_order_confirmed boolean,
      fut_large_order_bid_usd real,
      spot_large_order_confirmed boolean,
      spot_large_order_bid_usd real,
      current_price real,
      price_change_pct real,
      oi_30m real, oi_1h real, oi_4h real, oi_24h real,
      spot_vol_1h real, spot_vol_4h real, spot_vol_24h real,
      spot_vol_mult real, spot_vol_mcap_pct real,
      cvd_30m boolean, cvd_1h boolean, cvd_4h boolean,
      cycle_count integer NOT NULL DEFAULT 0,
      last_cycle_at timestamp
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS whale_alert_pool_symbol_status_idx ON whale_alert_pool (symbol, status)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS whale_alert_pool_detected_at_idx ON whale_alert_pool (detected_at)`,
    );
    // Дедуп между 2 прод-воркерами: только одна watching-запись на символ
    await db.execute(
      drizzleSql`CREATE UNIQUE INDEX IF NOT EXISTS whale_alert_pool_symbol_watching_uq ON whale_alert_pool (symbol) WHERE status = 'watching'`,
    );
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS whale_alert_watch_log (
      id serial PRIMARY KEY,
      pool_id integer NOT NULL,
      symbol text NOT NULL,
      ts timestamp NOT NULL DEFAULT now(),
      price real,
      oi_30m real, oi_1h real, oi_4h real, oi_24h real,
      spot_vol_1h real, spot_vol_4h real, spot_vol_24h real,
      spot_vol_mult real, spot_vol_mcap_pct real,
      cvd_30m boolean, cvd_1h boolean, cvd_4h boolean
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS whale_alert_log_symbol_ts_idx ON whale_alert_watch_log (symbol, ts)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS whale_alert_log_pool_id_idx ON whale_alert_watch_log (pool_id)`,
    );

    // Layer 11: персистентный дедуп seen-ключей whale-алертов — статистика
    // (whale_count/total_whale_usd) не задваивается после рестарта (идемпотентно)
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS whale_alert_seen (
      seen_key text PRIMARY KEY,
      ts timestamp NOT NULL DEFAULT now()
    )`);

    // pattern_debug_log — агрегированные счётчики checked/passed/rejectedAt по паттернам
    // за каждый скан-цикл. Используется в /api/scanner/pattern-debug/history.
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS pattern_debug_log (
      id serial PRIMARY KEY,
      pattern text NOT NULL,
      cycle_number integer,
      checked integer NOT NULL,
      passed integer NOT NULL,
      rejected_at text,
      symbol text,
      cvd_diag text,
      logged_at timestamp NOT NULL DEFAULT now()
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS pattern_debug_pattern_idx ON pattern_debug_log (pattern)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS pattern_debug_logged_at_idx ON pattern_debug_log (logged_at)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS pattern_debug_symbol_idx ON pattern_debug_log (symbol)`,
    );
    // Сброс устаревших PDB-счётчиков liquidation_cascade (до редизайна 2026-07-19):
    // старые лейблы no_1h_dump/oi_pass_blocks из кода до pool-redesign засоряли UI.
    // Идемпотентно: удаляем только строки старше 2026-07-19 09:00 UTC.
    await db.execute(
      drizzleSql`DELETE FROM pattern_debug_log WHERE pattern = 'liquidation_cascade' AND logged_at < '2026-07-19 09:00:00'`,
    );

    // Сброс устаревших PDB-счётчиков spot_vol_accumulation (до 2026-07-20):
    // лейблы no_spot_mult/mult_too_low/prev_mult_low/no_cvd — из кода до перестановки _pdbCheck
    // за mult-гейт. Сейчас _pdbCheck вызывается только ПОСЛЕ mult≥2.5, эти лейблы невозможны.
    await db.execute(
      drizzleSql`DELETE FROM pattern_debug_log WHERE pattern = 'spot_vol_accumulation' AND logged_at < '2026-07-20 00:00:00'`,
    );
    // Удаляем всю историю PDB для удалённых паттернов (2026-07-20): они больше не в коде,
    // их исторические строки засоряли PDB-дашборд. Идемпотентно.
    await db.execute(drizzleSql`DELETE FROM pattern_debug_log WHERE pattern IN (
      'impulse_buy','liquidation_cascade','whale_watch',
      'liq_magnet_squeeze','exchange_outflow_accum','oversold_reversal',
      'smart_money_divergence','4h_momentum','oi1h_breakout',
      'oi4h_silent_accum','quiet_trend_rider',
      'spot_momentum_reversal','spot_vol_surge','impulse_breakout',
      'dip_accumulation','spot_trend_accumulation','spot_divergence','accumulation_breakout',
      'quiet_oi_accumulation','volume_taker','spot_absorption','early_vol_oi',
      'spot_oi4h_build','short_squeeze','spot_taker_lead','spot_vol_breakout',
      'oi24h_accumulation','daily_oi_accum_experiment',
      'silent_whale','hidden_accumulation','whale_watch_spot','anomaly','mexc_pump',
      'aggressive_breakout','bear_trap','distribution','bearish_pressure',
      'volume_breakout','volume_breakout_futures',
      'volume_breakout_quiet','volume_breakout_mover','volume_breakout_spot'
    )`);

    // scan_reject_log: per-symbol per-pattern причины отклонения (TTL 7 дней)
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS scan_reject_log (
      id serial PRIMARY KEY,
      cycle_at timestamptz NOT NULL,
      symbol text NOT NULL,
      pattern text NOT NULL,
      reason text NOT NULL,
      oi30m real,
      vol_mult real,
      price24h real,
      prescan_cycles integer
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS scan_reject_log_sym_idx ON scan_reject_log (symbol, cycle_at)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS scan_reject_log_cycle_idx ON scan_reject_log (cycle_at)`,
    );
    await db.execute(
      drizzleSql`DELETE FROM scan_reject_log WHERE cycle_at < NOW() - INTERVAL '7 days'`,
    );

    // Futures vs Spot Volume (CoinGlass /api/futures_spot_volume_ratio, Binance+OKX+Bybit)
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS fut_vol_usd_24h   real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS spot_vol_usd_24h  real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS fut_spot_ratio     real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS fut_vol_pct_mcap  real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS spot_vol_pct_mcap real`,
    );
    // last_whale_index: per-token CoinGlass Whale Index (Binance futures, 4h); обновляется батчем раз в скан-цикл для OI Watch + топ prescan
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_whale_index real`,
    );
  } catch (err) {
    logger.warn({ err }, "Startup migration Part 1: ошибка (non-critical)");
  }

  // ── Part 2: Forward-accumulation tables — отдельный try/catch чтобы сбой Part 1 не блокировал ──
  try {
    // whale_event_tracking: T0/T+1h/T+4h/T+12h/T+24h/T+48h чекпоинты для событий китов HL
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS whale_event_tracking (
      id               serial PRIMARY KEY,
      event_id         text    NOT NULL,
      user_address     text    NOT NULL,
      symbol           text    NOT NULL,
      position_action  integer,
      position_value_usd real,
      entry_price      real,
      event_time       bigint  NOT NULL,
      checkpoint_label text    NOT NULL,
      checkpoint_at    timestamp NOT NULL DEFAULT now(),
      price_at_checkpoint real,
      price_change_pct    real,
      created_at       timestamp NOT NULL DEFAULT now(),
      UNIQUE (event_id, checkpoint_label)
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS whale_evt_symbol_idx ON whale_event_tracking (symbol)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS whale_evt_event_time_idx ON whale_event_tracking (event_time DESC)`,
    );

    // periodic_collection_log: лог запусков/ошибок для data-accumulation jobs
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS periodic_collection_log (
      id             serial PRIMARY KEY,
      job_name       text      NOT NULL,
      started_at     timestamp NOT NULL DEFAULT now(),
      finished_at    timestamp,
      records_written integer,
      error          text
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS periodic_log_job_idx ON periodic_collection_log (job_name, started_at DESC)`,
    );

    // cg_liq_heatmap_snapshot: снапшоты liq-кластеров каждые 4ч для top-prescan символов
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS cg_liq_heatmap_snapshot (
      id           serial PRIMARY KEY,
      symbol       text   NOT NULL,
      range        text   NOT NULL DEFAULT '3d',
      snapshot_at  timestamp NOT NULL,
      cluster_price real  NOT NULL,
      liq_usd      real   NOT NULL,
      side         text   NOT NULL,
      created_at   timestamp NOT NULL DEFAULT now(),
      UNIQUE (symbol, range, snapshot_at, cluster_price)
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS cg_heatmap_snap_symbol_idx ON cg_liq_heatmap_snapshot (symbol, snapshot_at DESC)`,
    );
    // Идемпотентно добавляем created_at если таблица была создана старой схемой (без неё)
    await db.execute(
      drizzleSql`ALTER TABLE cg_liq_heatmap_snapshot ADD COLUMN IF NOT EXISTS created_at timestamp DEFAULT now()`,
    );
    // TTL: хранить снапшоты 30 дней
    await db.execute(
      drizzleSql`DELETE FROM cg_liq_heatmap_snapshot WHERE created_at < NOW() - INTERVAL '30 days'`,
    );

    // cg_netflow_snapshot: снапшоты taker-netflow каждые 15 мин для 100 CoinGlass символов
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS cg_netflow_snapshot (
      id           serial PRIMARY KEY,
      symbol       text      NOT NULL,
      snapshot_at  timestamp NOT NULL,
      buy_1h       real, sell_1h  real, net_1h  real, net_pct_1h real,
      buy_4h       real, sell_4h  real, net_4h  real, net_pct_4h real,
      buy_24h      real, sell_24h real, net_24h real,
      market_cap_usd real,
      created_at   timestamp NOT NULL DEFAULT now(),
      UNIQUE (symbol, snapshot_at)
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS cg_netflow_snap_symbol_idx ON cg_netflow_snapshot (symbol, snapshot_at DESC)`,
    );
    // TTL: хранить 7 дней
    await db.execute(
      drizzleSql`DELETE FROM cg_netflow_snapshot WHERE created_at < NOW() - INTERVAL '7 days'`,
    );

    // tracked_signals — liq-cascade триггерные параметры (2026-07-22)
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_liq_long1h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_liq_long24h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_liq_ratio real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_liq_reason text`,
    );

    // tracked_signals — BingX orderbook snapshot при выстреле сигнала (2026-07-22)
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_ob_bids real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_ob_asks real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_ob_ratio real`,
    );

    // tracked_signals — OI 24h, 1h цена и futures taker при выстреле (универсально для всех паттернов)
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_oi_24h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_price_1h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS entry_fut_taker_net_buy real`,
    );

    // prescan_tracker — last_price_24h column (2026-07-23)
    // Персистируем lastPrice24h чтобы после рестарта не показывать firstPrice24h (значение при первом появлении).
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_price_24h real`,
    );

    // prescan_tracker — taker / CVD verdict columns (2026-07-23)
    // Персистируем futures taker netBuyPct, spot taker и CVD verdicts чтобы после рестарта
    // UI prescan-таблица и гейты сканера не показывали "—" (null) до первого скана (~10мин).
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_net_buy_pct real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_spot_taker_net_buy real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_spot_taker_dominance text`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_cvd_30m boolean`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_cvd_1h boolean`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_tracker ADD COLUMN IF NOT EXISTS last_cvd_4h boolean`,
    );

    // overheat_log — новые аналитические колонки для ретроанализа (2026-07-23)
    await db.execute(
      drizzleSql`ALTER TABLE overheat_log ADD COLUMN IF NOT EXISTS entry_vol_24h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE overheat_log ADD COLUMN IF NOT EXISTS first_seen_at timestamp`,
    );
    // retro = строка создана startup-бэкфилом, а не реальным logOverheatedTokens (2026-07-27)
    await db.execute(
      drizzleSql`ALTER TABLE overheat_log ADD COLUMN IF NOT EXISTS retro boolean NOT NULL DEFAULT false`,
    );

    // overheat_log — layers column type fix: text → text[] (2026-07-22)
    // Drizzle-схема определяет layers как .array(), но таблица была создана с type=text →
    // INSERT с array-значением падал с type mismatch, dbWriteBestEffort глотал ошибку → таблица пустая.
    await db.execute(drizzleSql`
      DO $$ BEGIN
        IF (SELECT data_type FROM information_schema.columns
            WHERE table_name = 'overheat_log' AND column_name = 'layers') = 'text' THEN
          ALTER TABLE overheat_log ALTER COLUMN layers TYPE text[] USING ARRAY[]::text[];
        END IF;
      END $$
    `);

    // growth_leader_log v3 — новые колонки (retro-v2 batch, inter-cycle deltas, CG coverage flag).
    // Добавляем идемпотентно, т.к. часть таблиц уже существовала без них.
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS prev_oi_30m real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS prev_oi_4h real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS spot_cvd_4h boolean`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS spot_taker_net_buy_pct real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS prev_spot_vol_mult real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE growth_leader_log ADD COLUMN IF NOT EXISTS cg_oi_available boolean`,
    );

    // Обновляем порог OI с 5% → 8% для сокращения отмен по слабым сигналам
    const updated = await db
      .update(settingsTable)
      .set({ oiChangePercent: 8 })
      .where(lt(settingsTable.oiChangePercent, 8))
      .returning({ oiChangePercent: settingsTable.oiChangePercent });
    if (updated.length > 0)
      logger.info(
        { newThreshold: 8 },
        "Startup migration: oiChangePercent обновлён до 8%",
      );

    // Снапшоты цены для overheat_log — обновляются каждый скан-цикл
    await db.execute(
      drizzleSql`ALTER TABLE overheat_log ADD COLUMN IF NOT EXISTS snapshot_price real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE overheat_log ADD COLUMN IF NOT EXISTS snapshot_at timestamp`,
    );

    // Одноразовая чистка «призраков» из overheat_log: строки без prescan-данных
    // (токены, которых не было в prescanTracker в момент логирования — напр. новые листинги).
    // Идемпотентно: повторный запуск no-op (строк с такой комбинацией NULL уже нет).
    await db.execute(drizzleSql`
      DELETE FROM overheat_log
      WHERE entry_price IS NULL
        AND entry_price_24h IS NULL
        AND cycle_count IS NULL
    `);

    // prescan_history — новые колонки для полного snapshot всех scored токенов
    await db.execute(
      drizzleSql`ALTER TABLE prescan_history ADD COLUMN IF NOT EXISTS net_buy_pct real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_history ADD COLUMN IF NOT EXISTS spot_taker_net_buy real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_history ADD COLUMN IF NOT EXISTS oi_accel_30m real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE prescan_history ADD COLUMN IF NOT EXISTS fut_spot_ratio real`,
    );

    // scan_reject_log — индексы для быстрых аналитических запросов (2026-07-27)
    // Таблица накопила 114k+ строк без индекса на (pattern, cycle_at) →
    // WHERE pattern IN (...) AND cycle_at > NOW()-'14 days' завершался ROLLBACK.
    // CONCURRENTLY не блокирует INSERT во время построения (важно для live-сервера).
    await db.execute(
      drizzleSql`CREATE INDEX CONCURRENTLY IF NOT EXISTS scan_reject_log_pattern_cycle_idx ON scan_reject_log (pattern, cycle_at DESC)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX CONCURRENTLY IF NOT EXISTS scan_reject_log_cycle_desc_idx ON scan_reject_log (cycle_at DESC)`,
    );
    // Удаляем дублирующий plain-индекс (cycle_at ASC) из Part 1 — B-tree покрывает оба направления,
    // DESC-индекс выше полностью заменяет его. Идемпотентно: IF EXISTS.
    await db.execute(
      drizzleSql`DROP INDEX CONCURRENTLY IF EXISTS scan_reject_log_cycle_idx`,
    );

    // Whale Alert post-exit price tracking — аудит качества сигналов (2026-07-27)
    await db.execute(
      drizzleSql`ALTER TABLE whale_alert_pool ADD COLUMN IF NOT EXISTS price_72h_pct real`,
    );
    await db.execute(
      drizzleSql`ALTER TABLE tracked_signals ADD COLUMN IF NOT EXISTS price_72h_after_exit_pct real`,
    );

    // TA Scanner cache — персистируем мульти-TF TA данные между деплоями (2026-07-28)
    // Одна строка (id=1, PRIMARY KEY). Обновляется каждые 5 мин.
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS ta_scanner_cache (
      id         integer     PRIMARY KEY DEFAULT 1,
      entries    jsonb       NOT NULL,
      updated_at timestamptz NOT NULL DEFAULT now()
    )`);
  } catch (err) {
    logger.warn(
      { err },
      "Startup migration Part 2 (accum tables): ошибка (non-critical)",
    );
  }

  // ── Part 3: inflow_outflow_l14_pool + candidate_growth_tracking ──
  try {
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS inflow_outflow_l14_pool (
      id                     serial PRIMARY KEY,
      symbol                 text NOT NULL,
      coin_symbol            text NOT NULL,
      status                 text NOT NULL DEFAULT 'watching',
      detected_at            timestamp NOT NULL DEFAULT now(),
      expires_at             timestamp NOT NULL,
      entry_price            real,
      tx_count               integer DEFAULT 0,
      total_outflow_usd      double precision,
      exchange_name          text,
      transfer_type          text DEFAULT 'outflow',
      balance_change_7d_pct  real,
      matched_pattern        text
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS inflow_outflow_l14_symbol_status_idx ON inflow_outflow_l14_pool (symbol, status)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS inflow_outflow_l14_detected_at_idx  ON inflow_outflow_l14_pool (detected_at)`,
    );

    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS candidate_growth_tracking (
      id                   serial PRIMARY KEY,
      symbol               text NOT NULL,
      detection_source     text NOT NULL,
      entry_price          real,
      entry_timestamp      timestamp NOT NULL DEFAULT now(),
      growth_from_entry_pct real,
      matched_pattern      text,
      status               text NOT NULL DEFAULT 'watching',
      source_table_id      integer,
      updated_at           timestamp NOT NULL DEFAULT now()
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS candidate_growth_tracking_symbol_source_idx ON candidate_growth_tracking (symbol, detection_source)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS candidate_growth_tracking_status_idx       ON candidate_growth_tracking (status)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS candidate_growth_tracking_entry_ts_idx     ON candidate_growth_tracking (entry_timestamp)`,
    );
    await db.execute(
      drizzleSql`CREATE UNIQUE INDEX IF NOT EXISTS candidate_growth_tracking_symbol_source_uq ON candidate_growth_tracking (symbol, detection_source) WHERE status = 'watching'`,
    );
    // TTL: чистим старые записи (60 дней)
    await db.execute(
      drizzleSql`DELETE FROM inflow_outflow_l14_pool     WHERE detected_at     < NOW() - INTERVAL '60 days'`,
    );
    await db.execute(
      drizzleSql`DELETE FROM candidate_growth_tracking   WHERE entry_timestamp < NOW() - INTERVAL '60 days'`,
    );
  } catch (err) {
    logger.warn({ err }, "Startup migration Part 3: ошибка (non-critical)");
  }

  // ── Part 4: Restore ошибочно закрытых liquidation_cascade сигналов ────────
  // 2026-07-21: liquidation_cascade был ошибочно добавлен в DEAD_PATTERN_KEYS,
  // из-за чего сигналы WLD/ONDO/BEAT закрылись без уведомления при рестарте.
  // Восстанавливаем все liq_cascade сигналы с cancel_reason='dead_pattern'.
  // Идемпотентно: после первого деплоя таких строк больше нет.
  try {
    const restored = await db
      .update(trackedSignalsTable)
      .set({
        status: "active",
        cancelReason: null,
        exitPrice: null,
        pnlPercent: null,
        closedAt: null,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(trackedSignalsTable.sentimentKey, "liquidation_cascade"),
          eq(trackedSignalsTable.status, "cancelled"),
          eq(trackedSignalsTable.cancelReason, "dead_pattern"),
        ),
      )
      .returning({
        id: trackedSignalsTable.id,
        symbol: trackedSignalsTable.symbol,
      });
    if (restored.length > 0) {
      logger.info(
        {
          count: restored.length,
          symbols: restored.map((r) => r.symbol).join(", "),
        },
        "🔧 Восстановлены ошибочно закрытые liquidation_cascade сигналы",
      );
    }
  } catch (err) {
    logger.warn(
      { err },
      "Startup Part 4 (liq_cascade restore): ошибка (non-critical)",
    );
  }

  // ── Part 5: overheat_log — токены вылетевшие из прескана из-за перегрева ──
  try {
    await db.execute(drizzleSql`CREATE TABLE IF NOT EXISTS overheat_log (
      id              serial PRIMARY KEY,
      symbol          text NOT NULL,
      kicked_at       timestamp NOT NULL DEFAULT now(),
      price_24h       real NOT NULL,
      price           real,
      entry_price     real,
      entry_price_24h real,
      entry_oi_30m    real,
      entry_oi_1h     real,
      entry_oi_4h     real,
      cycle_count     integer,
      layers          text[],
      matched_pattern text
    )`);
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS overheat_log_kicked_at_idx ON overheat_log (kicked_at)`,
    );
    await db.execute(
      drizzleSql`CREATE INDEX IF NOT EXISTS overheat_log_symbol_idx ON overheat_log (symbol)`,
    );
    // TTL: данные хранятся постоянно — удаление отключено для ретроанализа
  } catch (err) {
    logger.warn(
      { err },
      "Startup migration Part 5 (overheat_log): ошибка (non-critical)",
    );
  }

  // ── Part 6: Backfill market_cap_usd для сигналов с NULL (идемпотентно) ──────
  // tracked_signals.market_cap_usd = NULL для старых сигналов (поле добавлено позже создания).
  // market_cap_cache хранит mcap за 7 дней (base-символ без -USDT, напр. "BTC").
  // JOIN: ts.symbol = mcc.symbol || '-USDT'. Идемпотентно: WHERE market_cap_usd IS NULL.
  try {
    const mcapResult = await db.execute(drizzleSql`
      UPDATE tracked_signals ts
      SET market_cap_usd = mcc.mcap_usd
      FROM market_cap_cache mcc
      WHERE ts.market_cap_usd IS NULL
        AND ts.symbol = mcc.symbol || '-USDT'
    `);
    const updated = (mcapResult as any).rowCount ?? 0;
    if (updated > 0)
      logger.info(
        { updated },
        "Startup Part 6: backfilled market_cap_usd для старых сигналов",
      );
  } catch (err) {
    logger.warn(
      { err },
      "Startup Part 6 (mcap backfill): ошибка (non-critical)",
    );
  }

  // ── Part 7: Бэкфилл overheat_log из prescan_tracker (одноразовый) ──────────
  // После фикса layers text→text[] таблица overheat_log пустая — новые строки
  // начнут появляться только со следующего скана. Бэкфилл создаёт synthetic-записи
  // для всех токенов в prescan_tracker с last_price_24h ≥ 40%.
  // kicked_at = first_seen_at (unix ms → timestamp) — показывает когда токен ВОШЁЛ в prescan,
  // а не момент деплоя (иначе все строки имеют одинаковую дату).
  // Идемпотентно: NOT EXISTS guard — обе ветки: (1) уже логировался за 4ч (реальный logOverheatedTokens),
  // (2) уже есть запись вблизи first_seen_at ±6ч (повторный рестарт до первого скана).
  try {
    const backfillResult = await db.execute(drizzleSql`
      INSERT INTO overheat_log
        (symbol, kicked_at, price_24h, price, entry_price, entry_price_24h,
         entry_oi_30m, entry_oi_1h, entry_oi_4h, cycle_count, layers, matched_pattern, retro)
      SELECT
        pt.symbol,
        TO_TIMESTAMP(pt.first_seen_at / 1000.0)                     AS kicked_at,
        -- price_24h: наибольшее из 24h-изменения и движения от точки входа в prescan
        GREATEST(
          COALESCE(pt.last_price_24h, pt.first_price_24h, 0),
          CASE
            WHEN pt.last_price IS NOT NULL
             AND pt.first_price IS NOT NULL
             AND pt.first_price > 0
            THEN (pt.last_price - pt.first_price) / pt.first_price * 100
            ELSE 0
          END
        )                                                            AS price_24h,
        pt.last_price                                                AS price,
        pt.first_price                                               AS entry_price,
        pt.first_price_24h                                           AS entry_price_24h,
        pt.first_oi_30m                                              AS entry_oi_30m,
        pt.first_oi_1h                                               AS entry_oi_1h,
        pt.first_oi_4h                                               AS entry_oi_4h,
        pt.cycle_count,
        COALESCE(pt.layers, ARRAY[]::text[])                         AS layers,
        NULL                                                         AS matched_pattern,
        true                                                         AS retro
      FROM prescan_tracker pt
      WHERE (
        -- Ветка 1: классический overheat через 24h-изменение
        COALESCE(pt.last_price_24h, pt.first_price_24h) >= 40
        -- Ветка 2: priceMovePct >= 40% — токен вырос от точки входа в prescan
        OR (
          pt.last_price  IS NOT NULL
          AND pt.first_price IS NOT NULL
          AND pt.first_price > 0
          AND (pt.last_price - pt.first_price) / pt.first_price * 100 >= 40
        )
      )
      AND NOT EXISTS (
        SELECT 1 FROM overheat_log ol
        WHERE ol.symbol = pt.symbol
          AND (
            -- Ветка 1: уже есть реальный kicked (logOverheatedTokens) за последние 4ч
            ol.kicked_at > NOW() - INTERVAL '4 hours'
            -- Ветка 2: уже есть backfill-запись вблизи first_seen_at (повторный рестарт до первого скана)
            OR ol.kicked_at BETWEEN TO_TIMESTAMP(pt.first_seen_at / 1000.0) - INTERVAL '6 hours'
                                AND TO_TIMESTAMP(pt.first_seen_at / 1000.0) + INTERVAL '6 hours'
          )
      )
    `);
    const inserted = (backfillResult as any).rowCount ?? 0;
    if (inserted > 0) {
      logger.info(
        { inserted },
        "Startup Part 7: бэкфилл overheat_log — synthetic-записи созданы для перегретых prescan-токенов",
      );
    }
  } catch (err) {
    logger.warn(
      { err },
      "Startup Part 7 (overheat_log backfill): ошибка (non-critical)",
    );
  }

  // ── Seed known subscribers (идемпотентно через ON CONFLICT) ──────────────
  try {
    const knownSubs = [
      { chatId: 7818695412, username: "darshakl", firstName: "Darya" },
      { chatId: 6964248629, username: "DaryaKach", firstName: "Darya" },
    ];
    for (const sub of knownSubs) {
      await db
        .insert(subscribersTable)
        .values({
          chatId: sub.chatId,
          username: sub.username,
          firstName: sub.firstName,
          lastName: null,
          active: true,
        })
        .onConflictDoUpdate({
          target: subscribersTable.chatId,
          set: {
            active: true,
            username: sub.username,
            firstName: sub.firstName,
          },
        });
    }
    logger.info(
      { count: knownSubs.length },
      "Startup seed: known subscribers activated",
    );
  } catch (err) {
    logger.warn({ err }, "Startup seed subscribers: ошибка (non-critical)");
  }
}

// ── pg Pool error handler ──────────────────────────────────────────────────────
// Neon serverless периодически рвёт idle-соединения. Без обработчика 'error'
// Node.js бросает uncaughtException и процесс может упасть.
// Pool автоматически создаёт новое соединение при следующем запросе.
pool.on("error", (err) => {
  logger.warn(
    { err: String(err) },
    "pg pool: idle client error (Neon closed connection) — pool will reconnect automatically",
  );
});

// ── Глобальная защита от падения процесса ─────────────────────────────────────
// Без этого Node.js завершает процесс при любом необработанном промисе/исключении.
process.on("unhandledRejection", (reason, promise) => {
  logger.error(
    { reason, promise: String(promise) },
    "⚠️ Unhandled promise rejection — caught, server stays alive",
  );
});

process.on("uncaughtException", (err) => {
  logger.error({ err }, "⚠️ Uncaught exception — caught, server stays alive");
});

// ── Graceful shutdown при деплое (SIGTERM от Replit) ──────────────────────────
// Останавливаем планировщик сканера, даём текущим операциям завершиться (10 сек),
// затем выходим чисто — без обрыва на середине скана или отправки Telegram.
let isShuttingDown = false;
async function gracefulShutdown(signal: string) {
  if (isShuttingDown) return;
  isShuttingDown = true;
  logger.info(
    { signal },
    "Graceful shutdown: получен сигнал, останавливаем сканер...",
  );
  try {
    await stopScanner();
  } catch {
    /* non-critical */
  }
  // Ждём 5 секунд чтобы текущие DB/Telegram операции завершились
  await new Promise((resolve) => setTimeout(resolve, 5_000));
  logger.info("Graceful shutdown: завершено, выходим");
  process.exit(0);
}

process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
process.on("SIGINT", () => gracefulShutdown("SIGINT"));

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, async (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // Webhook регистрируем ТОЛЬКО в production.
  // В dev-режиме dev-домен (.replit.dev) умирает при idle и перебивает
  // продакшн-webhook, из-за чего бот теряет все апдейты от Telegram.
  const domains = process.env.REPLIT_DOMAINS;
  if (domains && process.env.NODE_ENV !== "development") {
    const domain = domains.split(",")[0].trim();
    const webhookUrl = `https://${domain}/api/telegram/webhook`;
    const ok = await setWebhook(webhookUrl);
    if (ok) {
      logger.info({ webhookUrl }, "Telegram webhook registered");
    } else {
      logger.warn(
        "Failed to register Telegram webhook — bot subscriptions may not work",
      );
    }
    await registerBotCommands();
  } else if (process.env.NODE_ENV === "development") {
    logger.info(
      "DEV mode — webhook registration skipped (production webhook preserved)",
    );
  } else {
    logger.info("REPLIT_DOMAINS not set, skipping webhook registration");
  }

  // One-time migration: перенос позиций из dev в prod (30.05.2026)
  if (process.env.NODE_ENV !== "development") {
    runStartupMigration().catch(() => {
      /* logged inside */
    });
  }

  // В dev-режиме сканер и watcher НЕ запускаются — только production.
  // Причина: dev-инстанс подключён к тем же BingX API ключам и той же сети,
  // что и prod. Если оба экземпляра сканируют одновременно, они детектируют
  // сигналы в разное время и пишут в разные БД (dev vs prod).
  // Результат: дашборд (dev) и Telegram (prod) показывают разные позиции.
  // В dev нужно только разрабатывать код — реальный трейдинг идёт через prod.
  // MCap preloader — грузит CoinGlass/CoinGecko/CoinPaprika в память при старте,
  // обновляет каждые 6 часов. Скан loop никогда не делает HTTP для MCap самостоятельно.
  startMarketCapPreloader();

  // Греем кэш channelId — чтобы Telegram broadcast не зависел от DB при отправке сигналов
  warmChannelIdCache().catch((err) =>
    logger.warn({ err }, "warmChannelIdCache failed"),
  );

  // CG supported-coins whitelist — основа классификации BingX-exclusive vs CG-covered.
  // Загружаем при старте, обновляем каждые 12ч.
  refreshCgSupportedCoins().catch((err) =>
    logger.warn({ err }, "refreshCgSupportedCoins: первый запуск не удался"),
  );
  setInterval(
    () => {
      refreshCgSupportedCoins().catch((err) =>
        logger.warn(
          { err },
          "refreshCgSupportedCoins: ошибка планового обновления",
        ),
      );
    },
    12 * 60 * 60 * 1000,
  );

  if (process.env.NODE_ENV === "development") {
    logger.info(
      "DEV mode — scanner NOT started; watcher started (Telegram suppressed)",
    );
    // Watcher runs in dev to keep signal statuses accurate (stop_loss / profit / cancelled).
    // All Telegram sends are suppressed via sendMessage() guard in telegram.ts.
    startWatcher();
  } else {
    startScanner().catch((err) =>
      logger.error({ err }, "Failed to auto-start scanner"),
    );

    // Auto-start alpha watcher
    startWatcher();

    // Бэкфилл growth_leader_log — ОТКЛЮЧЁН (2026-07-18): запись лидеров роста остановлена.

    const restartScanner = async () => {
      await stopScanner();
      await startScanner();
    };
    startWatchdog(getLastScanAt, restartScanner, getIsScanning);

    // HL Position Tracker — мониторинг позиций китов HL после whale_alert fire (каждые 15 мин)
    const { runHlPositionTracker } =
      await import("./lib/hl-position-tracker.js");
    setTimeout(
      () => {
        runHlPositionTracker().catch((err) =>
          logger.warn({ err }, "HlPositionTracker: первый запуск не удался"),
        );
      },
      2 * 60 * 1000,
    ); // первый запуск через 2 мин (после прогрева сигналов)
    setInterval(
      () => {
        runHlPositionTracker().catch((err) =>
          logger.warn({ err }, "HlPositionTracker: ошибка цикла"),
        );
      },
      15 * 60 * 1000,
    );

    // ── Part 2: Forward-accumulation jobs ─────────────────────────────────────
    // Whale Event Checkpoint — T+1h/.../T+48h follow-up для событий китов HL
    const { runWhaleEventCheckpointJob } =
      await import("./lib/whale-event-tracking-job.js");
    setTimeout(
      () => {
        runWhaleEventCheckpointJob().catch((err) =>
          logger.warn({ err }, "WhaleEventCheckpoint: первый запуск не удался"),
        );
      },
      4 * 60 * 1000,
    ); // через 4 мин — после прогрева whale_alert_pool
    setInterval(
      () => {
        runWhaleEventCheckpointJob().catch((err) =>
          logger.warn({ err }, "WhaleEventCheckpoint: ошибка цикла"),
        );
      },
      15 * 60 * 1000,
    );

    // Heatmap Periodic — снапшоты liq-кластеров для top-prescan символов (каждые 4ч)
    const { runHeatmapPeriodicJob } =
      await import("./lib/heatmap-periodic-job.js");
    setTimeout(
      () => {
        runHeatmapPeriodicJob().catch((err) =>
          logger.warn({ err }, "HeatmapPeriodicJob: первый запуск не удался"),
        );
      },
      20 * 60 * 1000,
    ); // через 20 мин (после первого скана ~10 мин + settle)
    setInterval(
      () => {
        runHeatmapPeriodicJob().catch((err) =>
          logger.warn({ err }, "HeatmapPeriodicJob: ошибка цикла"),
        );
      },
      4 * 60 * 60 * 1000,
    );

    // Netflow Collection — taker netflow снапшот каждые 15 мин (100 CoinGlass символов)
    const { runNetflowCollectionJob } =
      await import("./lib/netflow-collection-job.js");
    setTimeout(
      () => {
        runNetflowCollectionJob().catch((err) =>
          logger.warn({ err }, "NetflowCollectionJob: первый запуск не удался"),
        );
      },
      5 * 60 * 1000,
    ); // через 5 мин
    setInterval(
      () => {
        runNetflowCollectionJob().catch((err) =>
          logger.warn({ err }, "NetflowCollectionJob: ошибка цикла"),
        );
      },
      15 * 60 * 1000,
    );

    // Spot NetFlow Cache — batch /api/spot/netflow-list каждые 5 мин
    const { startSpotNetflowRefresh } =
      await import("./lib/spot-netflow-cache.js");
    startSpotNetflowRefresh();
  }

  // Startup notification отправляется из sendBotRestartNotification() через 3 мин —
  // с контекстом открытых сигналов и DB-дедупликацией. Дублировать здесь не нужно.
});
