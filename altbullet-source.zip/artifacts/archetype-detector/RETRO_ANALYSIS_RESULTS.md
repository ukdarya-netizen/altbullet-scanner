# Ретро-анализ 774 пампов — результаты (2026-07-19)

## Методология

- **Данные**: 774 событий из `retro_pre_growth` + `growth_leader_log` (июнь-июль 2026, 204 уникальных символа)
- **Forward gain**: `(price_T-2h - price_T-4h) / price_T-4h × 100` — изменение цены за 2ч до детекта
- **WR10**: % событий с forward_gain ≥ 10% при выполнении условий паттерна
- **SL proxy**: % событий с отрицательным forward gain (приближение к rate потерь)
- **EV**: `WR10/100 × 10 - SL_proxy × SL_size`
- **Ограничение**: 2h-окно недооценивает паттерны с горизонтом 12-24h (whale_watch, trend_accumulation в OI Watch)

## Распределение метрик на T-4h (4ч до пампа)

| Метрика | P10 | P25 | P50 | P75 | P90 | % ≥ 0 |
|---|---|---|---|---|---|---|
| OI 30m % | -1.65 | -0.19 | **0.00** | 0.78 | 2.71 | 73% |
| OI 1h % | -1.84 | 0.00 | **0.00** | 1.76 | 5.24 | 77% |
| OI 4h % | -4.42 | 0.00 | **2.94** | 10.64 | 21.47 | 76% |
| vol_mult | 0.62 | 0.86 | **1.00** | 1.19 | 1.76 | 100% |
| price_24h % | -1.70 | 5.01 | **12.30** | 17.95 | 24.57 | 87% |
| price_4h % | -4.83 | -0.71 | **2.27** | 6.13 | 11.51 | 69% |

**Forward gain T-4h → T-2h**: P50=+1.9%, P90=+9.0% | gain≥10%: **8%** событий | gain<0%: **30%**

## Главный предиктор быстрого роста

Сравнение Winners (gain≥10%) vs Losers (gain<10%) на T-4h:

| Метрика | Winners P50 | Losers P50 | Δ | Вывод |
|---|---|---|---|---|
| **OI 4h %** | **15.29%** | 2.33% | **+12.96** | ← главный предиктор |
| **price_24h %** | **0.61%** | 12.94% | **-12.33** | ← анти-корреляция! |
| OI 30m % | 0.00 | 0.00 | 0.00 | не предсказывает |
| OI 1h % | 0.00 | 0.00 | 0.00 | не предсказывает |
| vol_mult | 0.89 | 1.01 | -0.12 | обратная зависимость |

**Вывод**: только OI4h ≥ 15% + низкий p24h (≈0-5%) = профиль быстрого пампа. OI30m, OI1h, vol — нет предсказательной силы на T-4h.

## Подтверждение из CoinGlass OHLCV

Динамика объёма у 16 проверенных символов (T-48h..T-4h vs T-4h..T-0h):
- ARPA: объём вырос в **77x** в последние 4ч
- 2Z: **30x**, FOGO: **13x**, KAT: **11x**
- **Вывод**: объём взрывается ОДНОВРЕМЕННО с пампом, не до него.
- `spot_vol_accumulation` требует vol≥2.5x на T-4h → **физически не работает**

## Результаты по паттернам

| Паттерн | Recall T-4h | WR10 (2h) | EV ретро | EV live | Тип входа | Решение |
|---|---|---|---|---|---|---|
| liquidation_cascade | 2.7% | **33.3%** | +1.0 | — | Direct | ✅ KEEP |
| oversold_reversal | 4.1% | **28.1%** | +1.6 | — | Direct | ✅ KEEP |
| whale_futures | 16.0% | **23.4%** | +1.3 | +0.2 (n=58) | Direct | ✅ KEEP |
| bullish_accumulation | 1.4% | 18.2% | +0.0 | — | Direct/OIW | 🔧 TUNE recall |
| whale_watch | 4.1% | 0%* | -4.0* | **+2.4 (n=34)** | OI Watch | ✅ KEEP (live data) |
| trend_accumulation | 1.8% | 7.1% | -0.7 | — | OI Watch | 🔧 redesign (OI4h) |
| flush_reversal | 5.3% | 7.3% | -2.0 | — | OI Watch | ⏸ SUSPEND |
| smart_money_divergence | 24.2% | 9.1% | -1.6 | — | Direct | 🗑 DELETE |
| liq_magnet_squeeze | 25.5% | 7.6% | -0.8 | — | Direct | ⏸ SUSPEND |
| bid_wall_absorption | 18.7% | 7.6% | -2.3 | — | OI Watch | ⏸ SUSPEND |
| oi4h_silent_accum | 31.7% | 6.9% | -1.5 | — | Direct | 🗑 DELETE |
| 4h_pullback_continuation | 28.0% | 7.4% | -1.7 | — | Direct | 🗑 DELETE |
| oi1h_breakout | 11.4% | 6.8% | -2.4 | — | Direct | 🗑 DELETE |
| flush_reversal | 5.3% | 7.3% | -2.0 | — | OI Watch | 🗑 DELETE |
| 4h_momentum | 24.0% | 5.9% | -3.0 | — | Direct | 🗑 DELETE |
| quiet_trend_rider | 23.6% | 4.4% | -2.8 | — | Direct | 🗑 DELETE |
| bingx_exclusive | 71.4% | 4.5% | -2.3 | — | Direct | 🗑 DELETE |
| spot_vol_accumulation | 3.1% | 0.0% | -2.3 | — | Direct | 🗑 DELETE |
| exchange_outflow_accum | 0.4% | 0.0% | -3.3 | — | OI Watch | 🗑 DELETE |

*whale_watch: ретро 2h-окно не применимо (паттерн для 12-24h), live data достоверна.

## Итоговые решения

### 🗑 УДАЛИТЬ (8 паттернов, data-confirmed):
1. `4h_momentum` — EV=-3.0. Срабатывает когда цена уже бежит (поздний вход)
2. `oi1h_breakout` — EV=-2.4. OI спайки совпадают с пампом, не предшествуют
3. `spot_vol_accumulation` — EV=-2.3, WR=0%. Объём растёт одновременно с ценой, не до
4. `bingx_exclusive` — EV=-2.3. 71% recall = срабатывает почти всегда (мусор)
5. `quiet_trend_rider` — EV=-2.8. Поздний сигнал
6. `smart_money_divergence` — EV=-1.6. Нет данных CG, условия слишком широкие
7. `oi4h_silent_accum` — EV=-1.5. Дублирует whale_futures без его ворот
8. `exchange_outflow_accum` — EV=-3.3, recall=0.4% (почти не срабатывает)

### ⏸ SUSPEND до live данных (3 паттерна):
9. `flush_reversal` — OI Watch, нет live данных, retro EV=-2.0
10. `4h_pullback_continuation` — EV=-1.7, нет live данных
11. `liq_magnet_squeeze` — EV=-0.8, нужны liq cluster данные
12. `bid_wall_absorption` — нужны orderbook данные (нет Professional CG плана)

### ✅ ОСТАВИТЬ (4 паттерна):
- `whale_watch` — live EV=+2.4, n=34 (лучший паттерн)
- `whale_futures` — live EV=+0.2, retro EV=+1.3
- `oversold_reversal` — retro EV=+1.6, WR10=28%
- `liquidation_cascade` — retro EV=+1.0, WR10=33%

### 🔧 ТЮНИНГ (2 паттерна):
- `bullish_accumulation` — WR=18%, нужно поднять recall (снизить порог OI1h с 2% до 1.5%)
- `trend_accumulation` — redesign: убрать OI30m, добавить OI4h≥5%, снизить цену входа

## Новая идея паттерна на основе данных

**OI4h Structural Accumulation** (замена oi4h_silent_accum):
- OI4h ≥ 8% (медиана winners = 15%, используем консервативный порог)
- price_24h < 10% (winners P50 = 0.6%, исключаем уже разогретые)
- vol_mult < 1.5x (исключаем уже бегущие токены)
- price_4h: -3%..+5% (боковое движение с накоплением OI)

Это близко к `whale_futures` но более широкие условия для earlier entry.
