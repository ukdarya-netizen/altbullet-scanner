"""
Standalone CoinGlass backfill — запускается из bash, без сервиса.
Собирает OHLCV (futures + spot, 1h, 72h) и orderbook heatmap (30m, 72h)
для всех 204 уникальных символов из retro_pre_growth.

Прогресс пишется в collect_cg.log
"""
from __future__ import annotations
import os, sys, time, logging
from datetime import datetime, timezone

sys.path.insert(0, os.path.dirname(__file__))
from pipeline import cg_client, duckdb_store

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[
        logging.FileHandler("collect_cg.log"),
        logging.StreamHandler(),
    ]
)
logger = logging.getLogger(__name__)

import psycopg2, psycopg2.extras

H_TO_MS = 3_600_000
WINDOW_H = 72      # часов до пампа
OB_INTERVAL = "1h" # orderbook: 1h снапшоты

def get_symbols_with_pump_times() -> list[tuple[str, int]]:
    """204 уникальных символа + ts последнего пампа."""
    conn = psycopg2.connect(os.environ["DATABASE_URL"],
                            cursor_factory=psycopg2.extras.RealDictCursor)
    cur = conn.cursor()
    cur.execute("""
        SELECT r.symbol,
               MAX(EXTRACT(EPOCH FROM g.logged_at)::BIGINT * 1000) AS pump_ts_ms
        FROM retro_pre_growth r
        JOIN growth_leader_log g ON g.id = r.retro_log_id
        GROUP BY r.symbol
        ORDER BY r.symbol
    """)
    rows = [(r["symbol"], int(r["pump_ts_ms"])) for r in cur.fetchall()]
    conn.close()
    return rows


def collect_ohlcv(cg_sym: str, start_ms: int, end_ms: int,
                  endpoint: str = "/api/futures/price/history",
                  exchange: str = "Binance", interval: str = "1h") -> int:
    total = 0
    cursor = start_ms
    while cursor < end_ms:
        data = cg_client.cg_get(endpoint, {
            "exchange": exchange, "symbol": cg_sym,
            "interval": interval, "start_time": cursor, "limit": 500,
        })
        time.sleep(0.25)
        if not isinstance(data, list) or not data:
            break
        rows = []
        for bar in data:
            if not isinstance(bar, dict):
                continue
            ts = bar.get("time") or bar.get("t")
            if ts is None:
                continue
            rows.append({
                "ts_ms": int(ts), "symbol": cg_sym, "exchange": exchange,
                "interval_str": interval,
                "open":   bar.get("o"),  "high":   bar.get("h"),
                "low":    bar.get("l"),  "close":  bar.get("c"),
                "volume": bar.get("v") or bar.get("vol") or bar.get("volume_usd"),
            })
        if rows:
            total += duckdb_store.upsert_ohlcv_batch(rows)
        last_ts = max(r["ts_ms"] for r in rows) if rows else end_ms
        if len(data) < 500 or last_ts >= end_ms:
            break
        cursor = last_ts + 1
    return total


def collect_orderbook(cg_sym: str, start_ms: int, end_ms: int,
                      exchange: str = "Binance", interval: str = OB_INTERVAL) -> int:
    total = 0
    cursor = start_ms
    while cursor < end_ms:
        data = cg_client.cg_get("/api/futures/orderbook/history", {
            "exchange": exchange, "symbol": cg_sym,
            "interval": interval, "start_time": cursor, "limit": 200,
        })
        time.sleep(0.25)
        if not isinstance(data, list) or not data:
            break
        rows = []
        for item in data:
            if not isinstance(item, (list, tuple)) or len(item) < 3:
                continue
            ts_sec, bids, asks = item[0], item[1], item[2]
            rows.append({
                "ts_ms": int(ts_sec) * 1000, "symbol": cg_sym,
                "exchange": exchange, "interval_str": interval,
                "bids": bids, "asks": asks,
            })
        if rows:
            total += duckdb_store.upsert_orderbook_batch(rows)
        last_ts = max(r["ts_ms"] for r in rows) if rows else end_ms
        if len(data) < 200 or last_ts >= end_ms:
            break
        cursor = last_ts + 1
    return total


def main():
    symbols = get_symbols_with_pump_times()
    logger.info("Начинаем сбор: %d символов", len(symbols))

    done = 0
    errors = 0
    already = 0
    t0 = time.time()

    conn = duckdb_store.get_conn()

    for sym, pump_ts_ms in symbols:
        cg_sym = cg_client.to_cg_symbol(sym)
        start_ms = pump_ts_ms - WINDOW_H * H_TO_MS
        end_ms   = pump_ts_ms

        # Проверяем — уже собрано?
        existing = conn.execute(
            "SELECT COUNT(*) FROM ohlcv WHERE symbol=? AND ts_ms BETWEEN ? AND ?",
            (cg_sym, start_ms, end_ms)
        ).fetchone()[0]

        if existing >= 48:  # минимум 48 свечей из 72
            already += 1
            logger.info("[%d/%d] %s — пропуск (уже %d свечей)", done+1, len(symbols), sym, existing)
            done += 1
            continue

        try:
            n_ohlcv = collect_ohlcv(cg_sym, start_ms, end_ms,
                                     endpoint="/api/futures/price/history")
            n_ob    = collect_orderbook(cg_sym, start_ms, end_ms)
            elapsed = round(time.time() - t0)
            remaining = len(symbols) - done - 1
            eta = round(elapsed / (done + 1) * remaining) if done > 0 else "?"
            logger.info(
                "[%d/%d] %s — ohlcv=%d ob=%d  |  elapsed=%ds eta=%ss",
                done+1, len(symbols), sym, n_ohlcv, n_ob, elapsed, eta
            )
        except Exception as exc:
            errors += 1
            logger.error("[%d/%d] %s — ОШИБКА: %s", done+1, len(symbols), sym, exc)

        done += 1

    total_rows = conn.execute("SELECT COUNT(*) FROM ohlcv").fetchone()[0]
    ob_rows    = conn.execute("SELECT COUNT(*) FROM orderbook_heatmap").fetchone()[0]

    logger.info(
        "Сбор завершён: done=%d errors=%d already=%d | ohlcv_total=%d ob_total=%d",
        done, errors, already, total_rows, ob_rows
    )


if __name__ == "__main__":
    main()
