#!/usr/bin/env python3
import sys, os, logging
os.chdir('/home/runner/workspace/artifacts/archetype-detector')
sys.path.insert(0, '.')

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(levelname)s %(name)s — %(message)s',
    handlers=[logging.FileHandler('/tmp/cg_backfill.log'), logging.StreamHandler()]
)

from pipeline.collector import run_backfill

def on_progress(done, total, r):
    sym   = r.get('symbol', '?')
    skip  = r.get('skipped', False)
    err   = r.get('error', '')
    ohlcv = r.get('ohlcv_rows', 0)
    ob    = r.get('ob_rows', 0)
    lo    = r.get('lo_rows', 0)
    status = 'SKIP' if skip else ('ERR:' + str(err)[:60] if err else 'OK')
    print(f'[{done}/{total}] {sym} {status} ohlcv={ohlcv} ob={ob} lo={lo}', flush=True)

print("Starting CoinGlass backfill for 204 symbols...", flush=True)
result = run_backfill(min_price24h=0, pg_limit=800, window_h=72, on_progress=on_progress)
print('DONE:', result, flush=True)
