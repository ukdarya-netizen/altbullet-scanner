"""
Collector — бэкфилл исторических данных CoinGlass для «пампов».

Алгоритм:
  1. Читает список pump_events из PostgreSQL (growth_leader_log, price_24h >= порога).
  2. Для каждого события собирает 72h OHLCV (1h свечи) до момента пампа с Binance.
  3. Собирает снапшоты ордербука (30m, до 96 свечей = 48h).
  4. Собирает крупные лимитные ордера (history).
  5. Всё сохраняет в DuckDB через duckdb_store.

Параметры:
  MIN_PRICE24H  — минимальный pump_24h% для отбора событий (по умолчанию 20).
  WINDOW_H      — окно сбора до пампа (по умолчанию 72 часа).
  EXCHANGE      — биржа для CoinGlass (по умолчанию Binance).
  BATCH_SIZE    — параллельность (символов за раз).

Примечания:
  • Символы BingX "BTC-USDT" конвертируются в "BTCUSDT" для CoinGlass.
  • Если CoinGlass не покрывает символ (BingX-exclusive) — пропускаем, логируем.
  • Идемпотентно: повторный запуск не дублирует строки (INSERT OR REPLACE).
"""
from __future__ import annotations

import logging
import os
import time
from datetime import datetime, timezone
from typing import Any

import psycopg2
import psycopg2.extras

from . import cg_client, duckdb_store

logger = logging.getLogger(__name__)

MIN_PRICE24H = 20.0
WINDOW_H     = 72
EXCHANGE     = "Binance"
OHLCV_INTERVAL   = "1h"
OB_INTERVAL      = "30m"
CG_DELAY_MS      = 300   # мс между запросами одного символа
BATCH_DELAY_MS   = 1200  # мс между батчами символов

H_TO_MS = 3_600_000
MIN_TO_MS = 60_000


# ── PostgreSQL → pump_events ──────────────────────────────────────────────────

def load_pump_events_from_pg(min_price24h: float = MIN_PRICE24H,
                              limit: int = 500) -> list[dict]:
    """
    Читает из PostgreSQL уникальные pump-события.

    Источник: retro_pre_growth JOIN growth_leader_log.
    retro_pre_growth содержит 774 событий / 204 уникальных символа — намного
    богаче чем growth_leader_log (14 строк / 7 символов).

    Возвращает список dict с полями для duckdb_store.upsert_pump_event.
    """
    dsn = os.environ.get("DATABASE_URL")
    if not dsn:
        logger.error("DATABASE_URL не задан")
        return []

    try:
        conn = psycopg2.connect(dsn, cursor_factory=psycopg2.extras.RealDictCursor)
    except Exception as exc:
        logger.error("load_pump_events_from_pg: ошибка подключения к PostgreSQL: %s", exc)
        return []

    try:
        with conn.cursor() as cur:
            # Берём лучший снимок по каждому уникальному (retro_log_id, symbol)
            # hours_before=4 — самый близкий к пику с достаточным горизонтом
            cur.execute("""
                SELECT DISTINCT ON (g.id)
                    g.id                                             AS pg_id,
                    r.symbol,
                    EXTRACT(EPOCH FROM g.logged_at)::BIGINT * 1000  AS pump_ts_ms,
                    r.price_24h                                      AS price_24h,
                    r.price_1h,
                    r.oi_30m,
                    r.oi_1h,
                    r.oi_4h,
                    r.vol_mult,
                    r.oi_prev_30m,
                    r.cvd_1h,
                    r.cvd_30m,
                    r.price_4h,
                    r.price_24h                                     AS pre_price_24h,
                    r.funding
                FROM retro_pre_growth r
                JOIN growth_leader_log g ON g.id = r.retro_log_id
                ORDER BY g.id, r.hours_before
                LIMIT %s
            """, (limit,))
            rows = cur.fetchall()
    except Exception as exc:
        logger.error("load_pump_events_from_pg: SQL-ошибка: %s", exc)
        conn.close()
        return []

    conn.close()

    events = []
    for r in rows:
        events.append({
            "pg_id":          r["pg_id"],
            "symbol":         r["symbol"],
            "pump_ts_ms":     int(r["pump_ts_ms"]),
            "price_24h":      r["price_24h"],
            "price_1h":       r.get("price_1h"),
            "oi_30m":         r.get("oi_30m"),
            "oi_1h":          r.get("oi_1h"),
            "vol_mult":       r.get("vol_mult"),
            "spot_vol_mult":  None,
            "cycle_count":    None,
            "layers":         [],
            "entry_price_24h": r.get("pre_price_24h"),
        })

    logger.info("load_pump_events_from_pg: загружено %d событий (price_24h >= %.0f%%)",
                len(events), min_price24h)
    return events


# ── OHLCV сбор ────────────────────────────────────────────────────────────────

def _parse_ohlcv_response(data: Any, cg_symbol: str, exchange: str,
                          interval: str) -> list[dict]:
    """
    CoinGlass price/history response:
      data = [{time: ms, o, h, l, c, v?}, ...]
    """
    if not isinstance(data, list):
        return []
    rows = []
    for bar in data:
        if not isinstance(bar, dict):
            continue
        ts = bar.get("time") or bar.get("t")
        if ts is None:
            continue
        rows.append({
            "ts_ms":       int(ts),
            "symbol":      cg_symbol,
            "exchange":    exchange,
            "interval_str": interval,
            "open":        bar.get("o"),
            "high":        bar.get("h"),
            "low":         bar.get("l"),
            "close":       bar.get("c"),
            "volume":      bar.get("v") or bar.get("vol"),
        })
    return rows


def collect_ohlcv(cg_symbol: str, start_ms: int, end_ms: int,
                  exchange: str = EXCHANGE,
                  interval: str = OHLCV_INTERVAL) -> int:
    """
    Итеративно собирает OHLCV-свечи за период [start_ms, end_ms].
    Возвращает количество вставленных строк.
    """
    total = 0
    cursor = start_ms
    max_limit = 500

    while cursor < end_ms:
        data = cg_client.cg_get("/api/futures/price/history", {
            "exchange":   exchange,
            "symbol":     cg_symbol,
            "interval":   interval,
            "start_time": cursor,
            "limit":      max_limit,
        })
        time.sleep(CG_DELAY_MS / 1000)

        if not data:
            break

        rows = _parse_ohlcv_response(data, cg_symbol, exchange, interval)
        if not rows:
            break

        inserted = duckdb_store.upsert_ohlcv_batch(rows)
        total += inserted

        # Следующая страница: берём ts последней свечи + 1 свечу
        last_ts = max(r["ts_ms"] for r in rows)
        if len(rows) < max_limit or last_ts >= end_ms:
            break

        cursor = last_ts + 1

    return total


# ── Orderbook heatmap ─────────────────────────────────────────────────────────

def _parse_orderbook_response(data: Any, cg_symbol: str, exchange: str,
                               interval: str) -> list[dict]:
    """
    CoinGlass orderbook/history response:
      data[i] = [unix_sec, [[price, qty], ...bids], [[price, qty], ...asks]]
    """
    if not isinstance(data, list):
        return []
    rows = []
    for item in data:
        if not isinstance(item, (list, tuple)) or len(item) < 3:
            continue
        ts_sec, bids, asks = item[0], item[1], item[2]
        rows.append({
            "ts_ms":       int(ts_sec) * 1000,
            "symbol":      cg_symbol,
            "exchange":    exchange,
            "interval_str": interval,
            "bids":        bids,
            "asks":        asks,
        })
    return rows


def collect_orderbook(cg_symbol: str, start_ms: int, end_ms: int,
                      exchange: str = EXCHANGE,
                      interval: str = OB_INTERVAL) -> int:
    """
    Собирает снапшоты orderbook heatmap.
    CoinGlass поддерживает только Binance; для 30m — до 150 дней истории.
    """
    total = 0
    cursor = start_ms
    max_limit = 200

    while cursor < end_ms:
        # start_time в сек (CG ожидает ms для price/history, но ob/history нужно уточнить)
        data = cg_client.cg_get("/api/futures/orderbook/history", {
            "exchange":   exchange,
            "symbol":     cg_symbol,
            "interval":   interval,
            "start_time": cursor,
            "limit":      max_limit,
        })
        time.sleep(CG_DELAY_MS / 1000)

        if not data:
            break

        rows = _parse_orderbook_response(data, cg_symbol, exchange, interval)
        if not rows:
            break

        inserted = duckdb_store.upsert_orderbook_batch(rows)
        total += inserted

        last_ts = max(r["ts_ms"] for r in rows)
        if len(rows) < max_limit or last_ts >= end_ms:
            break
        cursor = last_ts + 1

    return total


# ── Large limit orders ────────────────────────────────────────────────────────

def collect_large_orders(cg_symbol: str,
                         exchange: str = EXCHANGE) -> int:
    """
    Собирает историю крупных лимитных ордеров (один запрос, история за ~30 дней).
    order_state: 1=active, 2=filled, 3+=cancelled.
    """
    data = cg_client.cg_get("/api/futures/orderbook/large-limit-order/history", {
        "exchange": exchange,
        "symbol":   cg_symbol,
    })
    time.sleep(CG_DELAY_MS / 1000)

    if not isinstance(data, list):
        return 0

    collected_ms = int(time.time() * 1000)
    rows = []
    for item in data:
        if not isinstance(item, dict):
            continue
        rows.append({
            "symbol":      cg_symbol,
            "exchange":    exchange,
            "collected_ms": collected_ms,
            "limit_price": item.get("limit_price"),
            "usd_value":   item.get("current_usd_value"),
            "order_state": item.get("order_state"),
            "order_side":  item.get("order_side"),
        })

    if rows:
        duckdb_store.insert_large_orders_batch(rows)
    return len(rows)


# ── Основной бэкфилл ──────────────────────────────────────────────────────────

def backfill_pump_event(evt: dict, window_h: int = WINDOW_H) -> dict:
    """
    Бэкфилл для одного pump_event.
    Возвращает словарь со статистикой.
    """
    symbol     = evt["symbol"]
    pump_ts_ms = evt["pump_ts_ms"]
    cg_symbol  = cg_client.to_cg_symbol(symbol)
    start_ms   = pump_ts_ms - window_h * H_TO_MS
    end_ms     = pump_ts_ms

    # Сохраняем событие в DuckDB
    duckdb_store.upsert_pump_event(evt)

    ohlcv_n = collect_ohlcv(cg_symbol, start_ms, end_ms)
    time.sleep(BATCH_DELAY_MS / 1000)

    ob_n = collect_orderbook(cg_symbol, start_ms, end_ms)
    time.sleep(BATCH_DELAY_MS / 1000)

    lo_n = collect_large_orders(cg_symbol)
    time.sleep(BATCH_DELAY_MS / 1000)

    result = {
        "symbol":     symbol,
        "cg_symbol":  cg_symbol,
        "pump_ts":    datetime.fromtimestamp(pump_ts_ms / 1000, tz=timezone.utc).isoformat(),
        "ohlcv_rows": ohlcv_n,
        "ob_rows":    ob_n,
        "lo_rows":    lo_n,
    }
    logger.info("backfill_pump_event %s: ohlcv=%d ob=%d lo=%d",
                symbol, ohlcv_n, ob_n, lo_n)
    return result


def run_backfill(
    min_price24h: float = MIN_PRICE24H,
    pg_limit: int = 300,
    window_h: int = WINDOW_H,
    on_progress=None,
) -> dict:
    """
    Главная точка входа: читает события из PostgreSQL и бэкфиллит DuckDB.
    on_progress(done, total, result_dict) — необязательный callback.

    Возвращает итоговую статистику.
    """
    events = load_pump_events_from_pg(min_price24h=min_price24h, limit=pg_limit)
    if not events:
        return {"status": "no_events", "events": 0}

    total      = len(events)
    done       = 0
    errors     = 0
    skipped    = 0
    ohlcv_sum  = 0
    ob_sum     = 0
    lo_sum     = 0
    processed_symbols: set[str] = set()

    for evt in events:
        symbol = evt["symbol"]
        # Дедупликация: не запускаем несколько раз для одного символа
        if symbol in processed_symbols:
            skipped += 1
            done += 1
            if on_progress:
                on_progress(done, total, {"symbol": symbol, "skipped": True})
            continue
        processed_symbols.add(symbol)

        try:
            r = backfill_pump_event(evt, window_h=window_h)
            ohlcv_sum += r.get("ohlcv_rows", 0)
            ob_sum    += r.get("ob_rows", 0)
            lo_sum    += r.get("lo_rows", 0)
        except Exception as exc:
            errors += 1
            logger.error("run_backfill %s: ошибка: %s", symbol, exc)
            r = {"symbol": symbol, "error": str(exc)}

        done += 1
        if on_progress:
            on_progress(done, total, r)

    return {
        "status":          "done",
        "events_total":    total,
        "symbols_unique":  len(processed_symbols),
        "skipped":         skipped,
        "errors":          errors,
        "ohlcv_rows":      ohlcv_sum,
        "orderbook_rows":  ob_sum,
        "large_order_rows": lo_sum,
    }
