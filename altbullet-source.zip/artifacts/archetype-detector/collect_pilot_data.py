"""
Pilot data collector: market_snapshots для confusion matrix.

Шаг 1: Загружаем CONFIRMED PUMP строки из retro_pre_growth (PostgreSQL).
        Эти строки уже имеют все фичи, label_win=1.

Шаг 2: Собираем FULL SCAN строки:
        - 150 случайных символов из BingX (через prescan_tracker)
        - Последние 62 дня, шаг 4 часа
        - CoinGlass OHLCV → price_1h/4h/24h, vol_mult
        - Coinalyze 30m OI → oi_30m, oi_prev_30m, oi_1h, oi_4h
        - label_win = 1 если price_24h >= 20% в [t, t+12h]

Запуск:
    python3 collect_pilot_data.py [--step 1|2|all] [--batch-size 20] [--limit 150]
"""
from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from typing import Any

import psycopg2
import psycopg2.extras

sys.path.insert(0, str(__import__("pathlib").Path(__file__).parent))

from pipeline import cg_client, coinalyze_client
from pipeline import duckdb_store as duck

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("collect_pilot")

MS_PER_DAY   = 86_400_000
DAYS_BACK    = 62          # окно сбора full_scan
SNAP_STEP_H  = 4           # шаг снапшота (часы)
SNAP_STEP_MS = SNAP_STEP_H * 3_600_000
LABEL_WIN_H  = 12          # окно метки (часы)
LABEL_WIN_MS = LABEL_WIN_H * 3_600_000
WIN_THRESHOLD = 20.0       # % рост price_24h для label_win=1
OI_BATCH     = 10          # символов за один запрос к Coinalyze

# ── Вспомогательные ──────────────────────────────────────────────────────────

def pg_conn():
    db_url = os.environ["DATABASE_URL"]
    return psycopg2.connect(db_url)


def bingx_to_cz_symbol(s: str) -> str:
    """BTC-USDT → BTCUSDT_PERP.A"""
    return coinalyze_client.to_coinalyze_symbol(s)


def bingx_to_cz_base(s: str) -> str:
    """BTC-USDT → BTCUSDT_PERP"""
    return s.replace("-USDT", "") + "USDT_PERP"


def calc_pct(a: float | None, b: float | None) -> float | None:
    if a is None or b is None or b == 0:
        return None
    return (a - b) / b * 100.0


# ── Шаг 1: confirmed_pump из retro_pre_growth ────────────────────────────────

def step1_load_confirmed_pumps() -> None:
    logger.info("=== ШАГ 1: загрузка confirmed_pump из retro_pre_growth ===")
    con = pg_conn()
    try:
        with con.cursor(cursor_factory=psycopg2.extras.DictCursor) as cur:
            cur.execute("""
                SELECT DISTINCT ON (g.id)
                    g.symbol,
                    EXTRACT(EPOCH FROM r.snapshot_time) * 1000 AS pump_ts_ms,
                    r.price_1h,
                    r.price_3h,
                    r.price_4h,
                    r.price_24h,
                    r.vol_mult,
                    r.oi_30m,
                    r.oi_prev_30m,
                    r.oi_1h,
                    r.oi_prev_1h,
                    r.oi_4h,
                    r.cvd_1h,
                    r.cvd_30m,
                    r.spot_net_pct,
                    r.funding
                FROM retro_pre_growth r
                JOIN growth_leader_log g ON g.id = r.retro_log_id
                WHERE r.hours_before = 4
                  AND r.price_24h IS NOT NULL
                ORDER BY g.id
            """)
            rows = cur.fetchall()
    finally:
        con.close()

    logger.info("Загружено %d confirmed_pump строк из PostgreSQL", len(rows))

    snapshots = []
    for row in rows:
        snap = {
            "symbol":         row["symbol"],
            "snapshot_ts_ms": int(row["pump_ts_ms"]),
            "price_1h":       float(row["price_1h"])       if row["price_1h"]       is not None else None,
            "price_3h":       float(row["price_3h"])       if row["price_3h"]       is not None else None,
            "price_4h":       float(row["price_4h"])       if row["price_4h"]       is not None else None,
            "price_24h":      float(row["price_24h"])      if row["price_24h"]      is not None else None,
            "vol_mult":       float(row["vol_mult"])        if row["vol_mult"]        is not None else None,
            "oi_30m":         float(row["oi_30m"])         if row["oi_30m"]         is not None else None,
            "oi_prev_30m":    float(row["oi_prev_30m"])    if row["oi_prev_30m"]    is not None else None,
            "oi_1h":          float(row["oi_1h"])          if row["oi_1h"]          is not None else None,
            "oi_prev_1h":     float(row["oi_prev_1h"])     if row["oi_prev_1h"]     is not None else None,
            "oi_4h":          float(row["oi_4h"])          if row["oi_4h"]          is not None else None,
            "cvd_1h":         bool(row["cvd_1h"])          if row["cvd_1h"]         is not None else None,
            "cvd_30m":        bool(row["cvd_30m"])         if row["cvd_30m"]        is not None else None,
            "spot_net_pct":   float(row["spot_net_pct"])   if row["spot_net_pct"]   is not None else None,
            "funding":        float(row["funding"])         if row["funding"]         is not None else None,
            "label_win":      1,
            "source":         "confirmed_pump",
        }
        snapshots.append(snap)

    n = duck.upsert_snapshot_batch(snapshots)
    logger.info("Сохранено %d confirmed_pump строк в market_snapshots", n)


# ── Шаг 2: full_scan ─────────────────────────────────────────────────────────

def fetch_symbols_from_prescan(limit: int = 150) -> list[str]:
    """Возвращает список BingX символов из prescan_tracker (самые активные)."""
    con = pg_conn()
    try:
        with con.cursor() as cur:
            cur.execute("""
                SELECT symbol
                FROM prescan_tracker
                WHERE cycle_count >= 3
                ORDER BY cycle_count DESC
                LIMIT %s
            """, (limit,))
            rows = cur.fetchall()
    finally:
        con.close()
    syms = [r[0] for r in rows]
    logger.info("Выбрано %d символов из prescan_tracker", len(syms))
    return syms


def download_ohlcv_for_symbol(symbol: str, from_ms: int, to_ms: int) -> list[dict]:
    """
    Скачивает 1h OHLCV для одного символа через CoinGlass.
    Возвращает отсортированный список баров [{ts_ms, open, high, low, close, volume}].
    """
    all_bars: list[dict] = []
    limit = 900
    step_ms = limit * 3_600_000  # 900 часов

    cur_to = to_ms
    while cur_to > from_ms:
        cur_from = max(from_ms, cur_to - step_ms)
        bars = cg_client.cg_get("/api/futures/price/history", {
            "exchange": "Binance",
            "symbol":   symbol,
            "interval": "1h",
            "from":     cur_from // 1000,
            "to":       cur_to   // 1000,
            "limit":    limit,
        })
        if isinstance(bars, list) and bars:
            all_bars.extend(bars)
        cur_to = cur_from
        time.sleep(0.25)

    # Нормализуем и дедупликация по времени
    seen: set[int] = set()
    result: list[dict] = []
    for b in all_bars:
        ts = None
        # CoinGlass возвращает [ts_ms, o, h, l, c, vol] или {t, o, h, l, c, v}
        if isinstance(b, list):
            if len(b) >= 6:
                ts = int(b[0])
                o, h, l, c, vol = float(b[1]), float(b[2]), float(b[3]), float(b[4]), float(b[5])
            elif len(b) >= 5:
                ts = int(b[0])
                o, h, l, c, vol = float(b[1]), float(b[2]), float(b[3]), float(b[4]), 0.0
        elif isinstance(b, dict):
            ts_raw = b.get("t") or b.get("time") or b.get("ts")
            if ts_raw is None:
                continue
            ts = int(ts_raw)
            if ts < 1e12:
                ts *= 1000  # seconds → ms
            o   = float(b.get("o") or b.get("open", 0))
            h   = float(b.get("h") or b.get("high", 0))
            l   = float(b.get("l") or b.get("low", 0))
            c   = float(b.get("c") or b.get("close", 0))
            vol = float(b.get("v") or b.get("volume") or b.get("volume_usd", 0))
        else:
            continue

        if ts is not None and ts not in seen:
            seen.add(ts)
            result.append({"ts_ms": ts, "open": o, "high": h, "low": l, "close": c, "volume": vol})

    result.sort(key=lambda x: x["ts_ms"])
    return result


def download_oi_batch(bingx_symbols: list[str], from_s: int, to_s: int) -> dict[str, list[dict]]:
    """
    Скачивает 30m OI для списка BingX символов.
    Возвращает {cz_base_symbol: [{t, c}, ...]} отсортированных по t.
    """
    cz_syms = [bingx_to_cz_symbol(s) for s in bingx_symbols]
    data = coinalyze_client.get_oi_history(cz_syms, from_s, to_s, interval="30min")
    result = {}
    for cz_base, bars in data.items():
        bars_sorted = sorted(bars, key=lambda x: x["t"])
        result[cz_base] = bars_sorted
    return result


def compute_price_features(bars: list[dict], snap_ts_ms: int) -> dict | None:
    """
    Вычисляет price_1h, price_4h, price_24h, vol_mult для снапшота snap_ts_ms.
    bars: отсортированный список 1h свечей [{ts_ms, open, high, low, close, volume}].
    """
    # Находим бар, ближайший к snap_ts_ms (closest-not-after)
    idx = None
    for i, b in enumerate(bars):
        if b["ts_ms"] <= snap_ts_ms:
            idx = i

    if idx is None or bars[idx]["close"] == 0:
        return None

    price_now = bars[idx]["close"]
    vol_now   = bars[idx]["volume"]

    def price_at(h_back: int) -> float | None:
        target = snap_ts_ms - h_back * 3_600_000
        for b in reversed(bars[:idx + 1]):
            if b["ts_ms"] <= target + 1_800_000:  # ±30m tolerance
                return b["close"] if b["close"] != 0 else None
        return None

    def avg_vol(h_window: int, h_back_start: int = 0) -> float | None:
        t_end   = snap_ts_ms - h_back_start * 3_600_000
        t_start = t_end - h_window * 3_600_000
        vols = [b["volume"] for b in bars if t_start <= b["ts_ms"] <= t_end and b["volume"] > 0]
        return sum(vols) / len(vols) if vols else None

    p1h  = price_at(1)
    p4h  = price_at(4)
    p24h = price_at(24)
    p3h  = price_at(3)

    # Средний объём за [24h-2h, 48h-2h] как baseline, сравниваем с текущим
    avg_vol_past = avg_vol(24, h_back_start=48)

    return {
        "price_1h":  calc_pct(price_now, p1h),
        "price_3h":  calc_pct(price_now, p3h),
        "price_4h":  calc_pct(price_now, p4h),
        "price_24h": calc_pct(price_now, p24h),
        "vol_mult":  vol_now / avg_vol_past if (avg_vol_past and avg_vol_past > 0 and vol_now > 0) else None,
    }


def compute_oi_features(oi_bars: list[dict], snap_ts_s: int) -> dict:
    """
    Вычисляет oi_30m, oi_prev_30m, oi_1h, oi_prev_1h, oi_4h
    из отсортированных 30m Coinalyze баров [{t, c}].
    snap_ts_s: unix seconds.
    """
    # Находим индекс ближайшего бара не позднее snap_ts_s
    idx = None
    for i, b in enumerate(oi_bars):
        if b["t"] <= snap_ts_s + 900:  # +15min tolerance
            idx = i

    def oi_at_offset(bars_back: int) -> float | None:
        """Возвращает OI в n 30m-баров назад от idx."""
        if idx is None or (idx - bars_back) < 0:
            return None
        return oi_bars[idx - bars_back]["c"]

    c0  = oi_at_offset(0)   # текущий
    c1  = oi_at_offset(1)   # -30m
    c2  = oi_at_offset(2)   # -60m
    c3  = oi_at_offset(3)   # -90m (для prev_1h)
    c8  = oi_at_offset(8)   # -4h
    c9  = oi_at_offset(9)   # -4h30m (для prev_1h смотрим на -2h)

    # prev_1h = изменение с [-2h до -1h]
    c2h = oi_at_offset(4)   # -2h
    c1h = oi_at_offset(2)   # -1h (уже есть как c2 при 30m баре)

    return {
        "oi_30m":      calc_pct(c0, c1),      # %Δ за последние 30m
        "oi_prev_30m": calc_pct(c1, c2),      # %Δ за 30m до того
        "oi_1h":       calc_pct(c0, c2),      # %Δ за последний час
        "oi_prev_1h":  calc_pct(c2, c4 := oi_at_offset(4)),  # %Δ за час до
        "oi_4h":       calc_pct(c0, c8),      # %Δ за 4 часа
    }


def compute_label(bars: list[dict], snap_ts_ms: int) -> int:
    """
    label_win = 1 если price_24h >= WIN_THRESHOLD% в любой момент t' в [snap_ts_ms, snap_ts_ms + LABEL_WIN_MS].
    Используем максимальный high в окне как proxy: (max_high - snap_close) / snap_close >= WIN_THRESHOLD.
    """
    snap_close = None
    for b in bars:
        if b["ts_ms"] <= snap_ts_ms:
            snap_close = b["close"]

    if not snap_close or snap_close == 0:
        return 0

    t_end = snap_ts_ms + LABEL_WIN_MS
    future_highs = [b["high"] for b in bars
                    if snap_ts_ms <= b["ts_ms"] <= t_end and b["high"] > 0]

    if not future_highs:
        return 0

    max_h = max(future_highs)
    pct   = (max_h - snap_close) / snap_close * 100.0
    return 1 if pct >= WIN_THRESHOLD else 0


def step2_collect_full_scan(symbols: list[str], batch_size: int = 20) -> None:
    logger.info("=== ШАГ 2: full_scan сбор %d символов ===", len(symbols))

    now_ms   = int(time.time() * 1000)
    from_ms  = now_ms - DAYS_BACK * MS_PER_DAY
    to_ms    = now_ms - 24 * 3_600_000  # не берём последние 24h (нет label)

    from_s   = from_ms // 1000
    to_s     = to_ms   // 1000

    # Генерируем временны́е точки снапшотов
    snap_points = list(range(
        (from_ms // SNAP_STEP_MS + 1) * SNAP_STEP_MS,
        to_ms,
        SNAP_STEP_MS,
    ))
    logger.info("Точек снапшотов: %d (каждые 4h за %d дней)", len(snap_points), DAYS_BACK)

    total_written = 0
    total_symbols = len(symbols)

    # Скачиваем OI батчами (Coinalyze)
    logger.info("Скачиваем OI (Coinalyze) для %d символов...", total_symbols)
    oi_map: dict[str, list[dict]] = {}  # cz_base → sorted bars

    for i in range(0, total_symbols, OI_BATCH):
        batch_syms = symbols[i:i + OI_BATCH]
        batch_data = download_oi_batch(batch_syms, from_s, to_s)
        oi_map.update(batch_data)
        done = min(i + OI_BATCH, total_symbols)
        logger.info("  OI: %d/%d символов, получено %d ответов", done, total_symbols, len(batch_data))
        time.sleep(0.5)

    logger.info("OI собран для %d/%d символов", len(oi_map), total_symbols)

    # Скачиваем OHLCV и строим снапшоты (батчами по batch_size)
    for i, symbol in enumerate(symbols):
        logger.info("[%d/%d] %s — OHLCV...", i + 1, total_symbols, symbol)
        bars = download_ohlcv_for_symbol(symbol, from_ms, to_ms + 12 * 3_600_000)

        if not bars:
            logger.warning("  %s: OHLCV пустой, пропускаем", symbol)
            continue

        cz_base   = bingx_to_cz_base(symbol)
        oi_bars   = oi_map.get(cz_base, [])

        snapshots = []
        for snap_ms in snap_points:
            price_feat = compute_price_features(bars, snap_ms)
            if price_feat is None:
                continue

            oi_feat = compute_oi_features(oi_bars, snap_ms // 1000) if oi_bars else {
                "oi_30m": None, "oi_prev_30m": None,
                "oi_1h": None, "oi_prev_1h": None, "oi_4h": None,
            }

            label = compute_label(bars, snap_ms)

            snap = {
                "symbol":         symbol,
                "snapshot_ts_ms": snap_ms,
                "source":         "full_scan",
                "label_win":      label,
                "cvd_1h":         None,
                "cvd_30m":        None,
                "spot_net_pct":   None,
                "funding":        None,
                **price_feat,
                **oi_feat,
            }
            snapshots.append(snap)

        n = duck.upsert_snapshot_batch(snapshots)
        total_written += n
        wins = sum(s["label_win"] for s in snapshots)
        logger.info("  %s: %d снапшотов, %d wins (%.1f%%), сохранено %d",
                    symbol, len(snapshots), wins,
                    100 * wins / len(snapshots) if snapshots else 0, n)

    logger.info("=== full_scan готов: итого %d строк ===", total_written)


# ── main ─────────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--step", choices=["1", "2", "all"], default="all")
    parser.add_argument("--limit", type=int, default=150, help="Кол-во символов full_scan")
    parser.add_argument("--batch-size", type=int, default=20)
    args = parser.parse_args()

    if args.step in ("1", "all"):
        step1_load_confirmed_pumps()

    if args.step in ("2", "all"):
        symbols = fetch_symbols_from_prescan(args.limit)
        if not symbols:
            logger.error("Нет символов в prescan_tracker, проверьте БД")
            sys.exit(1)
        step2_collect_full_scan(symbols, batch_size=args.batch_size)

    # Финальная статистика
    con = duck.get_conn()
    stats = con.execute("""
        SELECT source,
               COUNT(*) AS n,
               SUM(label_win) AS wins,
               ROUND(100.0 * SUM(label_win) / COUNT(*), 1) AS win_pct
        FROM market_snapshots
        GROUP BY source
    """).fetchall()
    logger.info("\n=== market_snapshots итого ===")
    for row in stats:
        logger.info("  %-20s n=%-6d wins=%-5d (%.1f%%)", *row)


if __name__ == "__main__":
    main()
