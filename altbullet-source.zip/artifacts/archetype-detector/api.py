"""
FastAPI-сервис детектора архетипов роста.

Endpoints:
  POST /classify         — классификация снэпшота
  GET  /signals/{symbol} — история сигналов по символу
  GET  /watchlist        — текущий stealth watchlist
  GET  /healthz          — healthcheck
"""
from __future__ import annotations
import logging
import os
import threading
from contextlib import asynccontextmanager
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse

from models import SnapshotInput, SignalOutput, WatchlistEntry
from orchestrator import classify_snapshot
from db import init_db, save_snapshot, save_signal, upsert_watchlist, get_signals, get_watchlist, get_previous_snapshot
from pipeline import collector, analyzer, duckdb_store

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
)
logger = logging.getLogger(__name__)


def _auto_backfill_thread():
    """Запускает бэкфилл CoinGlass в фоне если DuckDB пустая."""
    import time
    time.sleep(3)  # ждём полного старта сервиса
    try:
        conn = duckdb_store.get_conn()
        n = conn.execute("SELECT COUNT(*) FROM pump_events").fetchone()[0]
        if n < 100:
            logger.info("DuckDB содержит %d pump_events (< 100) — запускаем авто-бэкфилл (204 символа)", n)
            result = collector.run_backfill(pg_limit=800, window_h=72)
            logger.info("Авто-бэкфилл завершён: %s", result)
            # Сразу запускаем анализ
            analysis = analyzer.run_analysis()
            logger.info("Авто-анализ завершён: %d результатов", len(analysis))
        else:
            logger.info("DuckDB содержит %d pump_events — бэкфилл не нужен", n)
    except Exception as exc:
        logger.error("Авто-бэкфилл упал: %s", exc)


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    logger.info("DB initialised (SQLite)")
    # Авто-бэкфилл в фоновом потоке (не блокирует старт сервиса)
    t = threading.Thread(target=_auto_backfill_thread, daemon=True, name="auto-backfill")
    t.start()
    yield


app = FastAPI(
    title="Archetype Detector",
    description=(
        "Детектор торговых сигналов по архетипам роста. "
        "5 архетипов: B_silent_accumulation, C_price_led_momentum, "
        "D_pullback_continuation, F_balanced_grind, E_stealth_breakout. "
        "Архетип Explosive Ignition исключён по решению заказчика."
    ),
    version="1.0.0",
    lifespan=lifespan,
)


@app.get("/healthz")
def healthz():
    return {"status": "ok"}


@app.post("/classify", response_model=SignalOutput)
def classify(snapshot: SnapshotInput):
    """
    Классифицирует снэпшот по 5 архетипам.
    Сохраняет снэпшот и сигнал в БД (идемпотентно по symbol+snapshot_time).
    """
    current = snapshot.model_dump()
    st = str(snapshot.snapshot_time)

    # Сохранить снэпшот (ON CONFLICT DO NOTHING)
    save_snapshot(snapshot.symbol, current)

    # Достать предыдущий снэпшот для state-зависимых правил (C, D, E)
    previous = get_previous_snapshot(snapshot.symbol, st)

    # Классифицировать
    result = classify_snapshot(snapshot.symbol, current, previous)

    # Персистировать сигнал и watchlist
    archetype = result.get("archetype", "no_signal")
    save_signal(snapshot.symbol, result)
    if archetype == "watchlist_stealth":
        upsert_watchlist(snapshot.symbol, st, current)

    # Для no_signal / watchlist — возвращаем облегчённый объект
    if archetype in ("no_signal", "watchlist_stealth"):
        return SignalOutput(
            symbol=snapshot.symbol,
            snapshot_time=snapshot.snapshot_time,
            archetype=archetype,
            reason=result.get("reason"),
        )

    return SignalOutput(**{
        "symbol": result.get("symbol", snapshot.symbol),
        "snapshot_time": result.get("snapshot_time"),
        "archetype": archetype,
        "confidence_score": result.get("confidence_score"),
        "trigger_metrics": result.get("trigger_metrics"),
        "risk_recommendation": result.get("risk_recommendation"),
        "status": result.get("status", "active"),
        "note": result.get("note"),
    })


@app.get("/signals/{symbol}")
def signals_by_symbol(symbol: str):
    """История торговых сигналов по символу."""
    rows = get_signals(symbol.upper())
    if not rows:
        raise HTTPException(status_code=404, detail=f"No signals found for {symbol}")
    return rows


@app.get("/watchlist")
def watchlist():
    """Текущий список токенов в stealth watchlist."""
    return get_watchlist()


@app.post("/admin/sql")
def admin_sql(payload: dict):
    """
    Временный эндпоинт для анализа DuckDB market_snapshots.
    Принимает: {"sql": "SELECT ..."}
    """
    from pipeline.duckdb_store import get_conn
    sql = payload.get("sql", "").strip()
    if not sql:
        raise HTTPException(status_code=400, detail="sql is required")
    try:
        conn = get_conn()
        result = conn.execute(sql).fetchdf()
        return result.to_dict(orient="records")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── ETL Pipeline ──────────────────────────────────────────────────────────────

_pipeline_status: dict = {
    "running": False,
    "started_at": None,
    "done": 0,
    "total": 0,
    "last_result": None,
    "finished_at": None,
    "error": None,
}
_pipeline_lock = threading.Lock()


def _run_backfill_bg(min_price24h: float, pg_limit: int, window_h: int) -> None:
    global _pipeline_status

    def _progress(done: int, total: int, result: dict) -> None:
        with _pipeline_lock:
            _pipeline_status["done"] = done
            _pipeline_status["total"] = total
            _pipeline_status["last_result"] = result

    try:
        summary = collector.run_backfill(
            min_price24h=min_price24h,
            pg_limit=pg_limit,
            window_h=window_h,
            on_progress=_progress,
        )
        with _pipeline_lock:
            _pipeline_status["running"] = False
            _pipeline_status["finished_at"] = datetime.now(tz=timezone.utc).isoformat()
            _pipeline_status["last_result"] = summary
            _pipeline_status["error"] = None
        logger.info("Pipeline backfill done: %s", summary)
    except Exception as exc:
        logger.error("Pipeline backfill error: %s", exc)
        with _pipeline_lock:
            _pipeline_status["running"] = False
            _pipeline_status["error"] = str(exc)
            _pipeline_status["finished_at"] = datetime.now(tz=timezone.utc).isoformat()


@app.post("/pipeline/start")
def pipeline_start(
    background_tasks: BackgroundTasks,
    min_price24h: float = 20.0,
    pg_limit: int = 300,
    window_h: int = 72,
):
    """
    Запускает бэкфилл в фоне.
    Читает pump-события из PostgreSQL growth_leader_log (price_24h >= min_price24h),
    скачивает OHLCV + orderbook + large orders из CoinGlass, сохраняет в DuckDB.
    """
    with _pipeline_lock:
        if _pipeline_status["running"]:
            raise HTTPException(status_code=409, detail="Backfill уже запущен")
        _pipeline_status.update({
            "running": True,
            "started_at": datetime.now(tz=timezone.utc).isoformat(),
            "done": 0,
            "total": 0,
            "last_result": None,
            "finished_at": None,
            "error": None,
        })

    background_tasks.add_task(
        _run_backfill_bg, min_price24h, pg_limit, window_h
    )
    return {"status": "started", "min_price24h": min_price24h,
            "pg_limit": pg_limit, "window_h": window_h}


@app.get("/pipeline/status")
def pipeline_status():
    """Статус текущего / последнего бэкфилла."""
    with _pipeline_lock:
        return dict(_pipeline_status)


@app.post("/pipeline/analyze")
def pipeline_analyze(min_price24h: float = 20.0):
    """
    Запускает анализ паттернов на данных DuckDB (синхронно).
    Возвращает список паттернов с win rate.
    """
    try:
        result = analyzer.run_analysis(min_price24h=min_price24h)
        return result
    except Exception as exc:
        logger.error("pipeline_analyze error: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))


@app.get("/pipeline/results")
def pipeline_results():
    """Последние сохранённые результаты анализа паттернов из DuckDB."""
    try:
        rows = analyzer.get_latest_results()
        return {"patterns": rows, "count": len(rows)}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.get("/pipeline/stats")
def pipeline_stats():
    """Статистика по данным в DuckDB (количество строк по таблицам)."""
    try:
        con = duckdb_store.get_conn()
        stats = {}
        for table in ("ohlcv", "orderbook_heatmap", "large_limit_orders",
                      "pump_events", "analysis_results"):
            try:
                n = con.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                stats[table] = n
            except Exception:
                stats[table] = "error"
        return stats
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))
