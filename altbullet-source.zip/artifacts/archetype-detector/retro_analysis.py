"""
Полный ретро-анализ 774 пампов против паттернов сканера.

Precision вычисляется из retro_pre_growth напрямую:
  entry_price = retro.price (цена на T-Nh)
  pump_price  = growth_leader_log.price (цена в момент обнаружения)
  forward_gain = (pump_price - entry_price) / entry_price × 100

Recall = % пампов, у которых выполнены условия паттерна на T-Nh
Precision = WR = count(forward_gain >= 10%) / count(triggered)
EV = WR×10 - SL_rate×SL_size  (SL_size=10% для большинства паттернов)
"""
from __future__ import annotations
import os, sys
from collections import defaultdict
import psycopg2, psycopg2.extras

DB_URL = os.environ["DATABASE_URL"]

PATTERNS = [
    "trend_accumulation",
    "bullish_accumulation",
    "spot_vol_accumulation",
    "4h_momentum",
    "oi1h_breakout",
    "flush_reversal",
    "whale_watch",
    "whale_futures",
    "bingx_exclusive",
    "exchange_outflow_accum",
    "oversold_reversal",
    "smart_money_divergence",
    "bid_wall_absorption",
    "liq_magnet_squeeze",
    "quiet_trend_rider",
    "4h_pullback_continuation",
    "oi4h_silent_accum",
    "liquidation_cascade",
]

# Стоп-лосс по паттерну (для расчёта EV)
PATTERN_SL = {
    "spot_vol_accumulation": 5,
    "liq_magnet_squeeze": 5,
    "oversold_reversal": 5,
    "flush_reversal": 8,
    "liquidation_cascade": 8,
    "whale_alert": 8,
    "bid_wall_absorption": 8,
    "whale_watch": 8,
    "default": 10,
}


def get_sl(pat: str) -> int:
    return PATTERN_SL.get(pat, PATTERN_SL["default"])


def connect():
    return psycopg2.connect(DB_URL, cursor_factory=psycopg2.extras.RealDictCursor)


def load_retro_with_gain(entry_hours: int, exit_hours: int = 2) -> list[dict]:
    """
    Загружает retro снимки с forward gain = (price_exit - price_entry) / price_entry × 100.
    Оба снимка берутся из retro_pre_growth — gll.price = NULL, не используем.

    entry_hours — условия паттерна (T-4h, T-6h, T-12h)
    exit_hours  — точка «выхода» для расчёта gain (T-2h по умолчанию)
    """
    conn = connect()
    cur = conn.cursor()
    cur.execute("""
        SELECT
            r.retro_log_id,
            r.symbol,
            g.logged_at                                AS pump_time,
            -- Условия паттернов на T-entry_hours
            COALESCE(r.price_24h::float,  0)           AS price_24h,
            COALESCE(r.price_1h::float,   0)           AS price_1h,
            COALESCE(r.price_4h::float,   0)           AS price_4h,
            COALESCE(r.price_30m::float,  0)           AS price_30m,
            COALESCE(r.oi_30m::float,     0)           AS oi_30m,
            COALESCE(r.oi_1h::float,      0)           AS oi_1h,
            COALESCE(r.oi_4h::float,      0)           AS oi_4h,
            COALESCE(r.oi_prev_30m::float,0)           AS oi_prev_30m,
            COALESCE(r.oi_prev_1h::float, 0)           AS oi_prev_1h,
            COALESCE(r.vol_mult::float,   0)           AS vol_mult,
            r.cvd_1h,
            r.cvd_30m,
            COALESCE(r.spot_net_pct::float, 0)         AS spot_net_pct,
            COALESCE(r.funding::float,    0)           AS funding,
            -- Абсолютные цены для forward gain
            r.price                                    AS entry_price,
            rx.price                                   AS exit_price,
            CASE
                WHEN r.price > 0 AND rx.price > 0
                THEN (rx.price - r.price) / r.price * 100
                ELSE NULL
            END                                        AS forward_gain
        FROM retro_pre_growth r
        JOIN growth_leader_log g  ON g.id = r.retro_log_id
        JOIN retro_pre_growth rx  ON rx.retro_log_id = r.retro_log_id
                                  AND rx.hours_before = %s
        WHERE r.hours_before = %s
          AND r.price  > 0
          AND rx.price > 0
        ORDER BY r.retro_log_id
    """, (exit_hours, entry_hours))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def check_patterns(r: dict) -> dict[str, bool]:
    oi30  = r["oi_30m"];   oi1h  = r["oi_1h"];   oi4h  = r["oi_4h"]
    prev30 = r["oi_prev_30m"]; prev1h = r["oi_prev_1h"]
    vol    = r["vol_mult"]
    p24    = r["price_24h"]; p1h = r["price_1h"]; p4h = r["price_4h"]
    cvd1h  = r["cvd_1h"];   cvd30 = r["cvd_30m"]
    snet   = r["spot_net_pct"]; fund = r["funding"]

    cvd1h_ok = (cvd1h is not False)
    cvd30_ok = (cvd30 is not False)

    return {
        # ── Скальп / разворот ────────────────────────────────────────────────
        "flush_reversal": (
            prev30 <= -0.3 and oi30 >= 1.5 and p1h >= 0.5
        ),
        "liquidation_cascade": (
            p24 <= -7 and oi30 >= 0 and p1h >= -1
        ),
        # ── Интрадей / накопление ────────────────────────────────────────────
        "trend_accumulation": (
            oi30 >= 3.5 and prev30 >= 0.3
            and p1h >= 1.0 and vol >= 0.5 and 0 <= p24 <= 20
        ),
        "bullish_accumulation": (
            oi30 <= 2.5 and oi1h >= 2.0
            and prev30 >= -0.3 and vol >= 1.0 and 0 <= p24 <= 10
        ),
        "spot_vol_accumulation": (
            vol >= 2.5 and -5 <= p24 <= 40 and cvd1h_ok
        ),
        "4h_momentum": (
            p4h >= 2.5 and vol >= 1.0 and oi1h >= 0 and p24 <= 40
        ),
        "oi1h_breakout": (
            0.5 <= oi30 <= 15 and prev30 >= 0.0 and oi1h >= 1.5 and p1h <= 12
        ),
        # Апроксимация без cycle_count и CG-данных
        "bingx_exclusive": (
            vol >= 0.3 and 3 <= p24 <= 30
        ),
        # ── Киты ────────────────────────────────────────────────────────────
        "whale_watch": (
            oi30 >= 3.0 and 1.5 <= oi1h <= 7.0 and cvd1h_ok
        ),
        "whale_futures": (
            oi4h >= 15.0 and -20 <= p24 <= 20
        ),
        # ── Дополнительные ──────────────────────────────────────────────────
        "exchange_outflow_accum": (
            snet <= -2 and vol >= 1.3 and oi30 <= 5 and -5 <= p24 <= 15
        ),
        "oversold_reversal": (
            -25 <= p24 <= -5 and p1h >= -1
        ),
        "smart_money_divergence": (
            oi1h >= 1.0 and p24 <= 20 and vol >= 0.5
        ),
        "bid_wall_absorption": (
            oi30 >= 0.5 and oi1h >= 1.0 and cvd1h_ok
        ),
        "liq_magnet_squeeze": (
            (oi30 >= 3.0 or oi1h >= 1.5) and p4h >= -3 and fund <= 0.01
        ),
        "quiet_trend_rider": (
            5 <= p24 <= 38 and p1h >= 0 and p4h >= 4.0
        ),
        "4h_pullback_continuation": (
            p4h >= 2.0 and oi4h >= 2.0 and vol >= 0.8
        ),
        "oi4h_silent_accum": (
            oi4h >= 2.0 and -1 <= oi30 <= 2.0 and p24 >= 0
        ),
    }


def pct(lst, p):
    if not lst: return 0
    s = sorted(lst)
    idx = max(0, min(int(len(s)*p/100), len(s)-1))
    return round(s[idx], 2)


def analyze(entry_hours: int, exit_hours: int = 2) -> dict:
    rows = load_retro_with_gain(entry_hours, exit_hours)
    total = len(rows)

    gains_all = [r["forward_gain"] for r in rows if r["forward_gain"] is not None]

    pat_triggered: dict[str, list[float]] = defaultdict(list)

    for r in rows:
        gain = r["forward_gain"]
        if gain is None:
            continue
        pts = check_patterns(r)
        for pat, hit in pts.items():
            if hit:
                pat_triggered[pat].append(gain)

    results = {}
    for pat in PATTERNS:
        gains = pat_triggered.get(pat, [])
        n = len(gains)
        if n == 0:
            results[pat] = {"recall": 0, "n": 0, "wr10": 0, "wr5": 0, "wr20": 0,
                            "avg_gain": 0, "p50_gain": 0, "ev": None}
            continue

        recall = round(n / total * 100, 1)
        wr10 = round(sum(1 for g in gains if g >= 10) / n * 100, 1)
        wr5  = round(sum(1 for g in gains if g >= 5)  / n * 100, 1)
        wr20 = round(sum(1 for g in gains if g >= 20) / n * 100, 1)
        # Приближение SL rate: % токенов с gain < 0 или < -(sl/2)
        sl_size = get_sl(pat)
        sl_proxy = sum(1 for g in gains if g < 0) / n  # % с отрицательным forward gain
        ev = round(wr10/100 * 10 - sl_proxy * sl_size, 2)

        results[pat] = {
            "recall":   recall,
            "n":        n,
            "wr5":      wr5,
            "wr10":     wr10,
            "wr20":     wr20,
            "avg_gain": round(sum(gains)/n, 1),
            "p50_gain": pct(gains, 50),
            "p25_gain": pct(gains, 25),
            "p75_gain": pct(gains, 75),
            "sl_proxy": round(sl_proxy*100, 1),
            "ev":       ev,
        }

    return {"total": total, "entry_hours": entry_hours, "patterns": results,
            "gains_all": gains_all}


def show_distributions(rows: list[dict]):
    fields = ["oi_30m","oi_1h","oi_4h","oi_prev_30m","vol_mult",
              "price_24h","price_1h","price_4h","spot_net_pct"]
    print("\n" + "="*80)
    print("РАСПРЕДЕЛЕНИЕ МЕТРИК ПО 774 ПАМПАМ НА T-4h (реальные значения перед пампом)")
    print("="*80)
    print(f"{'Метрика':<18} {'P10':>7} {'P25':>7} {'P50':>7} {'P75':>7} {'P90':>7} {'%≥0':>7}")
    print("-"*65)
    for f in fields:
        vals = [float(r[f]) for r in rows if r.get(f) is not None]
        if not vals: continue
        pos_pct = round(sum(1 for v in vals if v >= 0) / len(vals) * 100, 0)
        print(f"{f:<18} {pct(vals,10):>7.2f} {pct(vals,25):>7.2f} {pct(vals,50):>7.2f} "
              f"{pct(vals,75):>7.2f} {pct(vals,90):>7.2f} {pos_pct:>6.0f}%")

    # Forward gain T-4h → T-2h
    gains = [float(r["forward_gain"]) for r in rows if r.get("forward_gain") is not None]
    if gains:
        print(f"\nForward gain (T-4h → T-2h, 2h window):")
        print(f"  P10={pct(gains,10):.1f}%  P25={pct(gains,25):.1f}%  P50={pct(gains,50):.1f}%  "
              f"P75={pct(gains,75):.1f}%  P90={pct(gains,90):.1f}%")
        print(f"  % gain≥5%:  {sum(1 for g in gains if g>=5)/len(gains)*100:.0f}%")
        print(f"  % gain≥10%: {sum(1 for g in gains if g>=10)/len(gains)*100:.0f}%")
        print(f"  % gain≥20%: {sum(1 for g in gains if g>=20)/len(gains)*100:.0f}%")
        print(f"  % gain<0%:  {sum(1 for g in gains if g<0)/len(gains)*100:.0f}%")


def main():
    # T-4h → T-2h: условия на 4h до пампа, gain за следующие 2h
    print("Загружаем retro_pre_growth (entry=T-4h, exit=T-2h)...")
    rows4h = load_retro_with_gain(entry_hours=4, exit_hours=2)
    # T-6h → T-2h: условия на 6h до пампа, gain за следующие 4h
    rows6h = load_retro_with_gain(entry_hours=6, exit_hours=2)
    print(f"  T-4h→T-2h: {len(rows4h)} снимков  |  T-6h→T-2h: {len(rows6h)} снимков")

    show_distributions(rows4h)

    res4 = analyze(4)
    res2 = analyze(6)  # используем T-6h для «R-2h» колонки

    total = res4["total"]

    # ── Итоговая таблица ──────────────────────────────────────────────────────
    print("\n" + "="*120)
    print("ПОЛНАЯ ТАБЛИЦА: RECALL × PRECISION (forward gain от точки входа T-4h/T-2h)")
    print("Precision = % пампов поймавших ≥10% роста ОТ МОМЕНТА ВХОДА (т.е. от T-Nh)")
    print("SL proxy = % событий с отрицательным forward gain (цена снизилась к моменту детекта)")
    print("="*120)
    hdr = (f"{'Паттерн':<30} {'R-4h':>6} {'WR10_4h':>8} {'SL_4h':>7} {'EV_4h':>7} "
           f"{'R-2h':>6} {'WR10_2h':>8} {'avgGain4h':>10} {'SL':>4} {'РЕШЕНИЕ'}")
    print(hdr)
    print("-"*120)

    decisions = []
    for pat in PATTERNS:
        p4 = res4["patterns"].get(pat, {})
        p2 = res2["patterns"].get(pat, {})

        r4   = p4.get("recall",   0)
        wr4  = p4.get("wr10",     0)
        sl4  = p4.get("sl_proxy", 0)
        ev4  = p4.get("ev",       None)
        r2   = p2.get("recall",   0)
        wr2  = p2.get("wr10",     0)
        avg4 = p4.get("avg_gain", 0)
        sl   = get_sl(pat)

        ev4s = f"{ev4:+.1f}" if ev4 is not None else "n/a"

        # Решение
        n4 = p4.get("n", 0)
        if n4 == 0:
            decision = "🗑 recall=0"
        elif wr4 >= 60 and r4 >= 5:
            decision = "✅ KEEP (strong)"
        elif wr4 >= 45 and r4 >= 5:
            decision = "✅ KEEP"
        elif wr4 >= 35 and r4 >= 3:
            decision = "🔧 TUNE gates"
        elif wr4 < 20 and n4 >= 20:
            decision = "🗑 низкий WR"
        elif r4 < 2:
            decision = "🔧 расширить ворота"
        else:
            decision = "🔧 TUNE"

        decisions.append(dict(pat=pat, r4=r4, wr4=wr4, sl4=sl4, ev4=ev4,
                               r2=r2, wr2=wr2, avg4=avg4, decision=decision, n4=n4))

        print(f"{pat:<30} {r4:>5.1f}% {wr4:>7.1f}% {sl4:>6.1f}% {ev4s:>7} "
              f"{r2:>5.1f}% {wr2:>7.1f}% {avg4:>9.1f}%  -{sl}%  {decision}")

    # ── Сводка ───────────────────────────────────────────────────────────────
    print("\n" + "="*80)
    print("ИТОГ")
    print("="*80)

    keeps   = [d for d in decisions if "KEEP"   in d["decision"]]
    deletes = [d for d in decisions if "🗑"      in d["decision"]]
    tunes   = [d for d in decisions if "TUNE"   in d["decision"] or "расширить" in d["decision"]]

    print(f"\n✅ ОСТАВИТЬ КАК ЕСТЬ ({len(keeps)}):")
    for d in keeps:
        print(f"   {d['pat']:<30} WR10={d['wr4']:.1f}%  Recall={d['r4']:.1f}%  avgGain={d['avg4']:.1f}%")

    print(f"\n🗑 УДАЛИТЬ / ПЕРЕРАБОТАТЬ ({len(deletes)}):")
    for d in deletes:
        ev_s = f"{d['ev4']:+.1f}" if d['ev4'] is not None else "n/a"
        print(f"   {d['pat']:<30} WR10={d['wr4']:.1f}%  Recall={d['r4']:.1f}%  EV={ev_s}  → {d['decision']}")

    print(f"\n🔧 ТЮНИНГ ПОРОГОВ ({len(tunes)}):")
    for d in tunes:
        ev_s = f"{d['ev4']:+.1f}" if d['ev4'] is not None else "n/a"
        print(f"   {d['pat']:<30} WR10={d['wr4']:.1f}%  Recall={d['r4']:.1f}%  avgGain={d['avg4']:.1f}%  → {d['decision']}")

    # ── Распределение gain по ключевым метрикам для тюнинга ──────────────────
    print("\n" + "="*80)
    print("OPTIMAL THRESHOLDS: распределение метрик у пампов с gain≥10% vs <10% (T-4h)")
    print("="*80)

    rows4 = load_retro_with_gain(entry_hours=4, exit_hours=2)
    winners = [r for r in rows4 if r.get("forward_gain") is not None and r["forward_gain"] >= 10]
    losers  = [r for r in rows4 if r.get("forward_gain") is not None and r["forward_gain"] < 10]

    print(f"\n  Winners (gain≥10%): n={len(winners)}")
    print(f"  Losers  (gain<10%): n={len(losers)}")

    metrics = [
        ("oi_30m",    "OI 30m %"),
        ("oi_1h",     "OI 1h %"),
        ("oi_4h",     "OI 4h %"),
        ("oi_prev_30m","prevOI30m %"),
        ("vol_mult",  "vol_mult x"),
        ("price_4h",  "price_4h %"),
        ("price_1h",  "price_1h %"),
        ("price_24h", "price_24h %"),
    ]

    print(f"\n{'Метрика':<18} {'W_P50':>8} {'W_P75':>8} {'L_P50':>8} {'L_P75':>8} {'Δ(P50)':>8}")
    print("-"*65)
    for col, label in metrics:
        wv = [float(r[col]) for r in winners if r.get(col) is not None]
        lv = [float(r[col]) for r in losers  if r.get(col) is not None]
        if not wv or not lv: continue
        wp50 = pct(wv, 50); wp75 = pct(wv, 75)
        lp50 = pct(lv, 50); lp75 = pct(lv, 75)
        delta = round(wp50 - lp50, 2)
        print(f"{label:<18} {wp50:>8.2f} {wp75:>8.2f} {lp50:>8.2f} {lp75:>8.2f} {delta:>+8.2f}")


if __name__ == "__main__":
    main()


# ══════════════════════════════════════════════════════════════════════════════
# check_patterns_v2 — аугментированная версия для confusion_matrix_v2
# Изменения по сравнению с check_patterns:
#   1. oi1h_breakout: p1h→p3h (spec: price3h ≤12%)
#   2. 4h_momentum: добавлен gate p3h ≤ 10% (anti-overheating)
#   3. oversold_reversal: добавлен rsi_1h ≤ 32 (None=fail-open)
#   4. whale_futures: добавлен price_vol_14d ≤ 35% sideways proxy (None=fail-open)
#   5. bingx_exclusive: обязателен флаг is_bingx_exclusive=True
#   6. liq_magnet_squeeze: False (ИСКЛЮЧЁН — liq-кластеры недоступны)
# ══════════════════════════════════════════════════════════════════════════════

def check_patterns_v2(r: dict) -> dict[str, bool]:
    """
    Аугментированная версия check_patterns с исправлениями:
    Новые поля (все fail-open если None):
      r["price_3h"]           — 3h price change %
      r["rsi_1h"]             — RSI14 на 1h TF (None → fail-open)
      r["price_vol_14d"]      — (max-min)/avg за 14д % (None → fail-open)
      r["is_bingx_exclusive"] — True только для BingX-exclusive токенов
    """
    oi30   = r["oi_30m"];      oi1h  = r["oi_1h"];   oi4h  = r["oi_4h"]
    prev30 = r["oi_prev_30m"]; prev1h = r["oi_prev_1h"]
    vol    = r["vol_mult"]
    p24    = r["price_24h"];   p1h = r["price_1h"];  p4h = r["price_4h"]
    p3h    = r.get("price_3h") or 0.0          # 3h price change (fix for oi1h_breakout, 4h_momentum)
    cvd1h  = r["cvd_1h"];     cvd30 = r["cvd_30m"]
    snet   = r["spot_net_pct"]; fund = r["funding"]

    rsi1h  = r.get("rsi_1h")          # None → fail-open
    vol14d = r.get("price_vol_14d")    # None → fail-open
    is_bingx = bool(r.get("is_bingx_exclusive", False))

    cvd1h_ok = (cvd1h is not False)
    cvd30_ok = (cvd30 is not False)

    # RSI gate: None (нет данных) → fail-open (паттерн может сработать)
    rsi_oversold_ok = (rsi1h is None or rsi1h <= 32)

    # whale_futures sideways: None → fail-open
    sideways_ok = (vol14d is None or vol14d <= 35.0)

    return {
        # ── Скальп / разворот ──────────────────────────────────────────────
        "flush_reversal": (
            prev30 <= -0.3 and oi30 >= 1.5 and p1h >= 0.5
        ),
        "liquidation_cascade": (
            p24 <= -7 and oi30 >= 0 and p1h >= -1
            # NOTE: отсутствует liqExhausted=true (fail-CLOSED в проде)
            # → тест даёт оптимистичный результат
        ),
        # ── Интрадей / накопление ──────────────────────────────────────────
        "trend_accumulation": (
            oi30 >= 3.5 and prev30 >= 0.3
            and p1h >= 1.0 and vol >= 0.5 and 0 <= p24 <= 20
            # NOTE: отсутствует cycleCount ≥ 3 — тест оптимистичный
        ),
        "bullish_accumulation": (
            oi30 <= 2.5 and oi1h >= 2.0
            and prev30 >= -0.3 and vol >= 1.0 and 0 <= p24 <= 10
        ),
        "spot_vol_accumulation": (
            vol >= 2.5 and -5 <= p24 <= 40 and cvd1h_ok
            # NOTE: отсутствует cycleCount ≥ 10 (backtest-критичное) → тест оптимистичный
        ),
        "4h_momentum": (
            p4h >= 2.5 and p3h <= 10.0 and vol >= 1.0   # ← p3h ≤ 10 FIXED
            and oi1h >= 0 and p24 <= 40
        ),
        "oi1h_breakout": (
            0.5 <= oi30 <= 15 and prev30 >= 0.0 and oi1h >= 1.5
            and p3h <= 12.0                               # ← FIXED: p3h (не p1h)
        ),
        "bingx_exclusive": (
            is_bingx and vol >= 0.3 and 3 <= p24 <= 30   # ← FIXED: обязателен флаг
        ),
        # ── Киты ───────────────────────────────────────────────────────────
        "whale_watch": (
            oi30 >= 3.0 and 1.5 <= oi1h <= 7.0 and cvd1h_ok
            # NOTE: 3-стейджная последовательность (60мин) невоспроизводима на 4h снимках
            # → trig только часть реальных whale_watch событий
        ),
        "whale_futures": (
            oi4h >= 15.0 and -20 <= p24 <= 20 and sideways_ok  # ← sideways_ok FIXED
        ),
        # ── Дополнительные ─────────────────────────────────────────────────
        "exchange_outflow_accum": (
            snet <= -2 and vol >= 1.3 and oi30 <= 5 and -5 <= p24 <= 15
            # NOTE: snet=None→0.0 в full_scan → паттерн не стреляет в full_scan
        ),
        "oversold_reversal": (
            -25 <= p24 <= -5 and p1h >= -1 and rsi_oversold_ok  # ← rsi FIXED
        ),
        "smart_money_divergence": (
            oi1h >= 1.0 and p24 <= 20 and vol >= 0.5
            # NOTE: verified trader data недоступны — паттерн неполный
        ),
        "bid_wall_absorption": (
            oi30 >= 0.5 and oi1h >= 1.0 and cvd1h_ok
            # NOTE: Layer 9 pool ≥10мин недоступен → тест оптимистичный
        ),
        "liq_magnet_squeeze": False,  # ИСКЛЮЧЁН: liq-кластерные данные недоступны
        "quiet_trend_rider": (
            5 <= p24 <= 38 and p1h >= 0 and p4h >= 4.0
            # NOTE: отсутствует cycleCount ≥ 50 → тест КРАЙНЕ оптимистичный
        ),
        "4h_pullback_continuation": (
            p4h >= 2.0 and oi4h >= 2.0 and vol >= 0.8
        ),
        "oi4h_silent_accum": (
            oi4h >= 2.0 and -1 <= oi30 <= 2.0 and p24 >= 0
        ),
    }


# Маппинг паттерн → колонка лейбла
# Определяет целевой процент роста для каждого паттерна:
#   whale_watch/whale_futures: exit target +8% (whale profile 8/12/7)
#   остальные: стандартный target +10%
PATTERN_LABEL_COL: dict[str, str] = {
    "whale_watch":              "label_8pct_24h",   # whale exit: target +8%
    "whale_futures":            "label_8pct_24h",   # whale exit: target +8%
    # все остальные → label_10pct_24h (дефолт)
}
PATTERN_LABEL_DEFAULT = "label_10pct_24h"


PATTERN_AUDIT: dict[str, dict] = {
    "flush_reversal":          {"coverage": "PARTIAL",    "missing": "vol_flush≥2x, rebound≥1.5x (оба fail-open в проде → ОК)"},
    "liquidation_cascade":     {"coverage": "НЕПОЛНЫЙ",   "missing": "Layer10 pool≥30мин + liqExhausted fail-CLOSED → тест ЗАВЫШАЕТ precision"},
    "trend_accumulation":      {"coverage": "ТОЧНЫЙ",     "missing": "cycleCount-гейт удалён из продакшн (2026-07-19) — тест теперь совпадает"},
    "bullish_accumulation":    {"coverage": "ТОЧНЫЙ",     "missing": "cycleCount≤25 ceiling удалён из продакшн (2026-07-19) — тест совпадает"},
    "spot_vol_accumulation":   {"coverage": "ТОЧНЫЙ",     "missing": "cycleCount≥10 удалён (2026-07-19): Prec=10% — честная цифра без gates; WARNING: в проде с gates было EV≈+3.6"},
    "4h_momentum":             {"coverage": "ИСПРАВЛЕН",  "missing": "добавлен p3h≤10 anti-overheating"},
    "oi1h_breakout":           {"coverage": "ИСПРАВЛЕН",  "missing": "p1h→p3h исправлен"},
    "bingx_exclusive":         {"coverage": "ТОЧНЫЙ",     "missing": "cycleCount≥2 gate удалён (2026-07-19); флаг is_bingx_exclusive сохранён; EV=-4.65"},
    "whale_watch":             {"coverage": "ОЧЕНЬ УПРОЩЁННЫЙ", "missing": "3-стейджная послед. (60мин) + FutTaker≥25% невоспроизводимы → ОСТОРОЖНО"},
    "whale_futures":           {"coverage": "УЛУЧШЕН",    "missing": "sideways_ok добавлен как proxy (35% range за 14д)"},
    "exchange_outflow_accum":  {"coverage": "НЕ ТЕСТИРУЕМ", "missing": "snet=None→0.0 в full_scan → 0 тригов; только confirmed_pump"},
    "oversold_reversal":       {"coverage": "ИСПРАВЛЕН",  "missing": "добавлен RSI1h≤32 (None=fail-open)"},
    "smart_money_divergence":  {"coverage": "НЕПОЛНЫЙ",   "missing": "verified trader data недоступны — паттерн неизмеримый"},
    "bid_wall_absorption":     {"coverage": "УПРОЩЁННЫЙ", "missing": "Layer9 pool≥10мин недоступен → тест оптимистичный"},
    "liq_magnet_squeeze":      {"coverage": "ИСКЛЮЧЁН",   "missing": "liq-кластерные данные физически недоступны"},
    "quiet_trend_rider":       {"coverage": "ТОЧНЫЙ",     "missing": "firstSeenAt≥90мин gate удалён (2026-07-19) — тест теперь совпадает; EV=-1.40"},
    "4h_pullback_continuation":{"coverage": "ПРИЕМЛЕМЫЙ", "missing": "нет cycle/layer данных"},
    "oi4h_silent_accum":       {"coverage": "ПРИЕМЛЕМЫЙ", "missing": "нет cycle данных"},
}
