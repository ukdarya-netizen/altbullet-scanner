"""
Confusion Matrix v2 — per-pattern labels, augmented check_patterns_v2, полный аудит.

Изменения vs v1:
  - NaN-fix: pandas NULL→NaN теперь корректно обрабатывается
  - Per-pattern labels: whale_watch/whale_futures → label_8pct_24h, остальные → label_10pct_24h
  - check_patterns_v2: RSI для oversold, sideways для whale_futures, p3h фиксы
  - liq_magnet_squeeze: ИСКЛЮЧЁН из матрицы
  - bingx_exclusive: тест только на реальных BingX-exclusive символах
  - Полная аудит-таблица с описанием coverage gap'ов
"""
from __future__ import annotations

import math
import sys
import logging
from collections import defaultdict

sys.path.insert(0, str(__import__("pathlib").Path(__file__).parent))

from pipeline import duckdb_store as duck
from retro_analysis import (
    check_patterns_v2,
    PATTERNS,
    PATTERN_SL,
    PATTERN_LABEL_COL,
    PATTERN_LABEL_DEFAULT,
    PATTERN_AUDIT,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s", datefmt="%H:%M:%S")
logger = logging.getLogger("cm_v2")

EXCLUDED_PATTERNS = {"liq_magnet_squeeze"}

WIN_TARGET = 10.0   # % — используется в EV расчёте для non-whale паттернов
WIN_TARGET_WHALE = 8.0  # % — для whale_watch / whale_futures


def _nan_safe(v, default=0.0):
    """Конвертирует None и NaN в default."""
    if v is None:
        return default
    if isinstance(v, float) and math.isnan(v):
        return default
    return v


_NUMERIC_DEFAULTS = {
    "oi_30m": 0.0, "oi_prev_30m": 0.0, "oi_1h": 0.0,
    "oi_prev_1h": 0.0, "oi_4h": 0.0,
    "vol_mult": 0.0, "price_1h": 0.0, "price_3h": 0.0,
    "price_4h": 0.0, "price_24h": 0.0,
    "spot_net_pct": 0.0,
    "funding": 0.0,
    "rsi_1h": None,         # None → fail-open
    "price_vol_14d": None,  # None → fail-open
    "is_bingx_exclusive": False,
}

_BOOL_FIELDS = {"cvd_1h", "cvd_30m"}


def safe_check_v2(row: dict) -> dict[str, bool]:
    """Безопасный вызов check_patterns_v2 с NaN-fix."""
    r = dict(row)

    # Числовые поля: NaN/None → default
    for field, default in _NUMERIC_DEFAULTS.items():
        v = r.get(field)
        if v is None or (isinstance(v, float) and math.isnan(v)):
            r[field] = default

    # Boolean поля: NaN → None (fail-open семантика)
    for field in _BOOL_FIELDS:
        v = r.get(field)
        if isinstance(v, float) and math.isnan(v):
            r[field] = None   # None → cvd_ok = True (fail-open)

    try:
        return check_patterns_v2(r)
    except Exception as exc:
        logger.warning("check_patterns_v2 error for %s: %s", r.get("symbol"), exc)
        return {p: False for p in PATTERNS}


def get_label(row: dict, pattern: str) -> int:
    """
    Возвращает лейбл для данного паттерна и снапшота.
    - confirmed_pump: всегда 1 (токен вырос → win по определению)
    - full_scan / bingx_excl: берём из соответствующей label_* колонки
    """
    if row.get("source") == "confirmed_pump":
        return 1

    label_col = PATTERN_LABEL_COL.get(pattern, PATTERN_LABEL_DEFAULT)
    v = row.get(label_col)
    if v is None or (isinstance(v, float) and math.isnan(v)):
        # fallback: используем legacy label_win (может быть None)
        v = row.get("label_win")
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return 0
    return int(v)


def get_win_target(pattern: str) -> float:
    """Win target % для EV расчёта."""
    if pattern in ("whale_watch", "whale_futures"):
        return WIN_TARGET_WHALE
    return WIN_TARGET


def run(source: str = "all") -> list[dict]:
    con = duck.get_conn()

    where = "" if source == "all" else f"WHERE source = '{source}'"
    df = con.execute(f"""
        SELECT
            symbol, snapshot_ts_ms, source,
            price_1h, price_3h, price_4h, price_24h, vol_mult,
            oi_30m, oi_prev_30m, oi_1h, oi_prev_1h, oi_4h,
            cvd_1h, cvd_30m, spot_net_pct, funding,
            rsi_1h, price_vol_14d, is_bingx_exclusive,
            label_win, label_8pct_24h, label_10pct_12h, label_10pct_24h
        FROM market_snapshots
        {where}
    """).fetchdf()

    rows = df.to_dict(orient="records")
    logger.info("Loaded %d snapshots (source=%s)", len(rows), source)
    if not rows:
        return []

    # Счётчики: pattern → {TP, FP, FN, TN}
    cnt: dict[str, dict[str, int]] = {
        p: {"TP": 0, "FP": 0, "FN": 0, "TN": 0}
        for p in PATTERNS if p not in EXCLUDED_PATTERNS
    }

    src_counts = defaultdict(int)
    for r in rows:
        src_counts[r.get("source", "?")] += 1

    wins_per_source = {}
    for src in src_counts:
        sub = [r for r in rows if r.get("source") == src]
        # Win rate used for first label column
        n_wins = sum(1 for r in sub
                     if int(_nan_safe(r.get("label_10pct_24h", r.get("label_win")), 0)) == 1)
        wins_per_source[src] = (n_wins, len(sub))

    for row in rows:
        fired = safe_check_v2(row)
        for pat, trig in fired.items():
            if pat in EXCLUDED_PATTERNS or pat not in cnt:
                continue
            label = get_label(row, pat)
            if trig and label == 1:
                cnt[pat]["TP"] += 1
            elif trig and label == 0:
                cnt[pat]["FP"] += 1
            elif not trig and label == 1:
                cnt[pat]["FN"] += 1
            else:
                cnt[pat]["TN"] += 1

    total = len(rows)
    results = []
    for pat in PATTERNS:
        if pat in EXCLUDED_PATTERNS:
            continue
        c = cnt[pat]
        tp, fp, fn, tn = c["TP"], c["FP"], c["FN"], c["TN"]
        trig = tp + fp
        sl   = float(PATTERN_SL.get(pat, 10))
        wt   = get_win_target(pat)
        prec = tp / trig if trig > 0 else None
        rec  = tp / (tp + fn) if (tp + fn) > 0 else None
        ev   = (prec * wt - (1 - prec) * sl) if prec is not None else None
        f1   = (2 * prec * rec / (prec + rec)) if (prec and rec and prec + rec > 0) else None
        audit = PATTERN_AUDIT.get(pat, {})
        results.append({
            "pattern": pat, "TP": tp, "FP": fp, "FN": fn, "TN": tn, "trig": trig,
            "prec": prec, "rec": rec, "ev": ev, "f1": f1,
            "sl": sl, "win_target": wt,
            "coverage": audit.get("coverage", "?"),
            "missing": audit.get("missing", ""),
        })

    results.sort(key=lambda x: x["ev"] if x["ev"] is not None else -999, reverse=True)
    return results, total, dict(src_counts), wins_per_source


def print_audit():
    """Печатает таблицу аудита coverage per pattern."""
    print("""
╔══════════════════════════════════════════════════════════════════════════════════════════════════════╗
║  АУДИТ: check_patterns_v2() — ПОЛНОЕ vs УПРОЩЁННОЕ условие                                         ║
╠══════════════════════════════════════════════════════════════════════════════════════════════════════╣""")
    for pat, a in PATTERN_AUDIT.items():
        cov = a["coverage"]
        miss = a["missing"][:80]
        print(f"║  {pat:<30} [{cov:<16}] {miss:<50} ║")
    print("╚══════════════════════════════════════════════════════════════════════════════════════════════════════╝")


def print_report(results: list[dict], total: int, src_counts: dict, wins_per_source: dict) -> None:
    N = total
    print(f"\n{'='*120}")
    print(f"CONFUSION MATRIX v2  n={N:,}  source_breakdown: {dict(src_counts)}")
    print(f"Label spec: whale_watch/whale_futures → label_8pct_24h (+8%/24h), остальные → label_10pct_24h (+10%/24h)")
    print(f"confirmed_pump: label=1 always  |  full_scan/bingx_excl: label from OHLCV forward-looking bars")
    print(f"ИСКЛЮЧЁН: liq_magnet_squeeze (liq-кластерные данные недоступны)")

    # Source breakdown
    for src, count in src_counts.items():
        wp = wins_per_source.get(src, (0, count))
        print(f"  {src}: {count} rows, {wp[0]} wins ({100*wp[0]/max(1,wp[1]):.1f}%)")

    print(f"\n{'Pattern':<30} {'Trig':>6} {'TP':>5} {'FP':>5} {'FN':>5} {'TN':>6}  {'Prec%':>6} {'Rec%':>6} {'EV':>7}  {'F1':>5}  SL% Win% Coverage")
    print("-" * 120)

    for r in results:
        ps  = f"{r['prec']*100:.1f}"   if r["prec"] is not None else "  n/a"
        rs  = f"{r['rec']*100:.1f}"    if r["rec"]  is not None else "  n/a"
        es  = f"{r['ev']:+.2f}"        if r["ev"]   is not None else "   n/a"
        fs  = f"{r['f1']:.3f}"         if r["f1"]   is not None else "  n/a"
        ev  = r["ev"]
        mark = "⭐" if (ev and ev > 4) else ("✓" if (ev and ev > 0) else "✗")
        cov = r["coverage"][:12]
        print(f"{mark} {r['pattern']:<29} {r['trig']:>6} {r['TP']:>5} {r['FP']:>5} {r['FN']:>5} {r['TN']:>6}  {ps:>6} {rs:>6} {es:>7}  {fs:>5}  {r['sl']:>2.0f}%  {r['win_target']:>3.0f}%  {cov}")

    print("=" * 120)

    print("\n📌 ИТОГ:")
    top = [r for r in results if r["ev"] and r["ev"] > 0 and r["trig"] >= 5]
    print(f"  Positive EV (trig≥5): {len(top)}")
    for r in top:
        print(f"    ⭐ {r['pattern']}: EV={r['ev']:+.2f}  Prec={r['prec']*100:.0f}%  trig={r['trig']}  [{r['coverage']}]")

    zero = [r["pattern"] for r in results if r["trig"] == 0]
    if zero:
        print(f"\n  Никогда не срабатывает (тест): {', '.join(zero)}")

    bad = [r for r in results if r["ev"] and r["ev"] < -3 and r["trig"] > 50]
    if bad:
        print(f"\n  Проблемные (EV<-3, trig>50):")
        for r in bad:
            gap = f" ← {r['missing'][:60]}" if r["missing"] else ""
            print(f"    ✗ {r['pattern']}: EV={r['ev']:+.2f}  Prec={r['prec']*100:.0f}%  trig={r['trig']} [{r['coverage']}]{gap}")

    print("""
⚠️  МЕТОДОЛОГИЧЕСКИЕ ОГРАНИЧЕНИЯ (честные цифры):
  1. 77 символов prescan_tracker → bias: уже замеченные сканером (не случайная выборка)
  2. cycleCount НЕ воспроизводим из 4h OHLCV:
     - spot_vol_accumulation: missing cycleCount≥10 → FP завышен ~10x
     - trend_accumulation: missing cycleCount≥3
     - quiet_trend_rider: missing cycleCount≥50 → FP завышен ~10x
  3. whale_watch: 3-стейджная последовательность за 60мин невоспроизводима на 4h снимках
  4. smart_money_divergence: verified trader data физически недоступны
  5. exchange_outflow_accum: netflow data = None→0.0 в full_scan → только confirmed_pump
  6. liquidation_cascade: liqExhausted (fail-CLOSED) отсутствует → FP завышен
""")


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default="all")
    parser.add_argument("--audit", action="store_true", help="Показать аудит-таблицу")
    args = parser.parse_args()

    if args.audit:
        print_audit()

    out = run(source=args.source)
    if out:
        results, total, src_counts, wins_per_source = out
        print_report(results, total, src_counts, wins_per_source)


if __name__ == "__main__":
    main()
