"""
Бэктест-модуль архетипного детектора.

Использование:
    python backtest.py --input retro_analysis_774.csv
    python backtest.py --export-from-db          # сначала экспортировать CSV из локальной DB

Прогоняет оркестратор по 774 токенам × 5 снэпшотов (T-12h → T-2h).
Для каждого токена ищет первый сигнал (наибольший hours_before при наличии сигнала).
Выводит backtest_report.md + backtest_report.csv.
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict

import pandas as pd

from orchestrator import classify_snapshot

SIGNAL_ARCHETYPES = {
    "B_silent_accumulation",
    "C_price_led_momentum",
    "D_pullback_continuation",
    "F_balanced_grind",
    "E_stealth_breakout",
}

EXPECTED_SHARES = {
    "B_silent_accumulation": 26.0,
    "C_price_led_momentum": 11.8,
    "D_pullback_continuation": 11.0,
    "F_balanced_grind": 32.3,
    "E_stealth_breakout": 12.7,
}

# ── Экспорт из локальной БД ────────────────────────────────────────────────

def export_from_db(output_path: str) -> None:
    """
    Экспортирует retro_pre_growth из локальной Postgres (DATABASE_URL) в CSV.
    Запускать один раз, результат — retro_analysis_774.csv.

    Ключ уникального события — retro_log_id (774 уникальных событий).
    Один и тот же символ может встречаться несколько раз (несколько пампов).
    """
    try:
        import psycopg2
    except ImportError:
        sys.exit("psycopg2 не установлен. Запустите: pip install psycopg2-binary")

    db_url = os.environ.get("DATABASE_URL")
    if not db_url:
        sys.exit("Переменная DATABASE_URL не задана. Нужна строка подключения к heliumdb/Neon.")

    print(f"Подключение к БД и экспорт в {output_path} ...")
    conn = psycopg2.connect(db_url)
    try:
        df = pd.read_sql("""
            SELECT
                retro_log_id,
                symbol,
                snapshot_time,
                hours_before,
                price_1h,
                price_3h,
                price_4h::float  AS price_4h,
                price_24h,
                oi_30m,
                oi_prev_30m,
                oi_1h,
                oi_prev_1h,
                oi_4h::float     AS oi_4h,
                vol_mult,
                cvd_1h,
                cvd_1h_ratio::float AS cvd_1h_ratio,
                cvd_30m,
                spot_net_pct::float AS spot_net_pct,
                net_buy_pct,
                funding::float   AS funding
            FROM retro_pre_growth
            ORDER BY retro_log_id, hours_before DESC
        """, conn)
    finally:
        conn.close()

    df.to_csv(output_path, index=False)
    n_events = df["retro_log_id"].nunique()
    print(f"Экспортировано {len(df)} строк, {n_events} событий ({df['symbol'].nunique()} уник. символов) → {output_path}")


# ── Основной бэктест ───────────────────────────────────────────────────────

def _row_to_dict(row: pd.Series) -> dict:
    """Конвертирует строку DataFrame в dict метрик для оркестратора."""
    d = row.to_dict()
    # pandas может вернуть NaN — нормализуем в None
    for k, v in d.items():
        if isinstance(v, float) and (v != v):   # NaN check
            d[k] = None
        elif pd.isna(v) if not isinstance(v, (bool, type(None))) else False:
            d[k] = None
    # cvd_1h и cvd_30m в CSV могут быть строкой "True"/"False" или bool
    for cvd_col in ("cvd_1h", "cvd_30m"):
        v = d.get(cvd_col)
        if isinstance(v, str):
            d[cvd_col] = v.lower() == "true"
        elif isinstance(v, float):
            d[cvd_col] = None  # NaN = нет данных
    return d


def run_backtest(csv_path: str) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """
    Запускает оркестратор по CSV с историей снэпшотов.

    Ключ группировки: retro_log_id (уникальное событие роста).
    Если retro_log_id отсутствует в CSV — fallback на symbol.

    Returns:
        per_snapshot_df: DataFrame с результатом по каждому снэпшоту
        first_signal_df: DataFrame первого сигнала по каждому событию
        summary: словарь с агрегированными метриками
    """
    df = pd.read_csv(csv_path)

    if "hours_before" not in df.columns:
        sys.exit("В CSV отсутствует столбец hours_before. Убедитесь что используется правильный файл.")

    # Определяем ключ события
    event_key = "retro_log_id" if "retro_log_id" in df.columns else "symbol"
    n_events = df[event_key].nunique()
    print(f"Загружено {len(df)} строк, {n_events} событий (ключ: {event_key}), {df['symbol'].nunique()} уник. символов")

    # Сортируем: по событию, затем hours_before DESC (12 → 6 → 4 → 3 → 2 = от старого к новому)
    df = df.sort_values([event_key, "hours_before"], ascending=[True, False]).reset_index(drop=True)

    records = []
    for event_id, group in df.groupby(event_key, sort=False):
        symbol = group.iloc[0]["symbol"]
        rows = list(group.itertuples(index=False))
        previous: dict | None = None

        for row in rows:
            current = _row_to_dict(pd.Series(row._asdict()))
            hours_before = current.get("hours_before")

            result = classify_snapshot(symbol, current, previous)
            archetype = result.get("archetype", "no_signal")
            confidence = result.get("confidence_score")

            records.append({
                event_key: event_id,
                "symbol": symbol,
                "hours_before": hours_before,
                "archetype": archetype,
                "confidence_score": confidence,
                "trigger_metrics": str(result.get("trigger_metrics", "")),
            })

            previous = current

    per_snapshot_df = pd.DataFrame(records)

    # ── Агрегация: первый сигнал по событию ──────────────────────────────
    signal_rows = per_snapshot_df[per_snapshot_df["archetype"].isin(SIGNAL_ARCHETYPES)]
    # Первый сигнал = максимальный hours_before с реальным архетипом (самый ранний)
    first_signal = (
        signal_rows.sort_values("hours_before", ascending=False)
        .groupby(event_key, sort=False)
        .first()
        .reset_index()[[event_key, "symbol", "hours_before", "archetype", "confidence_score"]]
        .rename(columns={"hours_before": "first_signal_hours_before", "archetype": "first_archetype"})
    )

    all_events = set(df[event_key].unique())
    caught_events = set(first_signal[event_key].unique())
    no_signal_events = all_events - caught_events
    # Имена символов без сигнала
    no_signal_symbols = sorted(
        df[df[event_key].isin(no_signal_events)]["symbol"].unique().tolist()
    )
    total = len(all_events)

    # Распределение по архетипам (по первому сигналу)
    archetype_dist = first_signal["first_archetype"].value_counts().to_dict()
    archetype_pct = {k: round(v / total * 100, 1) for k, v in archetype_dist.items()}

    # Средний hours_before первого срабатывания по архетипу
    avg_hours = (
        first_signal.groupby("first_archetype")["first_signal_hours_before"]
        .mean()
        .round(1)
        .to_dict()
    )
    avg_confidence = (
        first_signal.groupby("first_archetype")["confidence_score"]
        .mean()
        .round(1)
        .to_dict()
    )

    summary = {
        "total_tokens": total,
        "caught": len(caught_events),
        "no_signal_count": len(no_signal_events),
        "no_signal_pct": round(len(no_signal_events) / total * 100, 1),
        "archetype_counts": archetype_dist,
        "archetype_pct": archetype_pct,
        "avg_hours_before": avg_hours,
        "avg_confidence": avg_confidence,
        "no_signal_symbols": no_signal_symbols,
    }

    return per_snapshot_df, first_signal, summary


# ── Отчёт ─────────────────────────────────────────────────────────────────

def write_report(per_snapshot_df: pd.DataFrame, first_signal_df: pd.DataFrame, summary: dict, output_dir: str = ".") -> None:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    total = summary["total_tokens"]
    caught = summary["caught"]
    no_sig = summary["no_signal_count"]
    no_sig_pct = summary["no_signal_pct"]

    # ── backtest_report.md ────────────────────────────────────────────────
    lines = [
        "# Backtest Report — Archetype Detector",
        f"\n_Дата прогона: {ts}_\n",
        f"**Датасет:** {total} токенов × 5 снэпшотов (T-12h, T-6h, T-4h, T-3h, T-2h)\n",
        "## Итог покрытия\n",
        f"| Метрика | Значение |",
        f"|---------|----------|",
        f"| Всего токенов | {total} |",
        f"| Поймано (≥1 сигнал) | **{caught}** ({round(caught/total*100, 1)}%) |",
        f"| Слепая зона (no_signal на всех снэпшотах) | **{no_sig}** ({no_sig_pct}%) |",
        "",
        "## Распределение по архетипам (первый сигнал на токен)\n",
        "| Архетип | Кол-во | % от выборки | Ожидаемо % | Avg hours_before | Avg confidence |",
        "|---------|--------|-------------|------------|-----------------|----------------|",
    ]

    for arch in ["B_silent_accumulation", "C_price_led_momentum", "D_pullback_continuation",
                 "F_balanced_grind", "E_stealth_breakout"]:
        count = summary["archetype_counts"].get(arch, 0)
        pct = summary["archetype_pct"].get(arch, 0.0)
        expected = EXPECTED_SHARES.get(arch, "-")
        avg_h = summary["avg_hours_before"].get(arch, "-")
        avg_c = summary["avg_confidence"].get(arch, "-")
        lines.append(f"| {arch} | {count} | {pct}% | ~{expected}% | {avg_h}h | {avg_c} |")

    # Добавляем watchlist_stealth отдельно (не торговый сигнал)
    ws_count = (per_snapshot_df["archetype"] == "watchlist_stealth").sum()
    ns_count = (per_snapshot_df["archetype"] == "no_signal").sum()
    lines += [
        "",
        f"> **watchlist_stealth** (не торговый сигнал, ожидание разблокировки): {ws_count} снэпшотов",
        f"> **no_signal**: {ns_count} снэпшотов",
        "",
        "## Примечания\n",
        "- **Слепая зона не скрыта**: токены без единого сигнала (no_signal на всех 5 снэпшотах) "
        f"составляют **{no_sig_pct}%** датасета — это baseline системы.",
        "- Архетип **Explosive Ignition исключён** из системы по решению заказчика.",
        "- CVD, spot_net_pct, funding не являются обязательными условиями ни одного из 5 детекторов "
        "(используются только как бонус к confidence_score, если не null).",
        "- `first_archetype` по токену = архетип на ПЕРВОМ снэпшоте где появился сигнал "
        "(наибольший hours_before → самый ранний сигнал).",
        "",
        "## Детализация по токенам (backtest_report.csv)",
        "",
        "Полная построчная разметка сохранена в `backtest_report.csv`.",
    ]

    md_path = Path(output_dir) / "backtest_report.md"
    md_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Отчёт: {md_path}")

    # ── backtest_report.csv ───────────────────────────────────────────────
    csv_path = Path(output_dir) / "backtest_report.csv"
    per_snapshot_df.to_csv(csv_path, index=False)
    print(f"CSV: {csv_path}")

    # Сводка в консоль
    print("\n" + "═" * 60)
    print(f"Поймано {caught}/{total} токенов ({round(caught/total*100,1)}%)")
    print(f"Слепая зона: {no_sig} токенов ({no_sig_pct}%)")
    print("\nРаспределение по архетипам:")
    for arch in ["B_silent_accumulation", "C_price_led_momentum", "D_pullback_continuation",
                 "F_balanced_grind", "E_stealth_breakout"]:
        count = summary["archetype_counts"].get(arch, 0)
        pct = summary["archetype_pct"].get(arch, 0.0)
        expected = EXPECTED_SHARES.get(arch, "?")
        print(f"  {arch:<35} {count:>4} токена ({pct:>5.1f}% vs ожид. {expected}%)")
    print("═" * 60)


# ── CLI ───────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Backtest архетипного детектора")
    parser.add_argument("--input", default="retro_analysis_774.csv",
                        help="Путь к CSV с ретроспективными данными")
    parser.add_argument("--export-from-db", action="store_true",
                        help="Экспортировать retro_pre_growth из БД (DATABASE_URL) в --input CSV")
    parser.add_argument("--output-dir", default=".",
                        help="Директория для backtest_report.md и backtest_report.csv")
    args = parser.parse_args()

    if args.export_from_db:
        export_from_db(args.input)

    if not Path(args.input).exists():
        print(f"Файл {args.input} не найден.")
        print("Запустите: python backtest.py --export-from-db --input retro_analysis_774.csv")
        sys.exit(1)

    per_snapshot_df, first_signal_df, summary = run_backtest(args.input)
    write_report(per_snapshot_df, first_signal_df, summary, args.output_dir)


if __name__ == "__main__":
    main()
