"""
Confusion matrix для всех паттернов сканера.

Использует market_snapshots из DuckDB:
  - source='confirmed_pump': 774 строки, label_win=1
  - source='full_scan':      ~54k строк, label_win=0|1

Для каждого снапшота запускает check_patterns(r) из retro_analysis.py.
Вычисляет TP/FP/FN/TN, Precision, Recall, EV per pattern.

Запуск:
    python3 confusion_matrix.py [--source all|confirmed_pump|full_scan]
"""
from __future__ import annotations

import sys
import logging
from dataclasses import dataclass, field

sys.path.insert(0, str(__import__("pathlib").Path(__file__).parent))

from pipeline import duckdb_store as duck

# Импортируем check_patterns и список паттернов из retro_analysis
from retro_analysis import check_patterns, PATTERNS, PATTERN_SL

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("confusion_matrix")

# ── Win/Loss стоп для EV ──────────────────────────────────────────────────────
# EV = P(hit) × win_pct − P(stop) × stop_pct
# Используем эмпирические данные из бэктеста 90д
PATTERN_STOPS: dict[str, float] = {
    "flush_reversal":           8.0,
    "liquidation_cascade":      8.0,
    "trend_accumulation":       8.0,  # OI Watch, стоп -8%
    "bullish_accumulation":    10.0,
    "spot_vol_accumulation":    5.0,
    "4h_momentum":             10.0,
    "oi1h_breakout":           10.0,
    "bingx_exclusive":         10.0,
    "whale_alert":              8.0,
    "whale_watch":              8.0,  # whale profile
    "whale_futures":            8.0,
    "exchange_outflow_accum":   8.0,
    "oversold_reversal":        5.0,
    "smart_money_divergence":  10.0,
    "bid_wall_absorption":      8.0,
    "liq_magnet_squeeze":       5.0,
    "quiet_trend_rider":       10.0,
    "oi4h_silent_accum":        8.0,
}

WIN_TARGET = 10.0  # % — стандартная цель для EV расчёта


@dataclass
class PatternStats:
    name:  str
    TP:    int = 0   # triggered AND won (label=1)
    FP:    int = 0   # triggered AND lost (label=0)
    FN:    int = 0   # NOT triggered AND won (label=1)
    TN:    int = 0   # NOT triggered AND lost (label=0)

    @property
    def triggered(self) -> int:
        return self.TP + self.FP

    @property
    def total(self) -> int:
        return self.TP + self.FP + self.FN + self.TN

    @property
    def precision(self) -> float | None:
        """Истинный Win Rate при срабатывании паттерна."""
        if self.triggered == 0:
            return None
        return self.TP / self.triggered

    @property
    def recall(self) -> float | None:
        """Доля реальных пампов, которые паттерн поймал."""
        positives = self.TP + self.FN
        if positives == 0:
            return None
        return self.TP / positives

    @property
    def ev(self) -> float | None:
        """EV = Precision × WIN_TARGET − (1 − Precision) × stop."""
        prec = self.precision
        if prec is None:
            return None
        stop = PATTERN_STOPS.get(self.name, 10.0)
        return prec * WIN_TARGET - (1 - prec) * stop

    @property
    def f1(self) -> float | None:
        p, r = self.precision, self.recall
        if p is None or r is None or (p + r) == 0:
            return None
        return 2 * p * r / (p + r)


_NUMERIC_DEFAULTS = {
    "oi_30m": 0.0, "oi_prev_30m": 0.0, "oi_1h": 0.0,
    "oi_prev_1h": 0.0, "oi_4h": 0.0,
    "vol_mult": 0.0, "price_1h": 0.0, "price_3h": 0.0,
    "price_4h": 0.0, "price_24h": 0.0,
    "spot_net_pct": 0.0,    # 0 → exchange_outflow (snet<=-2) не сработает
    "funding": 0.0,          # 0 → liq_magnet (fund<=0.01) пропустит (fail-open)
}


def safe_check_patterns(row: dict) -> dict[str, bool]:
    """check_patterns с None-безопасными дефолтами для full_scan строк."""
    r = dict(row)
    for field, default in _NUMERIC_DEFAULTS.items():
        if r.get(field) is None:
            r[field] = default
    # cvd_1h/cvd_30m: None → не False → fail-open (cvd_ok=True)
    try:
        return check_patterns(r)
    except Exception:
        return {p: False for p in PATTERNS}


def run_confusion_matrix(source: str = "all") -> list[PatternStats]:
    con = duck.get_conn()

    where = "" if source == "all" else f"WHERE source = '{source}'"
    rows = con.execute(f"""
        SELECT
            symbol, snapshot_ts_ms, source,
            price_1h, price_3h, price_4h, price_24h, vol_mult,
            oi_30m, oi_prev_30m, oi_1h, oi_prev_1h, oi_4h,
            cvd_1h, cvd_30m, spot_net_pct, funding,
            label_win
        FROM market_snapshots
        {where}
    """).fetchdf().to_dict(orient="records")

    logger.info("Загружено %d снапшотов (source=%s)", len(rows), source)
    if not rows:
        logger.error("Нет данных в market_snapshots!")
        return []

    # Инициализируем счётчики для всех паттернов
    stats: dict[str, PatternStats] = {p: PatternStats(p) for p in PATTERNS}

    wins   = sum(1 for r in rows if r["label_win"] == 1)
    losses = len(rows) - wins
    logger.info("Баланс: %d wins (%.1f%%) / %d losses", wins, 100*wins/len(rows), losses)

    for i, row in enumerate(rows):
        if i % 5000 == 0:
            logger.info("  Обработано %d/%d...", i, len(rows))

        label = int(row["label_win"] or 0)
        fired = safe_check_patterns(row)

        for pname, triggered in fired.items():
            if pname not in stats:
                stats[pname] = PatternStats(pname)
            s = stats[pname]
            if triggered and label == 1:
                s.TP += 1
            elif triggered and label == 0:
                s.FP += 1
            elif not triggered and label == 1:
                s.FN += 1
            else:
                s.TN += 1

    return list(stats.values())


def print_report(stats: list[PatternStats], source: str) -> None:
    print(f"\n{'='*110}")
    print(f"CONFUSION MATRIX — source={source}")
    print(f"{'='*110}")
    header = (
        f"{'Pattern':<30} {'Trig':>6} {'TP':>6} {'FP':>6} {'FN':>6} {'TN':>6}"
        f" {'Prec%':>7} {'Rec%':>7} {'EV':>6} {'F1':>6}"
    )
    print(header)
    print("-" * 110)

    # Сортировка по EV (descending), None в конце
    def ev_key(s: PatternStats):
        return s.ev if s.ev is not None else -999

    for s in sorted(stats, key=ev_key, reverse=True):
        prec_s = f"{s.precision*100:.1f}" if s.precision is not None else "n/a"
        rec_s  = f"{s.recall*100:.1f}"    if s.recall    is not None else "n/a"
        ev_s   = f"{s.ev:+.2f}"           if s.ev        is not None else "n/a"
        f1_s   = f"{s.f1:.3f}"            if s.f1        is not None else "n/a"
        print(
            f"  {s.name:<28} {s.triggered:>6} {s.TP:>6} {s.FP:>6} {s.FN:>6} {s.TN:>6}"
            f" {prec_s:>7} {rec_s:>7} {ev_s:>6} {f1_s:>6}"
        )

    print("=" * 110)

    # Summary
    total_triggered = sum(s.triggered for s in stats)
    total_tp        = sum(s.TP for s in stats)
    total_fp        = sum(s.FP for s in stats)
    total_snapshots = stats[0].total if stats else 0

    print(f"\nВсего снапшотов: {total_snapshots}")
    print(f"Всего срабатываний: {total_triggered} (один снапшот может дать несколько паттернов)")
    if total_triggered > 0:
        print(f"Суммарный precision (микро): {100*total_tp/total_triggered:.1f}%")

    # Топ-3 по EV (только с ≥10 срабатываниями)
    ev_ranked = [(s.ev, s) for s in stats if s.ev is not None and s.triggered >= 10]
    ev_ranked.sort(reverse=True)
    if ev_ranked:
        print("\nТоп-3 паттерна по EV (min 10 срабатываний):")
        for ev, s in ev_ranked[:3]:
            print(f"  {s.name}: EV={ev:+.2f} prec={100*s.precision:.1f}% triggered={s.triggered}")


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", choices=["all", "confirmed_pump", "full_scan"], default="all")
    args = parser.parse_args()

    stats = run_confusion_matrix(source=args.source)
    if stats:
        print_report(stats, source=args.source)


if __name__ == "__main__":
    main()
