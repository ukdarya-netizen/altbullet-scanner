import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Layout } from "@/components/layout";
import Dashboard from "@/pages/dashboard";
import Tracker from "@/pages/tracker";
import Candidates from "@/pages/candidates";
import Subscribers from "@/pages/subscribers";
import GrowthLeaders from "@/pages/growth-leaders";
import OverheatLog from "@/pages/overheat-log";
import PatternDebug from "@/pages/pattern-debug";
import BotHealth from "@/pages/bot-health";
import PatternReference from "@/pages/pattern-reference";
import NotFound from "@/pages/not-found";
import { useEffect } from "react";

const queryClient = new QueryClient();

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/tracker" component={Tracker} />
        <Route path="/candidates" component={Candidates} />
        <Route path="/subscribers" component={Subscribers} />
        <Route path="/growth-leaders" component={GrowthLeaders} />
        <Route path="/overheat-log">{() => <OverheatLog />}</Route>
        <Route path="/pattern-debug" component={PatternDebug} />
        <Route path="/bot-health" component={BotHealth} />
        <Route path="/pattern-reference" component={PatternReference} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
