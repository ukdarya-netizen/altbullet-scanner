import { Badge } from "@/components/ui/badge";
import { getPatternTgLabel } from "@/lib/pattern-labels";

const PATTERN_COLORS: Record<string, string> = {
  trend_accumulation: "bg-blue-500/15 text-blue-300 border-blue-500/30",
  bullish_accumulation: "bg-green-500/15 text-green-300 border-green-500/30",
  spot_vol_accumulation: "bg-amber-400/15 text-amber-200 border-amber-400/30",
  whale_alert: "bg-blue-600/20 text-blue-200 border-blue-400/40",
  liquidation_cascade: "bg-orange-500/15 text-orange-300 border-orange-500/30",
  "4h_pullback_continuation": "bg-teal-500/15 text-teal-300 border-teal-500/30",
  price_led_momentum: "bg-purple-500/15 text-purple-300 border-purple-500/30",
  balanced_grind: "bg-slate-500/15 text-slate-300 border-slate-500/30",
  stealth_breakout: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
  demark: "bg-rose-500/15 text-rose-300 border-rose-500/30",
};

export function SentimentBadge({ sentimentKey }: { sentimentKey: string }) {
  const className =
    PATTERN_COLORS[sentimentKey] ??
    "bg-muted/30 text-muted-foreground border-border";
  return (
    <Badge
      variant="outline"
      className={`font-mono rounded-none text-xs whitespace-nowrap ${className}`}
    >
      {getPatternTgLabel(sentimentKey)}
    </Badge>
  );
}
