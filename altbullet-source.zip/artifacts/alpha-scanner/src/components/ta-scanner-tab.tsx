import { useState, useMemo } from "react";
import {
  useGetTaScanner,
  getGetTaScannerQueryKey,
} from "@workspace/api-client-react";
import type { TaScannerEntry } from "@workspace/api-client-react";
import { Activity, ArrowUpDown, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatDistanceToNow } from "date-fns";

// ─── helpers ─────────────────────────────────────────────────────────────────

function fmt(v: number | null | undefined, d = 1): string {
  if (v == null) return "—";
  return v.toFixed(d);
}

function fmtPct(v: number | null | undefined): string {
  if (v == null) return "—";
  const s = v.toFixed(1);
  return v > 0 ? `+${s}%` : `${s}%`;
}

// TD Sequential cell — positive=buy (green), negative=sell (red), |9|=reversal badge
function TdCell({ v }: { v: number | null | undefined }) {
  if (v == null) return <span className="text-gray-700">—</span>;
  const abs = Math.abs(v);
  const isBuy = v > 0;
  const isSell = v < 0;
  const isReversal = abs >= 9;
  const colorCls = isBuy
    ? "text-emerald-400"
    : isSell
      ? "text-red-400"
      : "text-gray-400";
  const label = v > 0 ? `+${v}` : `${v}`;
  if (isReversal) {
    return (
      <span
        className={`${colorCls} font-bold ring-1 ring-current rounded px-1 py-0.5 text-[10px]`}
      >
        {label}
      </span>
    );
  }
  return <span className={colorCls}>{label}</span>;
}

// EMA deviation %
function emaDevPct(
  price: number | null | undefined,
  ema: number | null | undefined,
): number | null {
  if (price == null || ema == null || ema === 0) return null;
  return ((price - ema) / ema) * 100;
}

function emaDevClass(pct: number | null): string {
  if (pct == null) return "text-gray-600";
  if (pct > 5) return "text-emerald-400 font-bold";
  if (pct > 1) return "text-green-400";
  if (pct > -1) return "text-gray-400";
  if (pct > -5) return "text-red-400";
  return "text-red-500 font-bold";
}

// MACD histogram = macd - signal
function macdHist(
  macd: number | null | undefined,
  signal: number | null | undefined,
): number | null {
  if (macd == null || signal == null) return null;
  return macd - signal;
}

function macdHistClass(hist: number | null): string {
  if (hist == null) return "text-gray-600";
  if (hist > 0) return "text-emerald-400";
  return "text-red-400";
}

// ─── types ───────────────────────────────────────────────────────────────────

type FilterKey = "all" | "td_buy" | "td_sell" | "td_reversal";

type SortKey =
  | "symbol"
  | "td1h"
  | "td4h"
  | "td1d"
  | "ema_dev"
  | "macd_hist"
  | "atr1h";

const QUICK_FILTERS: { key: FilterKey; label: string }[] = [
  { key: "all", label: "Все" },
  { key: "td_buy", label: "TD Buy" },
  { key: "td_sell", label: "TD Sell" },
  { key: "td_reversal", label: "TD ≥9 🔄" },
];

// ─── component ───────────────────────────────────────────────────────────────

interface Props {
  filterQ: string;
}

export default function TaScannerTab({ filterQ }: Props) {
  const [filterKey, setFilterKey] = useState<FilterKey>("all");
  const [sortKey, setSortKey] = useState<SortKey>("td1h");
  const [sortAsc, setSortAsc] = useState(false);

  const { data, isLoading, error, dataUpdatedAt, refetch, isFetching } =
    useGetTaScanner(
      { filter: filterKey },
      {
        query: {
          queryKey: getGetTaScannerQueryKey({ filter: filterKey }),
          refetchInterval: 30_000,
          staleTime: 25_000,
        },
      },
    );

  const rows = useMemo(() => {
    if (!data?.entries) return [];
    let items = [...data.entries] as TaScannerEntry[];

    // text search
    if (filterQ.trim()) {
      const q = filterQ.trim().toUpperCase();
      items = items.filter((e) => e.symbol.toUpperCase().includes(q));
    }

    // sort
    items.sort((a, b) => {
      let va: number | null = null;
      let vb: number | null = null;

      if (sortKey === "symbol") {
        const cmp = a.symbol.localeCompare(b.symbol);
        return sortAsc ? cmp : -cmp;
      }
      if (sortKey === "td1h") {
        va = Math.abs(a.td1h ?? 0);
        vb = Math.abs(b.td1h ?? 0);
      } else if (sortKey === "td4h") {
        va = Math.abs(a.td4h ?? 0);
        vb = Math.abs(b.td4h ?? 0);
      } else if (sortKey === "td1d") {
        va = Math.abs(a.td1d ?? 0);
        vb = Math.abs(b.td1d ?? 0);
      } else if (sortKey === "ema_dev") {
        va = emaDevPct(a.currentPrice ?? null, a.ema1h ?? null);
        vb = emaDevPct(b.currentPrice ?? null, b.ema1h ?? null);
      } else if (sortKey === "macd_hist") {
        va = macdHist(a.macd1h ?? null, a.signal1h ?? null);
        vb = macdHist(b.macd1h ?? null, b.signal1h ?? null);
      } else if (sortKey === "atr1h") {
        va = a.atr1h ?? null;
        vb = b.atr1h ?? null;
      }

      if (va == null && vb == null) return 0;
      if (va == null) return 1;
      if (vb == null) return -1;
      return sortAsc ? va - vb : vb - va;
    });

    return items;
  }, [data, filterQ, sortKey, sortAsc]);

  function onSort(key: SortKey) {
    if (sortKey === key) setSortAsc((p) => !p);
    else {
      setSortKey(key);
      setSortAsc(false);
    }
  }

  function SortTh({
    col,
    children,
    className = "",
  }: {
    col: SortKey;
    children: React.ReactNode;
    className?: string;
  }) {
    const active = sortKey === col;
    return (
      <th
        className={`px-2 py-2 text-left cursor-pointer select-none whitespace-nowrap hover:text-white transition-colors ${active ? "text-white" : "text-gray-500"} ${className}`}
        onClick={() => onSort(col)}
      >
        <span className="flex items-center gap-1">
          {children}
          {active ? (
            <span className="text-[9px]">{sortAsc ? "▲" : "▼"}</span>
          ) : (
            <ArrowUpDown className="w-2.5 h-2.5 opacity-30" />
          )}
        </span>
      </th>
    );
  }

  const updatedAgo =
    dataUpdatedAt > 0
      ? formatDistanceToNow(new Date(dataUpdatedAt), { addSuffix: true })
      : null;

  return (
    <div className="space-y-3">
      {/* ── Header ─────────────────────────────────────────────── */}
      <div className="flex flex-wrap items-center gap-2">
        <Activity className="w-4 h-4 text-violet-400 shrink-0" />
        <span className="text-xs font-semibold text-gray-300">TA Сканер</span>
        <span className="text-xs text-gray-600">
          MA · EMA · MACD · TD Sequential · ATR
        </span>

        <div className="flex-1" />

        {updatedAgo && (
          <span className="text-[10px] text-gray-600">
            обновлено {updatedAgo}
          </span>
        )}
        <Button
          size="sm"
          variant="ghost"
          className="h-6 w-6 p-0"
          onClick={() => refetch()}
          disabled={isFetching}
        >
          <RefreshCw
            className={`w-3 h-3 ${isFetching ? "animate-spin text-violet-400" : "text-gray-500"}`}
          />
        </Button>
      </div>

      {/* ── Quick filters ──────────────────────────────────────── */}
      <div className="flex flex-wrap gap-1.5">
        {QUICK_FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilterKey(f.key)}
            className={`px-2 py-0.5 rounded text-[11px] font-medium border transition-colors ${
              filterKey === f.key
                ? "bg-violet-700 border-violet-500 text-white"
                : "bg-gray-900 border-gray-700 text-gray-400 hover:border-gray-500 hover:text-gray-300"
            }`}
          >
            {f.label}
          </button>
        ))}
        <span className="ml-2 text-[11px] text-gray-600 self-center">
          {rows.length} монет
        </span>
      </div>

      {/* ── TD Legend ──────────────────────────────────────────── */}
      <div className="text-[10px] text-gray-600 leading-relaxed bg-gray-900/50 rounded px-3 py-1.5 border border-gray-800">
        <span className="text-violet-400 font-semibold">TD Sequential</span>{" "}
        (Tom DeMark): <span className="text-emerald-400">+N</span> = buy setup
        (N/9 свечей выше предыдущей закрытой),{" "}
        <span className="text-red-400">−N</span> = sell setup (N/9 ниже),{" "}
        <span className="text-emerald-400 font-bold ring-1 ring-emerald-400 rounded px-0.5">
          +9
        </span>
        {" / "}
        <span className="text-red-400 font-bold ring-1 ring-red-400 rounded px-0.5">
          −9
        </span>{" "}
        = завершённый setup → возможный разворот.
      </div>

      {/* ── Table ──────────────────────────────────────────────── */}
      {isLoading ? (
        <div className="text-center py-12 text-gray-500 text-sm">
          Загрузка данных CoinGlass…
        </div>
      ) : error ? (
        <div className="text-center py-12 text-red-400 text-sm">
          Ошибка загрузки TA данных
        </div>
      ) : rows.length === 0 ? (
        <div className="text-center py-12 text-gray-500 text-sm">
          Нет данных для текущего фильтра
        </div>
      ) : (
        <div className="overflow-x-auto rounded border border-gray-800">
          <table className="w-full text-xs min-w-[700px]">
            <thead>
              <tr className="border-b border-gray-800 bg-gray-900/80 text-gray-500 uppercase tracking-wide text-[10px]">
                <SortTh
                  col="symbol"
                  className="sticky left-0 bg-gray-900/95 backdrop-blur z-10 min-w-[80px]"
                >
                  Монета
                </SortTh>
                {/* TD group */}
                <th
                  colSpan={3}
                  className="px-2 py-1 text-center text-[9px] text-violet-500 border-l border-gray-800"
                >
                  ── TD Sequential ──
                </th>
                {/* Other */}
                <th className="px-2 py-1 text-center text-[9px] text-blue-500 border-l border-gray-800">
                  EMA1h Δ%
                </th>
                <th className="px-2 py-1 text-center text-[9px] text-teal-500 border-l border-gray-800">
                  MACD1h
                </th>
                <th className="px-2 py-1 text-center text-[9px] text-gray-500 border-l border-gray-800">
                  ATR1h
                </th>
              </tr>
              <tr className="border-b border-gray-800 bg-gray-900/60 text-gray-500 text-[10px]">
                <th className="sticky left-0 bg-gray-900/95 backdrop-blur z-10 px-2 py-1" />
                {/* TD sub-headers */}
                <SortTh
                  col="td1h"
                  className="border-l border-gray-800 text-violet-500"
                >
                  1h
                </SortTh>
                <SortTh col="td4h" className="text-violet-400">
                  4h
                </SortTh>
                <SortTh col="td1d" className="text-violet-300">
                  1d
                </SortTh>
                {/* Other sub-headers */}
                <SortTh
                  col="ema_dev"
                  className="border-l border-gray-800 text-blue-400"
                >
                  Δ%
                </SortTh>
                <SortTh
                  col="macd_hist"
                  className="border-l border-gray-800 text-teal-400"
                >
                  Hist
                </SortTh>
                <SortTh
                  col="atr1h"
                  className="border-l border-gray-800 text-gray-400"
                >
                  $
                </SortTh>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => {
                const devPct = emaDevPct(row.currentPrice, row.ema1h);
                const hist = macdHist(row.macd1h, row.signal1h);
                return (
                  <tr
                    key={row.symbol}
                    className="border-b border-gray-800/50 hover:bg-gray-800/30 transition-colors"
                  >
                    {/* Symbol */}
                    <td className="sticky left-0 bg-gray-950/95 backdrop-blur z-10 px-2 py-1.5 font-mono font-semibold text-gray-200">
                      {row.symbol}
                    </td>

                    {/* TD Sequential */}
                    <td className="px-2 py-1.5 text-right tabular-nums border-l border-gray-800/40">
                      <TdCell v={row.td1h} />
                    </td>
                    <td className="px-2 py-1.5 text-right tabular-nums">
                      <TdCell v={row.td4h} />
                    </td>
                    <td className="px-2 py-1.5 text-right tabular-nums">
                      <TdCell v={row.td1d} />
                    </td>

                    {/* EMA 1h deviation */}
                    <td
                      className={`px-2 py-1.5 text-right tabular-nums border-l border-gray-800/40 ${emaDevClass(devPct)}`}
                    >
                      {fmtPct(devPct)}
                    </td>

                    {/* MACD histogram */}
                    <td
                      className={`px-2 py-1.5 text-right tabular-nums border-l border-gray-800/40 ${macdHistClass(hist)}`}
                    >
                      {hist == null ? (
                        <span className="text-gray-700">—</span>
                      ) : (
                        <span>
                          {hist > 0 ? "▲" : "▼"} {fmt(hist, 2)}
                        </span>
                      )}
                    </td>

                    {/* ATR 1h */}
                    <td className="px-2 py-1.5 text-right tabular-nums text-gray-500 border-l border-gray-800/40">
                      {row.atr1h != null ? (
                        <span>
                          $
                          {row.atr1h >= 1000
                            ? (row.atr1h / 1000).toFixed(1) + "k"
                            : row.atr1h.toFixed(
                                row.atr1h < 1 ? 4 : row.atr1h < 10 ? 3 : 1,
                              )}
                        </span>
                      ) : (
                        <span className="text-gray-700">—</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {rows.length > 0 && (
        <p className="text-[10px] text-gray-700 text-center">
          Источник: CoinGlass · обновляется каждые 5 мин ·{" "}
          {data?.count ?? rows.length} монет из CoinGlass Futures
        </p>
      )}
    </div>
  );
}
