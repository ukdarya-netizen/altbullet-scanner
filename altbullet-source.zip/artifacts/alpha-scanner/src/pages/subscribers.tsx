import { useState, useEffect } from "react";
import {
  useGetSubscribers,
  useGetSubscriberStats,
  getGetSubscribersQueryKey,
  getGetSubscriberStatsQueryKey,
  useGetSettings,
  getGetSettingsQueryKey,
  useUpdateSettings,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Users,
  UserCheck,
  UserX,
  TrendingUp,
  Send,
  Check,
  Loader2,
} from "lucide-react";

export default function Subscribers() {
  const queryClient = useQueryClient();
  const { data, isLoading } = useGetSubscribers({
    query: { queryKey: getGetSubscribersQueryKey(), refetchInterval: 30000 },
  });
  const { data: stats } = useGetSubscriberStats({
    query: {
      queryKey: getGetSubscriberStatsQueryKey(),
      refetchInterval: 30000,
    },
  });
  const { data: settings } = useGetSettings({
    query: { queryKey: getGetSettingsQueryKey() },
  });
  const { mutateAsync: updateSettings } = useUpdateSettings();

  const [channelInput, setChannelInput] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Синхронизируем инпут с текущим значением из settings
  useEffect(() => {
    if (settings?.channelId != null) {
      setChannelInput(settings.channelId);
    }
  }, [settings?.channelId]);

  const handleSaveChannel = async () => {
    setSaving(true);
    setSaved(false);
    try {
      await updateSettings({
        data: { channelId: channelInput.trim() || null },
      });
      await queryClient.invalidateQueries({
        queryKey: getGetSettingsQueryKey(),
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold tracking-wider">
          TELEGRAM SUBSCRIBERS
        </h2>
        <p className="text-xs text-muted-foreground">
          People who sent /start to your bot
        </p>
      </div>

      {/* Channel Settings */}
      <Card className="border-border bg-card">
        <CardHeader className="border-b border-border py-4">
          <CardTitle className="text-sm font-medium tracking-wider text-muted-foreground flex items-center gap-2">
            <Send className="w-4 h-4" />
            CHANNEL BROADCAST
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <p className="text-xs text-muted-foreground mb-3">
            Канал куда бот дублирует все сигналы. Введи @username или числовой
            chat_id.
          </p>
          <div className="flex gap-2 items-center">
            <Input
              className="font-mono text-sm max-w-xs"
              placeholder="@cryptoaltsbullet"
              value={channelInput}
              onChange={(e) => {
                setChannelInput(e.target.value);
                setSaved(false);
              }}
              onKeyDown={(e) => e.key === "Enter" && handleSaveChannel()}
            />
            <Button
              size="sm"
              variant="outline"
              className="font-mono tracking-wider"
              onClick={handleSaveChannel}
              disabled={saving}
            >
              {saving ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : saved ? (
                <>
                  <Check className="w-4 h-4 text-green-500 mr-1" />
                  SAVED
                </>
              ) : (
                "SAVE"
              )}
            </Button>
          </div>
          {settings?.channelId && (
            <p className="text-xs text-muted-foreground mt-2">
              Текущий:{" "}
              <span className="text-foreground font-mono">
                {settings.channelId}
              </span>
            </p>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider">
                  TOTAL
                </p>
                <p className="text-3xl font-bold mt-2">{stats?.total ?? 0}</p>
              </div>
              <div className="p-2 bg-muted text-primary">
                <Users className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider">
                  ACTIVE
                </p>
                <p className="text-3xl font-bold mt-2 text-green-500">
                  {stats?.active ?? 0}
                </p>
              </div>
              <div className="p-2 bg-muted text-green-500">
                <UserCheck className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider">
                  NEW TODAY
                </p>
                <p className="text-3xl font-bold mt-2 text-violet-400">
                  {stats?.newToday ?? 0}
                </p>
              </div>
              <div className="p-2 bg-muted text-violet-400">
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border bg-card">
          <CardContent className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <p className="text-xs text-muted-foreground tracking-wider">
                  UNSUBSCRIBED
                </p>
                <p className="text-3xl font-bold mt-2 text-muted-foreground">
                  {stats?.inactive ?? 0}
                </p>
              </div>
              <div className="p-2 bg-muted text-muted-foreground">
                <UserX className="w-5 h-5" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-border bg-card">
        <CardHeader className="border-b border-border py-4">
          <CardTitle className="text-lg font-medium">SUBSCRIBER LIST</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex items-center justify-center h-32 text-muted-foreground">
              LOADING...
            </div>
          ) : data?.subscribers.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-muted-foreground space-y-2">
              <Users className="w-8 h-8 opacity-30" />
              <p className="text-sm">No subscribers yet.</p>
              <p className="text-xs">
                Share your bot link so people can subscribe.
              </p>
            </div>
          ) : (
            <table className="w-full text-sm">
              <thead className="sticky top-0 bg-card border-b border-border">
                <tr className="text-muted-foreground text-left">
                  <th className="px-4 py-3 font-medium">CHAT ID</th>
                  <th className="px-4 py-3 font-medium">USERNAME</th>
                  <th className="px-4 py-3 font-medium">NAME</th>
                  <th className="px-4 py-3 font-medium">STATUS</th>
                  <th className="px-4 py-3 font-medium">SUBSCRIBED</th>
                </tr>
              </thead>
              <tbody>
                {data?.subscribers.map((sub) => (
                  <tr
                    key={sub.chatId}
                    className="border-b border-border/50 hover:bg-muted/30 transition-colors"
                  >
                    <td className="px-4 py-3 font-mono text-muted-foreground">
                      {sub.chatId}
                    </td>
                    <td className="px-4 py-3 font-medium">
                      {sub.username ? (
                        `@${sub.username}`
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      {[sub.firstName, sub.lastName]
                        .filter(Boolean)
                        .join(" ") || (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      {sub.active ? (
                        <Badge
                          variant="outline"
                          className="bg-green-500/10 text-green-500 border-green-500/20 font-mono rounded-none text-xs"
                        >
                          ACTIVE
                        </Badge>
                      ) : (
                        <Badge
                          variant="outline"
                          className="bg-red-500/10 text-red-500 border-red-500/20 font-mono rounded-none text-xs"
                        >
                          STOPPED
                        </Badge>
                      )}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground font-mono text-xs">
                      {new Date(sub.subscribedAt).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
