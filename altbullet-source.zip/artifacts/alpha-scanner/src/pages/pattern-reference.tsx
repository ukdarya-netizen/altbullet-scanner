// ── Справочник паттернов — статическая страница ─────────────────────────────
// Данные взяты из PATTERNS_REFERENCE.md (27.07.2026).
// При изменении условий в коде обновить здесь вручную.

import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

// ── Типы ─────────────────────────────────────────────────────────────────────

interface PatternDef {
  key: string;
  emoji: string;
  name: string;
  englishName: string;
  exit: "direct" | "oi_watch" | "direct_or_oi_watch";
  stop: string;
  minStop?: string;
  noTouchH?: number;
  maxWatchDays?: number;
  ev?: number;
  evN?: number;
  evHit10?: number;
  evSL?: number;
  evPeak?: string;
  evNote?: string;
  updated?: string;
  conditions: string[];
  note?: string;
}

interface GroupDef {
  title: string;
  subtitle: string;
  color: string; // tailwind ring/border colour token
  patterns: PatternDef[];
}

// ── Данные паттернов ──────────────────────────────────────────────────────────

const GROUPS: GroupDef[] = [
  {
    title: "🕯 TA-Разворот",
    subtitle: "чисто технические паттерны, без OI",
    color: "border-rose-500/40",
    patterns: [
      {
        key: "demark",
        emoji: "🕯",
        name: "ДеМарк TD9 разворот",
        englishName: "Demark TD9 Buy Setup · ЭКСПЕРИМЕНТАЛЬНЫЙ",
        exit: "direct",
        stop: "−8%",
        noTouchH: 4,
        maxWatchDays: 2,
        updated: "28.07.2026",
        evNote: "эксперимент",
        conditions: [
          "td1h = 9 ИЛИ td4h = 9 (CoinGlass TA bulk: 9 баров подряд close[i] < close[i−4])",
          "Кулдаун 4ч на символ (td=9 удерживается несколько циклов, повторный огонь блокируется)",
          "cycleCount ≥ 3 (не новый листинг)",
          "price24h ≤ 40% (не перегретый)",
          "Байпас anyOiPass: чисто технический паттерн, OI не требуется",
          "__isConfirmedFire = true: не попадает в ОКНО ПОДТВЕРЖДЕНИЯ (oi_watch)",
        ],
        note: "Отмены: demark_counter_td (FastCycle: td1h ≤ −3 → sell-setup формируется → разворот провалился); stale_oi_vol; smart_cancel_oi_taker. Стоп ≈ 2×ATR_1h, кап −8%. Данные через ta-cache.ts (watcher→scanner bridge).",
      },
    ],
  },
  {
    title: "⚡ Скальп / Разворот",
    subtitle: "< 2ч",
    color: "border-orange-500/40",
    patterns: [
      {
        key: "liquidation_cascade",
        emoji: "💥",
        name: "Каскад ликвидаций",
        englishName: "Liquidation Cascade · Layer 10",
        exit: "direct",
        stop: "−10%",
        updated: "15.07.2026",
        evNote: "в сборе",
        conditions: [
          "Вход в пул (liq_spike): longLiq1h/longLiq24h ≥ 25% + longLiq1h > $50K + price24h ≤ 5%",
          "Вход в пул (liq_order_stream): ≥ 3 long-liq ордера ≥ $10K за 15 мин",
          "liqExhausted = true (fail-closed — null → ждём; false → блок)",
          "Пул ≥ 30 мин выдержан (кроме liq_order_stream)",
          "OI 30m > 1.5% или null (fail-open)",
          "CVD 30m не false (fail-open)",
          "price24h не обвал (> −50%)",
        ],
        note: "Источник: liq-cascade-watcher.ts, каждые 3 мин независимо от скана.",
      },
    ],
  },
  {
    title: "📅 Интрадей — Прямые сигналы",
    subtitle: "4–24ч",
    color: "border-blue-500/40",
    patterns: [
      {
        key: "spot_vol_accumulation",
        emoji: "📊🌊",
        name: "Спот объём накопление",
        englishName: "Spot Vol Accumulation",
        exit: "direct",
        stop: "−5%",
        updated: "27.07.2026",
        ev: 3.6,
        evN: 22,
        evHit10: 41,
        evSL: 9,
        evPeak: "11.7%",
        conditions: [
          "spotVolMult ≥ 2.5× (прескан) + ≥ 3 циклов со спот-данными",
          "cycleCount ≥ 10 (победители avg=24, стопы avg=6)",
          "OI: fail-open — только OI4h < −3% (дистрибуция) блокирует",
          "OI1h: CG доступен + OI1h < −1% → блок (fail-open если нет CG)",
          "SpotCVD 1h — обязателен; CVD 4h — fail-open",
          "SpotVol24h ≥ 1.5% MCap",
          "price24h: −10%…+20%",
          "price1h ≥ 0% или null (fail-open)",
          "Cooldown 4ч; блок 12ч после stop_loss",
        ],
      },
      {
        key: "4h_pullback_continuation",
        emoji: "🔻📈",
        name: "Коррекция в тренде",
        englishName: "4H Pullback Continuation · v3",
        exit: "direct",
        stop: "−6%",
        updated: "27.07.2026",
        evNote: "в сборе",
        conditions: [
          "price24h: 1%…25% (суточный тренд восходящий)",
          "price4h ≤ −1.0% (реальный откат; ретро median −1.43%)",
          "Путь A: OI4h доступен + отрицательный предыдущего цикла + улучшается",
          "Путь B: OI4h null (CG-таймаут) → OI30m ≥ 0.1% как прокси",
          "OI30m ≥ 0 или null (fail-open)",
          "volMult ≥ 0.3× (в откате объём снижен естественно)",
          "cycleCount ≥ 3",
        ],
        note: "PDB-причины отказа: price24h_range / no_pullback / oi4h_not_neg / oi4h_not_improving / vol_cycles_low",
      },
      {
        key: "price_led_momentum",
        emoji: "🟡",
        name: "Цена без OI",
        englishName: "Price-Led Momentum · Архетип C (~11.8%)",
        exit: "direct",
        stop: "−6%",
        updated: "27.07.2026",
        evNote: "в сборе",
        conditions: [
          "price3h ≥ 2.5% + price4h ≥ 2.5% (синхронный ценовой импульс)",
          "OI4h < 3.0% или null (fail-open) — деривативы не накоплены",
          "OI30m < 2.5% или null (fail-open) — цена опережает OI",
          "price24h ≤ 35%",
          "cycleCount ≥ 2",
        ],
        note: "PDB-причины отказа: price_low / oi4h_high / oi30m_high / p24h_or_cycles",
      },
      {
        key: "balanced_grind",
        emoji: "🟢",
        name: "Умеренный широкий рост",
        englishName: "Balanced Grind · Архетип F (~32.3%)",
        exit: "direct",
        stop: "−10%",
        updated: "27.07.2026",
        evNote: "в сборе",
        conditions: [
          "OI30m: 0.1%–3.5% (не null; CG-данные нужны)",
          "OI1h: не обязателен — если есть, ≤ 4.0% (убран из gate 27.07)",
          "OI4h (путь A): доступен в диапазоне 0.3%–8.0%",
          "OI4h (путь B): null или < 0.3% + cycleCount ≥ 5 (slow-build без явного OI4h)",
          "price3h: 0.5%–5.0%",
          "volMult ≥ 0.8× или null (fail-open)",
          "price24h ≤ 30%; cycleCount ≥ 3",
        ],
        note: "PDB-причины отказа: oi30m_range / oi4h_range / price_or_vol",
      },
      {
        key: "stealth_breakout",
        emoji: "⚪",
        name: "Пробой из тихой зоны",
        englishName: "Stealth Breakout · Архетип E (~12.7%)",
        exit: "direct",
        stop: "−5%",
        updated: "27.07.2026",
        evNote: "в сборе",
        conditions: [
          "prevOI4h < 2.0% или null (fail-open если CG покрыт) — предыдущий цикл тихий",
          "Триггер A: ΔOI4h = lastOI4h − prevOI4h > +1.5 pp (было 3.0pp)",
          "Триггер B: volAccel ≥ 1.5× + lastVol ≥ 1.0× (ускорение объёма)",
          "price24h ≤ 40%; cycleCount ≥ 2",
          "⚠️ prevOI4h=null допустим только при cgNoDataCount < 3 (CG покрытие есть)",
        ],
        note: "PDB-причины отказа: cg_no_data / no_breakout / p24h_or_cycles",
      },
    ],
  },
  {
    title: "📊 Свинг — OI Watch",
    subtitle: "накопление → дозревание 0–6ч",
    color: "border-violet-500/40",
    patterns: [
      {
        key: "trend_accumulation",
        emoji: "📈🔥",
        name: "Трендовое накопление",
        englishName: "Trend Accumulation",
        exit: "oi_watch",
        stop: "−10%",
        updated: "19.07.2026",
        ev: 1.2,
        evN: 34,
        evHit10: 26,
        evSL: 18,
        evPeak: "7.0%",
        conditions: [
          "OI30m ≥ 3.5% (текущий цикл)",
          "prevOI30m ≥ 0.3% или null (fail-open) — два цикла накопления",
          "Цена (30m) ≥ +1.0% (тренд направленный)",
          "price24h ≤ 20%; volMult ≥ 0.5× (detectSentiment); futVol ≥ 0.4× (scanner gate)",
          "Funding rate 7d > 0.01% → skip (лонги перегреты)",
          "Archetype bonus: footprint buyAtAskPct ≥ 55% → alphaScore +1 (fail-open)",
        ],
        note: "Выход через OI Watch PATH A: price confirm +1.5–2% от entry.",
      },
      {
        key: "bullish_accumulation",
        emoji: "📊",
        name: "Бычье накопление",
        englishName: "Bullish Accumulation · fallback",
        exit: "direct_or_oi_watch",
        stop: "−10%",
        updated: "27.07.2026",
        ev: 0.4,
        evN: 18,
        evHit10: 33,
        evSL: 33,
        evPeak: "9.7%",
        evNote: "до фильтров 19.07",
        conditions: [
          "OI floor: cgOI30m ≥ 3.5% ИЛИ OI1h ≥ 2.0% ИЛИ OI4h ≥ 2.5% (≥ 1 TF)",
          "Two-cycle: prevOI30m > −0.3% или null (fail-open)",
          "Vol: с CG OI ≥ 3.5% → ≥ 1.0×; без CG OI → ≥ 1.8×",
          "OI1h < 0% → блок; OI4h < −5% → блок",
          "cycleCount ≤ 25; price24h ≤ 10%",
          "SpotCVD 1h явно false при CG available → блок",
        ],
        note: "Fallback: срабатывает если ни один специфичный паттерн не подошёл.",
      },
    ],
  },
  {
    title: "🐋 Среднесрок / Китовые",
    subtitle: "дни–недели",
    color: "border-cyan-500/40",
    patterns: [
      {
        key: "whale_alert",
        emoji: "🐋🎯",
        name: "Кит открыл лонг",
        englishName: "Whale Alert · Hyperliquid · Layer 11",
        exit: "direct",
        stop: "−8%",
        minStop: "−4%",
        noTouchH: 4,
        maxWatchDays: 14,
        updated: "27.07.2026",
        evNote: "—",
        conditions: [
          "Источник: Hyperliquid whale-alert, лонг ≥ $500K, BTC/ETH исключены, дедуп кит+токен 6ч",
          "price24h ≤ 20%; priceChange от whale entry ≥ −1%",
          "Cooldown по адресу кита: закрывал позицию < 4ч назад → skip",
          "Liq proximity: цена в пределах 8% от liqPrice кита → skip (fail-open если null)",
          "OI подтверждение: OI30m ≥ 1.5% ИЛИ OI1h ≥ 2.0%",
          "Альтернатива: FutTaker ≥ 10% + SpotCVD 1h positive",
          "Confirm lag cap: кит держит > 3ч + priceChange < 0.5% → skip",
          "Крупные лимитники false → блок; null = fail-open",
        ],
        note: "Выход: whale-профиль 8% / trailing с 12% / gap 7%. Max watch 14 дней. HL Position Tracking каждые 15 мин.",
      },
    ],
  },
];

// ── OI Watch пути ─────────────────────────────────────────────────────────────

const OI_WATCH_PATHS = [
  {
    path: "PATH A",
    condition:
      "vol ≥ 2× при скане → ждём цену +1.5–2% от entry + SpotVol ≥ 0.15% MCap; CVD негативный → откладываем; CVD null → проходит",
    window: "6 ч",
  },
  {
    path: "PATH B",
    condition:
      "vol < 2× → ждём объём: CG turnover ≥ 15% ИЛИ спот vol ≥ 1.5× ИЛИ vol вырос ≥ 1.8× + SpotCVD (30m ИЛИ 1h); цена −4%…+20%; OI при fire ≥ 3%; CVD 1h+4h оба false → отменяем",
    window: "6 ч",
  },
  {
    path: "cg_timeout",
    condition: "Топ-активный + CG таймаут + vol ≥ 1.3× + cycleCount ≥ 3",
    window: "12 ч",
  },
  {
    path: "cg_building",
    condition: "2+ TF с OI 2–5% (ниже порога) + vol ≥ 1.5×",
    window: "12 ч",
  },
  {
    path: "dark_flow",
    condition:
      "CG есть, OI не растёт + cycleCount ≥ 3 + vol ≥ 2× + price24h < 15%",
    window: "6 ч",
  },
  {
    path: "tSteady",
    condition:
      "OI30m ≥ 2.0% (медленный рост) + spotVolMult ≥ 1.2× + токен ≥ 30 мин в прескане",
    window: "6 ч",
  },
];

// ── Удалённые паттерны ────────────────────────────────────────────────────────

const DELETED_PATTERNS = [
  {
    key: "flush_reversal",
    date: "июль 2026",
    reason:
      "Удалён из SentimentKey и scanner.ts; условия поглощены другими паттернами",
  },
  {
    key: "ob_smart_accumulation",
    date: "24.07.2026",
    reason: "L14/spot_ob_pool удалён; бэктест не собран",
  },
  {
    key: "whale_futures / whale_futures_early",
    date: "июль 2026",
    reason: "EV −0.2; 72 сигн. · 9% hit+10% · 13% SL",
  },
  {
    key: "whale_onchain",
    date: "июль 2026",
    reason: "Инжект-слой полностью удалён из codebase",
  },
  {
    key: "impulse_buy",
    date: "19.07.2026",
    reason: "EV −2.3; 0/12 hit+10%, 50% SL; поздний вход (price3h≥8%)",
  },
  {
    key: "whale_watch",
    date: "19.07.2026",
    reason: "Отрицательный/незначимый EV 90д",
  },
  {
    key: "liq_magnet_squeeze / exchange_outflow_accum",
    date: "19.07.2026",
    reason: "Незначимый EV 90д",
  },
  {
    key: "oversold_reversal / smart_money_divergence",
    date: "19.07.2026",
    reason: "Незначимый EV 90д",
  },
  {
    key: "4h_momentum / oi1h_breakout / oi4h_silent_accum",
    date: "19.07.2026",
    reason: "Незначимый EV 90д",
  },
  {
    key: "quiet_trend_rider",
    date: "19.07.2026",
    reason: "PDB-лог без сигналов",
  },
  {
    key: "spot_absorption / early_vol_oi / spot_divergence",
    date: "18.07.2026",
    reason: "0 сигналов за 753 ретроспективных кейса",
  },
  {
    key: "quiet_oi_accumulation / volume_taker / spot_oi4h_build",
    date: "18.07.2026",
    reason: "0 сигналов за 753 ретроспективных кейса",
  },
  {
    key: "spot_trend_accumulation / short_squeeze / spot_taker_lead",
    date: "18.07.2026",
    reason: "0 сигналов за 753 ретроспективных кейса",
  },
  {
    key: "spot_vol_breakout / accumulation_breakout",
    date: "18.07.2026",
    reason: "0 сигналов за 753 ретроспективных кейса",
  },
  {
    key: "dip_accumulation",
    date: "18.07.2026",
    reason: "det=null (отключён); low-fire с RSI gate",
  },
  {
    key: "oi24h_accumulation",
    date: "15.07.2026",
    reason: "Море ложных сигналов; EV отрицательный",
  },
];

// ── Вспомогательные компоненты ────────────────────────────────────────────────

const PATTERN_BORDER: Record<string, string> = {
  demark: "border-rose-500/30",
  liquidation_cascade: "border-orange-500/30",
  spot_vol_accumulation: "border-amber-400/30",
  "4h_pullback_continuation": "border-teal-500/30",
  price_led_momentum: "border-yellow-500/30",
  balanced_grind: "border-green-500/30",
  stealth_breakout: "border-zinc-500/30",
  trend_accumulation: "border-blue-500/30",
  bullish_accumulation: "border-green-500/30",
  whale_alert: "border-cyan-400/30",
};

const PATTERN_BADGE: Record<string, string> = {
  demark: "bg-rose-500/15 text-rose-300 border-rose-500/30",
  liquidation_cascade: "bg-orange-500/15 text-orange-300 border-orange-500/30",
  spot_vol_accumulation: "bg-amber-400/15 text-amber-200 border-amber-400/30",
  "4h_pullback_continuation": "bg-teal-500/15 text-teal-300 border-teal-500/30",
  price_led_momentum: "bg-yellow-500/15 text-yellow-200 border-yellow-500/30",
  balanced_grind: "bg-green-500/15 text-green-300 border-green-500/30",
  stealth_breakout: "bg-zinc-500/15 text-zinc-300 border-zinc-500/30",
  trend_accumulation: "bg-blue-500/15 text-blue-300 border-blue-500/30",
  bullish_accumulation: "bg-green-600/15 text-green-200 border-green-600/30",
  whale_alert: "bg-cyan-600/20 text-cyan-200 border-cyan-400/40",
};

function ExitBadge({ exit }: { exit: PatternDef["exit"] }) {
  if (exit === "direct")
    return (
      <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
        прямой
      </span>
    );
  if (exit === "oi_watch")
    return (
      <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-violet-500/10 text-violet-300 border border-violet-500/20">
        OI Watch
      </span>
    );
  return (
    <span className="text-xs font-mono px-1.5 py-0.5 rounded bg-violet-500/10 text-violet-300 border border-violet-500/20">
      прямой / OI Watch
    </span>
  );
}

function EvBadge({
  ev,
  n,
  hit10,
  sl,
  peak,
  note,
}: {
  ev?: number;
  n?: number;
  hit10?: number;
  sl?: number;
  peak?: string;
  note?: string;
}) {
  if (note && ev == null) {
    return <span className="text-xs text-zinc-500 italic">{note}</span>;
  }
  if (ev == null) return null;
  const color =
    ev >= 2
      ? "text-green-400"
      : ev >= 1
        ? "text-yellow-400"
        : ev >= 0
          ? "text-zinc-300"
          : "text-red-400";
  const bgColor =
    ev >= 2
      ? "bg-green-500/10 border-green-500/20"
      : ev >= 1
        ? "bg-yellow-500/10 border-yellow-500/20"
        : ev >= 0
          ? "bg-zinc-500/10 border-zinc-500/20"
          : "bg-red-500/10 border-red-500/20";
  return (
    <div className="flex items-center gap-2 flex-wrap">
      <span
        className={cn(
          "text-xs font-mono px-1.5 py-0.5 rounded border font-semibold",
          bgColor,
          color,
        )}
      >
        EV {ev >= 0 ? "+" : ""}
        {ev.toFixed(1)}
      </span>
      {n != null && (
        <span className="text-xs text-zinc-500">
          {n} сигн. · {hit10}% hit+10% · {sl}% SL · avg_peak {peak}
          {note ? ` (${note})` : ""}
        </span>
      )}
    </div>
  );
}

function PatternCard({ p }: { p: PatternDef }) {
  const border = PATTERN_BORDER[p.key] ?? "border-zinc-700/50";
  const badge =
    PATTERN_BADGE[p.key] ?? "bg-zinc-700/30 text-zinc-300 border-zinc-600/30";

  return (
    <div className={cn("rounded border bg-card/40 p-4 space-y-3", border)}>
      {/* Header */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="space-y-1">
          <Badge
            variant="outline"
            className={cn("font-mono rounded-none text-xs", badge)}
          >
            {p.emoji} {p.name}
          </Badge>
          <div className="text-xs text-zinc-500">{p.englishName}</div>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          <ExitBadge exit={p.exit} />
          <span className="text-xs font-mono text-red-400">стоп {p.stop}</span>
          {p.minStop && (
            <span className="text-xs text-zinc-500">min {p.minStop}</span>
          )}
          {p.noTouchH && (
            <span className="text-xs text-zinc-500">
              no-touch {p.noTouchH}ч
            </span>
          )}
          {p.maxWatchDays && (
            <span className="text-xs text-zinc-500">max {p.maxWatchDays}д</span>
          )}
        </div>
      </div>

      {/* EV */}
      <EvBadge
        ev={p.ev}
        n={p.evN}
        hit10={p.evHit10}
        sl={p.evSL}
        peak={p.evPeak}
        note={p.evNote}
      />

      {/* Conditions */}
      <ul className="space-y-1">
        {p.conditions.map((c, i) => (
          <li
            key={i}
            className="flex gap-2 text-xs text-zinc-300 leading-relaxed"
          >
            <span className="text-zinc-600 shrink-0 mt-0.5">·</span>
            <span>{c}</span>
          </li>
        ))}
      </ul>

      {/* Note */}
      {p.note && (
        <p className="text-xs text-zinc-500 border-t border-zinc-800 pt-2 leading-relaxed">
          {p.note}
        </p>
      )}

      {/* Updated */}
      {p.updated && (
        <div className="text-xs text-zinc-600">обновлено {p.updated}</div>
      )}
    </div>
  );
}

// ── Основная страница ─────────────────────────────────────────────────────────

export default function PatternReference() {
  return (
    <div className="max-w-5xl mx-auto space-y-10 pb-12">
      {/* Title + glossary */}
      <div className="space-y-4">
        <div className="flex items-baseline gap-3">
          <h2 className="text-2xl font-bold">Справочник паттернов</h2>
          <span className="text-sm text-zinc-500">
            BingX AltBullet · 28.07.2026
          </span>
        </div>

        {/* Glossary */}
        <div className="rounded border border-zinc-800 bg-card/30 p-4 grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-1">
          {[
            ["OI", "открытый интерес (Open Interest, CoinGlass)"],
            ["volMult", "фьюч. объём BingX / 20-свечное среднее"],
            ["spotVolMult", "спотовый объём BingX / среднее (приоритет)"],
            ["SpotCVD", "спотовая дельта покупок/продаж (CG, ТФ: 30m/1h/4h)"],
            ["FutTaker", "netBuyPct фьюч. тейкеров (агрег. по биржам)"],
            ["cycleCount", "циклов токен в пуле (~10 мин каждый)"],
            ["fail-open", "если данные null — гейт не блокирует"],
            ["fail-closed", "если данные null — гейт блокирует (не стреляем)"],
          ].map(([term, def]) => (
            <div key={term} className="flex gap-2 text-xs">
              <span className="font-mono text-zinc-300 shrink-0 w-24">
                {term}
              </span>
              <span className="text-zinc-500">{def}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Pattern groups */}
      {GROUPS.map((group) => (
        <section key={group.title} className="space-y-4">
          <div className={cn("border-l-2 pl-3", group.color)}>
            <div className="text-base font-semibold">{group.title}</div>
            <div className="text-xs text-zinc-500">{group.subtitle}</div>
          </div>
          <div className="space-y-3">
            {group.patterns.map((p) => (
              <PatternCard key={p.key} p={p} />
            ))}
          </div>
        </section>
      ))}

      {/* OI Watch table */}
      <section className="space-y-3">
        <div className="border-l-2 border-violet-500/40 pl-3">
          <div className="text-base font-semibold">
            👁 OI Watch — пути дозревания
          </div>
          <div className="text-xs text-zinc-500">watcher.ts, каждые 2 мин</div>
        </div>
        <div className="rounded border border-zinc-800 overflow-hidden">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-zinc-800 bg-zinc-900/60">
                <th className="text-left px-3 py-2 font-mono text-zinc-400 w-28">
                  Путь
                </th>
                <th className="text-left px-3 py-2 text-zinc-400">Условие</th>
                <th className="text-right px-3 py-2 text-zinc-400 w-16">
                  Окно
                </th>
              </tr>
            </thead>
            <tbody>
              {OI_WATCH_PATHS.map((row, i) => (
                <tr
                  key={row.path}
                  className={cn(
                    "border-b border-zinc-800/50 last:border-0",
                    i % 2 === 0 ? "bg-transparent" : "bg-zinc-900/20",
                  )}
                >
                  <td className="px-3 py-2 font-mono text-violet-300">
                    {row.path}
                  </td>
                  <td className="px-3 py-2 text-zinc-400 leading-relaxed">
                    {row.condition}
                  </td>
                  <td className="px-3 py-2 text-right text-zinc-500 font-mono">
                    {row.window}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Stop-loss table */}
      <section className="space-y-3">
        <div className="border-l-2 border-red-500/40 pl-3">
          <div className="text-base font-semibold">
            🔒 Стоп-лоссы по паттернам
          </div>
          <div className="text-xs text-zinc-500">
            PATTERN_MAX_STOP · watcher-config.ts
          </div>
        </div>
        <div className="rounded border border-zinc-800 overflow-hidden">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-zinc-800 bg-zinc-900/60">
                <th className="text-left px-3 py-2 text-zinc-400">Паттерн</th>
                <th className="text-right px-3 py-2 text-zinc-400">Max стоп</th>
                <th className="text-right px-3 py-2 text-zinc-400">Min стоп</th>
                <th className="text-right px-3 py-2 text-zinc-400">No-touch</th>
              </tr>
            </thead>
            <tbody>
              {[
                {
                  name: "spot_vol_accumulation",
                  stop: "−5%",
                  min: "—",
                  nt: "2ч",
                },
                { name: "stealth_breakout", stop: "−5%", min: "—", nt: "2ч" },
                {
                  name: "4h_pullback_continuation",
                  stop: "−6%",
                  min: "—",
                  nt: "2ч",
                },
                { name: "price_led_momentum", stop: "−6%", min: "—", nt: "2ч" },
                { name: "whale_alert", stop: "−8%", min: "−4%", nt: "4ч" },
                { name: "demark", stop: "−8%", min: "—", nt: "4ч" },
                {
                  name: "liquidation_cascade",
                  stop: "−10%",
                  min: "—",
                  nt: "2ч",
                },
                {
                  name: "Все остальные",
                  stop: "−10% (глобальный)",
                  min: "—",
                  nt: "2ч",
                },
              ].map((row, i) => (
                <tr
                  key={row.name}
                  className={cn(
                    "border-b border-zinc-800/50 last:border-0",
                    i % 2 === 0 ? "bg-transparent" : "bg-zinc-900/20",
                  )}
                >
                  <td className="px-3 py-2 font-mono text-zinc-300">
                    {row.name}
                  </td>
                  <td className="px-3 py-2 text-right text-red-400 font-mono">
                    {row.stop}
                  </td>
                  <td className="px-3 py-2 text-right text-zinc-500">
                    {row.min}
                  </td>
                  <td className="px-3 py-2 text-right text-zinc-500">
                    {row.nt}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Deleted patterns */}
      <section className="space-y-3">
        <div className="border-l-2 border-zinc-600/40 pl-3">
          <div className="text-base font-semibold text-zinc-400">
            📋 Удалённые паттерны
          </div>
          <div className="text-xs text-zinc-600">
            ключи сохранены для истории в DB
          </div>
        </div>
        <div className="rounded border border-zinc-800/60 overflow-hidden">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-zinc-800 bg-zinc-900/40">
                <th className="text-left px-3 py-2 text-zinc-500">Ключ</th>
                <th className="text-left px-3 py-2 text-zinc-500 w-28">
                  Удалён
                </th>
                <th className="text-left px-3 py-2 text-zinc-500">Причина</th>
              </tr>
            </thead>
            <tbody>
              {DELETED_PATTERNS.map((row, i) => (
                <tr
                  key={row.key}
                  className={cn(
                    "border-b border-zinc-800/30 last:border-0",
                    i % 2 === 0 ? "bg-transparent" : "bg-zinc-900/10",
                  )}
                >
                  <td className="px-3 py-2 font-mono text-zinc-500">
                    {row.key}
                  </td>
                  <td className="px-3 py-2 text-zinc-600">{row.date}</td>
                  <td className="px-3 py-2 text-zinc-600">{row.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
