import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectGroup,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { SignalBadge } from "@/components/signal-badge";
import { SentimentBadge } from "@/components/sentiment-badge";
import { useToast } from "@/hooks/use-toast";
import {
  Trophy,
  BarChart2,
  RefreshCw,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  History,
} from "lucide-react";
import { SymbolHistorySheet } from "@/components/symbol-history-sheet";
import { ACTIVE_PATTERN_KEYS, getPatternTgLabel } from "@/lib/pattern-labels";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const PAGE_SIZE = 50;

async function fetchTracked() {
  const res = await fetch(`${API_BASE}/api/tracker?limit=100`, {
    cache: "no-store",
  });
  return res.json();
}

async function fetchSignalHistory(
  status: string,
  page: number,
  pattern: string,
  symbol: string,
) {
  const offset = (page - 1) * PAGE_SIZE;
  const params = new URLSearchParams({
    limit: String(PAGE_SIZE),
    offset: String(offset),
  });
  if (status !== "all") params.set("status", status);
  if (pattern !== "all") params.set("pattern", pattern);
  if (symbol.trim()) params.set("symbol", symbol.trim());
  const res = await fetch(`${API_BASE}/api/tracker/signal-history?${params}`, {
    cache: "no-store",
  });
  return res.json();
}

async function fetchStats() {
  const res = await fetch(`${API_BASE}/api/tracker/stats`, {
    cache: "no-store",
  });
  return res.json();
}

async function fetchCancelledToday() {
  const res = await fetch(`${API_BASE}/api/tracker/cancelled-today`, {
    cache: "no-store",
  });
  return res.json();
}

async function triggerCycle() {
  const res = await fetch(`${API_BASE}/api/tracker/run-cycle`, {
    method: "POST",
  });
  return res.json();
}

function fmtPrice(p: number | null | undefined): string {
  if (p == null) return "—";
  if (p >= 100) return `$${p.toFixed(2)}`;
  if (p >= 1) return `$${p.toFixed(4)}`;
  if (p >= 0.01) return `$${p.toFixed(5)}`;
  return `$${p.toFixed(6)}`;
}

function ageStr(date: string | Date): string {
  const ms = Date.now() - new Date(date).getTime();
  const h = ms / 3_600_000;
  if (h < 1) return `${Math.round(h * 60)}m`;
  if (h < 48) return `${h.toFixed(0)}h`;
  return `${(h / 24).toFixed(1)}d`;
}

function fmtDT(date: string | Date): string {
  return new Date(date).toLocaleString("ru-RU", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatNum(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(0)}K`;
  return n.toFixed(0);
}

const STATUS_CFG: Record<
  string,
  {
    label: string;
    icon: string;
    textCls: string;
    rowCls: string;
    borderCls: string;
  }
> = {
  active: {
    label: "ACTIVE",
    icon: "🟡",
    textCls: "text-zinc-300",
    rowCls: "",
    borderCls: "border-zinc-700/50",
  },
  in_run: {
    label: "IN RUN",
    icon: "🚀",
    textCls: "text-orange-300",
    rowCls: "bg-orange-950/20",
    borderCls: "border-l-2 border-l-orange-500",
  },
  accumulation: {
    label: "ACCUM",
    icon: "🔵",
    textCls: "text-blue-300",
    rowCls: "bg-blue-950/10",
    borderCls: "border-zinc-700/50",
  },
  re_entry: {
    label: "RE-ENTRY",
    icon: "🔄",
    textCls: "text-purple-300",
    rowCls: "bg-purple-950/10",
    borderCls: "border-zinc-700/50",
  },
  profit: {
    label: "PROFIT",
    icon: "✅",
    textCls: "text-green-400",
    rowCls: "bg-green-950/10",
    borderCls: "border-zinc-700/50",
  },
  stop_loss: {
    label: "STOP",
    icon: "❌",
    textCls: "text-red-400",
    rowCls: "bg-red-950/10",
    borderCls: "border-zinc-700/50",
  },
  breakeven: {
    label: "B/E",
    icon: "⚖️",
    textCls: "text-yellow-500",
    rowCls: "",
    borderCls: "border-zinc-700/50",
  },
  bu_stop: {
    label: "BU STOP",
    icon: "🎯",
    textCls: "text-emerald-300",
    rowCls: "bg-emerald-950/10",
    borderCls: "border-zinc-700/50",
  },
  cancelled: {
    label: "CANCEL",
    icon: "🚫",
    textCls: "text-zinc-500",
    rowCls: "bg-zinc-900/30 opacity-60",
    borderCls: "border-zinc-700/50",
  },
};

function StatusBadge({ status }: { status: string | null }) {
  const cfg = status
    ? (STATUS_CFG[status] ?? STATUS_CFG.active)
    : STATUS_CFG.active;
  return (
    <Badge
      variant="outline"
      className={`font-mono rounded-none text-[10px] font-bold border-zinc-700/50 ${cfg.textCls}`}
    >
      {cfg.icon} {cfg.label}
    </Badge>
  );
}

function PnlCell({
  value,
  bold,
}: {
  value: number | null | undefined;
  bold?: boolean;
}) {
  if (value == null) return <span className="text-muted-foreground">—</span>;
  const cls = value >= 0 ? "text-green-400" : "text-red-400";
  return (
    <span
      className={`font-mono ${bold ? "font-bold text-sm" : "text-xs"} ${cls}`}
    >
      {value > 0 ? "+" : ""}
      {value.toFixed(2)}%
    </span>
  );
}

function OiCell({ value }: { value: number | null | undefined }) {
  if (value == null) return <span className="text-border text-[10px]">—</span>;
  const cls =
    value >= 5
      ? "text-green-400 font-semibold"
      : value > 0
        ? "text-green-400/70"
        : value < -3
          ? "text-red-400 font-semibold"
          : "text-red-400/60";
  return (
    <span className={`font-mono text-[10px] ${cls}`}>
      {value >= 0 ? "+" : ""}
      {value.toFixed(1)}%
    </span>
  );
}

function CvdDot({ value }: { value: boolean | null | undefined }) {
  if (value == null) return <span className="text-border text-[10px]">—</span>;
  return value ? (
    <span className="text-green-400 font-bold text-xs">✓</span>
  ) : (
    <span className="text-red-400/60 text-xs">✗</span>
  );
}

function LiqCell({ value }: { value: number | null | undefined }) {
  if (value == null) return <span className="text-border text-[10px]">—</span>;
  return (
    <span className="font-mono text-[10px] text-orange-300/80">
      ${formatNum(value)}
    </span>
  );
}

function LiqRCell({ value }: { value: number | null | undefined }) {
  if (value == null) return <span className="text-border text-[10px]">—</span>;
  const pct = value * 100;
  const cls =
    pct >= 25 ? "text-orange-300 font-semibold" : "text-muted-foreground";
  return (
    <span className={`font-mono text-[10px] ${cls}`}>{pct.toFixed(0)}%</span>
  );
}

function LiqTriggerCell({ value }: { value: string | null | undefined }) {
  if (!value) return <span className="text-border text-[10px]">—</span>;
  const label =
    value === "liq_order_stream"
      ? "stream"
      : value === "liq_spike"
        ? "spike"
        : value;
  const cls =
    value === "liq_order_stream" ? "text-purple-400" : "text-orange-400";
  return <span className={`font-mono text-[9px] ${cls}`}>{label}</span>;
}
function ObCell({ value }: { value: number | null | undefined }) {
  if (value == null) return <span className="text-muted-foreground/30">—</span>;
  const cls =
    value >= 2.0
      ? "text-green-400"
      : value >= 1.3
        ? "text-green-400/70"
        : value < 0.8
          ? "text-red-400"
          : "text-muted-foreground";
  return (
    <span className={`font-mono text-[10px] ${cls}`}>{value.toFixed(1)}x</span>
  );
}

// ── SNF helpers ────────────────────────────────────────────────────────────────
interface SnfEntry {
  netPct1h: number | null;
  netPct4h: number | null;
  netPct24h: number | null;
  netPct7d: number | null;
}

function toCgBase(s: string): string {
  const b = s.replace("-USDT", "");
  return /^1000[A-Z]/.test(b) ? b.slice(4).toUpperCase() : b.toUpperCase();
}

function snfCell(pct: number | null) {
  if (pct == null) return <span className="text-border/40 text-[10px]">—</span>;
  const cls =
    pct >= 15
      ? "text-emerald-400 font-semibold"
      : pct >= 5
        ? "text-emerald-400/80"
        : pct >= 0
          ? "text-emerald-400/50"
          : pct >= -5
            ? "text-red-400/50"
            : pct >= -15
              ? "text-red-400/80"
              : "text-red-400 font-semibold";
  return (
    <span className={`font-mono text-[11px] ${cls}`}>
      {pct >= 0 ? "+" : ""}
      {pct.toFixed(1)}%
    </span>
  );
}

// Приоритет: stored entry-time value → live snfMap (для активных без stored values).
// Для исторических/отменённых/закрытых сигналов live snfMap пустой → всегда used stored.
function snfCells(s: any, snfMap: Map<string, SnfEntry>) {
  const live = snfMap.get(toCgBase(s.symbol));
  return (
    <>
      <td className="px-2 py-2 text-right">
        {snfCell(s.entrySpotNetBuy1h ?? live?.netPct1h ?? null)}
      </td>
      <td className="px-2 py-2 text-right">
        {snfCell(s.entrySpotNetBuy4h ?? live?.netPct4h ?? null)}
      </td>
      <td className="px-2 py-2 text-right">
        {snfCell(s.entrySpotNetBuy24h ?? live?.netPct24h ?? null)}
      </td>
    </>
  );
}

// ── Блок открытых позиций (= trackedSignalsTable) ─────────────────────────────
function OpenPositions({
  data,
  isLoading,
  isError,
  onRetry,
  signals: sigOverride,
  snfMap,
  onSelectSymbol,
}: {
  data: any;
  isLoading: boolean;
  isError: boolean;
  onRetry: () => void;
  signals?: any[];
  snfMap: Map<string, SnfEntry>;
  onSelectSymbol?: (sym: string) => void;
}) {
  const open =
    sigOverride ??
    (data?.signals ?? []).filter((s: any) =>
      ["active", "in_run", "accumulation", "re_entry"].includes(s.status),
    );

  if (isLoading)
    return (
      <div className="flex items-center justify-center h-16 text-muted-foreground text-sm">
        Загрузка...
      </div>
    );

  if (isError)
    return (
      <div className="flex items-center gap-4 px-4 py-4 text-sm">
        <span className="text-red-400">
          ⚠️ Ошибка загрузки позиций (нет связи с БД)
        </span>
        <Button
          variant="outline"
          size="sm"
          className="h-7 border-border text-muted-foreground"
          onClick={onRetry}
        >
          <RefreshCw className="w-3 h-3 mr-1" /> Retry
        </Button>
      </div>
    );

  if (open.length === 0)
    return (
      <div className="flex items-center gap-3 px-4 py-3 text-muted-foreground text-sm border-b border-border/50">
        <span>Нет открытых позиций.</span>
        <span className="text-xs text-muted-foreground/60">
          Сканер следит за рынком и откроет позицию при сигнале.
        </span>
      </div>
    );

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-muted-foreground text-left text-[11px] border-b border-border">
            <th className="px-3 py-2 font-medium text-muted-foreground/40">
              #
            </th>
            <th className="px-3 py-2 font-medium">СИМВОЛ</th>
            <th className="px-3 py-2 font-medium">ПАТТЕРН</th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="Количество скан-циклов токена на момент входа"
            >
              ЦИКЛЫ
            </th>
            <th className="px-3 py-2 font-medium text-right">ВХОД</th>
            <th className="px-3 py-2 font-medium text-right">ЦЕНА</th>
            <th className="px-3 py-2 font-medium text-right">P&L</th>
            <th className="px-3 py-2 font-medium text-right">ПИК</th>
            <th
              className="px-3 py-2 font-medium text-right"
              title="BE STOP: трейлинг ≥ вход (позиция в безубытке). Оранжевый — трейлинг ниже входа."
            >
              BE STOP
            </th>
            <th className="px-2 py-2 font-medium text-right" title="OI Δ30m">
              OI 30m
            </th>
            <th className="px-2 py-2 font-medium text-right" title="OI Δ1h">
              OI 1h
            </th>
            <th className="px-2 py-2 font-medium text-right" title="OI Δ4h">
              OI 4h
            </th>
            <th className="px-2 py-2 font-medium text-right" title="OI Δ24h">
              OI 24h
            </th>
            <th
              className="px-2 py-2 font-medium text-center"
              title="Spot CVD 30m"
            >
              CVD 30m
            </th>
            <th
              className="px-2 py-2 font-medium text-center"
              title="Spot CVD 1h"
            >
              CVD 1h
            </th>
            <th
              className="px-2 py-2 font-medium text-center"
              title="Spot CVD 4h"
            >
              CVD 4h
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="Futures Taker Net Buy % (CoinGlass) — положительный = покупатели доминируют"
            >
              Фьюч тейкер
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="Spot Taker Net Buy % (Binance/BingX спот) — положительный = спот покупатели доминируют"
            >
              Спот тейкер
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="Изменение цены за последний 1h"
            >
              1h%
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="Funding rate % (BingX, 8h ставка) при входе — raw × 100"
            >
              Fund%
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="CoinGlass Whale Index (Binance 4h) при входе"
            >
              WI
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="BingX orderbook bid/ask ratio при входе (>1 = биды давят, <1 = аски давят)"
            >
              OB
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="Long liquidations за 1h на момент детекции"
            >
              Liq 1h
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="Long liquidations за 24h на момент детекции"
            >
              Liq 24h
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="Ratio: liq1h / liq24h"
            >
              LiqR
            </th>
            <th
              className="px-2 py-2 font-medium text-center"
              title="Причина входа в пул: liq_spike или liq_order_stream"
            >
              Триггер
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="Spot Net Flow 1h % (CoinGlass)"
            >
              SNF 1h
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="Spot Net Flow 4h % (CoinGlass)"
            >
              SNF 4h
            </th>
            <th
              className="px-2 py-2 font-medium text-right"
              title="Spot Net Flow 24h % (CoinGlass)"
            >
              SNF 24h
            </th>
            <th className="px-3 py-2 font-medium text-center">СТАТУС</th>
            <th className="px-3 py-2 font-medium text-right">ДАТА</th>
            <th className="px-3 py-2 font-medium"></th>
          </tr>
        </thead>
        <tbody>
          {open.map((s: any) => {
            const cfg = STATUS_CFG[s.status] ?? STATUS_CFG.active;
            const entryPrice = s.entryPrice as number | null;
            const peakPrice = s.peakPrice as number | null;
            const trailStop = s.trailingStopLevel as number | null;
            const pnlPercent = s.pnlPercent as number | null;
            const currentPrice = s.currentPrice as number | null;
            const peakPct =
              peakPrice && entryPrice && entryPrice > 0
                ? ((peakPrice - entryPrice) / entryPrice) * 100
                : null;
            const tvBase = s.symbol.replace("-USDT", "");
            const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${tvBase}USDT.P`;

            return (
              <tr
                key={s.id}
                className={`border-b border-border/50 hover:bg-muted/20 transition-colors ${cfg.rowCls} ${cfg.borderCls}`}
              >
                <td className="px-3 py-3 font-mono text-[10px] text-muted-foreground/40">
                  #{s.id}
                </td>
                <td className="px-3 py-3">
                  <div className="font-bold font-mono text-foreground flex items-center gap-1.5">
                    {s.symbol.replace("-USDT", "")}
                    {s.isShort && (
                      <span className="ml-1 text-[10px] text-red-400">
                        SHORT
                      </span>
                    )}
                    <button
                      onClick={() => onSelectSymbol?.(s.symbol)}
                      className="ml-0.5 text-muted-foreground/40 hover:text-muted-foreground transition-colors"
                      title="История статуса"
                    >
                      <History className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="text-[10px] text-muted-foreground/60">
                    {s.signalType === "super_alpha"
                      ? "⚡⚡ SUPER BULLET"
                      : s.signalType === "alpha"
                        ? "⚡ BULLET"
                        : (s.signalType ?? "")}
                  </div>
                </td>
                <td className="px-3 py-3">
                  <SentimentBadge sentimentKey={s.sentimentKey ?? "unknown"} />
                </td>
                <td className="px-2 py-3 text-right font-mono text-[11px] text-muted-foreground">
                  {s.prescanCycles ?? "—"}
                </td>
                <td className="px-3 py-3 text-right font-mono text-xs text-foreground font-semibold">
                  {fmtPrice(entryPrice)}
                </td>
                <td className="px-3 py-3 text-right font-mono text-xs text-muted-foreground">
                  {currentPrice != null ? fmtPrice(currentPrice) : "—"}
                </td>
                <td className="px-3 py-3 text-right">
                  <PnlCell value={pnlPercent} bold />
                </td>
                <td className="px-3 py-3 text-right">
                  {peakPct != null && peakPct > 0 ? (
                    <span className="font-mono text-xs text-green-400/80">
                      +{peakPct.toFixed(1)}%
                    </span>
                  ) : (
                    <span className="text-muted-foreground text-xs">—</span>
                  )}
                </td>
                <td className="px-3 py-3 text-right">
                  {trailStop && entryPrice && trailStop >= entryPrice ? (
                    <span className="font-mono text-xs text-emerald-400 font-bold">
                      🎯 {fmtPrice(trailStop)}
                    </span>
                  ) : trailStop ? (
                    <span className="font-mono text-xs text-orange-300">
                      🛡 {fmtPrice(trailStop)}
                    </span>
                  ) : (
                    <span className="text-muted-foreground text-xs">—</span>
                  )}
                </td>
                <td className="px-2 py-3 text-right">
                  <OiCell value={s.oi30m} />
                </td>
                <td className="px-2 py-3 text-right">
                  <OiCell value={s.oi1h} />
                </td>
                <td className="px-2 py-3 text-right">
                  <OiCell value={s.oi4h} />
                </td>
                <td className="px-2 py-3 text-right">
                  <OiCell value={s.oi24h} />
                </td>
                <td className="px-2 py-3 text-center">
                  <CvdDot value={s.cvd30m} />
                </td>
                <td className="px-2 py-3 text-center">
                  <CvdDot value={s.cvd1h} />
                </td>
                <td className="px-2 py-3 text-center">
                  <CvdDot value={s.cvd4h} />
                </td>
                <td className="px-2 py-3 text-right">
                  <OiCell value={s.netBuyPct} />
                </td>
                <td className="px-2 py-3 text-right">
                  <OiCell value={s.spotTakerNetBuy} />
                </td>
                <td className="px-2 py-3 text-right">
                  <OiCell value={s.price1h} />
                </td>
                <td className="px-2 py-3 text-right font-mono text-[10px]">
                  {s.entryFundingRate != null ? (
                    <span
                      className={
                        (s.entryFundingRate as number) * 100 > 0.05
                          ? "text-orange-300"
                          : (s.entryFundingRate as number) * 100 < -0.01
                            ? "text-blue-300"
                            : "text-muted-foreground"
                      }
                    >
                      {((s.entryFundingRate as number) * 100).toFixed(4)}
                    </span>
                  ) : (
                    <span className="text-border">—</span>
                  )}
                </td>
                <td className="px-2 py-3 text-right font-mono text-[10px]">
                  {s.entryWhaleIndex != null ? (
                    <span
                      className={
                        (s.entryWhaleIndex as number) >= 10
                          ? "text-green-400"
                          : (s.entryWhaleIndex as number) <= -10
                            ? "text-red-400"
                            : "text-muted-foreground"
                      }
                    >
                      {(s.entryWhaleIndex as number) > 0 ? "+" : ""}
                      {(s.entryWhaleIndex as number).toFixed(0)}
                    </span>
                  ) : (
                    <span className="text-border">—</span>
                  )}
                </td>
                <td className="px-2 py-3 text-right">
                  <ObCell value={s.entryObRatio} />
                </td>
                <td className="px-2 py-3 text-right">
                  <LiqCell value={s.entryLiqLong1h} />
                </td>
                <td className="px-2 py-3 text-right">
                  <LiqCell value={s.entryLiqLong24h} />
                </td>
                <td className="px-2 py-3 text-right">
                  <LiqRCell value={s.entryLiqRatio} />
                </td>
                <td className="px-2 py-3 text-center">
                  <LiqTriggerCell value={s.entryLiqReason} />
                </td>
                {snfCells(s, snfMap)}
                <td className="px-3 py-3 text-center">
                  <StatusBadge status={s.status} />
                </td>
                <td className="px-3 py-3 text-right font-mono text-[11px] text-muted-foreground whitespace-nowrap">
                  {fmtDT(s.detectedAt)}
                  <div className="text-[10px] text-muted-foreground/50">
                    {ageStr(s.detectedAt)}
                  </div>
                </td>
                <td className="px-3 py-3 text-center">
                  <a
                    href={tvUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-zinc-600 hover:text-primary"
                  >
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

// ── Лог всех сигналов (= trackedSignalsTable, все entry metrics) ───────────────
function SignalLog({
  statusFilter,
  page,
  setPage,
  setStatusFilter,
  patternFilter,
  setPatternFilter,
  snfMap,
  onSelectSymbol,
}: {
  statusFilter: string;
  page: number;
  setPage: (n: number) => void;
  setStatusFilter: (s: string) => void;
  patternFilter: string;
  setPatternFilter: (p: string) => void;
  snfMap: Map<string, SnfEntry>;
  onSelectSymbol?: (sym: string) => void;
}) {
  const { data, isLoading } = useQuery({
    queryKey: ["signals-log", statusFilter, page, patternFilter],
    queryFn: () => fetchSignalHistory(statusFilter, page, patternFilter, ""),
    refetchInterval: 20_000,
  });

  const signals = data?.signals ?? [];
  const total = data?.total ?? 0;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <Card className="border-border bg-card">
      <CardHeader className="py-3 px-4 border-b border-border">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <CardTitle className="text-sm font-mono tracking-wider text-muted-foreground">
            ИСТОРИЯ СИГНАЛОВ
          </CardTitle>
          <div className="flex items-center gap-2 flex-wrap">
            <Select
              value={patternFilter}
              onValueChange={(v) => {
                setPatternFilter(v);
                setPage(1);
              }}
            >
              <SelectTrigger className="w-[240px] h-8 bg-card border-border text-xs">
                <SelectValue placeholder="Все паттерны" />
              </SelectTrigger>
              <SelectContent className="max-h-[400px]">
                <SelectItem value="all">— Все паттерны —</SelectItem>
                <SelectGroup>
                  <SelectLabel className="text-[10px] uppercase text-muted-foreground tracking-widest">
                    Активные
                  </SelectLabel>
                  {ACTIVE_PATTERN_KEYS.map((key) => (
                    <SelectItem key={key} value={key} className="text-xs">
                      {getPatternTgLabel(key)}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
            <Select
              value={statusFilter}
              onValueChange={(v) => {
                setStatusFilter(v);
                setPage(1);
              }}
            >
              <SelectTrigger className="w-[220px] h-8 bg-card border-border text-xs">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">ВСЕ СИГНАЛЫ</SelectItem>
                <SelectItem value="open">📂 Открытые</SelectItem>
                <SelectItem value="active">🟡 Активные</SelectItem>
                <SelectItem value="in_run">🚀 В полёте</SelectItem>
                <SelectItem value="accumulation">🔵 Накопление</SelectItem>
                <SelectItem value="closed">🗄 Закрытые</SelectItem>
                <SelectItem value="profit">✅ Профит</SelectItem>
                <SelectItem value="bu_stop">🎯 БУ Стоп</SelectItem>
                <SelectItem value="breakeven">⚖️ Безубыток</SelectItem>
                <SelectItem value="stop_loss">❌ Стоп-лосс</SelectItem>
                <SelectItem value="cancelled">🚫 Отменены</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">
            Загрузка...
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs whitespace-nowrap">
              <thead className="sticky top-0 bg-card border-b border-border z-10">
                <tr className="text-muted-foreground text-left text-[10px]">
                  <th className="px-2 py-2 font-medium text-muted-foreground/40">
                    #
                  </th>
                  <th className="px-2 py-2 font-medium">ВРЕМЯ</th>
                  <th className="px-2 py-2 font-medium">СИМВОЛ</th>
                  <th className="px-2 py-2 font-medium">GRADE</th>
                  <th className="px-2 py-2 font-medium">ПАТТЕРН</th>
                  <th className="px-2 py-2 font-medium text-center">СТАТУС</th>
                  <th className="px-2 py-2 font-medium text-right">P&amp;L</th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Лучший % от входа (peakPrice)"
                  >
                    ПИК%
                  </th>
                  <th className="px-2 py-2 font-medium text-right">ВХОД</th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Alpha Score при детекте"
                  >
                    SCORE
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="BTC price24h% в момент входа — рыночный режим"
                  >
                    BTC 24h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="price24h% токена в момент детекта"
                  >
                    P24h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="OI Δ30m % (CoinGlass) в момент входа"
                  >
                    OI 30m
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="OI Δ1h % (CoinGlass) в момент входа"
                  >
                    OI 1h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="OI Δ4h % (CoinGlass) в момент входа"
                  >
                    OI 4h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="OI Δ24h % (CoinGlass) в момент входа"
                  >
                    OI 24h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-center"
                    title="Spot CVD 30m бычий?"
                  >
                    CVD30
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-center"
                    title="Spot CVD 1h бычий?"
                  >
                    CVD1h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-center"
                    title="Spot CVD 4h бычий?"
                  >
                    CVD4h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Спот Vol mult (lastSpotVol1h/avg) при детекте"
                  >
                    Спот×
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Фьюч Vol mult (BingX 30m) при детекте"
                  >
                    Фьюч×
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Futures Taker Net Buy % (CoinGlass) при входе — положительный = покупатели доминируют"
                  >
                    Фьюч тейкер
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Spot taker net buy % (CoinGlass, ~30m) — >0 давят покупки"
                  >
                    Тейкер
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Spot net buy 1h % (CoinGlass)"
                  >
                    NB 1h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Изменение цены за последний 1h в момент входа"
                  >
                    1h%
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Funding rate % (BingX) при входе"
                  >
                    Fund%
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="CoinGlass Whale Index (Binance 4h) при входе"
                  >
                    WI
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="BingX orderbook bid/ask ratio при входе (>1 = биды давят, <1 = аски давят)"
                  >
                    OB
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Кол-во циклов в прескане в момент детекта"
                  >
                    Цикл
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Стоп-лосс % от входа"
                  >
                    Стоп%
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-left"
                    title="Источник записи (OI Watch trigger / entrySource)"
                  >
                    Источник
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Long-ликвидации за 1h в момент детекта (только liq_cascade)"
                  >
                    Liq 1h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Long-ликвидации за 24h в момент детекта (только liq_cascade)"
                  >
                    Liq 24h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Liq1h / Liq24h — концентрация ликвидаций в последний час"
                  >
                    LiqR
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-left"
                    title="Тип триггера: liq_spike или liq_order_stream"
                  >
                    Триггер
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Spot Net Flow 1h % (CoinGlass)"
                  >
                    SNF 1h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Spot Net Flow 4h % (CoinGlass)"
                  >
                    SNF 4h
                  </th>
                  <th
                    className="px-2 py-2 font-medium text-right"
                    title="Spot Net Flow 24h % (CoinGlass)"
                  >
                    SNF 24h
                  </th>
                </tr>
              </thead>
              <tbody>
                {signals.length === 0 ? (
                  <tr>
                    <td
                      colSpan={36}
                      className="px-4 py-10 text-center text-muted-foreground"
                    >
                      Нет сигналов
                    </td>
                  </tr>
                ) : (
                  signals.map((s: any) => {
                    const cfg =
                      STATUS_CFG[s.status as string] ?? STATUS_CFG.active;
                    const tvBase = s.symbol.replace("-USDT", "");
                    const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${tvBase}USDT.P`;

                    return (
                      <tr
                        key={s.id}
                        className={`border-b border-border/40 hover:bg-muted/20 transition-colors ${cfg.rowCls} ${cfg.borderCls}`}
                      >
                        <td className="px-2 py-2 font-mono text-[10px] text-muted-foreground/40">
                          <a
                            href={tvUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="hover:text-primary"
                          >
                            #{s.id}
                          </a>
                        </td>
                        <td className="px-2 py-2 font-mono text-[10px] text-muted-foreground">
                          {fmtDT(s.detectedAt)}
                          <div className="text-[9px] text-muted-foreground/50">
                            {ageStr(s.detectedAt)}
                          </div>
                        </td>
                        <td className="px-2 py-2 font-bold font-mono text-foreground">
                          <div className="flex items-center gap-1">
                            {s.symbol.replace("-USDT", "")}
                            {s.isShort && (
                              <span className="ml-1 text-[9px] text-red-400">
                                SHORT
                              </span>
                            )}
                            <button
                              onClick={() => onSelectSymbol?.(s.symbol)}
                              className="text-muted-foreground/40 hover:text-muted-foreground transition-colors"
                              title="История статуса"
                            >
                              <History className="w-3 h-3" />
                            </button>
                          </div>
                        </td>
                        <td className="px-2 py-2">
                          <SignalBadge type={s.signalType} />
                        </td>
                        <td className="px-2 py-2">
                          <SentimentBadge
                            sentimentKey={s.sentimentKey ?? "unknown"}
                          />
                        </td>
                        <td className="px-2 py-2 text-center">
                          <StatusBadge status={s.status} />
                          {s.status === "cancelled" && s.cancelReason && (
                            <div
                              className="text-[9px] text-muted-foreground/60 mt-0.5 max-w-[90px] truncate"
                              title={s.cancelReason}
                            >
                              {s.cancelReason}
                            </div>
                          )}
                        </td>
                        <td className="px-2 py-2 text-right">
                          <PnlCell value={s.pnlPercent} bold />
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px]">
                          {s.peakPct != null && s.peakPct > 0 ? (
                            <span className="text-green-400/80">
                              +{(s.peakPct as number).toFixed(1)}%
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px] text-foreground/80">
                          {fmtPrice(s.entryPrice)}
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px]">
                          {s.alphaScore != null ? (
                            <span
                              className={
                                s.alphaScore >= 8
                                  ? "text-yellow-300"
                                  : s.alphaScore >= 6
                                    ? "text-blue-300"
                                    : "text-green-400"
                              }
                            >
                              {s.alphaScore}/10
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.entryBtc24h} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.price24hAtFire} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.entryOi30m} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.entryOi1h} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.entryOi4h} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.entryOi24h} />
                        </td>
                        <td className="px-2 py-2 text-center">
                          <CvdDot value={s.entryCvd30m} />
                        </td>
                        <td className="px-2 py-2 text-center">
                          <CvdDot value={s.entryCvd1h} />
                        </td>
                        <td className="px-2 py-2 text-center">
                          <CvdDot value={s.entryCvd4h} />
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px]">
                          {s.entrySpotVolMult != null ? (
                            <span
                              className={
                                (s.entrySpotVolMult as number) >= 2
                                  ? "text-cyan-300"
                                  : "text-cyan-400/70"
                              }
                            >
                              {(s.entrySpotVolMult as number).toFixed(1)}x
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px]">
                          {s.entryFutVolMult != null ? (
                            <span className="text-muted-foreground">
                              {(s.entryFutVolMult as number).toFixed(1)}x
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.entryFutTakerNetBuy} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.entrySpotTakerNetBuy} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.entrySpotNetBuy1h} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.entryPrice1h} />
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px]">
                          {s.entryFundingRate != null ? (
                            <span
                              className={
                                (s.entryFundingRate as number) * 100 > 0.05
                                  ? "text-orange-300"
                                  : (s.entryFundingRate as number) * 100 < -0.01
                                    ? "text-blue-300"
                                    : "text-muted-foreground"
                              }
                            >
                              {((s.entryFundingRate as number) * 100).toFixed(
                                4,
                              )}
                              %
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px]">
                          {s.entryWhaleIndex != null ? (
                            <span
                              className={
                                (s.entryWhaleIndex as number) >= 10
                                  ? "text-green-400"
                                  : (s.entryWhaleIndex as number) <= -10
                                    ? "text-red-400"
                                    : "text-muted-foreground"
                              }
                            >
                              {(s.entryWhaleIndex as number) > 0 ? "+" : ""}
                              {(s.entryWhaleIndex as number).toFixed(0)}
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2 text-right">
                          <ObCell value={s.entryObRatio} />
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px] text-muted-foreground">
                          {s.prescanCycles ?? "—"}
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px]">
                          {s.stopLossPct != null ? (
                            <span className="text-red-400/70">
                              −{(s.stopLossPct as number).toFixed(1)}%
                            </span>
                          ) : (
                            <span className="text-muted-foreground">—</span>
                          )}
                        </td>
                        <td
                          className="px-2 py-2 text-left font-mono text-[10px] text-muted-foreground/70 max-w-[100px] truncate"
                          title={s.entrySource ?? ""}
                        >
                          {s.entrySource ?? "—"}
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px]">
                          {s.entryLiqLong1h != null ? (
                            <span className="text-orange-300">
                              ${formatNum(s.entryLiqLong1h)}
                            </span>
                          ) : (
                            <span className="text-muted-foreground/30">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px]">
                          {s.entryLiqLong24h != null ? (
                            <span className="text-orange-400/70">
                              ${formatNum(s.entryLiqLong24h)}
                            </span>
                          ) : (
                            <span className="text-muted-foreground/30">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px]">
                          {s.entryLiqRatio != null ? (
                            <span
                              className={
                                (s.entryLiqRatio as number) >= 0.25
                                  ? "text-red-400"
                                  : "text-muted-foreground"
                              }
                            >
                              {((s.entryLiqRatio as number) * 100).toFixed(0)}%
                            </span>
                          ) : (
                            <span className="text-muted-foreground/30">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2 text-left font-mono text-[10px]">
                          {s.entryLiqReason === "liq_order_stream" ? (
                            <span className="text-purple-400">stream</span>
                          ) : s.entryLiqReason === "liq_spike" ? (
                            <span className="text-orange-400/80">spike</span>
                          ) : (
                            <span className="text-muted-foreground/30">—</span>
                          )}
                        </td>
                        {snfCells(s, snfMap)}
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        )}
        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-2 border-t border-border text-xs text-muted-foreground">
          <span className="font-mono">
            {signals.length > 0
              ? `${(page - 1) * PAGE_SIZE + 1}–${(page - 1) * PAGE_SIZE + signals.length}`
              : "0"}{" "}
            из {total}
          </span>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="h-7 border-border text-muted-foreground"
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page <= 1}
            >
              <ChevronLeft className="w-3 h-3" />
            </Button>
            <span className="font-mono text-[11px]">
              {page}/{totalPages}
            </span>
            <Button
              variant="outline"
              size="sm"
              className="h-7 border-border text-muted-foreground"
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page >= totalPages}
            >
              <ChevronRight className="w-3 h-3" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// ── Главная страница ───────────────────────────────────────────────────────────
export default function Tracker() {
  const [statusFilter, setStatusFilter] = useState("all");
  const [patternFilter, setPatternFilter] = useState("all");
  const [page, setPage] = useState(1);
  const [snfMap, setSnfMap] = useState<Map<string, SnfEntry>>(new Map());
  const [selectedSymbol, setSelectedSymbol] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const doFetch = () =>
      fetch(`${API_BASE}/api/scanner/spot-netflow`)
        .then((r) => r.json())
        .then((d: { data?: Record<string, SnfEntry> }) => {
          if (d.data) setSnfMap(new Map(Object.entries(d.data)));
        })
        .catch(() => {});
    doFetch();
    const id = setInterval(doFetch, 5 * 60 * 1000);
    return () => clearInterval(id);
  }, []);
  const qc = useQueryClient();

  const {
    data: trackedData,
    isLoading: trackedLoading,
    isError: trackedError,
    refetch: refetchTracked,
  } = useQuery({
    queryKey: ["tracked-open"],
    queryFn: fetchTracked,
    refetchInterval: 15_000,
    retry: 3,
  });

  const { data: statsData } = useQuery({
    queryKey: ["tracker-stats"],
    queryFn: fetchStats,
    refetchInterval: 30_000,
  });

  const { data: cancelledTodayData } = useQuery({
    queryKey: ["cancelled-today"],
    queryFn: fetchCancelledToday,
    refetchInterval: 60_000,
  });

  const cycleMut = useMutation({
    mutationFn: triggerCycle,
    onSuccess: (d) => {
      toast({
        title: "Watcher цикл завершён",
        description: `Проверено: ${d.checked}, обновлено: ${d.updated}`,
      });
      qc.invalidateQueries({ queryKey: ["tracked-open"] });
      qc.invalidateQueries({ queryKey: ["tracker-stats"] });
    },
    onError: () =>
      toast({
        title: "Ошибка",
        description: "Цикл watcher не запустился",
        variant: "destructive",
      }),
  });

  const sendReport = async (type: "daily" | "weekly" | "positions") => {
    const url =
      type === "daily"
        ? "/api/tracker/daily-digest"
        : type === "weekly"
          ? "/api/tracker/weekly-digest"
          : "/api/tracker/positions-update";
    try {
      await fetch(`${API_BASE}${url}`, { method: "POST" });
      toast({
        title: "Отправлено",
        description: "Сообщение отправлено в Telegram",
      });
    } catch {
      toast({
        title: "Ошибка",
        description: "Не удалось отправить",
        variant: "destructive",
      });
    }
  };

  const stats = statsData ?? {};
  const allTracked = (trackedData?.signals ?? []) as any[];
  const openPos = allTracked.filter((s: any) =>
    ["active", "in_run", "accumulation", "re_entry"].includes(s.status),
  );
  const regularPos = openPos;
  const closedPos = allTracked.filter((s: any) =>
    ["profit", "bu_stop", "stop_loss", "breakeven", "cancelled"].includes(
      s.status,
    ),
  );

  const inRunCount = regularPos.filter(
    (s: any) => s.status === "in_run",
  ).length;
  const watchingCount = regularPos.filter((s: any) =>
    ["active", "accumulation", "re_entry"].includes(s.status),
  ).length;

  const monthStats = stats.monthStats ?? {};
  const profitCount = monthStats["profit"]?.count ?? 0;
  const stopCount = monthStats["stop_loss"]?.count ?? 0;
  const winRate = stats.monthWinRate ?? null;
  const avgProfit =
    stats.monthAvgProfit != null ? Number(stats.monthAvgProfit) : null;
  const cancelledCount = monthStats["cancelled"]?.count ?? 0;
  const buStopCount = monthStats["bu_stop"]?.count ?? 0;

  return (
    <div className="space-y-4">
      {/* Заголовок + кнопки */}
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold tracking-wider">ALTBULLET WATCHER</h2>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            className="border-border text-muted-foreground hover:text-foreground h-8"
            onClick={() => sendReport("positions")}
          >
            📊 ПОЗИЦИИ
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="border-border text-muted-foreground hover:text-foreground h-8"
            onClick={() => sendReport("daily")}
          >
            <BarChart2 className="w-3 h-3 mr-1" /> DAILY
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="border-border text-muted-foreground hover:text-foreground h-8"
            onClick={() => sendReport("weekly")}
          >
            <Trophy className="w-3 h-3 mr-1" /> WEEKLY
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="border-border text-muted-foreground hover:text-foreground h-8"
            onClick={() => cycleMut.mutate()}
            disabled={cycleMut.isPending}
          >
            <RefreshCw
              className={`w-3 h-3 mr-1 ${cycleMut.isPending ? "animate-spin" : ""}`}
            />
            CHECK
          </Button>
        </div>
      </div>

      {/* Стат-бар */}
      <div className="grid grid-cols-8 gap-3">
        {[
          {
            label: "В НАБЛЮДЕНИИ",
            value: watchingCount,
            cls: "text-blue-400",
            card: "",
          },
          {
            label: "🚀 В ПОЛЁТЕ",
            value: inRunCount,
            cls: "text-orange-300",
            card: "border-orange-500/30 bg-orange-950/10",
          },
          {
            label: "ПРОФИТ",
            value: profitCount,
            cls: "text-green-400",
            card: "",
            sub: "тек. мес.",
          },
          {
            label: "BE STOP",
            value: buStopCount,
            cls: "text-emerald-400",
            card: "border-emerald-500/20",
            sub: "капитал защищён",
          },
          {
            label: "СТОП-ЛОСС",
            value: stopCount,
            cls: "text-red-400",
            card: "",
            sub: "тек. мес.",
          },
          {
            label: "WIN RATE",
            value: winRate !== null ? `${winRate}%` : "—",
            cls: "text-yellow-300",
            card: "",
            sub: "тек. мес.",
          },
          {
            label: "AVG PROFIT",
            value: avgProfit !== null ? `+${avgProfit.toFixed(1)}%` : "—",
            cls:
              avgProfit && avgProfit > 0
                ? "text-green-400"
                : "text-muted-foreground",
            card: "",
            sub: "тек. мес.",
          },
          {
            label: "ОТМЕНЕНО",
            value: cancelledCount,
            cls: "text-zinc-400",
            card: "border-zinc-500/20",
            sub: "тек. мес.",
          },
        ].map(({ label, value, cls, card, sub }) => (
          <Card key={label} className={`border-border bg-card ${card}`}>
            <CardContent className="p-4">
              <div className="text-[10px] text-muted-foreground mb-1 tracking-wider">
                {label}
              </div>
              <div className={`text-2xl font-bold font-mono ${cls}`}>
                {value}
              </div>
              {sub && (
                <div className="text-[10px] text-muted-foreground/50 mt-1">
                  {sub}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Правила */}
      <div className="flex gap-x-5 gap-y-1 text-[11px] font-mono border border-border bg-card/50 px-4 py-2 flex-wrap items-center">
        <span className="text-orange-300">
          🚀 IN RUN ≥+10%: Trailing{" "}
          <span className="text-orange-200">акт. +15% → отступ −10%</span>
        </span>
        <span className="text-cyan-300">
          🐋 whale_*:{" "}
          <span className="text-cyan-200">цель +8% / трейлинг +12% → −7%</span>
        </span>
        <span className="text-red-400">❌ STOP −10%</span>
        <span className="text-emerald-400">🎯 BU: trailing ≤ entry → B/E</span>
        <span className="text-blue-400">🔵 ACCUM: 24h–7d</span>
        <span className="text-muted-foreground">⚖️ B/E: 7д без результата</span>
        <span className="text-zinc-500">
          🚫 STALE-CANCEL: 3ч если пик &lt;+2%
        </span>
      </div>

      {/* ── Раздел 1: Открытые позиции (без whale watch) ─────────────────── */}
      <Card className="border-border bg-card">
        <CardHeader className="py-3 px-4 border-b border-border">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm font-mono tracking-wider">
              📍 ОТКРЫТЫЕ ПОЗИЦИИ
              <span className="ml-2 text-muted-foreground font-normal">
                ({regularPos.length})
              </span>
            </CardTitle>
            <span className="text-[10px] text-muted-foreground/60 font-mono">
              = источник TG-отчёта об открытых позициях
            </span>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <OpenPositions
            data={trackedData}
            isLoading={trackedLoading}
            isError={trackedError}
            onRetry={refetchTracked}
            signals={regularPos}
            snfMap={snfMap}
            onSelectSymbol={setSelectedSymbol}
          />
        </CardContent>
      </Card>

      {/* Недавно закрытые (последние 5) */}
      {closedPos.slice(0, 5).length > 0 && (
        <Card className="border-border bg-card">
          <CardHeader className="py-3 px-4 border-b border-border">
            <CardTitle className="text-sm font-mono tracking-wider text-muted-foreground">
              🏁 ПОСЛЕДНИЕ ЗАКРЫТЫЕ
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-muted-foreground text-[11px] border-b border-border/50 text-left">
                  <th className="px-3 py-2 text-muted-foreground/40">#</th>
                  <th className="px-3 py-2">СИМВОЛ</th>
                  <th className="px-3 py-2">ПАТТЕРН</th>
                  <th
                    className="px-2 py-2 text-right"
                    title="Количество скан-циклов токена на момент входа"
                  >
                    ЦИКЛЫ
                  </th>
                  <th className="px-3 py-2 text-right">ВХОД</th>
                  <th className="px-3 py-2 text-right">ВЫХОД</th>
                  <th className="px-3 py-2 text-right">P&L</th>
                  <th className="px-2 py-2 text-right" title="OI Δ30m">
                    OI 30m
                  </th>
                  <th className="px-2 py-2 text-right" title="OI Δ1h">
                    OI 1h
                  </th>
                  <th className="px-2 py-2 text-right" title="OI Δ4h">
                    OI 4h
                  </th>
                  <th className="px-2 py-2 text-right" title="OI Δ24h">
                    OI 24h
                  </th>
                  <th className="px-2 py-2 text-center" title="Spot CVD 30m">
                    CVD 30m
                  </th>
                  <th className="px-2 py-2 text-center" title="Spot CVD 1h">
                    CVD 1h
                  </th>
                  <th className="px-2 py-2 text-center" title="Spot CVD 4h">
                    CVD 4h
                  </th>
                  <th
                    className="px-2 py-2 text-right"
                    title="Futures Taker Net Buy % при входе"
                  >
                    Фьюч тейкер
                  </th>
                  <th
                    className="px-2 py-2 text-right"
                    title="Spot Taker Net Buy % при входе"
                  >
                    Спот тейкер
                  </th>
                  <th
                    className="px-2 py-2 text-right"
                    title="Изменение цены за 1h при входе"
                  >
                    1h%
                  </th>
                  <th
                    className="px-3 py-2 text-right"
                    title="CoinGlass Whale Index (Binance 4h) при входе"
                  >
                    WI
                  </th>
                  <th
                    className="px-2 py-2 text-right"
                    title="BingX orderbook bid/ask ratio при входе (>1 = биды давят, <1 = аски давят)"
                  >
                    OB
                  </th>
                  <th
                    className="px-2 py-2 text-right"
                    title="Long liquidations за 1h на момент детекции"
                  >
                    Liq 1h
                  </th>
                  <th
                    className="px-2 py-2 text-right"
                    title="Long liquidations за 24h на момент детекции"
                  >
                    Liq 24h
                  </th>
                  <th
                    className="px-2 py-2 text-right"
                    title="Ratio: liq1h / liq24h"
                  >
                    LiqR
                  </th>
                  <th
                    className="px-2 py-2 text-center"
                    title="Причина входа в пул"
                  >
                    Триггер
                  </th>
                  <th
                    className="px-2 py-2 text-right"
                    title="Spot Net Flow 1h % (CoinGlass)"
                  >
                    SNF 1h
                  </th>
                  <th
                    className="px-2 py-2 text-right"
                    title="Spot Net Flow 4h % (CoinGlass)"
                  >
                    SNF 4h
                  </th>
                  <th
                    className="px-2 py-2 text-right"
                    title="Spot Net Flow 24h % (CoinGlass)"
                  >
                    SNF 24h
                  </th>
                  <th className="px-3 py-2 text-center">РЕЗУЛЬТАТ</th>
                  <th className="px-3 py-2 text-right">ДАТА</th>
                </tr>
              </thead>
              <tbody>
                {closedPos.slice(0, 5).map((s: any) => {
                  const cfg = STATUS_CFG[s.status] ?? STATUS_CFG.active;
                  return (
                    <tr
                      key={s.id}
                      className={`border-b border-border/40 hover:bg-muted/20 ${cfg.rowCls}`}
                    >
                      <td className="px-3 py-2 font-mono text-[10px] text-muted-foreground/40">
                        #{s.id}
                      </td>
                      <td className="px-3 py-2 font-bold font-mono">
                        <div className="flex items-center gap-1">
                          {s.symbol.replace("-USDT", "")}
                          <button
                            onClick={() => setSelectedSymbol(s.symbol)}
                            className="text-muted-foreground/40 hover:text-muted-foreground transition-colors"
                            title="История статуса"
                          >
                            <History className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                      <td className="px-3 py-2 text-xs text-muted-foreground">
                        {s.sentimentKey ?? "—"}
                      </td>
                      <td className="px-2 py-2 text-right font-mono text-[11px] text-muted-foreground">
                        {s.prescanCycles ?? "—"}
                      </td>
                      <td className="px-3 py-2 text-right font-mono text-xs">
                        {fmtPrice(s.entryPrice)}
                      </td>
                      <td className="px-3 py-2 text-right font-mono text-xs">
                        {fmtPrice(s.exitPrice)}
                      </td>
                      <td className="px-3 py-2 text-right">
                        <PnlCell value={s.pnlPercent} bold />
                      </td>
                      <td className="px-2 py-2 text-right">
                        <OiCell value={s.entryOi30m} />
                      </td>
                      <td className="px-2 py-2 text-right">
                        <OiCell value={s.entryOi1h} />
                      </td>
                      <td className="px-2 py-2 text-right">
                        <OiCell value={s.entryOi4h} />
                      </td>
                      <td className="px-2 py-2 text-right">
                        <OiCell value={s.entryOi24h} />
                      </td>
                      <td className="px-2 py-2 text-center">
                        <CvdDot value={s.entryCvd30m} />
                      </td>
                      <td className="px-2 py-2 text-center">
                        <CvdDot value={s.entryCvd1h} />
                      </td>
                      <td className="px-2 py-2 text-center">
                        <CvdDot value={s.entryCvd4h} />
                      </td>
                      <td className="px-2 py-2 text-right">
                        <OiCell value={s.entryFutTakerNetBuy} />
                      </td>
                      <td className="px-2 py-2 text-right">
                        <OiCell value={s.entrySpotTakerNetBuy} />
                      </td>
                      <td className="px-2 py-2 text-right">
                        <OiCell value={s.entryPrice1h} />
                      </td>
                      <td className="px-3 py-2 text-right font-mono text-[10px]">
                        {s.entryWhaleIndex != null ? (
                          <span
                            className={
                              (s.entryWhaleIndex as number) >= 10
                                ? "text-green-400"
                                : (s.entryWhaleIndex as number) <= -10
                                  ? "text-red-400"
                                  : "text-muted-foreground"
                            }
                          >
                            {(s.entryWhaleIndex as number) > 0 ? "+" : ""}
                            {(s.entryWhaleIndex as number).toFixed(0)}
                          </span>
                        ) : (
                          <span className="text-border">—</span>
                        )}
                      </td>
                      <td className="px-2 py-2 text-right">
                        <ObCell value={s.entryObRatio} />
                      </td>
                      <td className="px-2 py-2 text-right">
                        <LiqCell value={s.entryLiqLong1h} />
                      </td>
                      <td className="px-2 py-2 text-right">
                        <LiqCell value={s.entryLiqLong24h} />
                      </td>
                      <td className="px-2 py-2 text-right">
                        <LiqRCell value={s.entryLiqRatio} />
                      </td>
                      <td className="px-2 py-2 text-center">
                        <LiqTriggerCell value={s.entryLiqReason} />
                      </td>
                      {snfCells(s, snfMap)}
                      <td className="px-3 py-2 text-center">
                        <StatusBadge status={s.status} />
                      </td>
                      <td className="px-3 py-2 text-right font-mono text-[11px] text-muted-foreground whitespace-nowrap">
                        {fmtDT(s.detectedAt)}
                        <div className="text-[10px] text-muted-foreground/50">
                          {ageStr(s.detectedAt)}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {/* ── Отменено сегодня ──────────────────────────────────────────────── */}
      {(() => {
        const cancelledToday = (cancelledTodayData?.signals ?? []) as any[];
        if (cancelledToday.length === 0) return null;
        return (
          <Card className="border-border bg-card border-zinc-700/30">
            <CardHeader className="py-3 px-4 border-b border-border">
              <CardTitle className="text-sm font-mono tracking-wider text-zinc-400">
                🚫 ОТМЕНЕНО СЕГОДНЯ
                <span className="ml-2 text-muted-foreground font-normal text-xs">
                  ({cancelledToday.length})
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="text-muted-foreground text-[11px] border-b border-border/50 text-left">
                    <th className="px-3 py-2 text-muted-foreground/40">#</th>
                    <th className="px-3 py-2">СИМВОЛ</th>
                    <th className="px-3 py-2">ПАТТЕРН</th>
                    <th
                      className="px-2 py-2 text-right"
                      title="Количество скан-циклов токена на момент входа"
                    >
                      ЦИКЛЫ
                    </th>
                    <th className="px-3 py-2 text-right">ВХОД</th>
                    <th className="px-3 py-2 text-right">ВЫХОД</th>
                    <th className="px-3 py-2 text-right">P&amp;L</th>
                    <th className="px-3 py-2 text-right">ПИК</th>
                    <th className="px-3 py-2 text-left">ПРИЧИНА</th>
                    <th className="px-2 py-2 text-right" title="OI Δ30m">
                      OI 30m
                    </th>
                    <th className="px-2 py-2 text-right" title="OI Δ1h">
                      OI 1h
                    </th>
                    <th className="px-2 py-2 text-right" title="OI Δ4h">
                      OI 4h
                    </th>
                    <th className="px-2 py-2 text-right" title="OI Δ24h">
                      OI 24h
                    </th>
                    <th className="px-2 py-2 text-center" title="Spot CVD 30m">
                      CVD 30m
                    </th>
                    <th className="px-2 py-2 text-center" title="Spot CVD 1h">
                      CVD 1h
                    </th>
                    <th className="px-2 py-2 text-center" title="Spot CVD 4h">
                      CVD 4h
                    </th>
                    <th
                      className="px-2 py-2 text-right"
                      title="Futures Taker Net Buy %"
                    >
                      Фьюч тейкер
                    </th>
                    <th
                      className="px-2 py-2 text-right"
                      title="Spot Taker Net Buy %"
                    >
                      Спот тейкер
                    </th>
                    <th
                      className="px-2 py-2 text-right"
                      title="Изменение цены за 1h при входе"
                    >
                      1h%
                    </th>
                    <th
                      className="px-2 py-2 text-right"
                      title="CoinGlass Whale Index (Binance 4h) при входе"
                    >
                      WI
                    </th>
                    <th
                      className="px-2 py-2 text-right"
                      title="BingX orderbook bid/ask ratio при входе (>1 = биды давят, <1 = аски давят)"
                    >
                      OB
                    </th>
                    <th
                      className="px-2 py-2 text-right"
                      title="Long liquidations за 1h на момент детекции"
                    >
                      Liq 1h
                    </th>
                    <th
                      className="px-2 py-2 text-right"
                      title="Long liquidations за 24h на момент детекции"
                    >
                      Liq 24h
                    </th>
                    <th
                      className="px-2 py-2 text-right"
                      title="Ratio: liq1h / liq24h"
                    >
                      LiqR
                    </th>
                    <th
                      className="px-2 py-2 text-center"
                      title="Причина входа в пул"
                    >
                      Триггер
                    </th>
                    <th
                      className="px-2 py-2 text-right"
                      title="Spot Net Flow 1h % (CoinGlass)"
                    >
                      SNF 1h
                    </th>
                    <th
                      className="px-2 py-2 text-right"
                      title="Spot Net Flow 4h % (CoinGlass)"
                    >
                      SNF 4h
                    </th>
                    <th
                      className="px-2 py-2 text-right"
                      title="Spot Net Flow 24h % (CoinGlass)"
                    >
                      SNF 24h
                    </th>
                    <th className="px-3 py-2 text-center">СТАТУС</th>
                    <th className="px-3 py-2 text-right">ЗАКРЫТО</th>
                    <th className="px-3 py-2"></th>
                  </tr>
                </thead>
                <tbody>
                  {cancelledToday.map((s: any) => {
                    const entryPrice = s.entryPrice as number | null;
                    const exitPrice = (s.exitPrice ?? s.peakPrice) as
                      | number
                      | null;
                    const peakPrice = s.peakPrice as number | null;
                    const peakPct =
                      peakPrice && entryPrice && entryPrice > 0
                        ? ((peakPrice - entryPrice) / entryPrice) * 100
                        : null;
                    const tvBase = s.symbol.replace("-USDT", "");
                    const tvUrl = `https://www.tradingview.com/chart/?symbol=BINGX:${tvBase}USDT.P`;
                    return (
                      <tr
                        key={s.id}
                        className="border-b border-border/30 hover:bg-muted/10 opacity-70"
                      >
                        <td className="px-3 py-2 font-mono text-[10px] text-muted-foreground/40">
                          #{s.id}
                        </td>
                        <td className="px-3 py-2">
                          <div className="font-bold font-mono text-zinc-400 flex items-center gap-1">
                            {tvBase}
                            {s.isShort && (
                              <span className="ml-1 text-[10px] text-red-400">
                                SHORT
                              </span>
                            )}
                            <button
                              onClick={() => setSelectedSymbol(s.symbol)}
                              className="text-muted-foreground/40 hover:text-muted-foreground transition-colors"
                              title="История статуса"
                            >
                              <History className="w-3 h-3" />
                            </button>
                          </div>
                          <div className="text-[10px] text-muted-foreground/60">
                            {s.signalType === "super_alpha"
                              ? "⚡⚡ SUPER BULLET"
                              : s.signalType === "alpha"
                                ? "⚡ BULLET"
                                : (s.signalType ?? "")}
                          </div>
                        </td>
                        <td className="px-3 py-2">
                          <SentimentBadge
                            sentimentKey={s.sentimentKey ?? "unknown"}
                          />
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[11px] text-muted-foreground">
                          {s.prescanCycles ?? "—"}
                        </td>
                        <td className="px-3 py-2 text-right font-mono text-xs text-zinc-400">
                          {fmtPrice(entryPrice)}
                        </td>
                        <td className="px-3 py-2 text-right font-mono text-xs text-zinc-500">
                          {fmtPrice(exitPrice)}
                        </td>
                        <td className="px-3 py-2 text-right">
                          <PnlCell value={s.pnlPercent} />
                        </td>
                        <td className="px-3 py-2 text-right">
                          {peakPct != null && peakPct > 0 ? (
                            <span className="font-mono text-xs text-green-400/80">
                              +{peakPct.toFixed(1)}%
                            </span>
                          ) : (
                            <span className="text-muted-foreground text-xs">
                              —
                            </span>
                          )}
                        </td>
                        <td className="px-3 py-2 text-left">
                          {s.cancelReason ? (
                            <span className="text-[9px] font-mono text-muted-foreground/60 bg-muted/30 px-1 py-0.5 rounded">
                              {s.cancelReason}
                            </span>
                          ) : (
                            <span className="text-border">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.oi30m} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.oi1h} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.oi4h} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.oi24h} />
                        </td>
                        <td className="px-2 py-2 text-center">
                          <CvdDot value={s.cvd30m} />
                        </td>
                        <td className="px-2 py-2 text-center">
                          <CvdDot value={s.cvd1h} />
                        </td>
                        <td className="px-2 py-2 text-center">
                          <CvdDot value={s.cvd4h} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.netBuyPct} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.spotTakerNetBuy} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <OiCell value={s.price1h} />
                        </td>
                        <td className="px-2 py-2 text-right font-mono text-[10px]">
                          {s.entryWhaleIndex != null ? (
                            <span
                              className={
                                (s.entryWhaleIndex as number) >= 10
                                  ? "text-green-400"
                                  : (s.entryWhaleIndex as number) <= -10
                                    ? "text-red-400"
                                    : "text-muted-foreground"
                              }
                            >
                              {(s.entryWhaleIndex as number) > 0 ? "+" : ""}
                              {(s.entryWhaleIndex as number).toFixed(0)}
                            </span>
                          ) : (
                            <span className="text-border">—</span>
                          )}
                        </td>
                        <td className="px-2 py-2 text-right">
                          <ObCell value={s.entryObRatio} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <LiqCell value={s.entryLiqLong1h} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <LiqCell value={s.entryLiqLong24h} />
                        </td>
                        <td className="px-2 py-2 text-right">
                          <LiqRCell value={s.entryLiqRatio} />
                        </td>
                        <td className="px-2 py-2 text-center">
                          <LiqTriggerCell value={s.entryLiqReason} />
                        </td>
                        {snfCells(s, snfMap)}
                        <td className="px-3 py-2 text-center">
                          <StatusBadge status={s.status} />
                        </td>
                        <td className="px-3 py-2 text-right font-mono text-[11px] text-muted-foreground whitespace-nowrap">
                          {s.closedAt ? fmtDT(s.closedAt) : "—"}
                          {s.closedAt && (
                            <div className="text-[10px] text-muted-foreground/50">
                              {ageStr(s.closedAt)}
                            </div>
                          )}
                        </td>
                        <td className="px-3 py-2 text-center">
                          <a
                            href={tvUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="text-zinc-600 hover:text-primary"
                          >
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </CardContent>
          </Card>
        );
      })()}

      {/* ── Раздел 2: Лог сигналов ────────────────────────────────────────── */}
      <SignalLog
        statusFilter={statusFilter}
        page={page}
        setPage={setPage}
        setStatusFilter={setStatusFilter}
        patternFilter={patternFilter}
        setPatternFilter={setPatternFilter}
        snfMap={snfMap}
        onSelectSymbol={setSelectedSymbol}
      />

      <SymbolHistorySheet
        symbol={selectedSymbol}
        onClose={() => setSelectedSymbol(null)}
      />
    </div>
  );
}
