import React, { useState, useEffect } from "react";
import {
  useGetScannerStatus,
  useGetSignalsSummary,
  useGetSignals,
  useStartScanner,
  useStopScanner,
  useScanNow,
  useGetSubscriberStats,
  useGetTrackerJournal,
  useGetTrackerMonthlyStats,
  getGetScannerStatusQueryKey,
  getGetSignalsSummaryQueryKey,
  getGetSubscriberStatsQueryKey,
  getGetTrackerJournalQueryKey,
  getGetTrackerMonthlyStatsQueryKey,
  getGetSignalsQueryKey,
  type JournalStats,
  type JournalPatternRow,
  type JournalTokenRow,
  type JournalTrade,
  type MonthlyStatRow,
  type Signal,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Play,
  Square,
  Zap,
  Activity,
  BarChart3,
  Users,
  TrendingUp,
  TrendingDown,
  Trophy,
  AlertTriangle,
  Calendar,
  BookOpen,
  Archive,
  Shield,
} from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { getPatternTgLabel, ACTIVE_PATTERN_KEYS } from "@/lib/pattern-labels";

// ─── constants ────────────────────────────────────────────────────────────────
// Вычисляются при каждом рендере — иначе страница открытая через полночь показывает прошлый месяц.

function getCurrentPeriod() {
  const now = new Date();
  const from = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-01`;
  const label = new Date(from + "T00:00:00")
    .toLocaleDateString("ru-RU", {
      day: "numeric",
      month: "long",
      year: "numeric",
    })
    .replace(" г.", "");
  const monthLabel = now
    .toLocaleDateString("ru-RU", { month: "long", year: "numeric" })
    .replace(" г.", "")
    .toUpperCase();
  return { from, label, monthLabel };
}

// Единый источник актуальных паттернов — pattern-labels.ts (ACTIVE_PATTERN_KEYS).
const ACTIVE_PATTERNS_DASHBOARD = ACTIVE_PATTERN_KEYS;

// ─── helpers ──────────────────────────────────────────────────────────────────

function patLabel(key: string | null | undefined) {
  return getPatternTgLabel(key);
}

function fmtPnl(v: number | null | undefined, decimals = 1) {
  if (v == null) return "—";
  return `${v >= 0 ? "+" : ""}${v.toFixed(decimals)}%`;
}

function fmtPx(v: number | null | undefined) {
  if (v == null) return "—";
  return `$${v < 1 ? v.toFixed(5) : v.toFixed(4)}`;
}

function fmtDate(iso: string) {
  const d = new Date(iso);
  return (
    d.toLocaleDateString("ru-RU", { day: "2-digit", month: "short" }) +
    " " +
    d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })
  );
}

function StatusBadge({ status }: { status: string }) {
  if (status === "profit")
    return (
      <span className="text-green-400 font-bold text-[10px]">✅ PROFIT</span>
    );
  if (status === "stop_loss")
    return <span className="text-red-400  font-bold text-[10px]">❌ STOP</span>;
  if (status === "cancelled")
    return (
      <span className="text-zinc-400 font-bold text-[10px]">🚫 CANCEL</span>
    );
  if (status === "breakeven")
    return (
      <span className="text-yellow-400 font-bold text-[10px]">↔ BEVEN</span>
    );
  return (
    <span className="text-blue-400 font-bold text-[10px]">
      {status.toUpperCase()}
    </span>
  );
}

function WinRateBar({
  winRate,
  profit,
  stopLoss,
  buStop = 0,
}: {
  winRate: number | null;
  profit: number;
  stopLoss: number;
  buStop?: number;
}) {
  const total = profit + buStop + stopLoss;
  if (!total) return null;
  const pct = winRate ?? 0;
  return (
    <div className="mt-1 w-full h-1.5 bg-red-900/40 rounded-none overflow-hidden">
      <div
        className="h-full bg-green-500 transition-all"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

// ─── tab nav ──────────────────────────────────────────────────────────────────

type Tab = "overview" | "stats" | "archive" | "journal";

const TABS: { id: Tab; label: string; icon: React.ElementType }[] = [
  { id: "overview", label: "Обзор", icon: Activity },
  { id: "journal", label: "Дневник трейдера", icon: BookOpen },
  { id: "archive", label: "Архив статистики", icon: Archive },
];

function TabNav({
  active,
  onChange,
}: {
  active: Tab;
  onChange: (t: Tab) => void;
}) {
  return (
    <div className="flex border-b border-border gap-0">
      {TABS.map(({ id, label, icon: Icon }) => (
        <button
          key={id}
          onClick={() => onChange(id)}
          className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-medium tracking-wider transition-colors
            ${
              active === id
                ? "border-b-2 border-primary text-primary -mb-px"
                : "text-muted-foreground hover:text-foreground"
            }`}
        >
          <Icon className="w-3.5 h-3.5" />
          {label.toUpperCase()}
        </button>
      ))}
    </div>
  );
}

// ─── main component ───────────────────────────────────────────────────────────

export default function Dashboard() {
  const queryClient = useQueryClient();
  // Вычисляем период при каждом рендере — иначе страница открытая через полночь показывает прошлый месяц
  const {
    from: CURRENT_PERIOD_FROM,
    label: CURRENT_PERIOD_LABEL,
    monthLabel: CURRENT_MONTH_LABEL,
  } = getCurrentPeriod();
  const [tab, setTab] = useState<Tab>("overview");
  const [layerStats, setLayerStats] = useState<{
    cycleAt: number;
    totalBatch: number;
    byLayer: Record<string, number>;
  } | null>(null);
  useEffect(() => {
    const load = () =>
      fetch("/api/scanner/layer-stats")
        .then((r) => r.json())
        .then(setLayerStats)
        .catch(() => {});
    load();
    const id = setInterval(load, 30_000);
    return () => clearInterval(id);
  }, []);

  const { data: status } = useGetScannerStatus({
    query: { queryKey: getGetScannerStatusQueryKey(), refetchInterval: 5000 },
  });
  const { data: summary } = useGetSignalsSummary({
    query: { queryKey: getGetSignalsSummaryQueryKey(), refetchInterval: 10000 },
  });
  const { data: subStats } = useGetSubscriberStats({
    query: {
      queryKey: getGetSubscriberStatsQueryKey(),
      refetchInterval: 30000,
    },
  });
  const { data: journalAll } = useGetTrackerJournal(undefined, {
    query: { queryKey: getGetTrackerJournalQueryKey(), refetchInterval: 30000 },
  });
  // Используем прямой fetch чтобы гарантировать ?from= в URL (генерированный хук теряет параметр)
  const [journalCur, setJournalCur] = useState<JournalStats | null>(null);
  useEffect(() => {
    const load = () =>
      fetch(`/api/tracker/journal?from=${CURRENT_PERIOD_FROM}`)
        .then((r) => r.json())
        .then((d: JournalStats) => setJournalCur(d))
        .catch(() => {});
    load();
    const id = setInterval(load, 30_000);
    return () => clearInterval(id);
  }, [CURRENT_PERIOD_FROM]);
  const { data: monthlyStats } = useGetTrackerMonthlyStats({
    query: {
      queryKey: getGetTrackerMonthlyStatsQueryKey(),
      refetchInterval: 60000,
    },
  });
  const { data: recentSignals } = useGetSignals(
    { limit: 25, type: "all" },
    {
      query: {
        queryKey: getGetSignalsQueryKey({ limit: 25, type: "all" }),
        refetchInterval: 10000,
      },
    },
  );

  const startScanner = useStartScanner();
  const stopScanner = useStopScanner();
  const scanNow = useScanNow();

  return (
    <div className="space-y-4">
      <TabNav active={tab} onChange={setTab} />

      {/* ── Tab: Обзор + Общая статистика ── */}
      {tab === "overview" && (
        <div className="space-y-6">
          {/* Scanner controls */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-card border border-border px-4 py-2">
                <span className="text-sm font-medium text-muted-foreground">
                  STATUS:
                </span>
                {status?.running ? (
                  <span className="flex items-center text-green-500 font-bold text-sm">
                    <span className="w-2 h-2 rounded-full bg-green-500 mr-2 animate-pulse" />
                    RUNNING
                  </span>
                ) : (
                  <span className="flex items-center text-red-500 font-bold text-sm">
                    <span className="w-2 h-2 rounded-full bg-red-500 mr-2" />
                    STOPPED
                  </span>
                )}
              </div>
              <div className="flex space-x-2">
                {status?.running ? (
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() =>
                      stopScanner.mutate(undefined, {
                        onSuccess: () => queryClient.invalidateQueries(),
                      })
                    }
                    disabled={stopScanner.isPending}
                    className="border border-destructive"
                  >
                    <Square className="w-4 h-4 mr-2" /> STOP
                  </Button>
                ) : (
                  <Button
                    variant="default"
                    size="sm"
                    onClick={() =>
                      startScanner.mutate(undefined, {
                        onSuccess: () => queryClient.invalidateQueries(),
                      })
                    }
                    disabled={startScanner.isPending}
                    className="bg-green-600 hover:bg-green-700 text-white"
                  >
                    <Play className="w-4 h-4 mr-2" /> START
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() =>
                    scanNow.mutate(undefined, {
                      onSuccess: () => queryClient.invalidateQueries(),
                    })
                  }
                  disabled={scanNow.isPending || !status?.running}
                >
                  <Zap className="w-4 h-4 mr-2" /> FORCE SCAN
                </Button>
              </div>
            </div>
            <div className="flex flex-wrap gap-x-5 gap-y-1 text-sm">
              {(() => {
                const running = status?.running;
                return (
                  [
                    {
                      label: "BINGX",
                      ok:
                        running == null
                          ? undefined
                          : running
                            ? status?.bingxConnected
                            : null,
                    },
                    {
                      label: "TELEGRAM",
                      ok:
                        running == null
                          ? undefined
                          : running
                            ? status?.telegramConnected
                            : null,
                    },
                    { label: "COINGLASS", ok: status?.coinglassConnected },
                    { label: "COINALYZE", ok: status?.coinalyzeConnected },
                    { label: "COINGECKO", ok: status?.coinGeckoConnected },
                    { label: "COINPAPRIKA", ok: status?.coinPaprikaConnected },
                  ] as { label: string; ok: boolean | null | undefined }[]
                ).map(({ label, ok }) => (
                  <div key={label} className="flex items-center gap-1.5">
                    <span className="text-muted-foreground">{label}:</span>
                    <span
                      className={`flex items-center gap-1 ${ok == null ? "text-zinc-500" : ok ? "text-green-500" : "text-red-500"}`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full inline-block ${ok == null ? "bg-zinc-600" : ok ? "bg-green-500" : "bg-red-500"}`}
                      />
                      {ok == null
                        ? ok === undefined
                          ? "..."
                          : "—"
                        : ok
                          ? "OK"
                          : "ERR"}
                    </span>
                  </div>
                ));
              })()}
            </div>
          </div>

          {/* CG latency row */}
          {status?.cgLatency && (
            <div className="flex flex-wrap gap-x-5 gap-y-1 text-xs text-muted-foreground border-t border-border pt-2">
              <span className="text-zinc-500 uppercase tracking-wider">
                CG Latency:
              </span>
              {(() => {
                const cg = status.cgLatency!;
                const toPct = cg.timeoutPct;
                const pctColor =
                  toPct === 0
                    ? "text-green-500"
                    : toPct <= 10
                      ? "text-yellow-400"
                      : "text-red-400";
                const p95Color =
                  cg.p95Ms < 3000
                    ? "text-green-500"
                    : cg.p95Ms < 6000
                      ? "text-yellow-400"
                      : "text-red-400";
                const elColor =
                  cg.elLagP95Ms < 0
                    ? "text-zinc-500"
                    : cg.elLagP95Ms < 100
                      ? "text-green-500"
                      : cg.elLagP95Ms < 500
                        ? "text-yellow-400"
                        : "text-red-400";
                return (
                  <>
                    <span>
                      timeout:{" "}
                      <span className={`font-mono font-semibold ${pctColor}`}>
                        {toPct}%
                      </span>
                    </span>
                    <span>
                      p50:{" "}
                      <span className="font-mono text-zinc-300">
                        {cg.p50Ms}ms
                      </span>
                    </span>
                    <span>
                      p95:{" "}
                      <span className={`font-mono font-semibold ${p95Color}`}>
                        {cg.p95Ms}ms
                      </span>
                    </span>
                    <span>
                      max:{" "}
                      <span className="font-mono text-zinc-400">
                        {cg.maxMs}ms
                      </span>
                    </span>
                    <span>
                      req:{" "}
                      <span className="font-mono text-zinc-300">{cg.req}</span>{" "}
                      <span className="text-zinc-600">
                        ({cg.reqPerMin}/мин)
                      </span>
                    </span>
                    {cg.elLagP95Ms >= 0 && (
                      <span>
                        el-lag p95:{" "}
                        <span className={`font-mono font-semibold ${elColor}`}>
                          {cg.elLagP95Ms}ms
                        </span>
                      </span>
                    )}
                    <span className="text-zinc-600">
                      окно {cg.windowMin}мин
                    </span>
                  </>
                );
              })()}
            </div>
          )}

          {/* Signal counters */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard
              title="СИГНАЛОВ СЕГОДНЯ"
              value={summary?.signalsToday ?? 0}
              icon={Zap}
              color="text-blue-300"
            />
            <StatCard
              title="ВСЕГО СИГНАЛОВ"
              value={summary?.totalSignals ?? 0}
              icon={BarChart3}
              color="text-blue-500"
            />
            <StatCard
              title="РЫНКОВ СКАНИРУЕТСЯ"
              value={status?.marketsScanned || 0}
              icon={Activity}
              color="text-green-500"
            />
            <StatCard
              title="ПОДПИСЧИКОВ"
              value={subStats?.active || 0}
              icon={Users}
              color="text-violet-400"
              subtitle={subStats ? `+${subStats.newToday} сегодня` : undefined}
            />
          </div>

          {/* Current period stats */}
          <div className="flex items-center gap-2 text-xs text-muted-foreground pt-2 border-t border-border">
            <Calendar className="w-3.5 h-3.5" />
            <span>
              Общая статистика с{" "}
              <span className="text-foreground font-medium">
                {CURRENT_PERIOD_LABEL}
              </span>
            </span>
          </div>

          {journalCur && journalCur.summary.total > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
              <PerfCard
                title="WIN RATE"
                value={
                  journalCur.summary.winRate != null
                    ? `${journalCur.summary.winRate}%`
                    : "—"
                }
                sub={`${journalCur.summary.profit}✅ / ${journalCur.summary.buStop}🛡 / ${journalCur.summary.stopLoss}❌`}
                icon={Trophy}
                color={
                  journalCur.summary.winRate != null &&
                  journalCur.summary.winRate >= 30
                    ? "text-green-400"
                    : "text-yellow-400"
                }
                bar={
                  <WinRateBar
                    winRate={journalCur.summary.winRate}
                    profit={journalCur.summary.profit}
                    buStop={journalCur.summary.buStop}
                    stopLoss={journalCur.summary.stopLoss}
                  />
                }
              />
              <PerfCard
                title="BE STOP"
                value={String(journalCur.summary.buStop)}
                sub="капитал защищён"
                icon={Shield}
                color="text-emerald-400"
              />
              <PerfCard
                title="AVG PROFIT"
                value={fmtPnl(journalCur.summary.avgProfit)}
                sub={`${journalCur.summary.profit} сделок`}
                icon={TrendingUp}
                color="text-green-400"
              />
              <PerfCard
                title="AVG LOSS"
                value={fmtPnl(journalCur.summary.avgLoss)}
                sub={`${journalCur.summary.stopLoss} стопов`}
                icon={TrendingDown}
                color="text-red-400"
              />
              <PerfCard
                title="ЛУЧШАЯ СДЕЛКА"
                value={fmtPnl(journalCur.summary.bestTrade?.pnl)}
                sub={
                  journalCur.summary.bestTrade
                    ? `${journalCur.summary.bestTrade.symbol} · ${patLabel(journalCur.summary.bestTrade.sentimentKey)}`
                    : "—"
                }
                icon={Trophy}
                color="text-emerald-400"
              />
              <PerfCard
                title="АКТИВНЫХ"
                value={String(journalCur.summary.active)}
                sub={`${journalCur.summary.cancelled} отменено`}
                icon={AlertTriangle}
                color="text-orange-400"
              />
            </div>
          )}

          {journalCur &&
            (() => {
              const patMap = new Map(
                (journalCur.byPattern ?? []).map((r: JournalPatternRow) => [
                  r.sentimentKey,
                  r,
                ]),
              );
              const mergedRows: JournalPatternRow[] =
                ACTIVE_PATTERNS_DASHBOARD.map(
                  (key) =>
                    patMap.get(key) ??
                    ({
                      sentimentKey: key,
                      total: 0,
                      profit: 0,
                      stopLoss: 0,
                      cancelled: 0,
                      winRate: null,
                      avgPnl: null,
                      avgPeak: null,
                      lastSignalAt: null,
                    } as JournalPatternRow),
                );
              return (
                <Card className="border-border bg-card">
                  <CardHeader className="border-b border-border py-3">
                    <CardTitle className="text-sm font-medium tracking-wider text-muted-foreground">
                      РЕЗУЛЬТАТЫ ПО ПАТТЕРНАМ — {CURRENT_MONTH_LABEL}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="overflow-x-auto">
                      <table className="w-full text-xs">
                        <thead>
                          <tr className="border-b border-border text-muted-foreground text-left">
                            <th className="px-4 py-2 font-medium">ПАТТЕРН</th>
                            <th className="px-3 py-2 font-medium text-center">
                              ВСЕГО
                            </th>
                            <th className="px-3 py-2 font-medium text-center text-green-500">
                              PROFIT
                            </th>
                            <th className="px-3 py-2 font-medium text-center text-red-500">
                              STOP
                            </th>
                            <th className="px-3 py-2 font-medium text-center text-zinc-400">
                              CANCEL
                            </th>
                            <th className="px-3 py-2 font-medium text-right">
                              WIN%
                            </th>
                            <th className="px-3 py-2 font-medium text-right">
                              AVG PnL
                            </th>
                            <th className="px-3 py-2 font-medium text-right">
                              AVG PEAK
                            </th>
                            <th className="px-3 py-2 font-medium text-right">
                              ПОСЛЕДНИЙ
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {mergedRows.map((row: JournalPatternRow) => {
                            const isEmpty = row.total === 0;
                            const wr = row.winRate ?? 0;
                            const wrColor =
                              wr >= 40
                                ? "text-green-400"
                                : wr >= 20
                                  ? "text-yellow-400"
                                  : "text-red-400";
                            return (
                              <tr
                                key={row.sentimentKey}
                                className={`border-b border-border/40 hover:bg-muted/30 transition-colors${isEmpty ? " opacity-35" : ""}`}
                              >
                                <td
                                  className={`px-4 py-2 font-medium ${isEmpty ? "text-muted-foreground" : "text-foreground"}`}
                                >
                                  {patLabel(row.sentimentKey)}
                                </td>
                                <td className="px-3 py-2 text-center text-muted-foreground font-mono">
                                  {isEmpty ? "—" : row.total}
                                </td>
                                <td className="px-3 py-2 text-center text-green-400 font-mono">
                                  {isEmpty ? "—" : row.profit}
                                </td>
                                <td className="px-3 py-2 text-center text-red-400 font-mono">
                                  {isEmpty ? "—" : row.stopLoss}
                                </td>
                                <td className="px-3 py-2 text-center text-zinc-500 font-mono">
                                  {isEmpty ? "—" : row.cancelled}
                                </td>
                                <td
                                  className={`px-3 py-2 text-right font-bold font-mono ${isEmpty ? "text-muted-foreground" : wrColor}`}
                                >
                                  {isEmpty
                                    ? "—"
                                    : row.winRate != null
                                      ? `${row.winRate}%`
                                      : "—"}
                                </td>
                                <td
                                  className={`px-3 py-2 text-right font-mono ${row.avgPnl != null && row.avgPnl >= 0 ? "text-green-400" : "text-red-400"}`}
                                >
                                  {fmtPnl(row.avgPnl)}
                                </td>
                                <td className="px-3 py-2 text-right font-mono text-blue-300">
                                  {fmtPnl(row.avgPeak)}
                                </td>
                                <td className="px-3 py-2 text-right font-mono text-muted-foreground whitespace-nowrap">
                                  {row.lastSignalAt
                                    ? fmtDate(row.lastSignalAt)
                                    : "—"}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </CardContent>
                </Card>
              );
            })()}

          {/* Recent signals feed with per-token stats */}
          {(() => {
            const filtered = recentSignals?.signals ?? [];
            const tokenMap = new Map<string, JournalTokenRow>(
              (journalAll?.byToken ?? []).map((r: JournalTokenRow) => [
                r.symbol,
                r,
              ]),
            );
            return (
              <Card className="border-border bg-card">
                <CardHeader className="border-b border-border py-3">
                  <CardTitle className="text-sm font-medium tracking-wider flex items-center justify-between">
                    <span className="text-muted-foreground">
                      ПОСЛЕДНИЕ СИГНАЛЫ
                    </span>
                    <span className="text-xs text-muted-foreground font-normal">
                      последние 25 · без китовых
                    </span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr className="border-b border-border text-muted-foreground text-left">
                          <th className="px-3 py-2 font-medium">
                            ДАТА / ВРЕМЯ
                          </th>
                          <th className="px-3 py-2 font-medium">ТОКЕН</th>
                          <th className="px-3 py-2 font-medium">ПАТТЕРН</th>
                          <th className="px-3 py-2 font-medium text-right">
                            ЦЕНА
                          </th>
                          <th className="px-3 py-2 font-medium text-right">
                            OI%
                          </th>
                          <th className="px-3 py-2 font-medium text-right">
                            VOL×
                          </th>
                          <th className="px-3 py-2 font-medium text-center">
                            СТАТУС
                          </th>
                          <th className="px-3 py-2 font-medium text-center border-l border-border/60 text-zinc-500">
                            ВСЕГО
                          </th>
                          <th className="px-3 py-2 font-medium text-center text-green-600">
                            P
                          </th>
                          <th className="px-3 py-2 font-medium text-center text-red-600">
                            S
                          </th>
                          <th className="px-3 py-2 font-medium text-center text-zinc-500">
                            C
                          </th>
                          <th className="px-3 py-2 font-medium text-right">
                            WIN%
                          </th>
                          <th className="px-3 py-2 font-medium text-right">
                            AVG PnL
                          </th>
                          <th className="px-3 py-2 font-medium text-right">
                            BEST
                          </th>
                          <th className="px-3 py-2 font-medium text-right">
                            AVG PEAK
                          </th>
                          <th className="px-3 py-2 font-medium text-right">
                            ПОСЛЕД.
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {!recentSignals ? (
                          <tr>
                            <td
                              colSpan={16}
                              className="px-4 py-8 text-center text-muted-foreground"
                            >
                              Загрузка...
                            </td>
                          </tr>
                        ) : filtered.length === 0 ? (
                          <tr>
                            <td
                              colSpan={16}
                              className="px-4 py-8 text-center text-muted-foreground"
                            >
                              Нет сигналов
                            </td>
                          </tr>
                        ) : (
                          filtered.map((s: Signal) => {
                            const tok = tokenMap.get(s.symbol);
                            const wr = tok?.winRate ?? 0;
                            const wrColor =
                              tok == null
                                ? "text-zinc-600"
                                : wr >= 40
                                  ? "text-green-400"
                                  : wr >= 20
                                    ? "text-yellow-400"
                                    : "text-red-400";
                            return (
                              <tr
                                key={s.id}
                                className="border-b border-border/40 hover:bg-muted/30 transition-colors"
                              >
                                <td className="px-3 py-2 text-muted-foreground whitespace-nowrap font-mono">
                                  {fmtDate(s.detectedAt)}
                                </td>
                                <td className="px-3 py-2 font-bold text-foreground font-mono">
                                  {s.symbol.replace("-USDT", "")}
                                </td>
                                <td className="px-3 py-2">
                                  <div
                                    className={`text-[10px] font-bold font-mono ${s.type === "super_alpha" ? "text-yellow-300" : "text-blue-300"}`}
                                  >
                                    {s.type === "super_alpha"
                                      ? "⚡⚡ SUPER BULLET"
                                      : "⚡ BULLET"}
                                  </div>
                                  {s.sentimentKey && (
                                    <div className="text-[10px] text-muted-foreground mt-0.5">
                                      {patLabel(s.sentimentKey)}
                                    </div>
                                  )}
                                </td>
                                <td className="px-3 py-2 text-right font-mono text-foreground/80">
                                  {fmtPx(s.price)}
                                </td>
                                <td className="px-3 py-2 text-right font-mono text-blue-300">
                                  {s.oiChangePercent != null
                                    ? `${s.oiChangePercent > 0 ? "+" : ""}${s.oiChangePercent.toFixed(1)}%`
                                    : "—"}
                                </td>
                                <td className="px-3 py-2 text-right font-mono text-zinc-400">
                                  {s.avgVolume > 0
                                    ? `${(s.volume24h / s.avgVolume).toFixed(1)}×`
                                    : "—"}
                                </td>
                                <td className="px-3 py-2 text-center">
                                  <span
                                    className={`text-[10px] font-bold ${
                                      s.trackedStatus === "active" ||
                                      s.trackedStatus === "in_run"
                                        ? "text-green-400"
                                        : s.trackedStatus === "cancelled"
                                          ? "text-zinc-500"
                                          : s.trackedStatus === "profit"
                                            ? "text-emerald-400"
                                            : s.trackedStatus === "stop_loss"
                                              ? "text-red-400"
                                              : "text-muted-foreground"
                                    }`}
                                  >
                                    {s.trackedStatus?.toUpperCase() ?? "—"}
                                  </span>
                                </td>
                                {/* per-token stats */}
                                <td className="px-3 py-2 text-center text-muted-foreground border-l border-border/60 font-mono">
                                  {tok ? (
                                    tok.total
                                  ) : (
                                    <span className="text-zinc-700">—</span>
                                  )}
                                </td>
                                <td className="px-3 py-2 text-center text-green-400 font-mono">
                                  {tok ? (
                                    tok.profit
                                  ) : (
                                    <span className="text-zinc-700">—</span>
                                  )}
                                </td>
                                <td className="px-3 py-2 text-center text-red-400 font-mono">
                                  {tok ? (
                                    tok.stopLoss
                                  ) : (
                                    <span className="text-zinc-700">—</span>
                                  )}
                                </td>
                                <td className="px-3 py-2 text-center text-zinc-500 font-mono">
                                  {tok ? (
                                    tok.cancelled
                                  ) : (
                                    <span className="text-zinc-700">—</span>
                                  )}
                                </td>
                                <td
                                  className={`px-3 py-2 text-right font-bold font-mono ${wrColor}`}
                                >
                                  {tok?.winRate != null ? (
                                    `${tok.winRate}%`
                                  ) : (
                                    <span className="text-zinc-700">—</span>
                                  )}
                                </td>
                                <td
                                  className={`px-3 py-2 text-right font-mono ${tok?.avgPnl != null && tok.avgPnl >= 0 ? "text-green-400" : "text-red-400"}`}
                                >
                                  {tok ? (
                                    fmtPnl(tok.avgPnl)
                                  ) : (
                                    <span className="text-zinc-700">—</span>
                                  )}
                                </td>
                                <td
                                  className={`px-3 py-2 text-right font-mono font-semibold ${tok?.bestPnl != null && tok.bestPnl >= 0 ? "text-emerald-400" : tok?.bestPnl != null ? "text-red-400" : "text-zinc-700"}`}
                                >
                                  {tok ? (
                                    fmtPnl(tok.bestPnl)
                                  ) : (
                                    <span className="text-zinc-700">—</span>
                                  )}
                                </td>
                                <td className="px-3 py-2 text-right font-mono text-blue-300">
                                  {tok ? (
                                    fmtPnl(tok.avgPeak)
                                  ) : (
                                    <span className="text-zinc-700">—</span>
                                  )}
                                </td>
                                <td className="px-3 py-2 text-right font-mono text-muted-foreground whitespace-nowrap">
                                  {tok?.lastSignalAt ? (
                                    fmtDate(tok.lastSignalAt)
                                  ) : (
                                    <span className="text-zinc-700">—</span>
                                  )}
                                </td>
                              </tr>
                            );
                          })
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            );
          })()}
        </div>
      )}

      {/* ── Tab: Архив статистики ── */}
      {tab === "archive" && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Archive className="w-3.5 h-3.5" />
            <span>
              Исторические данные по месяцам — включая тестовый период (Май 2025
              и ранее)
            </span>
          </div>

          {!monthlyStats ? (
            <div className="text-center py-12 text-muted-foreground text-sm">
              Загрузка...
            </div>
          ) : monthlyStats.months.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground text-sm">
              Нет архивных данных
            </div>
          ) : (
            <Card className="border-border bg-card">
              <CardHeader className="border-b border-border py-3">
                <CardTitle className="text-sm font-medium tracking-wider text-muted-foreground">
                  СТАТИСТИКА ПО МЕСЯЦАМ
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-border text-muted-foreground text-left">
                        <th className="px-4 py-2 font-medium">МЕСЯЦ</th>
                        <th className="px-3 py-2 font-medium text-center">
                          ВСЕГО
                        </th>
                        <th className="px-3 py-2 font-medium text-center text-green-500">
                          PROFIT
                        </th>
                        <th className="px-3 py-2 font-medium text-center text-red-500">
                          STOP
                        </th>
                        <th className="px-3 py-2 font-medium text-center text-zinc-400">
                          CANCEL
                        </th>
                        <th className="px-3 py-2 font-medium text-right">
                          WIN%
                        </th>
                        <th className="px-3 py-2 font-medium text-right">
                          AVG PROFIT
                        </th>
                        <th className="px-3 py-2 font-medium text-right">
                          AVG LOSS
                        </th>
                        <th className="px-3 py-2 font-medium text-right">
                          ЛУЧШАЯ
                        </th>
                        <th className="px-3 py-2 font-medium text-right">
                          ХУДШАЯ
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {monthlyStats.months.map((row: MonthlyStatRow) => {
                        const wr = row.winRate ?? 0;
                        const wrColor =
                          wr >= 40
                            ? "text-green-400"
                            : wr >= 20
                              ? "text-yellow-400"
                              : "text-red-400";
                        const isCurrent =
                          row.month >= CURRENT_PERIOD_FROM.slice(0, 7);
                        return (
                          <tr
                            key={row.month}
                            className={`border-b border-border/40 hover:bg-muted/30 transition-colors ${isCurrent ? "bg-blue-950/20" : ""}`}
                          >
                            <td className="px-4 py-2 font-medium text-foreground whitespace-nowrap">
                              {isCurrent && (
                                <span className="text-blue-400 text-[10px] mr-1.5">
                                  ▶
                                </span>
                              )}
                              {row.label}
                            </td>
                            <td className="px-3 py-2 text-center text-muted-foreground">
                              {row.total}
                            </td>
                            <td className="px-3 py-2 text-center text-green-400 font-mono">
                              {row.profit}
                            </td>
                            <td className="px-3 py-2 text-center text-red-400 font-mono">
                              {row.stopLoss}
                            </td>
                            <td className="px-3 py-2 text-center text-zinc-500 font-mono">
                              {row.cancelled}
                            </td>
                            <td
                              className={`px-3 py-2 text-right font-bold font-mono ${wrColor}`}
                            >
                              {row.winRate != null ? `${row.winRate}%` : "—"}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-green-400">
                              {fmtPnl(row.avgProfit)}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-red-400">
                              {fmtPnl(row.avgLoss)}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-emerald-400">
                              {fmtPnl(row.bestPnl)}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-red-300">
                              {fmtPnl(row.worstPnl)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* ── Tab: Дневник трейдера ── */}
      {tab === "journal" && (
        <div className="space-y-6">
          {journalAll && (
            <div className="grid grid-cols-2 md:grid-cols-6 gap-3">
              <PerfCard
                title="WIN RATE (ALL)"
                value={
                  journalAll.summary.winRate != null
                    ? `${journalAll.summary.winRate}%`
                    : "—"
                }
                sub={`${journalAll.summary.profit}✅ / ${journalAll.summary.buStop}🛡 / ${journalAll.summary.stopLoss}❌`}
                icon={Trophy}
                color={
                  journalAll.summary.winRate != null &&
                  journalAll.summary.winRate >= 30
                    ? "text-green-400"
                    : "text-yellow-400"
                }
                bar={
                  <WinRateBar
                    winRate={journalAll.summary.winRate}
                    profit={journalAll.summary.profit}
                    buStop={journalAll.summary.buStop}
                    stopLoss={journalAll.summary.stopLoss}
                  />
                }
              />
              <PerfCard
                title="BE STOP"
                value={String(journalAll.summary.buStop)}
                sub="капитал защищён"
                icon={Shield}
                color="text-emerald-400"
              />
              <PerfCard
                title="AVG PROFIT"
                value={fmtPnl(journalAll.summary.avgProfit)}
                sub={`${journalAll.summary.profit} сделок`}
                icon={TrendingUp}
                color="text-green-400"
              />
              <PerfCard
                title="AVG LOSS"
                value={fmtPnl(journalAll.summary.avgLoss)}
                sub={`${journalAll.summary.stopLoss} стопов`}
                icon={TrendingDown}
                color="text-red-400"
              />
              <PerfCard
                title="ЛУЧШАЯ СДЕЛКА"
                value={fmtPnl(journalAll.summary.bestTrade?.pnl)}
                sub={
                  journalAll.summary.bestTrade
                    ? `${journalAll.summary.bestTrade.symbol} · ${patLabel(journalAll.summary.bestTrade.sentimentKey)}`
                    : "—"
                }
                icon={Trophy}
                color="text-emerald-400"
              />
              <PerfCard
                title="АКТИВНЫХ"
                value={String(journalAll.summary.active)}
                sub={`${journalAll.summary.cancelled} отменено`}
                icon={AlertTriangle}
                color="text-orange-400"
              />
            </div>
          )}

          <Card className="border-border bg-card">
            <CardHeader className="border-b border-border py-3">
              <CardTitle className="text-sm font-medium tracking-wider flex items-center justify-between">
                <span className="text-muted-foreground">ЖУРНАЛ СДЕЛОК</span>
                <span className="text-xs text-muted-foreground font-normal">
                  последние 50 закрытых
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-border text-muted-foreground text-left">
                      <th className="px-3 py-2 font-medium">ДАТА</th>
                      <th className="px-3 py-2 font-medium">СИМВОЛ</th>
                      <th className="px-3 py-2 font-medium">ПАТТЕРН</th>
                      <th className="px-3 py-2 font-medium text-right">ВХОД</th>
                      <th className="px-3 py-2 font-medium text-right">PnL</th>
                      <th className="px-3 py-2 font-medium text-right">
                        ПИКОВЫЙ
                      </th>
                      <th className="px-3 py-2 font-medium text-right">
                        ДЕРЖАЛИ
                      </th>
                      <th className="px-3 py-2 font-medium text-right">OI%</th>
                      <th className="px-3 py-2 font-medium text-right">VM</th>
                      <th className="px-3 py-2 font-medium text-right">24h</th>
                      <th className="px-3 py-2 font-medium text-center">
                        ИТОГ
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {!journalAll ? (
                      <tr>
                        <td
                          colSpan={11}
                          className="px-4 py-8 text-center text-muted-foreground"
                        >
                          Загрузка...
                        </td>
                      </tr>
                    ) : journalAll.trades.length === 0 ? (
                      <tr>
                        <td
                          colSpan={11}
                          className="px-4 py-8 text-center text-muted-foreground"
                        >
                          Нет закрытых сделок.
                        </td>
                      </tr>
                    ) : (
                      journalAll.trades.map((t: JournalTrade) => {
                        const isProfit = t.status === "profit";
                        const isStop = t.status === "stop_loss";
                        const isCancelled = t.status === "cancelled";
                        const rowCls = isProfit
                          ? "bg-green-950/10"
                          : isStop
                            ? "bg-red-950/10"
                            : isCancelled
                              ? "opacity-60"
                              : "";
                        const pnlCls =
                          t.pnlPercent == null
                            ? "text-muted-foreground"
                            : t.pnlPercent >= 0
                              ? "text-green-400"
                              : "text-red-400";
                        const px24Cls =
                          t.px24h == null
                            ? "text-muted-foreground"
                            : t.px24h >= 0
                              ? "text-green-300"
                              : "text-red-300";
                        return (
                          <tr
                            key={t.id}
                            className={`border-b border-border/40 hover:bg-muted/30 transition-colors ${rowCls}`}
                          >
                            <td className="px-3 py-2 text-muted-foreground whitespace-nowrap">
                              {fmtDate(t.detectedAt)}
                            </td>
                            <td className="px-3 py-2 font-bold text-foreground">
                              {t.symbol.replace("-USDT", "")}
                            </td>
                            <td className="px-3 py-2 text-muted-foreground">
                              {patLabel(t.sentimentKey)}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-foreground/80">
                              {fmtPx(t.entryPrice)}
                            </td>
                            <td
                              className={`px-3 py-2 text-right font-mono font-bold ${pnlCls}`}
                            >
                              {fmtPnl(t.pnlPercent)}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-blue-300">
                              {fmtPnl(t.peakPct)}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-muted-foreground">
                              {t.hoursHeld != null ? `${t.hoursHeld}h` : "—"}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-muted-foreground">
                              {t.oiChangePct != null
                                ? `${t.oiChangePct.toFixed(1)}%`
                                : t.cumulativeOi != null
                                  ? `${t.cumulativeOi.toFixed(1)}%`
                                  : "—"}
                            </td>
                            <td className="px-3 py-2 text-right font-mono text-muted-foreground">
                              {t.volMult != null ? `${t.volMult}x` : "—"}
                            </td>
                            <td
                              className={`px-3 py-2 text-right font-mono ${px24Cls}`}
                            >
                              {t.px24h != null ? fmtPnl(t.px24h, 1) : "—"}
                            </td>
                            <td className="px-3 py-2 text-center">
                              <StatusBadge status={t.status} />
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {layerStats && (
        <div className="rounded-lg border border-border bg-muted/10 p-4">
          <p className="text-[11px] font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            Layer Stats — последний цикл ({layerStats.totalBatch} токенов в
            батче
            {layerStats.cycleAt
              ? `, ${new Date(layerStats.cycleAt).toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" })}`
              : ""}
            )
          </p>
          <div className="flex flex-wrap gap-2">
            {Object.entries(layerStats.byLayer)
              .sort(([a], [b]) => {
                const ord: Record<string, number> = {
                  WL: 0,
                  L1: 1,
                  L2: 2,
                  L3: 3,
                  L4: 4,
                  L5: 5,
                  L6c: 6,
                  L7: 7,
                  L8: 8,
                  L8b: 9,
                };
                return (ord[a] ?? 99) - (ord[b] ?? 99);
              })
              .map(([layer, count]) => {
                const color =
                  layer === "WL"
                    ? "text-yellow-300 border-yellow-500/40 bg-yellow-500/10"
                    : layer === "L1"
                      ? "text-orange-300 border-orange-500/40 bg-orange-500/10"
                      : layer === "L2"
                        ? "text-yellow-300 border-yellow-500/40 bg-yellow-500/10"
                        : layer === "L3"
                          ? "text-red-300 border-red-500/40 bg-red-500/10"
                          : layer === "L4"
                            ? "text-green-300 border-green-500/40 bg-green-500/10"
                            : layer === "L5"
                              ? "text-teal-300 border-teal-500/40 bg-teal-500/10"
                              : layer === "L6c"
                                ? "text-indigo-300 border-indigo-500/40 bg-indigo-500/10"
                                : layer === "L7"
                                  ? "text-slate-300 border-slate-500/40 bg-slate-500/10"
                                  : layer === "L8"
                                    ? "text-pink-300 border-pink-500/40 bg-pink-500/10"
                                    : layer === "L8b"
                                      ? "text-sky-300 border-sky-500/40 bg-sky-500/10"
                                      : "text-muted-foreground border-border bg-muted/20";
                return (
                  <span
                    key={layer}
                    className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded border text-xs font-mono ${color}`}
                  >
                    <span className="font-semibold">{layer}</span>
                    <span className="opacity-70">{count}</span>
                  </span>
                );
              })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── sub-components ───────────────────────────────────────────────────────────

function StatCard({
  title,
  value,
  icon: Icon,
  subtitle,
  color = "text-primary",
}: {
  title: string;
  value: number;
  icon: React.ElementType;
  subtitle?: string;
  color?: string;
}) {
  return (
    <Card className="border-border bg-card">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div className="space-y-2">
            <p className="text-xs font-medium text-muted-foreground tracking-wider">
              {title}
            </p>
            <p className="text-3xl font-bold tracking-tight">{value}</p>
          </div>
          <div className={`p-2 bg-muted rounded-none ${color}`}>
            <Icon className="w-5 h-5" />
          </div>
        </div>
        {subtitle && (
          <div className="mt-4 text-xs text-green-500 font-medium">
            {subtitle}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function PerfCard({
  title,
  value,
  sub,
  icon: Icon,
  color,
  bar,
}: {
  title: string;
  value: string;
  sub?: string;
  icon: React.ElementType;
  color: string;
  bar?: React.ReactNode;
}) {
  return (
    <Card className="border-border bg-card">
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <p className="text-[10px] font-medium text-muted-foreground tracking-wider leading-tight">
            {title}
          </p>
          <div className={`${color} opacity-70`}>
            <Icon className="w-3.5 h-3.5" />
          </div>
        </div>
        <p className={`text-2xl font-bold mt-1 ${color}`}>{value}</p>
        {bar}
        {sub && (
          <p className="text-[10px] text-muted-foreground mt-1 truncate">
            {sub}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
