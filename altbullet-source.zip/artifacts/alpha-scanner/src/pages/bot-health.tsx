import { useEffect, useState } from "react";
import {
  useGetBotHealth,
  getGetBotHealthQueryKey,
} from "@workspace/api-client-react";
import type { BotHealthStatus } from "@workspace/api-client-react";

// ─── helpers ──────────────────────────────────────────────────────────────────

type StatusLevel = "ok" | "warn" | "crit" | "unknown";

function fmtMs(ms: number | null | undefined): string {
  if (ms == null) return "—";
  if (ms < 1000) return `${ms}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

function fmtMin(ms: number): string {
  const m = Math.round(ms / 60_000);
  return m < 60 ? `${m}мин` : `${(m / 60).toFixed(1)}ч`;
}

function fmtAge(ts: number | null | undefined): string {
  if (ts == null) return "никогда";
  const secs = Math.floor((Date.now() - ts) / 1000);
  if (secs < 60) return `${secs}с назад`;
  const mins = Math.floor(secs / 60);
  if (mins < 60) return `${mins}мин назад`;
  return `${Math.floor(mins / 60)}ч назад`;
}

function fmtIso(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleTimeString("ru-RU", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
}

function statusColor(level: StatusLevel): string {
  if (level === "ok") return "text-green-400";
  if (level === "warn") return "text-yellow-400";
  if (level === "crit") return "text-red-400";
  return "text-zinc-500";
}

function statusDot(level: StatusLevel): string {
  if (level === "ok") return "bg-green-500";
  if (level === "warn") return "bg-yellow-400";
  if (level === "crit") return "bg-red-500";
  return "bg-zinc-600";
}

function statusLabel(level: StatusLevel): string {
  if (level === "ok") return "OK";
  if (level === "warn") return "WARN";
  if (level === "crit") return "CRIT";
  return "—";
}

function cgTimeoutLevel(pct: number): StatusLevel {
  if (pct < 10) return "ok";
  if (pct < 30) return "warn";
  return "crit";
}

function cgP95Level(ms: number): StatusLevel {
  if (ms < 3000) return "ok";
  if (ms < 8000) return "warn";
  return "crit";
}

function elLagLevel(ms: number): StatusLevel {
  if (ms < 100) return "ok";
  if (ms < 500) return "warn";
  return "crit";
}

function dbPingLevel(ms: number | null | undefined): StatusLevel {
  if (ms == null) return "unknown";
  if (ms < 50) return "ok";
  if (ms < 200) return "warn";
  return "crit";
}

function jobLevel(intervalMs: number, overdueMs: number | null): StatusLevel {
  if (overdueMs === null) return "unknown"; // never ran
  if (overdueMs === 0) return "ok";
  if (overdueMs < intervalMs * 0.5) return "warn";
  return "crit";
}

// ─── sub-components ───────────────────────────────────────────────────────────

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-xs font-mono tracking-widest text-primary/60 uppercase mb-3 border-b border-border pb-1">
      {children}
    </div>
  );
}

function Row({
  label,
  value,
  level,
}: {
  label: string;
  value: React.ReactNode;
  level?: StatusLevel;
}) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-border/40 last:border-0 text-xs">
      <span className="text-muted-foreground font-mono">{label}</span>
      <span
        className={`font-mono font-medium ${level ? statusColor(level) : "text-foreground"}`}
      >
        {value}
      </span>
    </div>
  );
}

function ConnectionRow({
  label,
  ok,
}: {
  label: string;
  ok: boolean | null | undefined;
}) {
  const level: StatusLevel =
    ok === true ? "ok" : ok === false ? "crit" : "unknown";
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-border/40 last:border-0 text-xs">
      <span className="text-muted-foreground font-mono">{label}</span>
      <span className="flex items-center gap-2">
        <span className={`w-1.5 h-1.5 rounded-full ${statusDot(level)}`} />
        <span className={`font-mono font-medium ${statusColor(level)}`}>
          {statusLabel(level)}
        </span>
      </span>
    </div>
  );
}

function GaugeBar({
  value,
  max,
  level,
}: {
  value: number;
  max: number;
  level: StatusLevel;
}) {
  const pct = Math.min(100, (value / max) * 100);
  const barColor =
    level === "ok"
      ? "bg-green-500"
      : level === "warn"
        ? "bg-yellow-400"
        : "bg-red-500";
  return (
    <div className="w-full h-1 bg-zinc-800 rounded-none overflow-hidden mt-1">
      <div
        className={`h-full transition-all ${barColor}`}
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

function JobRow({
  job,
}: {
  job: {
    label: string;
    intervalMs: number;
    lastRunAt: number | null;
    overdueMs: number | null;
  };
}) {
  const level = jobLevel(job.intervalMs, job.overdueMs);
  const overdueDisplay =
    job.overdueMs === null
      ? "—"
      : job.overdueMs === 0
        ? "в норме"
        : `+${fmtMs(job.overdueMs)}`;

  return (
    <div className="py-2 border-b border-border/40 last:border-0">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span
            className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${statusDot(level)}`}
          />
          <span className="text-xs font-mono text-foreground">{job.label}</span>
        </div>
        <span className={`text-xs font-mono font-medium ${statusColor(level)}`}>
          {statusLabel(level)}
          {job.overdueMs != null && job.overdueMs > 0 && (
            <span className="ml-1 text-zinc-500">({overdueDisplay})</span>
          )}
        </span>
      </div>
      <div className="flex items-center justify-between mt-0.5 pl-3.5">
        <span className="text-[10px] text-zinc-600 font-mono">
          последний: {fmtAge(job.lastRunAt ?? undefined)}
        </span>
        <span className="text-[10px] text-zinc-600 font-mono">
          интервал: {fmtMin(job.intervalMs)}
        </span>
      </div>
      {job.overdueMs !== null && (
        <div className="pl-3.5 mt-1">
          <GaugeBar
            value={Math.min(job.overdueMs, job.intervalMs)}
            max={job.intervalMs}
            level={level}
          />
        </div>
      )}
    </div>
  );
}

// ─── main ─────────────────────────────────────────────────────────────────────

const JOB_ORDER = [
  "fastCycle",
  "liqCascade",
  "whaleAlert",
  "watcherCycle",
  "price24hRefresh",
  "backfill",
  "whalePostExit",
];

const API_BASE = import.meta.env.BASE_URL.replace(/\/$/, "");

interface WhalePoolEntry {
  id: number;
  symbol: string;
  status: string;
  detectedAt: string;
  firedAt: string | null;
  alertTime: string | null;
  positionValueUsdM: number | null;
  whaleCount: number;
  detectLagMin: number | null;
  confirmLagMin: number | null;
  totalLagMin: number | null;
  price72hPct: number | null;
}

interface WhaleSignal {
  id: number;
  symbol: string;
  status: string;
  pnlPercent: number | null;
  cancelReason: string | null;
  detectedAt: string;
  closedAt: string | null;
  price72hAfterExitPct: number | null;
}

interface WhaleAlertStats {
  summary: {
    firedCount: number;
    watchingCount: number;
    expiredCount: number;
    avgDetectLagMin: number | null;
    avgConfirmLagMin: number | null;
    avgTotalLagMin: number | null;
    p50ConfirmLagMin: number | null;
  };
  poolEntries: WhalePoolEntry[];
  recentSignals: WhaleSignal[];
}

export default function BotHealth() {
  const [now, setNow] = useState(Date.now());
  const [whaleStats, setWhaleStats] = useState<WhaleAlertStats | null>(null);

  const { data, isLoading, dataUpdatedAt } = useGetBotHealth({
    query: {
      queryKey: getGetBotHealthQueryKey(),
      refetchInterval: 15_000,
    },
  });

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 5_000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const fetchWhaleStats = async () => {
      try {
        const res = await fetch(`${API_BASE}/api/whale-alert/stats`);
        if (res.ok) setWhaleStats((await res.json()) as WhaleAlertStats);
      } catch {
        // fail-open
      }
    };
    void fetchWhaleStats();
    const t = setInterval(fetchWhaleStats, 60_000);
    return () => clearInterval(t);
  }, []);

  const d = data as BotHealthStatus | undefined;

  const cg = d?.cgLatency;
  const conn = d?.connections;
  const sc = d?.scanner;
  const db = d?.db;
  const oiW = d?.oiWatch;
  const jobs = d?.jobs ?? {};

  if (isLoading && !d) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground text-sm font-mono">
        Загрузка...
      </div>
    );
  }

  const scanAgeMs = sc?.lastScanAt
    ? now - new Date(sc.lastScanAt).getTime()
    : null;
  const scannerLevel: StatusLevel = !sc?.running
    ? "crit"
    : sc.isScanning
      ? "warn"
      : scanAgeMs != null && scanAgeMs > 40 * 60_000
        ? "crit"
        : scanAgeMs != null && scanAgeMs > 20 * 60_000
          ? "warn"
          : "ok";

  return (
    <div className="space-y-6 max-w-5xl">
      {/* Header row */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-mono text-muted-foreground">
            SYSTEM HEALTH MONITOR
          </h2>
          {dataUpdatedAt > 0 && (
            <p className="text-[10px] text-zinc-600 font-mono mt-0.5">
              обновлено: {new Date(dataUpdatedAt).toLocaleTimeString("ru-RU")}
              &nbsp;·&nbsp;авто-обновление 15с
            </p>
          )}
        </div>
        <OverallBadge data={d} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {/* ── Scanner ── */}
        <div className="bg-card border border-border p-4">
          <SectionTitle>Scanner Core</SectionTitle>
          <Row
            label="Статус"
            level={scannerLevel}
            value={
              !sc?.running ? "STOPPED" : sc.isScanning ? "SCANNING…" : "IDLE"
            }
          />
          <Row
            label="Последний скан"
            value={fmtIso(sc?.lastScanAt)}
            level={
              scanAgeMs == null
                ? "unknown"
                : scanAgeMs > 40 * 60_000
                  ? "crit"
                  : scanAgeMs > 20 * 60_000
                    ? "warn"
                    : "ok"
            }
          />
          <Row label="Следующий скан" value={fmtIso(sc?.nextScanAt)} />
          <Row
            label="Длительность"
            value={
              sc?.lastScanDurationMs != null
                ? fmtMs(sc.lastScanDurationMs)
                : "—"
            }
            level={
              sc?.lastScanDurationMs == null
                ? "unknown"
                : sc.lastScanDurationMs < 15 * 60_000
                  ? "ok"
                  : sc.lastScanDurationMs < 25 * 60_000
                    ? "warn"
                    : "crit"
            }
          />
          <Row label="Рынков отсканировано" value={sc?.marketsScanned ?? "—"} />
          <Row
            label="Интервал"
            value={sc?.scanIntervalMs != null ? fmtMin(sc.scanIntervalMs) : "—"}
          />
        </div>

        {/* ── CoinGlass Latency ── */}
        <div className="bg-card border border-border p-4">
          <SectionTitle>CoinGlass Latency</SectionTitle>
          {!cg ? (
            <div className="text-xs text-zinc-500 font-mono py-4 text-center">
              Нет данных (первый скан не завершён)
            </div>
          ) : (
            <>
              <Row
                label="Timeout %"
                level={cgTimeoutLevel(cg.timeoutPct)}
                value={`${cg.timeoutPct}%`}
              />
              <div className="pb-1">
                <GaugeBar
                  value={cg.timeoutPct}
                  max={100}
                  level={cgTimeoutLevel(cg.timeoutPct)}
                />
              </div>
              <Row
                label="p50"
                value={fmtMs(cg.p50Ms)}
                level={cgP95Level(cg.p50Ms)}
              />
              <Row
                label="p95"
                value={fmtMs(cg.p95Ms)}
                level={cgP95Level(cg.p95Ms)}
              />
              <div className="pb-1">
                <GaugeBar
                  value={cg.p95Ms}
                  max={10_000}
                  level={cgP95Level(cg.p95Ms)}
                />
              </div>
              <Row label="Max" value={fmtMs(cg.maxMs)} />
              <Row
                label="Event Loop p95"
                value={fmtMs(cg.elLagP95Ms)}
                level={elLagLevel(cg.elLagP95Ms)}
              />
              <Row
                label="Запросов/мин"
                value={`${cg.reqPerMin} (${cg.req} всего)`}
              />
              <Row
                label="Окно наблюдения"
                value={`${cg.windowMin.toFixed(1)} мин`}
              />
            </>
          )}
        </div>

        {/* ── Connections ── */}
        <div className="bg-card border border-border p-4">
          <SectionTitle>API Connections</SectionTitle>
          <ConnectionRow label="BingX" ok={conn?.bingx} />
          <ConnectionRow label="Telegram" ok={conn?.telegram} />
          <ConnectionRow label="CoinGlass" ok={conn?.coinglass} />
          <ConnectionRow label="Coinalyze" ok={conn?.coinalyze} />
          <ConnectionRow label="CoinGecko" ok={conn?.coinGecko} />
          <ConnectionRow label="CoinPaprika" ok={conn?.coinPaprika} />

          {/* DB ping */}
          <div className="mt-3 pt-3 border-t border-border/60">
            <SectionTitle>Database (Neon)</SectionTitle>
            <Row
              label="Ping"
              value={db?.ok ? fmtMs(db.pingMs) : "FAIL"}
              level={db?.ok === false ? "crit" : dbPingLevel(db?.pingMs)}
            />
            {db?.ok && db.pingMs != null && (
              <GaugeBar
                value={db.pingMs}
                max={300}
                level={dbPingLevel(db.pingMs)}
              />
            )}
          </div>

          {/* OI Watch */}
          {oiW && (
            <div className="mt-3 pt-3 border-t border-border/60">
              <SectionTitle>OI Watch</SectionTitle>
              <Row
                label="Ошибки INS"
                value={oiW.insertErrors}
                level={
                  oiW.insertErrors === 0
                    ? "ok"
                    : oiW.insertErrors < 5
                      ? "warn"
                      : "crit"
                }
              />
              <Row
                label="CG таймауты (скан)"
                value={oiW.cgTimeoutsLastScan}
                level={
                  oiW.cgTimeoutsLastScan === 0
                    ? "ok"
                    : oiW.cgTimeoutsLastScan < 10
                      ? "warn"
                      : "crit"
                }
              />
            </div>
          )}
        </div>

        {/* ── Whale Alert Audit ── */}
        <div className="bg-card border border-border p-4 md:col-span-2 xl:col-span-3">
          <SectionTitle>
            🐋 Whale Alert — аудит скорости и ретроспектива
          </SectionTitle>
          {!whaleStats ? (
            <div className="text-xs text-zinc-500 font-mono py-3 text-center">
              Загрузка…
            </div>
          ) : (
            <div className="space-y-4">
              {/* Summary row */}
              <div className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-7 gap-3">
                {[
                  {
                    label: "Watching",
                    value: whaleStats.summary.watchingCount,
                    color: "text-yellow-400",
                  },
                  {
                    label: "Fired",
                    value: whaleStats.summary.firedCount,
                    color: "text-green-400",
                  },
                  {
                    label: "Expired",
                    value: whaleStats.summary.expiredCount,
                    color: "text-zinc-500",
                  },
                  {
                    label: "Avg detect lag",
                    value:
                      whaleStats.summary.avgDetectLagMin != null
                        ? `${whaleStats.summary.avgDetectLagMin}м`
                        : "—",
                    color:
                      whaleStats.summary.avgDetectLagMin != null &&
                      whaleStats.summary.avgDetectLagMin > 10
                        ? "text-yellow-400"
                        : "text-foreground",
                  },
                  {
                    label: "Avg confirm lag",
                    value:
                      whaleStats.summary.avgConfirmLagMin != null
                        ? `${whaleStats.summary.avgConfirmLagMin}м`
                        : "—",
                    color: "text-foreground",
                  },
                  {
                    label: "p50 confirm",
                    value:
                      whaleStats.summary.p50ConfirmLagMin != null
                        ? `${whaleStats.summary.p50ConfirmLagMin}м`
                        : "—",
                    color: "text-foreground",
                  },
                  {
                    label: "Avg total lag",
                    value:
                      whaleStats.summary.avgTotalLagMin != null
                        ? `${whaleStats.summary.avgTotalLagMin}м`
                        : "—",
                    color:
                      whaleStats.summary.avgTotalLagMin != null &&
                      whaleStats.summary.avgTotalLagMin > 20
                        ? "text-yellow-400"
                        : "text-foreground",
                  },
                ].map((s) => (
                  <div
                    key={s.label}
                    className="bg-background border border-border/60 p-2 text-center"
                  >
                    <div className={`text-sm font-mono font-bold ${s.color}`}>
                      {s.value}
                    </div>
                    <div className="text-[10px] text-zinc-500 font-mono mt-0.5">
                      {s.label}
                    </div>
                  </div>
                ))}
              </div>

              {/* Recent pool entries table */}
              <div className="overflow-x-auto">
                <table className="w-full text-[10px] font-mono">
                  <thead>
                    <tr className="border-b border-border text-zinc-500">
                      <th className="text-left py-1 pr-3">Символ</th>
                      <th className="text-left py-1 pr-3">Статус</th>
                      <th className="text-right py-1 pr-3">USD млн</th>
                      <th className="text-right py-1 pr-3">Det лаг</th>
                      <th className="text-right py-1 pr-3">Conf лаг</th>
                      <th className="text-right py-1 pr-3">Итог лаг</th>
                      <th className="text-right py-1">+72ч%</th>
                    </tr>
                  </thead>
                  <tbody>
                    {whaleStats.poolEntries.slice(0, 15).map((e) => (
                      <tr
                        key={e.id}
                        className="border-b border-border/30 hover:bg-accent/10"
                      >
                        <td className="py-1 pr-3 text-foreground">
                          {e.symbol.replace("-USDT", "")}
                        </td>
                        <td
                          className={`py-1 pr-3 ${e.status === "fired" ? "text-green-400" : e.status === "watching" ? "text-yellow-400" : "text-zinc-500"}`}
                        >
                          {e.status}
                        </td>
                        <td className="py-1 pr-3 text-right">
                          {e.positionValueUsdM != null
                            ? `$${e.positionValueUsdM}M`
                            : "—"}
                        </td>
                        <td
                          className={`py-1 pr-3 text-right ${e.detectLagMin != null && e.detectLagMin > 10 ? "text-yellow-400" : ""}`}
                        >
                          {e.detectLagMin != null ? `${e.detectLagMin}м` : "—"}
                        </td>
                        <td className="py-1 pr-3 text-right">
                          {e.confirmLagMin != null
                            ? `${e.confirmLagMin}м`
                            : "—"}
                        </td>
                        <td
                          className={`py-1 pr-3 text-right ${e.totalLagMin != null && e.totalLagMin > 20 ? "text-yellow-400" : ""}`}
                        >
                          {e.totalLagMin != null ? `${e.totalLagMin}м` : "—"}
                        </td>
                        <td
                          className={`py-1 text-right ${e.price72hPct != null ? (e.price72hPct > 0 ? "text-green-400" : "text-red-400") : "text-zinc-500"}`}
                        >
                          {e.price72hPct != null
                            ? `${e.price72hPct > 0 ? "+" : ""}${e.price72hPct.toFixed(1)}%`
                            : "—"}
                        </td>
                      </tr>
                    ))}
                    {whaleStats.poolEntries.length === 0 && (
                      <tr>
                        <td
                          colSpan={7}
                          className="py-3 text-center text-zinc-600"
                        >
                          Нет данных
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Recent tracked signals */}
              {whaleStats.recentSignals.length > 0 && (
                <div className="overflow-x-auto">
                  <div className="text-[10px] text-zinc-500 font-mono mb-1">
                    Закрытые сигналы (tracked_signals)
                  </div>
                  <table className="w-full text-[10px] font-mono">
                    <thead>
                      <tr className="border-b border-border text-zinc-500">
                        <th className="text-left py-1 pr-3">Символ</th>
                        <th className="text-left py-1 pr-3">Статус</th>
                        <th className="text-right py-1 pr-3">PnL%</th>
                        <th className="text-right py-1 pr-3">Причина</th>
                        <th className="text-right py-1">+72ч% после выхода</th>
                      </tr>
                    </thead>
                    <tbody>
                      {whaleStats.recentSignals
                        .filter((s) => s.closedAt)
                        .slice(0, 10)
                        .map((s) => (
                          <tr
                            key={s.id}
                            className="border-b border-border/30 hover:bg-accent/10"
                          >
                            <td className="py-1 pr-3 text-foreground">
                              {s.symbol.replace("-USDT", "")}
                            </td>
                            <td
                              className={`py-1 pr-3 ${s.status === "cancelled" || s.status === "stop_loss" ? "text-red-400" : "text-green-400"}`}
                            >
                              {s.status}
                            </td>
                            <td
                              className={`py-1 pr-3 text-right ${s.pnlPercent != null ? (s.pnlPercent > 0 ? "text-green-400" : "text-red-400") : "text-zinc-500"}`}
                            >
                              {s.pnlPercent != null
                                ? `${s.pnlPercent > 0 ? "+" : ""}${s.pnlPercent.toFixed(1)}%`
                                : "—"}
                            </td>
                            <td className="py-1 pr-3 text-right text-zinc-400">
                              {s.cancelReason ?? "—"}
                            </td>
                            <td
                              className={`py-1 text-right ${s.price72hAfterExitPct != null ? (s.price72hAfterExitPct > 0 ? "text-green-400" : "text-red-400") : "text-zinc-500"}`}
                            >
                              {s.price72hAfterExitPct != null
                                ? `${s.price72hAfterExitPct > 0 ? "+" : ""}${s.price72hAfterExitPct.toFixed(1)}%`
                                : "—"}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>

        {/* ── Background Jobs ── */}
        <div className="bg-card border border-border p-4 md:col-span-2 xl:col-span-3">
          <SectionTitle>Background Jobs</SectionTitle>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            {JOB_ORDER.filter((k) => jobs[k]).map((key) => (
              <JobRow key={key} job={jobs[key]} />
            ))}
            {JOB_ORDER.filter((k) => jobs[k]).length === 0 && (
              <div className="col-span-4 text-xs text-zinc-500 font-mono py-2 text-center">
                Данные появятся после первого запуска каждого джоба
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── overall status badge ─────────────────────────────────────────────────────

function OverallBadge({ data }: { data: BotHealthStatus | undefined }) {
  if (!data) {
    return (
      <span className="px-3 py-1.5 text-xs font-mono bg-zinc-800 text-zinc-500 border border-zinc-700">
        LOADING
      </span>
    );
  }

  const levels: StatusLevel[] = [];

  const sc = data.scanner;
  const cg = data.cgLatency;
  const jobs = data.jobs ?? {};

  levels.push(sc.running ? "ok" : "crit");
  if (cg) {
    levels.push(cgTimeoutLevel(cg.timeoutPct));
    levels.push(cgP95Level(cg.p95Ms));
    levels.push(elLagLevel(cg.elLagP95Ms));
  }
  levels.push(data.db.ok ? dbPingLevel(data.db.pingMs) : "crit");
  Object.values(jobs).forEach((j) => {
    if (j.lastRunAt !== null) levels.push(jobLevel(j.intervalMs, j.overdueMs));
  });

  const overall: StatusLevel = levels.includes("crit")
    ? "crit"
    : levels.includes("warn")
      ? "warn"
      : "ok";

  const bg =
    overall === "ok"
      ? "bg-green-500/10 border-green-500/30 text-green-400"
      : overall === "warn"
        ? "bg-yellow-400/10 border-yellow-400/30 text-yellow-300"
        : "bg-red-500/10 border-red-500/30 text-red-400";

  return (
    <span
      className={`px-3 py-1.5 text-xs font-mono font-bold border ${bg} tracking-widest`}
    >
      {overall === "ok"
        ? "● ALL SYSTEMS OK"
        : overall === "warn"
          ? "◐ DEGRADED"
          : "● CRITICAL"}
    </span>
  );
}
