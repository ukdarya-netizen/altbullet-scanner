import React, { useState, useEffect } from "react";
import {
  useGetOverheatLog,
  getGetOverheatLogQueryKey,
} from "@workspace/api-client-react";
import type { OverheatEntry } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Flame, RefreshCw, TrendingUp, History, Download } from "lucide-react";
import { cn } from "@/lib/utils";

// ── SNF helpers ────────────────────────────────────────────────────────────────
interface SnfEntry {
  netPct1h: number | null;
  netPct4h: number | null;
  netPct24h: number | null;
}

function toCgBase(s: string): string {
  const base = s.replace(/-USDT$/, "");
  return base.startsWith("1000") ? base.slice(4) : base;
}

function snfCell(pct: number | null) {
  if (pct == null) return <span className="text-border/40">—</span>;
  const c =
    pct >= 3
      ? "text-green-400 font-semibold"
      : pct >= 1
        ? "text-green-500/80"
        : pct <= -3
          ? "text-red-400 font-semibold"
          : pct <= -1
            ? "text-red-500/80"
            : "text-muted-foreground";
  return (
    <span className={cn("font-mono text-[11px]", c)}>
      {pct >= 0 ? "+" : ""}
      {pct.toFixed(1)}%
    </span>
  );
}

function snfCells(snfMap: Map<string, SnfEntry>, symbol: string) {
  const e = snfMap.get(toCgBase(symbol));
  return (
    <>
      <td className="px-2 py-2 text-right align-top">
        {snfCell(e?.netPct1h ?? null)}
      </td>
      <td className="px-2 py-2 text-right align-top">
        {snfCell(e?.netPct4h ?? null)}
      </td>
      <td className="px-2 py-2 text-right align-top">
        {snfCell(e?.netPct24h ?? null)}
      </td>
    </>
  );
}

// ── Formatters ─────────────────────────────────────────────────────────────────

function fmtPct(v: number | null | undefined, dec = 1) {
  if (v == null) return <span className="text-border/40">—</span>;
  const c =
    v > 0 ? "text-green-400" : v < 0 ? "text-red-400" : "text-muted-foreground";
  return (
    <span className={c}>
      {v >= 0 ? "+" : ""}
      {v.toFixed(dec)}%
    </span>
  );
}

function fmtOi(v: number | null | undefined) {
  if (v == null) return <span className="text-border/40">—</span>;
  const c =
    v >= 3
      ? "text-green-300"
      : v > 0
        ? "text-green-500/70"
        : v < -1
          ? "text-red-400"
          : "text-muted-foreground";
  return (
    <span className={c}>
      {v >= 0 ? "+" : ""}
      {v.toFixed(2)}%
    </span>
  );
}

function fmtPrice(v: number | null | undefined) {
  if (v == null) return "—";
  if (v < 0.0001) return v.toExponential(2);
  if (v < 0.01) return v.toFixed(6);
  if (v < 1) return v.toFixed(4);
  return v.toFixed(3);
}

function fmtDatetime(v: string | null | undefined): string {
  if (v == null) return "—";
  const d = new Date(v);
  const dd = String(d.getDate()).padStart(2, "0");
  const mo = String(d.getMonth() + 1).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${dd}.${mo} ${hh}:${mm}`;
}

function fmtAge(v: string | null | undefined): string {
  if (v == null) return "";
  const ms = new Date(v).getTime();
  const m = Math.round((Date.now() - ms) / 60_000);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

function fmtVol(v: number | null | undefined) {
  if (v == null) return <span className="text-border/40">—</span>;
  const s =
    v >= 1e9
      ? `$${(v / 1e9).toFixed(2)}B`
      : v >= 1e6
        ? `$${(v / 1e6).toFixed(1)}M`
        : v >= 1e3
          ? `$${(v / 1e3).toFixed(0)}K`
          : `$${v.toFixed(0)}`;
  return <span className="font-mono text-muted-foreground">{s}</span>;
}

function priceDeltaPct(
  currentPriceLive: number | null | undefined,
  currentPrice: number | null | undefined,
  entryPrice: number | null | undefined,
): number | null {
  const cur = currentPriceLive ?? currentPrice;
  if (cur == null || entryPrice == null || entryPrice === 0) return null;
  return ((cur - entryPrice) / entryPrice) * 100;
}

const LAYER_COLORS: Record<string, string> = {
  WL: "bg-yellow-500/20 text-yellow-300 border-yellow-500/30",
  L1: "bg-orange-500/20 text-orange-300 border-orange-500/30",
  L2: "bg-blue-500/20 text-blue-300 border-blue-500/30",
  L3: "bg-purple-500/20 text-purple-300 border-purple-500/30",
  L4: "bg-cyan-500/20 text-cyan-300 border-cyan-500/30",
  L5: "bg-teal-500/20 text-teal-300 border-teal-500/30",
  L7: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30",
  L8: "bg-green-500/20 text-green-300 border-green-500/30",
  L9: "bg-pink-500/20 text-pink-300 border-pink-500/30",
  L10: "bg-red-500/20 text-red-300 border-red-500/30",
  L11: "bg-violet-500/20 text-violet-300 border-violet-500/30",
};

function LayerBadge({ tag }: { tag: string }) {
  const cls =
    LAYER_COLORS[tag] ?? "bg-muted/30 text-muted-foreground border-border/30";
  return (
    <span
      className={cn(
        "inline-block text-[9px] font-mono px-1 py-0.5 rounded border leading-none",
        cls,
      )}
    >
      {tag}
    </span>
  );
}

function OiTriCell({
  oi30m,
  oi1h,
  oi4h,
  oi24h,
}: {
  oi30m?: number | null;
  oi1h?: number | null;
  oi4h?: number | null;
  oi24h?: number | null;
}) {
  return (
    <div className="flex flex-col gap-0.5 items-end text-[10px] leading-tight">
      <div className="flex gap-1 items-center">
        <span className="text-muted-foreground/40 text-[9px]">30m</span>
        {fmtOi(oi30m)}
      </div>
      <div className="flex gap-1 items-center">
        <span className="text-muted-foreground/40 text-[9px]">1h</span>
        {fmtOi(oi1h)}
      </div>
      <div className="flex gap-1 items-center">
        <span className="text-muted-foreground/40 text-[9px]">4h</span>
        {fmtOi(oi4h)}
      </div>
      {oi24h != null && (
        <div className="flex gap-1 items-center">
          <span className="text-muted-foreground/40 text-[9px]">24h</span>
          {fmtOi(oi24h)}
        </div>
      )}
    </div>
  );
}

// Дельта: сколько вырос p24h от момента входа до перегрева
function growthDelta(
  entry: number | null | undefined,
  peak: number | null | undefined,
): number | null {
  if (entry == null || peak == null) return null;
  return peak - entry;
}

// ── Row ────────────────────────────────────────────────────────────────────────

function OverheatRow({
  e,
  rank,
  onSymbolSelect,
  snfMap,
}: {
  e: OverheatEntry;
  rank: number;
  onSymbolSelect?: (symbol: string) => void;
  snfMap: Map<string, SnfEntry>;
}) {
  const sym = e.symbol.replace(/-USDT$/, "");
  const delta = growthDelta(e.entryPrice24h, e.peakPrice24h);
  const priceChg = priceDeltaPct(
    e.currentPriceLive,
    e.snapshotPrice ?? e.currentPrice,
    e.entryPrice,
  );
  const priceSource =
    e.currentPriceLive != null
      ? "live"
      : e.snapshotPrice != null
        ? "снапш"
        : null;
  const isFreshKick =
    e.lastKickedAt != null &&
    Date.now() - new Date(e.lastKickedAt).getTime() < 60 * 60 * 1000;
  const currentSpotMult =
    e.currentSpotVol1h != null &&
    e.currentSpotVolAvg1h != null &&
    e.currentSpotVolAvg1h > 0
      ? e.currentSpotVol1h / e.currentSpotVolAvg1h
      : null;

  return (
    <tr
      className={cn(
        "border-b border-border/20 text-xs transition-colors hover:bg-muted/15",
        isFreshKick && "bg-orange-500/5",
      )}
    >
      {/* # */}
      <td className="px-2 py-2 text-right text-muted-foreground/30 font-mono w-6 align-top pt-2.5">
        {rank}
      </td>

      {/* Символ + слои */}
      <td className="px-3 py-2 align-top min-w-[130px]">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-1.5">
            <a
              href={`https://www.bingx.com/en/perpetual/${sym}-USDT/`}
              target="_blank"
              rel="noreferrer"
              className="font-mono font-semibold text-foreground hover:text-primary transition-colors"
            >
              {sym}
            </a>
            {e.inPrescan && (
              <span
                title="в prescan"
                className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400/80 flex-shrink-0"
              />
            )}
            {onSymbolSelect && (
              <button
                onClick={() => onSymbolSelect(e.symbol)}
                title="История наблюдения"
                className="text-muted-foreground/40 hover:text-muted-foreground transition-colors"
              >
                <History className="w-3 h-3" />
              </button>
            )}
          </div>
          {(e as OverheatEntry & { retro?: boolean }).retro && (
            <span
              title="Строка создана startup-бэкфилом — данные при входе в prescan, а не в момент перегрева"
              className="inline-block text-[8px] leading-none px-1 py-0.5 rounded bg-zinc-700/60 text-zinc-400 font-mono uppercase tracking-wide"
            >
              ретро
            </span>
          )}
          {e.firstSeenAt && (
            <div className="text-[9px] text-muted-foreground/40">
              📅 с {fmtDatetime(e.firstSeenAt)}
            </div>
          )}
          <div className="flex flex-wrap gap-0.5">
            {(e.layers ?? []).slice(0, 6).map((tag) => (
              <LayerBadge key={tag} tag={tag} />
            ))}
          </div>
          {e.matchedPattern && (
            <span
              className="text-[9px] text-primary/70 font-mono truncate max-w-[120px]"
              title={e.matchedPattern}
            >
              🎯 {e.matchedPattern}
            </span>
          )}
        </div>
      </td>

      {/* Вход в prescan: p24h + цена */}
      <td className="px-3 py-2 text-right align-top">
        <div className="flex flex-col gap-0.5">
          <div>{fmtPct(e.entryPrice24h)}</div>
          <div className="text-[10px] text-muted-foreground/50">
            {fmtPrice(e.entryPrice)}
          </div>
        </div>
      </td>

      {/* Объём в момент кика (BingX quoteVolume USDT) */}
      <td className="px-3 py-2 text-right align-top">
        {fmtVol(e.entryVol24h)}
      </td>

      {/* OI при входе в prescan */}
      <td className="px-3 py-2 text-right align-top">
        <OiTriCell oi30m={e.entryOi30m} oi1h={e.entryOi1h} oi4h={e.entryOi4h} />
      </td>

      {/* OI сейчас (из prescan_tracker — живые данные) */}
      <td className="px-3 py-2 text-right align-top">
        {e.currentOi30m == null &&
        e.currentOi1h == null &&
        e.currentOi4h == null ? (
          <span className="text-border/40 text-[10px]">—</span>
        ) : (
          <OiTriCell
            oi30m={e.currentOi30m}
            oi1h={e.currentOi1h}
            oi4h={e.currentOi4h}
            oi24h={e.currentOi24h}
          />
        )}
      </td>

      {/* Циклов в prescan */}
      <td className="px-3 py-2 text-right align-top">
        <span
          className={cn(
            "font-mono",
            (e.cycleCount ?? 0) >= 20
              ? "text-green-400"
              : (e.cycleCount ?? 0) >= 10
                ? "text-yellow-400"
                : "text-muted-foreground",
          )}
        >
          {e.cycleCount ?? "—"}
        </span>
      </td>

      {/* Peak p24h + дельта от входа */}
      <td className="px-3 py-2 text-right align-top">
        <div className="flex flex-col gap-0.5">
          <div className="text-orange-300 font-mono font-semibold">
            {e.peakPrice24h != null ? `+${e.peakPrice24h.toFixed(1)}%` : "—"}
          </div>
          {delta != null && (
            <div className="text-[10px] text-muted-foreground/60">
              Δ+{delta.toFixed(1)}%
            </div>
          )}
        </div>
      </td>

      {/* Δ Цена: текущая цена vs цена при входе в prescan */}
      <td className="px-3 py-2 text-right align-top">
        <div className="flex flex-col gap-0.5">
          {fmtPct(priceChg)}
          {priceSource != null && (
            <div
              className={`text-[9px] text-right ${priceSource === "live" ? "text-primary/50" : "text-muted-foreground/40"}`}
              title={
                priceSource === "снапш" && e.snapshotAt
                  ? `снапш ${fmtAge(e.snapshotAt)} ago`
                  : undefined
              }
            >
              {priceSource}
            </div>
          )}
        </div>
      </td>

      {/* Текущий p24h (из growth_leader_log) */}
      <td className="px-3 py-2 text-right align-top">
        <div className="flex flex-col gap-0.5">
          {fmtPct(e.currentPrice24h)}
          {e.currentPrice != null && (
            <div className="text-[10px] text-muted-foreground/50">
              {fmtPrice(e.currentPrice)}
            </div>
          )}
        </div>
      </td>

      {/* Когда kicked: first + last + возраст */}
      <td className="px-3 py-2 text-right align-top text-[11px]">
        <div className="flex flex-col gap-0.5">
          <div className="text-muted-foreground">
            {fmtDatetime(e.lastKickedAt)}
          </div>
          <div className="text-muted-foreground/40 text-[9px]">
            {fmtAge(e.lastKickedAt)} ago
          </div>
          {e.kickCount > 1 && (
            <div className="text-[9px] text-orange-400/70">
              ×{e.kickCount} kicks
            </div>
          )}
        </div>
      </td>

      {/* Whale Index */}
      <td className="px-3 py-2 text-right align-top font-mono text-[11px]">
        {e.whaleIndex != null ? (
          <span
            className={
              e.whaleIndex >= 10
                ? "text-green-400"
                : e.whaleIndex <= -10
                  ? "text-red-400"
                  : "text-muted-foreground"
            }
          >
            {e.whaleIndex > 0 ? "+" : ""}
            {e.whaleIndex.toFixed(0)}
          </span>
        ) : (
          <span className="text-border">—</span>
        )}
      </td>

      {/* Цена 1h / Спот Mult */}
      <td className="px-3 py-2 text-right align-top">
        <div className="flex flex-col gap-0.5 items-end">
          {e.currentPrice1h != null ? (
            <span
              className={cn(
                "font-mono text-[11px]",
                e.currentPrice1h >= 1
                  ? "text-green-400"
                  : e.currentPrice1h <= -1
                    ? "text-red-400"
                    : "text-muted-foreground",
              )}
            >
              {e.currentPrice1h >= 0 ? "+" : ""}
              {e.currentPrice1h.toFixed(1)}%
            </span>
          ) : (
            <span className="text-border/40 text-[10px]">—</span>
          )}
          {currentSpotMult != null && (
            <span
              className={cn(
                "font-mono text-[10px]",
                currentSpotMult >= 2.5
                  ? "text-orange-400"
                  : currentSpotMult >= 1.5
                    ? "text-yellow-400/80"
                    : "text-muted-foreground/50",
              )}
            >
              S×{currentSpotMult.toFixed(1)}
            </span>
          )}
        </div>
      </td>

      {/* Тейкер: спот + фьюч + CVD 1h */}
      <td className="px-3 py-2 text-right align-top">
        <div className="flex flex-col gap-0.5 items-end">
          {e.currentSpotTaker != null ? (
            <span
              className={cn(
                "font-mono text-[11px]",
                e.currentSpotTaker >= 5
                  ? "text-green-400"
                  : e.currentSpotTaker <= -5
                    ? "text-red-400"
                    : "text-muted-foreground",
              )}
            >
              S{e.currentSpotTaker >= 0 ? "+" : ""}
              {e.currentSpotTaker.toFixed(0)}%
            </span>
          ) : (
            <span className="text-border/40 text-[10px]">—</span>
          )}
          {e.currentNetBuyPct != null && (
            <span
              className={cn(
                "font-mono text-[9px]",
                e.currentNetBuyPct >= 5
                  ? "text-green-400/70"
                  : e.currentNetBuyPct <= -5
                    ? "text-red-400/70"
                    : "text-muted-foreground/50",
              )}
            >
              F{e.currentNetBuyPct >= 0 ? "+" : ""}
              {e.currentNetBuyPct.toFixed(0)}%
            </span>
          )}
          {e.currentCvd1h != null && (
            <span
              className={cn(
                "text-[9px]",
                e.currentCvd1h ? "text-green-400/60" : "text-red-400/60",
              )}
            >
              1h{e.currentCvd1h ? "✓" : "✗"}
            </span>
          )}
        </div>
      </td>

      {/* CVD 30m / 4h */}
      <td className="px-3 py-2 text-right align-top">
        <div className="flex flex-col gap-0.5 items-end">
          {e.currentCvd30m != null ? (
            <span
              className={cn(
                "font-mono text-[11px]",
                e.currentCvd30m ? "text-green-400" : "text-red-400/60",
              )}
            >
              30m{e.currentCvd30m ? "✓" : "✗"}
            </span>
          ) : (
            <span className="text-border/40 text-[10px]">—</span>
          )}
          {e.currentCvd4h != null && (
            <span
              className={cn(
                "font-mono text-[10px]",
                e.currentCvd4h ? "text-green-400/70" : "text-red-400/40",
              )}
            >
              4h{e.currentCvd4h ? "✓" : "✗"}
            </span>
          )}
        </div>
      </td>

      {/* OI 30m acceleration */}
      <td className="px-3 py-2 text-right align-top font-mono text-[11px]">
        {e.currentOiAccel != null ? (
          <span
            className={cn(
              e.currentOiAccel >= 1.5
                ? "text-orange-400 font-semibold"
                : e.currentOiAccel >= 1.0
                  ? "text-yellow-400/80"
                  : "text-red-400/60",
            )}
          >
            {e.currentOiAccel.toFixed(2)}×
          </span>
        ) : (
          <span className="text-border/40">—</span>
        )}
      </td>

      {/* Futures / Spot ratio */}
      <td className="px-3 py-2 text-right align-top font-mono text-[11px]">
        {e.currentFutSpotRatio != null ? (
          <span
            className={cn(
              e.currentFutSpotRatio >= 5
                ? "text-orange-400"
                : e.currentFutSpotRatio >= 2
                  ? "text-yellow-400/80"
                  : "text-muted-foreground",
            )}
          >
            {e.currentFutSpotRatio.toFixed(1)}×
          </span>
        ) : (
          <span className="text-border/40">—</span>
        )}
      </td>

      {/* CVD pos cycles / Taker pos cycles */}
      <td className="px-3 py-2 text-right align-top">
        <div className="flex flex-col gap-0.5 items-end">
          {e.currentCvdPosCycles != null ? (
            <span
              className={cn(
                "font-mono text-[11px]",
                e.currentCvdPosCycles >= 3
                  ? "text-green-400"
                  : "text-muted-foreground",
              )}
            >
              CVD↑{e.currentCvdPosCycles}
            </span>
          ) : null}
          {e.currentTakerPosCycles != null ? (
            <span
              className={cn(
                "font-mono text-[10px]",
                e.currentTakerPosCycles >= 3
                  ? "text-green-400/70"
                  : "text-muted-foreground/50",
              )}
            >
              TKR↑{e.currentTakerPosCycles}
            </span>
          ) : null}
          {e.currentCvdPosCycles == null && e.currentTakerPosCycles == null && (
            <span className="text-border/40 text-[10px]">—</span>
          )}
        </div>
      </td>

      {/* SNF 1h / 4h / 24h */}
      {snfCells(snfMap, e.symbol)}
    </tr>
  );
}

// ── Main page ──────────────────────────────────────────────────────────────────

export default function OverheatLog({
  onSymbolSelect,
  filterQ = "",
}: {
  onSymbolSelect?: (symbol: string) => void;
  filterQ?: string;
}) {
  const [days, setDays] = useState(7);
  const queryClient = useQueryClient();
  const [snfMap, setSnfMap] = useState<Map<string, SnfEntry>>(new Map());

  useEffect(() => {
    const doFetch = () =>
      fetch("/api/scanner/spot-netflow")
        .then((r) => r.json())
        .then((d: { data?: Record<string, SnfEntry> }) => {
          if (d.data) setSnfMap(new Map(Object.entries(d.data)));
        })
        .catch(() => {});
    doFetch();
    const id = setInterval(doFetch, 5 * 60 * 1000);
    return () => clearInterval(id);
  }, []);

  const { data, isLoading, isError, dataUpdatedAt } = useGetOverheatLog(
    { days },
    {
      query: {
        queryKey: getGetOverheatLogQueryKey({ days }),
        refetchInterval: 60_000,
      },
    },
  );

  const allEntries = data?.entries ?? [];
  const fq = filterQ.trim().toLowerCase();
  const entries = fq
    ? allEntries.filter((e) => e.symbol.toLowerCase().includes(fq))
    : allEntries;

  function downloadCsv() {
    const cols: {
      header: string;
      get: (e: OverheatEntry) => string | number | boolean | null | undefined;
    }[] = [
      { header: "Символ", get: (e) => e.symbol },
      { header: "В prescan", get: (e) => (e.inPrescan ? "да" : "нет") },
      { header: "Первый вход", get: (e) => e.firstSeenAt ?? "" },
      { header: "Циклов в prescan", get: (e) => e.cycleCount ?? "" },
      { header: "Слои", get: (e) => (e.layers ?? []).join("|") },
      { header: "Паттерн", get: (e) => e.matchedPattern ?? "" },
      { header: "Вход p24h%", get: (e) => e.entryPrice24h ?? "" },
      { header: "Вход цена", get: (e) => e.entryPrice ?? "" },
      { header: "Объём на кике (USDT 24h)", get: (e) => e.entryVol24h ?? "" },
      { header: "OI вход 30m%", get: (e) => e.entryOi30m ?? "" },
      { header: "OI вход 1h%", get: (e) => e.entryOi1h ?? "" },
      { header: "OI вход 4h%", get: (e) => e.entryOi4h ?? "" },
      { header: "Пик p24h%", get: (e) => e.peakPrice24h ?? "" },
      { header: "Кол-во киков", get: (e) => e.kickCount },
      { header: "Первый кик", get: (e) => e.firstKickedAt ?? "" },
      { header: "Последний кик", get: (e) => e.lastKickedAt ?? "" },
      { header: "Текущий p24h%", get: (e) => e.currentPrice24h ?? "" },
      { header: "Текущая цена", get: (e) => e.currentPrice ?? "" },
      { header: "Текущая цена live", get: (e) => e.currentPriceLive ?? "" },
      { header: "Δ цена 1h%", get: (e) => e.currentPrice1h ?? "" },
      { header: "OI сейчас 30m%", get: (e) => e.currentOi30m ?? "" },
      { header: "OI сейчас 1h%", get: (e) => e.currentOi1h ?? "" },
      { header: "OI сейчас 4h%", get: (e) => e.currentOi4h ?? "" },
      { header: "OI сейчас 24h%", get: (e) => e.currentOi24h ?? "" },
      { header: "OI Accel 30m", get: (e) => e.currentOiAccel ?? "" },
      { header: "Спот тейкер net%", get: (e) => e.currentSpotTaker ?? "" },
      { header: "Фьюч net buy%", get: (e) => e.currentNetBuyPct ?? "" },
      {
        header: "CVD 1h",
        get: (e) => (e.currentCvd1h == null ? "" : e.currentCvd1h ? "1" : "0"),
      },
      {
        header: "CVD 30m",
        get: (e) =>
          e.currentCvd30m == null ? "" : e.currentCvd30m ? "1" : "0",
      },
      {
        header: "CVD 4h",
        get: (e) => (e.currentCvd4h == null ? "" : e.currentCvd4h ? "1" : "0"),
      },
      { header: "CVD pos циклов", get: (e) => e.currentCvdPosCycles ?? "" },
      { header: "Taker pos циклов", get: (e) => e.currentTakerPosCycles ?? "" },
      { header: "F/S ratio", get: (e) => e.currentFutSpotRatio ?? "" },
      { header: "Whale Index", get: (e) => e.whaleIndex ?? "" },
    ];

    const esc = (v: string | number | boolean | null | undefined): string => {
      const s = String(v ?? "");
      return s.includes(",") || s.includes('"') || s.includes("\n")
        ? `"${s.replace(/"/g, '""')}"`
        : s;
    };

    const header = cols.map((c) => esc(c.header)).join(",");
    const rows = allEntries.map((e) =>
      cols.map((c) => esc(c.get(e))).join(","),
    );
    const csv = [header, ...rows].join("\n");

    const blob = new Blob(["\uFEFF" + csv], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    const dateStr = new Date().toISOString().slice(0, 10);
    a.download = `overheat-prescan-${days}d-${dateStr}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-border shrink-0">
        <div className="flex items-center gap-3">
          <Flame className="w-5 h-5 text-orange-400" />
          <div>
            <h1 className="text-base font-semibold">Перегретые токены</h1>
            <p className="text-xs text-muted-foreground">
              Prescan-токены выкинутые фильтром p24h &gt; 40% · дедуп 4ч · TTL
              30 дней
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {/* Days selector */}
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <span>Период:</span>
            {([1, 3, 7, 14, 30, 3650] as const).map((d) => (
              <button
                key={d}
                onClick={() => setDays(d)}
                className={cn(
                  "px-2 py-1 rounded text-xs transition-colors",
                  days === d
                    ? "bg-primary/20 text-primary border border-primary/30"
                    : "hover:bg-muted/50 text-muted-foreground border border-transparent",
                )}
              >
                {d === 3650 ? "Все" : `${d}д`}
              </button>
            ))}
          </div>

          {/* Stats */}
          <span className="text-xs text-muted-foreground bg-muted/30 px-2 py-1 rounded">
            {entries.length} токенов
          </span>

          {/* Download CSV */}
          <button
            onClick={downloadCsv}
            disabled={allEntries.length === 0}
            title={`Скачать CSV (${allEntries.length} токенов)`}
            className="flex items-center gap-1.5 px-2 py-1.5 rounded hover:bg-muted/50 transition-colors text-xs text-muted-foreground disabled:opacity-30"
          >
            <Download className="w-3.5 h-3.5" />
            CSV
          </button>

          {/* Refresh */}
          <button
            onClick={() =>
              queryClient.invalidateQueries({
                queryKey: getGetOverheatLogQueryKey({ days }),
              })
            }
            className="p-1.5 rounded hover:bg-muted/50 transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* Updated at */}
      {dataUpdatedAt > 0 && (
        <div className="px-6 py-1 text-[10px] text-muted-foreground/40 shrink-0">
          Обновлено: {new Date(dataUpdatedAt).toLocaleTimeString()}
        </div>
      )}

      {/* Table */}
      <div className="flex-1 overflow-auto">
        {isLoading ? (
          <div className="flex items-center justify-center h-32 text-muted-foreground text-sm">
            Загрузка...
          </div>
        ) : isError ? (
          <div className="flex items-center justify-center h-32 text-red-400 text-sm">
            Ошибка загрузки данных
          </div>
        ) : entries.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-muted-foreground text-sm gap-2">
            <Flame className="w-8 h-8 text-muted-foreground/30" />
            <p>Нет данных за {days} дней</p>
            <p className="text-xs text-muted-foreground/60">
              Данные появятся после следующего скан-цикла (~10 мин)
            </p>
          </div>
        ) : (
          <table className="w-full border-collapse">
            <thead className="sticky top-0 bg-card z-10 border-b border-border">
              <tr className="text-[10px] text-muted-foreground font-medium uppercase tracking-wider">
                <th className="px-2 py-2 text-right w-6">#</th>
                <th className="px-3 py-2 text-left">Символ</th>
                <th className="px-3 py-2 text-right">
                  <div className="flex flex-col items-end gap-0">
                    <span>Вход</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      p24h / цена
                    </span>
                  </div>
                </th>
                <th className="px-3 py-2 text-right">
                  <div className="flex flex-col items-end gap-0">
                    <span>Вол кик</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      USDT 24h
                    </span>
                  </div>
                </th>
                <th className="px-3 py-2 text-right">
                  <div className="flex flex-col items-end gap-0">
                    <span>OI вход</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      30m/1h/4h
                    </span>
                  </div>
                </th>
                <th className="px-3 py-2 text-right">
                  <div className="flex flex-col items-end gap-0">
                    <span>OI сейчас</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      prescan live
                    </span>
                  </div>
                </th>
                <th className="px-3 py-2 text-right">
                  <div className="flex flex-col items-end gap-0">
                    <span>Циклы</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      в prescan
                    </span>
                  </div>
                </th>
                <th className="px-3 py-2 text-right">
                  <div className="flex flex-col items-end gap-0">
                    <TrendingUp className="w-3 h-3 ml-auto" />
                    <span>Пик / Δ</span>
                  </div>
                </th>
                <th className="px-3 py-2 text-right">
                  <div className="flex flex-col items-end gap-0">
                    <span>Δ Цена</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      от входа
                    </span>
                  </div>
                </th>
                <th className="px-3 py-2 text-right">
                  <div className="flex flex-col items-end gap-0">
                    <span>Сейчас</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      p24h
                    </span>
                  </div>
                </th>
                <th className="px-3 py-2 text-right">
                  <div className="flex flex-col items-end gap-0">
                    <span>Кик</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      последний
                    </span>
                  </div>
                </th>
                <th
                  className="px-3 py-2 text-right"
                  title="CoinGlass Whale Index (Binance 4h) на текущий момент"
                >
                  WI
                </th>
                <th
                  className="px-3 py-2 text-right"
                  title="Цена 1h% (prescan live) / Спот Vol Mult (vol 1h / 5-цикл. ср.)"
                >
                  <div className="flex flex-col items-end gap-0">
                    <span>Цена 1h</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      / S×
                    </span>
                  </div>
                </th>
                <th
                  className="px-3 py-2 text-right"
                  title="Спот тейкер net buy % (S) / Фьюч тейкер (F) / CVD 1h"
                >
                  <div className="flex flex-col items-end gap-0">
                    <span>Тейкер</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      спот / фьюч
                    </span>
                  </div>
                </th>
                <th
                  className="px-3 py-2 text-right"
                  title="CVD 30m / CVD 4h verdicts из prescan_tracker"
                >
                  <div className="flex flex-col items-end gap-0">
                    <span>CVD</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      30m / 4h
                    </span>
                  </div>
                </th>
                <th
                  className="px-3 py-2 text-right"
                  title="OI 30m acceleration: lastOi30m / prevOi30m"
                >
                  <div className="flex flex-col items-end gap-0">
                    <span>OI Acc</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      30m accel
                    </span>
                  </div>
                </th>
                <th
                  className="px-3 py-2 text-right"
                  title="Futures/spot volume ratio (24h)"
                >
                  F/S
                </th>
                <th
                  className="px-3 py-2 text-right"
                  title="Накопление: CVD positive cycles / Taker positive cycles подряд"
                >
                  <div className="flex flex-col items-end gap-0">
                    <span>Нак.</span>
                    <span className="text-[9px] normal-case font-normal text-muted-foreground/50">
                      CVD/TKR ↑
                    </span>
                  </div>
                </th>
                <th
                  className="px-2 py-2 text-right"
                  title="Spot Net Flow 1h % (CoinGlass)"
                >
                  SNF 1h
                </th>
                <th
                  className="px-2 py-2 text-right"
                  title="Spot Net Flow 4h % (CoinGlass)"
                >
                  SNF 4h
                </th>
                <th
                  className="px-2 py-2 text-right"
                  title="Spot Net Flow 24h % (CoinGlass)"
                >
                  SNF 24h
                </th>
              </tr>
            </thead>
            <tbody>
              {entries.map((e, i) => (
                <OverheatRow
                  key={e.symbol}
                  e={e}
                  rank={i + 1}
                  onSymbolSelect={onSymbolSelect}
                  snfMap={snfMap}
                />
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Legend */}
      <div className="px-6 py-2 border-t border-border/30 shrink-0">
        <div className="flex flex-wrap gap-4 text-[10px] text-muted-foreground/60">
          <span>
            <span className="text-orange-300">Пик</span> — максимальный p24h
            зафиксированный в момент кика
          </span>
          <span>
            <span className="text-muted-foreground/80">Δ</span> — рост от
            момента входа в prescan до кика
          </span>
          <span>
            <span className="text-primary/50">live</span> — из prescan_tracker
            (в памяти) · <span className="text-muted-foreground/60">снапш</span>{" "}
            — BingX цена каждый скан-цикл (персистентно)
          </span>
          <span>🎯 — паттерн если был сигнал пока токен был в prescan</span>
          <span>Дедуп: один кик на символ раз в 4ч · TTL 30 дней</span>
        </div>
      </div>
    </div>
  );
}
