import React, { useState, useMemo } from "react";
import {
  useGetGrowthLeaders,
  getGetGrowthLeadersQueryKey,
} from "@workspace/api-client-react";
import type { GrowthLeaderEntry } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  TrendingUp,
  RefreshCw,
  AlertTriangle,
  Database,
  History,
  Download,
} from "lucide-react";
import { cn } from "@/lib/utils";

// ── Formatters ─────────────────────────────────────────────────────────────────

function fmtPct(v: number | null | undefined, dec = 1) {
  if (v == null) return <span className="text-border/40">—</span>;
  const c =
    v > 0 ? "text-green-400" : v < 0 ? "text-red-400" : "text-muted-foreground";
  return (
    <span className={c}>
      {v >= 0 ? "+" : ""}
      {v.toFixed(dec)}%
    </span>
  );
}

function fmtOi(v: number | null | undefined) {
  if (v == null) return <span className="text-border/40">—</span>;
  const c =
    v >= 3
      ? "text-green-300"
      : v > 0
        ? "text-green-500/70"
        : v < -1
          ? "text-red-400"
          : "text-muted-foreground";
  return (
    <span className={c}>
      {v >= 0 ? "+" : ""}
      {v.toFixed(2)}%
    </span>
  );
}

function fmtCvd(v: boolean | null | undefined) {
  if (v == null) return <span className="text-border/40">—</span>;
  return v ? (
    <span className="text-green-400">▲</span>
  ) : (
    <span className="text-red-400">▼</span>
  );
}

function fmtCvdStrength(v: number | null | undefined) {
  if (v == null) return <span className="text-border/40">—</span>;
  const pct = Math.round(v * 100);
  const c =
    v >= 0.15
      ? "text-green-300"
      : v >= 0.05
        ? "text-green-500/70"
        : v <= -0.15
          ? "text-red-400"
          : v <= -0.05
            ? "text-red-400/70"
            : "text-muted-foreground/50";
  return (
    <span className={c}>
      {pct >= 0 ? "+" : ""}
      {pct}%
    </span>
  );
}

function fmtMult(v: number | null | undefined) {
  if (v == null || v <= 0) return <span className="text-border/40">—</span>;
  const c =
    v >= 3
      ? "text-orange-400"
      : v >= 1.5
        ? "text-yellow-400"
        : "text-muted-foreground";
  return <span className={c}>{v.toFixed(2)}x</span>;
}

function fmtNetBuy(v: number | null | undefined) {
  if (v == null) return <span className="text-border/40">—</span>;
  const c =
    v >= 20
      ? "text-green-300"
      : v >= 5
        ? "text-green-500/80"
        : v <= -20
          ? "text-red-400"
          : v < -5
            ? "text-red-400/70"
            : "text-muted-foreground";
  return (
    <span className={c}>
      {v >= 0 ? "+" : ""}
      {v.toFixed(1)}%
    </span>
  );
}

function fmtUsd(v: number | null | undefined) {
  if (v == null || v <= 0) return null;
  if (v >= 1_000_000) return `${(v / 1_000_000).toFixed(2)}M`;
  if (v >= 1_000) return `${(v / 1_000).toFixed(1)}K`;
  return v.toFixed(0);
}

function fmtPrice(v: number | null | undefined) {
  if (v == null) return "—";
  if (v < 0.0001) return v.toExponential(2);
  if (v < 0.01) return v.toFixed(6);
  if (v < 1) return v.toFixed(4);
  return v.toFixed(3);
}

function fmtFunding(v: number | null | undefined) {
  if (v == null) return <span className="text-border/40">—</span>;
  const pct = v * 100;
  const c =
    pct > 0.02
      ? "text-red-400"
      : pct < -0.01
        ? "text-green-400"
        : "text-muted-foreground";
  return (
    <span className={c}>
      {pct >= 0 ? "+" : ""}
      {pct.toFixed(4)}%
    </span>
  );
}

function fmtOiUsd(v: number | null | undefined) {
  if (v == null || v <= 0) return <span className="text-border/40">—</span>;
  if (v >= 1_000_000_000)
    return (
      <span className="text-muted-foreground">
        {(v / 1_000_000_000).toFixed(1)}B
      </span>
    );
  if (v >= 1_000_000)
    return (
      <span className="text-muted-foreground">
        {(v / 1_000_000).toFixed(1)}M
      </span>
    );
  return (
    <span className="text-muted-foreground">{(v / 1_000).toFixed(0)}K</span>
  );
}

/** Дата + время в формате ДД.ММ ЧЧ:мм:сс */
function fmtDatetime(v: string | number | null | undefined): string {
  if (v == null) return "—";
  const d = new Date(typeof v === "number" ? v : v);
  const dd = String(d.getDate()).padStart(2, "0");
  const mo = String(d.getMonth() + 1).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${dd}.${mo} ${hh}:${mm}`;
}

function fmtFirstSeen(msUnix: number | null | undefined): string {
  if (msUnix == null) return "—";
  const d = new Date(msUnix);
  const dd = String(d.getDate()).padStart(2, "0");
  const mo = String(d.getMonth() + 1).padStart(2, "0");
  const hh = String(d.getHours()).padStart(2, "0");
  const mm = String(d.getMinutes()).padStart(2, "0");
  return `${dd}.${mo} ${hh}:${mm}`;
}

/** Лёгкий relative age */
function fmtAge(v: string | number | null | undefined): string {
  if (v == null) return "";
  const ms = typeof v === "number" ? v : new Date(v).getTime();
  const m = Math.round((Date.now() - ms) / 60_000);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h`;
  return `${Math.floor(h / 24)}d`;
}

// ── OI tri-cell ────────────────────────────────────────────────────────────────

function OiTriCell({
  oi30m,
  oi1h,
  oi4h,
}: {
  oi30m?: number | null;
  oi1h?: number | null;
  oi4h?: number | null;
}) {
  return (
    <div className="flex flex-col gap-0.5 items-end text-[10px] leading-tight">
      <div className="flex gap-1 items-center">
        <span className="text-muted-foreground/40 text-[9px]">30m</span>
        {fmtOi(oi30m)}
      </div>
      <div className="flex gap-1 items-center">
        <span className="text-muted-foreground/40 text-[9px]">1h</span>
        {fmtOi(oi1h)}
      </div>
      <div className="flex gap-1 items-center">
        <span className="text-muted-foreground/40 text-[9px]">4h</span>
        {fmtOi(oi4h)}
      </div>
    </div>
  );
}

// ── Live Row ──────────────────────────────────────────────────────────────────

function LiveRow({ e, rank }: { e: GrowthLeaderEntry; rank: number }) {
  const sym = e.symbol.replace(/-USDT$/, "");
  const inPrescan = e.source === "scan";
  const bigMover = (e.price24h ?? 0) >= 20;
  const hasEntry =
    inPrescan &&
    (e.entryOi30m != null || e.entryOi1h != null || e.entryOi4h != null);

  return (
    <tr
      className={cn(
        "border-b border-border/25 text-xs transition-colors hover:bg-muted/20",
        bigMover ? "bg-orange-500/3" : "",
      )}
    >
      <td className="px-2 py-2 text-right text-muted-foreground/30 font-mono w-6 align-top pt-3">
        {rank}
      </td>
      <td className="px-3 py-2 align-top">
        <div className="flex flex-col gap-0.5">
          <a
            href={`https://www.tradingview.com/chart/?symbol=BINGX:${sym}USDT.P`}
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono font-semibold text-primary hover:underline"
          >
            {sym}
          </a>
          <div className="flex items-center gap-1 flex-wrap">
            {inPrescan ? (
              <span className="text-[9px] text-green-500/60 border border-green-500/20 px-1 rounded-sm">
                scan
              </span>
            ) : (
              <span className="text-[9px] text-zinc-500/60 border border-zinc-500/20 px-1 rounded-sm">
                bingx
              </span>
            )}
            {e.layers && e.layers.length > 0 && (
              <span className="text-[9px] text-cyan-400/60">
                {e.layers.slice(0, 3).join(" ")}
              </span>
            )}
          </div>
        </div>
      </td>

      <td className="px-3 py-2 align-top">
        {e.firstSeenAt != null ? (
          <div className="flex flex-col gap-0.5">
            <span className="font-mono text-foreground/80">
              {fmtFirstSeen(e.firstSeenAt)}
            </span>
            <span className="text-[9px] text-muted-foreground/40">
              {fmtAge(e.firstSeenAt)} назад
            </span>
          </div>
        ) : (
          <span className="text-border/40">—</span>
        )}
      </td>

      <td className="px-3 py-2 align-top">
        <div className="flex flex-col gap-0.5">
          <span className="font-mono text-foreground/80">
            ${fmtPrice(e.price)}
          </span>
          {inPrescan && e.entryPrice != null && (
            <span className="text-[9px] text-muted-foreground/40">
              вход: ${fmtPrice(e.entryPrice)}
            </span>
          )}
        </div>
      </td>

      <td className="px-3 py-2 align-top">
        <div className="flex flex-col gap-0.5">
          <div className="font-semibold">{fmtPct(e.price24h)}</div>
          {inPrescan && e.entryPrice24h != null && (
            <div className="text-[9px] text-muted-foreground/50">
              вход: {fmtPct(e.entryPrice24h)}
            </div>
          )}
        </div>
      </td>

      <td className="px-3 py-2 align-top text-right">
        {inPrescan ? (
          fmtPct(e.growthFromEntry)
        ) : (
          <span className="text-border/40">—</span>
        )}
      </td>

      <td className="px-3 py-2 align-top text-center">
        <div className="flex gap-2 justify-center">
          <span title="CVD 30m">{fmtCvd(e.cvd30m)}</span>
          <span title="CVD 1h">{fmtCvd(e.cvd1h)}</span>
        </div>
        <div className="text-[9px] text-muted-foreground/30 text-center">
          30m·1h
        </div>
      </td>

      <td className="px-2 py-2 align-top text-right text-[10px]">
        {fmtMult(e.spotVolMult)}
      </td>
      <td className="px-2 py-2 align-top text-right text-[10px]">
        {fmtMult(e.volMult)}
      </td>
      <td className="px-2 py-2 align-top text-right text-[10px]">
        {fmtNetBuy(e.netBuyPct)}
      </td>

      <td className="px-2 py-2 align-top text-[10px]">
        {e.spotTakerBuyUsd != null || e.spotTakerSellUsd != null ? (
          (() => {
            const buy = e.spotTakerBuyUsd ?? 0;
            const sell = e.spotTakerSellUsd ?? 0;
            const total = buy + sell;
            const buyPct = total > 0 ? Math.round((buy / total) * 100) : null;
            return (
              <div className="flex flex-col gap-0.5 items-end">
                <span className="text-green-400">{fmtUsd(buy) ?? "—"}</span>
                <span className="text-red-400">{fmtUsd(sell) ?? "—"}</span>
                {buyPct != null && (
                  <span
                    className={cn(
                      "text-[9px]",
                      buyPct >= 55
                        ? "text-green-300"
                        : buyPct <= 45
                          ? "text-red-400"
                          : "text-muted-foreground/50",
                    )}
                  >
                    {buyPct}% buy
                  </span>
                )}
              </div>
            );
          })()
        ) : (
          <span className="text-border/40">—</span>
        )}
      </td>

      <td className="px-2 py-2 align-top text-right">
        <OiTriCell oi30m={e.oi30m} oi1h={e.oi1h} oi4h={e.oi4h} />
      </td>

      <td className="px-2 py-2 align-top">
        {hasEntry ? (
          <OiTriCell
            oi30m={e.entryOi30m}
            oi1h={e.entryOi1h}
            oi4h={e.entryOi4h}
          />
        ) : (
          <span className="text-center text-border/30 text-[10px]">—</span>
        )}
      </td>

      <td className="px-3 py-2 align-top text-right text-muted-foreground/60 text-[10px]">
        {inPrescan && e.cycleCount != null ? (
          `${e.cycleCount} цкл`
        ) : (
          <span className="text-border/40">—</span>
        )}
      </td>
    </tr>
  );
}

// ── Retro Row ─────────────────────────────────────────────────────────────────

function RetroRow({ e, rank }: { e: GrowthLeaderEntry; rank: number }) {
  const sym = e.symbol.replace(/-USDT$/, "");
  const p24h = e.price24h ?? 0;
  const big = p24h >= 50;
  const medium = p24h >= 30;

  // Оценка продолжительности памп-периода по price3h/4h
  const p3h = e.price3h ?? null;
  const p4h = e.price4h ?? null;
  const durationLabel = (() => {
    if (p3h == null && p4h == null) return null;
    const maxShort = Math.max(p3h ?? 0, p4h ?? 0);
    const ratio = p24h > 0 ? maxShort / p24h : 0;
    if (ratio >= 0.8) return "~3-4ч";
    if (ratio >= 0.5) return "~6-12ч";
    return ">12ч";
  })();

  const hasCg = e.cgOiAvailable;
  const noCg = e.cgOiAvailable === false;

  return (
    <tr
      className={cn(
        "border-b border-border/25 text-xs transition-colors hover:bg-muted/20",
        big ? "bg-orange-500/5" : medium ? "bg-yellow-500/3" : "",
      )}
    >
      {/* # */}
      <td className="px-2 py-2 text-right text-muted-foreground/30 font-mono w-6 align-top pt-3">
        {rank}
      </td>

      {/* Дата памп-события */}
      <td className="px-3 py-2 align-top whitespace-nowrap">
        <div className="flex flex-col gap-0.5">
          <span className="font-mono text-foreground/80">
            {fmtDatetime(e.loggedAt)}
          </span>
          <span className="text-[9px] text-muted-foreground/40">
            {fmtAge(e.loggedAt)} назад
          </span>
        </div>
      </td>

      {/* Токен + CG badge */}
      <td className="px-3 py-2 align-top">
        <div className="flex flex-col gap-0.5">
          <a
            href={`https://www.tradingview.com/chart/?symbol=BINGX:${sym}USDT.P`}
            target="_blank"
            rel="noopener noreferrer"
            className="font-mono font-semibold text-primary hover:underline whitespace-nowrap"
          >
            {sym}
          </a>
          {noCg && (
            <span className="text-[9px] text-amber-500/70 border border-amber-500/20 px-1 rounded-sm w-fit">
              no CG
            </span>
          )}
          {hasCg && (
            <span className="text-[9px] text-green-500/50 border border-green-500/15 px-1 rounded-sm w-fit">
              CG ✓
            </span>
          )}
        </div>
      </td>

      {/* Рост 24h — главный показатель */}
      <td className="px-3 py-2 align-top whitespace-nowrap">
        <div className="flex flex-col gap-0.5">
          <div
            className={cn(
              "font-bold text-sm",
              big
                ? "text-orange-400"
                : medium
                  ? "text-yellow-400"
                  : "text-green-400",
            )}
          >
            {p24h >= 0 ? "+" : ""}
            {p24h.toFixed(1)}%
          </div>
          {durationLabel && (
            <div className="text-[9px] text-muted-foreground/50">
              {durationLabel}
            </div>
          )}
        </div>
      </td>

      {/* Темп: p3h/p4h + prevPrice30m */}
      <td className="px-3 py-2 align-top">
        <div className="flex flex-col gap-0.5 text-[10px]">
          <div className="flex gap-1 items-center">
            <span className="text-muted-foreground/40 text-[9px]">3h</span>
            {fmtPct(e.price3h)}
          </div>
          <div className="flex gap-1 items-center">
            <span className="text-muted-foreground/40 text-[9px]">4h</span>
            {fmtPct(e.price4h)}
          </div>
          {e.prevPrice30m != null && (
            <div className="flex gap-1 items-center border-t border-border/20 pt-0.5 mt-0.5">
              <span className="text-muted-foreground/30 text-[9px]">пр30m</span>
              {fmtPct(e.prevPrice30m, 2)}
            </div>
          )}
        </div>
      </td>

      {/* OI при входе (начало памп-периода) — текущий цикл */}
      <td className="px-2 py-2 align-top text-right">
        <OiTriCell oi30m={e.oi30m} oi1h={e.oi1h} oi4h={e.oi4h} />
      </td>

      {/* OI предыдущего цикла (накопление до пампа) — NEW */}
      <td className="px-2 py-2 align-top text-right">
        {e.prevOi30m != null || e.prevOi1h != null || e.prevOi4h != null ? (
          <OiTriCell oi30m={e.prevOi30m} oi1h={e.prevOi1h} oi4h={e.prevOi4h} />
        ) : (
          <span className="text-border/30 text-[10px]">—</span>
        )}
      </td>

      {/* OI суточный D1 / D2 — NEW */}
      <td className="px-2 py-2 align-top text-right">
        <div className="flex flex-col gap-0.5 items-end text-[10px]">
          <div className="flex gap-1 items-center">
            <span className="text-muted-foreground/30 text-[9px]">D1</span>
            {fmtOi(e.oi24hD1)}
          </div>
          <div className="flex gap-1 items-center">
            <span className="text-muted-foreground/30 text-[9px]">D2</span>
            {fmtOi(e.oi24hD2)}
          </div>
        </div>
      </td>

      {/* Объём: фьюч / спот текущий / спот пред. */}
      <td className="px-2 py-2 align-top text-right">
        <div className="flex flex-col gap-0.5 items-end text-[10px]">
          <div className="flex gap-1 items-center">
            <span className="text-muted-foreground/40 text-[9px]">ф</span>
            {fmtMult(e.volMult)}
          </div>
          <div className="flex gap-1 items-center">
            <span className="text-muted-foreground/40 text-[9px]">с</span>
            {fmtMult(e.spotVolMult)}
          </div>
          {e.prevSpotVolMult != null && (
            <div className="flex gap-1 items-center border-t border-border/20 pt-0.5 mt-0.5">
              <span className="text-muted-foreground/30 text-[9px]">пр</span>
              {fmtMult(e.prevSpotVolMult)}
            </div>
          )}
        </div>
      </td>

      {/* CVD: 30m / 1h / 4h bool + strength */}
      <td className="px-2 py-2 align-top text-center">
        <div className="flex gap-1 justify-center">
          <span title="CVD 30m">{fmtCvd(e.cvd30m)}</span>
          <span title="CVD 1h">{fmtCvd(e.cvd1h)}</span>
          <span title="CVD 4h">{fmtCvd(e.spotCvd4h)}</span>
        </div>
        <div className="text-[9px] text-muted-foreground/30 text-center">
          30·1h·4h
        </div>
        {e.cvdStrength1h != null && (
          <div className="mt-0.5 text-center text-[10px]">
            {fmtCvdStrength(e.cvdStrength1h)}
          </div>
        )}
      </td>

      {/* Спот Taker: net% + buy/sell USD */}
      <td className="px-2 py-2 align-top text-right text-[10px]">
        <div className="flex flex-col gap-0.5 items-end">
          {e.spotTakerNetBuyPct != null ? (
            <span
              className={cn(
                "font-medium",
                e.spotTakerNetBuyPct >= 10
                  ? "text-green-300"
                  : e.spotTakerNetBuyPct >= 0
                    ? "text-green-500/70"
                    : e.spotTakerNetBuyPct <= -10
                      ? "text-red-400"
                      : "text-red-400/70",
              )}
            >
              {e.spotTakerNetBuyPct >= 0 ? "+" : ""}
              {e.spotTakerNetBuyPct.toFixed(1)}%
            </span>
          ) : (
            (() => {
              if (e.spotTakerBuyUsd == null && e.spotTakerSellUsd == null)
                return <span className="text-border/40">—</span>;
              const buy = e.spotTakerBuyUsd ?? 0;
              const sell = e.spotTakerSellUsd ?? 0;
              const total = buy + sell;
              const pct = total > 0 ? Math.round((buy / total) * 100) : null;
              return pct != null ? (
                <span
                  className={cn(
                    pct >= 55
                      ? "text-green-300"
                      : pct <= 45
                        ? "text-red-400"
                        : "text-muted-foreground/50",
                  )}
                >
                  {pct}% buy
                </span>
              ) : (
                <span className="text-border/40">—</span>
              );
            })()
          )}
          {(e.spotTakerBuyUsd != null || e.spotTakerSellUsd != null) && (
            <div className="flex flex-col items-end text-[9px] text-muted-foreground/40">
              <span>{fmtUsd(e.spotTakerBuyUsd ?? 0) ?? "—"} B</span>
              <span>{fmtUsd(e.spotTakerSellUsd ?? 0) ?? "—"} S</span>
            </div>
          )}
        </div>
      </td>

      {/* Funding */}
      <td className="px-2 py-2 align-top text-right text-[10px]">
        {fmtFunding(e.fundingRate)}
      </td>

      {/* OI $ абс */}
      <td className="px-2 py-2 align-top text-right text-[10px]">
        {fmtOiUsd(e.oiUsdAbs)}
      </td>
    </tr>
  );
}

// ── Summary Live ───────────────────────────────────────────────────────────────

function LiveSummary({ entries }: { entries: GrowthLeaderEntry[] }) {
  const inPrescan = entries.filter((e) => e.source === "scan").length;
  const bingxOnly = entries.filter((e) => e.source === "bingx_only").length;
  const bigMovers = entries.filter((e) => (e.price24h ?? 0) >= 20).length;
  const withEntry = entries.filter(
    (e) => e.entryOi30m != null || e.entryOi1h != null,
  ).length;

  return (
    <div className="flex gap-4 text-xs text-muted-foreground flex-wrap">
      <span>
        Всего: <span className="text-foreground">{entries.length}</span>
      </span>
      <span className="text-green-400">
        {inPrescan} в prescan (полные данные)
      </span>
      <span className="text-zinc-400">{bingxOnly} только BingX</span>
      {bigMovers > 0 && (
        <span className="text-orange-400">🚀 {bigMovers} × p24h ≥20%</span>
      )}
      {withEntry > 0 && (
        <span className="text-cyan-400/70">{withEntry} с entry-OI</span>
      )}
    </div>
  );
}

// ── Summary Retro ──────────────────────────────────────────────────────────────

function RetroSummary({ entries }: { entries: GrowthLeaderEntry[] }) {
  const tokens = new Set(entries.map((e) => e.symbol)).size;
  const big = entries.filter((e) => (e.price24h ?? 0) >= 50).length;
  const med = entries.filter(
    (e) => (e.price24h ?? 0) >= 30 && (e.price24h ?? 0) < 50,
  ).length;
  const withOi = entries.filter(
    (e) => e.oi30m != null || e.oi1h != null,
  ).length;
  const withCvd = entries.filter((e) => e.cvd1h != null).length;

  return (
    <div className="flex gap-4 text-xs text-muted-foreground flex-wrap">
      <span>
        Событий:{" "}
        <span className="text-foreground font-semibold">{entries.length}</span>
      </span>
      <span className="text-zinc-400">
        Уникальных токенов: <span className="text-foreground">{tokens}</span>
      </span>
      {big > 0 && <span className="text-orange-400">🚀 {big} × ≥50%</span>}
      {med > 0 && <span className="text-yellow-400">⚡ {med} × 30–50%</span>}
      <span className="text-green-400/70">
        OI: {withOi}/{entries.length}
      </span>
      <span className="text-cyan-400/70">
        CVD: {withCvd}/{entries.length}
      </span>
    </div>
  );
}

// ── Sort/filter bar for retro ──────────────────────────────────────────────────

type SortKey =
  | "date"
  | "p24h"
  | "oi30m"
  | "vol"
  | "prevOi30m"
  | "oi24hD1"
  | "cvdStrength";

function useRetroSorted(
  entries: GrowthLeaderEntry[],
  sort: SortKey,
  minP24h: number,
) {
  return useMemo(() => {
    const filtered = entries.filter((e) => (e.price24h ?? 0) >= minP24h);
    return [...filtered].sort((a, b) => {
      if (sort === "p24h") return (b.price24h ?? 0) - (a.price24h ?? 0);
      if (sort === "oi30m") return (b.oi30m ?? -999) - (a.oi30m ?? -999);
      if (sort === "vol")
        return (
          (b.spotVolMult ?? b.volMult ?? 0) - (a.spotVolMult ?? a.volMult ?? 0)
        );
      if (sort === "prevOi30m")
        return (b.prevOi30m ?? -999) - (a.prevOi30m ?? -999);
      if (sort === "oi24hD1") return (b.oi24hD1 ?? -999) - (a.oi24hD1 ?? -999);
      if (sort === "cvdStrength")
        return (b.cvdStrength1h ?? -999) - (a.cvdStrength1h ?? -999);
      // date: newest first (default)
      return new Date(b.loggedAt).getTime() - new Date(a.loggedAt).getTime();
    });
  }, [entries, sort, minP24h]);
}

// ── Main ──────────────────────────────────────────────────────────────────────

type TabMode = "live" | "retro";

export default function GrowthLeaders() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<TabMode>("live");
  const [hours, setHours] = useState(24);
  const [retroSort, setRetroSort] = useState<SortKey>("date");
  const [retroMinP24h, setRetroMinP24h] = useState(20);

  // Live query
  const liveParams = { hours };
  const liveQ = useGetGrowthLeaders(liveParams, {
    query: {
      queryKey: getGetGrowthLeadersQueryKey(liveParams),
      refetchInterval: 60_000,
      enabled: tab === "live",
    },
  });

  // Retro query — retro=true, 30 days
  const retroParams = { retro: "true", hours: 720 };
  const retroQ = useGetGrowthLeaders(
    retroParams as Parameters<typeof useGetGrowthLeaders>[0],
    {
      query: {
        queryKey: getGetGrowthLeadersQueryKey(
          retroParams as Parameters<typeof useGetGrowthLeaders>[0],
        ),
        staleTime: 5 * 60_000,
        enabled: tab === "retro",
      },
    },
  );

  const liveEntries = liveQ.data?.entries ?? [];
  const retroAllEntries = (retroQ.data?.entries ?? []) as GrowthLeaderEntry[];
  const retroEntries = useRetroSorted(retroAllEntries, retroSort, retroMinP24h);

  function handleRefresh() {
    if (tab === "live")
      queryClient.invalidateQueries({
        queryKey: getGetGrowthLeadersQueryKey(liveParams),
      });
    else
      queryClient.invalidateQueries({
        queryKey: getGetGrowthLeadersQueryKey(
          retroParams as Parameters<typeof useGetGrowthLeaders>[0],
        ),
      });
  }

  const [downloading, setDownloading] = useState(false);
  const [backfilling, setBackfilling] = useState(false);
  const [backfillMsg, setBackfillMsg] = useState<string | null>(null);

  async function getAdminToken(): Promise<string | null> {
    let tok = localStorage.getItem("adminToken") ?? "";
    if (!tok) {
      tok = window.prompt("Admin token:") ?? "";
      if (!tok) return null;
      localStorage.setItem("adminToken", tok);
    }
    return tok;
  }

  async function handleFullBackfill() {
    const tok = await getAdminToken();
    if (!tok) return;
    if (
      !window.confirm(
        "Сканер будет остановлен на время бэкфилла (~20–40 мин). Продолжить?",
      )
    )
      return;
    setBackfilling(true);
    setBackfillMsg(null);
    try {
      const res = await fetch("/api/admin/backfill-growth-leader-full", {
        method: "POST",
        headers: { "x-admin-token": tok },
      });
      if (res.status === 401) {
        setBackfillMsg("❌ Неверный токен");
        return;
      }
      if (!res.ok) {
        setBackfillMsg(`❌ HTTP ${res.status}`);
        return;
      }
      setBackfillMsg(
        "✅ Запущен — сканер остановлен, бэкфилл идёт в фоне. ~20–40 мин.",
      );
    } catch (e) {
      setBackfillMsg(`❌ ${e}`);
    } finally {
      setBackfilling(false);
    }
  }

  async function handleDownload(format: "csv" | "json" = "csv") {
    let tok = localStorage.getItem("adminToken") ?? "";
    if (!tok) {
      tok = window.prompt("Admin token:") ?? "";
      if (!tok) return;
      localStorage.setItem("adminToken", tok);
    }
    setDownloading(true);
    try {
      const res = await fetch(
        `/api/admin/export-growth-leaders?format=${format}`,
        {
          headers: { "x-admin-token": tok },
        },
      );
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `growth-leaders-${new Date().toISOString().slice(0, 10)}.${format}`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (e) {
      alert(`Ошибка: ${e}`);
    } finally {
      setDownloading(false);
    }
  }

  const isLoading = tab === "live" ? liveQ.isLoading : retroQ.isLoading;
  const isError = tab === "live" ? liveQ.isError : retroQ.isError;
  const updatedAt = tab === "live" ? liveQ.dataUpdatedAt : retroQ.dataUpdatedAt;
  const snapAt = tab === "live" ? liveQ.data?.snapshotAt : null;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-green-400" />
            Лидеры роста BingX
          </h2>
          <p className="text-xs text-muted-foreground mt-0.5">
            {tab === "live"
              ? "Все BingX фьючерсные тикеры с p24h > 3% — снимок каждые ~10 мин."
              : "Ретроспективные данные: токены с ростом ≥20% за 30 дней + метрики OI/CVD/объём при входе."}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Tab switcher */}
          <div className="flex gap-1 border border-border/50 rounded-sm p-0.5">
            <button
              onClick={() => setTab("live")}
              className={cn(
                "px-3 py-1 text-xs rounded-sm transition-colors flex items-center gap-1.5",
                tab === "live"
                  ? "bg-primary/15 text-primary"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              <TrendingUp className="w-3 h-3" />
              Лайв
            </button>
            <button
              onClick={() => setTab("retro")}
              className={cn(
                "px-3 py-1 text-xs rounded-sm transition-colors flex items-center gap-1.5",
                tab === "retro"
                  ? "bg-primary/15 text-primary"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              <History className="w-3 h-3" />
              Ретро 30д
            </button>
          </div>

          {/* Time filter (live only) */}
          {tab === "live" && (
            <div className="flex gap-1">
              {[
                { label: "1h", val: 1 },
                { label: "6h", val: 6 },
                { label: "24h", val: 24 },
                { label: "3д", val: 72 },
                { label: "7д", val: 168 },
              ].map(({ label, val }) => (
                <button
                  key={val}
                  onClick={() => setHours(val)}
                  className={cn(
                    "px-2 py-1 text-xs border rounded-sm transition-colors",
                    hours === val
                      ? "bg-primary/15 text-primary border-primary/30"
                      : "text-muted-foreground border-border/40 hover:border-border hover:text-foreground",
                  )}
                >
                  {label}
                </button>
              ))}
            </div>
          )}

          {/* Retro controls */}
          {tab === "retro" && (
            <div className="flex items-center gap-2">
              <select
                value={retroMinP24h}
                onChange={(e) => setRetroMinP24h(Number(e.target.value))}
                className="text-xs bg-card border border-border/50 rounded-sm px-2 py-1 text-foreground"
              >
                <option value={20}>≥20%</option>
                <option value={30}>≥30%</option>
                <option value={50}>≥50%</option>
                <option value={100}>≥100%</option>
              </select>
              <select
                value={retroSort}
                onChange={(e) => setRetroSort(e.target.value as SortKey)}
                className="text-xs bg-card border border-border/50 rounded-sm px-2 py-1 text-foreground"
              >
                <option value="date">По дате</option>
                <option value="p24h">По росту</option>
                <option value="oi30m">По OI 30m (входа)</option>
                <option value="prevOi30m">По OI пред.цикл</option>
                <option value="oi24hD1">По OI 24h D-1</option>
                <option value="vol">По объёму</option>
                <option value="cvdStrength">По CVD сила</option>
              </select>
            </div>
          )}

          {updatedAt > 0 && (
            <span className="text-[10px] text-muted-foreground/50">
              {new Date(updatedAt).toLocaleTimeString("ru-RU")}
            </span>
          )}
          <button
            onClick={handleRefresh}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-2 py-1 border border-border/40 hover:border-border rounded-sm"
          >
            <RefreshCw className="w-3 h-3" />
            Обновить
          </button>

          {/* Full backfill */}
          <button
            onClick={handleFullBackfill}
            disabled={backfilling}
            className="flex items-center gap-1.5 text-xs text-orange-400 hover:text-orange-300 transition-colors px-2 py-1 border border-orange-400/40 hover:border-orange-400/70 rounded-sm disabled:opacity-40"
            title="Остановить сканер и заполнить все NULL поля (spot/CVD/OI)"
          >
            <Database className="w-3 h-3" />
            {backfilling ? "Запуск…" : "Заполнить все"}
          </button>

          {/* Download CSV / JSON */}
          <div className="flex gap-1">
            <button
              onClick={() => handleDownload("csv")}
              disabled={downloading}
              className="flex items-center gap-1.5 text-xs text-cyan-400 hover:text-cyan-300 transition-colors px-2 py-1 border border-cyan-400/30 hover:border-cyan-400/60 rounded-sm disabled:opacity-40"
            >
              <Download className="w-3 h-3" />
              {downloading ? "…" : "CSV"}
            </button>
            <button
              onClick={() => handleDownload("json")}
              disabled={downloading}
              className="flex items-center gap-1.5 text-xs text-cyan-400/70 hover:text-cyan-300 transition-colors px-2 py-1 border border-cyan-400/20 hover:border-cyan-400/50 rounded-sm disabled:opacity-40"
            >
              JSON
            </button>
          </div>
        </div>
      </div>

      {/* Snapshot info (live only) */}
      {backfillMsg && (
        <div
          className={`text-xs px-2 py-1 rounded-sm border ${backfillMsg.startsWith("✅") ? "border-orange-400/40 text-orange-300 bg-orange-400/5" : "border-red-400/40 text-red-300 bg-red-400/5"}`}
        >
          {backfillMsg}
        </div>
      )}

      {tab === "live" && snapAt && (
        <div className="text-[10px] text-muted-foreground/50 flex items-center gap-1.5">
          <Database className="w-3 h-3" />
          Снимок от: {new Date(snapAt).toLocaleString("ru-RU")}
        </div>
      )}

      {/* Stats */}
      {!isLoading && tab === "live" && liveEntries.length > 0 && (
        <LiveSummary entries={liveEntries} />
      )}
      {!isLoading && tab === "retro" && retroAllEntries.length > 0 && (
        <RetroSummary entries={retroAllEntries} />
      )}

      {/* Legend */}
      {tab === "live" ? (
        <div className="flex gap-3 text-[10px] text-muted-foreground/60 bg-card/30 border border-border/30 px-3 py-2 rounded-sm flex-wrap">
          <span>
            <span className="text-foreground/60">p24h вход</span> = p24h% когда
            токен впервые попал в пресканер
          </span>
          <span>
            <span className="text-foreground/60">OI вход</span> = OI 30m/1h/4h
            при первом попадании
          </span>
          <span>
            <span className="text-foreground/60">Рост от входа</span> = (текущая
            цена / цена при входе − 1)
          </span>
          <span>
            <span className="text-green-400/70">scan</span> = полные OI/CVD ·{" "}
            <span className="text-zinc-400/70">bingx</span> = нет CG данных
          </span>
        </div>
      ) : (
        <div className="flex gap-3 text-[10px] text-muted-foreground/60 bg-card/30 border border-border/30 px-3 py-2 rounded-sm flex-wrap">
          <span>
            <span className="text-foreground/60">OI входа</span> = OI % в момент
            пампа (cyan) ·{" "}
            <span className="text-blue-400/70">OI пред.цикл</span> = OI за ~10
            мин до (синий)
          </span>
          <span>
            <span className="text-violet-400/70">OI 24h D-1/D-2</span> =
            суточный OI за 1/2 дня до пика
          </span>
          <span>
            <span className="text-foreground/60">CVD сила</span> =
            (buy−sell)/(buy+sell) за 1h: +% → покупки доминируют
          </span>
          <span>
            <span className="text-foreground/60">пр30m</span> = изменение цены
            предыдущей 30m свечи ·{" "}
            <span className="text-foreground/60">пред</span> = спот объём пред.
            свечи
          </span>
          <span>
            <span className="text-amber-500/70">no CG</span> = нет данных
            CoinGlass для токена ·{" "}
            <span className="text-green-500/50">CG ✓</span> = покрытие есть
          </span>
          <span>
            <span className="text-foreground/60">Длит.</span>: ~3-4ч → быстрый
            памп, &gt;12ч → долгий рост
          </span>
        </div>
      )}

      {/* Table */}
      {isLoading ? (
        <div className="flex items-center gap-2 text-sm text-muted-foreground py-12 justify-center">
          <RefreshCw className="w-4 h-4 animate-spin" />
          Загрузка...
        </div>
      ) : isError ? (
        <div className="flex items-center gap-2 text-sm text-red-400 py-12 justify-center">
          <AlertTriangle className="w-4 h-4" />
          Ошибка загрузки
        </div>
      ) : tab === "live" ? (
        liveEntries.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground/50 text-sm">
            <TrendingUp className="w-8 h-8 mx-auto mb-3 opacity-20" />
            <p>
              Нет данных — снимок появится после первого скан-цикла (~10 мин
              после деплоя)
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto rounded-sm border border-border/40">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-border/50 bg-card/50">
                  <th className="px-2 py-2.5 w-6" />
                  <th className="px-3 py-2.5 text-left font-medium text-muted-foreground">
                    Токен
                  </th>
                  <th className="px-3 py-2.5 text-left font-medium text-muted-foreground">
                    Дата входа
                  </th>
                  <th className="px-3 py-2.5 text-left font-medium text-muted-foreground">
                    Цена
                  </th>
                  <th className="px-3 py-2.5 text-left font-medium text-muted-foreground">
                    p24h
                  </th>
                  <th className="px-3 py-2.5 text-right font-medium text-muted-foreground whitespace-nowrap">
                    Рост от входа
                  </th>
                  <th className="px-3 py-2.5 text-center font-medium text-muted-foreground">
                    CVD
                  </th>
                  <th className="px-2 py-2.5 text-right font-medium text-muted-foreground whitespace-nowrap">
                    Спот obj
                  </th>
                  <th className="px-2 py-2.5 text-right font-medium text-muted-foreground whitespace-nowrap">
                    Фьюч obj
                  </th>
                  <th className="px-2 py-2.5 text-right font-medium text-purple-400/60 whitespace-nowrap">
                    NetFlow
                  </th>
                  <th className="px-2 py-2.5 text-right font-medium text-sky-400/60 whitespace-nowrap">
                    Спот Taker
                    <br />
                    <span className="text-[9px] text-muted-foreground/40 font-normal">
                      buy / sell
                    </span>
                  </th>
                  <th className="px-2 py-2.5 text-right font-medium text-green-400/60 whitespace-nowrap">
                    OI текущий
                    <br />
                    <span className="text-[9px] text-muted-foreground/40 font-normal">
                      (последний цикл)
                    </span>
                  </th>
                  <th className="px-2 py-2.5 text-right font-medium text-cyan-400/60 whitespace-nowrap">
                    OI при входе
                    <br />
                    <span className="text-[9px] text-muted-foreground/40 font-normal">
                      (1-й раз в prescan)
                    </span>
                  </th>
                  <th className="px-3 py-2.5 text-right font-medium text-muted-foreground">
                    Prescan
                  </th>
                </tr>
              </thead>
              <tbody>
                {liveEntries.map((e, i) => (
                  <LiveRow
                    key={`${e.symbol}-${e.loggedAt}`}
                    e={e}
                    rank={i + 1}
                  />
                ))}
              </tbody>
            </table>
          </div>
        )
      ) : /* Retro tab */
      retroEntries.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground/50 text-sm">
          <History className="w-8 h-8 mx-auto mb-3 opacity-20" />
          <p>
            {retroQ.isLoading
              ? "Загружаем ретроданные…"
              : retroAllEntries.length === 0
                ? "Ретроданные не собраны — деплой ретроджоба ещё не завершён (~10–20 мин)"
                : `Нет событий с ростом ≥${retroMinP24h}% — попробуй снизить фильтр`}
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-sm border border-border/40">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border/50 bg-card/50">
                <th className="px-2 py-2.5 w-6" />
                <th className="px-3 py-2.5 text-left font-medium text-muted-foreground whitespace-nowrap">
                  Дата
                </th>
                <th className="px-3 py-2.5 text-left font-medium text-muted-foreground">
                  Токен
                </th>
                <th className="px-3 py-2.5 text-left font-medium text-green-400/70 whitespace-nowrap">
                  Пик роста
                  <br />
                  <span className="text-[9px] text-muted-foreground/40 font-normal">
                    p24h / длит.
                  </span>
                </th>
                <th className="px-3 py-2.5 text-left font-medium text-yellow-400/60 whitespace-nowrap">
                  Темп
                  <br />
                  <span className="text-[9px] text-muted-foreground/40 font-normal">
                    3h / 4h / пр30m
                  </span>
                </th>
                <th className="px-2 py-2.5 text-right font-medium text-cyan-400/60 whitespace-nowrap">
                  OI входа
                  <br />
                  <span className="text-[9px] text-muted-foreground/40 font-normal">
                    30m / 1h / 4h
                  </span>
                </th>
                <th className="px-2 py-2.5 text-right font-medium text-blue-400/60 whitespace-nowrap">
                  OI пред.цикл
                  <br />
                  <span className="text-[9px] text-muted-foreground/40 font-normal">
                    30m / 1h / 4h
                  </span>
                </th>
                <th className="px-2 py-2.5 text-right font-medium text-violet-400/60 whitespace-nowrap">
                  OI 24h
                  <br />
                  <span className="text-[9px] text-muted-foreground/40 font-normal">
                    D-1 / D-2
                  </span>
                </th>
                <th className="px-2 py-2.5 text-right font-medium text-muted-foreground whitespace-nowrap">
                  Объём ×<br />
                  <span className="text-[9px] text-muted-foreground/40 font-normal">
                    ф / с / пред
                  </span>
                </th>
                <th className="px-2 py-2.5 text-center font-medium text-teal-400/60 whitespace-nowrap">
                  CVD
                  <br />
                  <span className="text-[9px] text-muted-foreground/40 font-normal">
                    30m·1h·4h / сила
                  </span>
                </th>
                <th className="px-2 py-2.5 text-right font-medium text-sky-400/60 whitespace-nowrap">
                  Тейкер спот
                  <br />
                  <span className="text-[9px] text-muted-foreground/40 font-normal">
                    net% / B / S
                  </span>
                </th>
                <th className="px-2 py-2.5 text-right font-medium text-purple-400/60 whitespace-nowrap">
                  Funding
                </th>
                <th className="px-2 py-2.5 text-right font-medium text-orange-400/60 whitespace-nowrap">
                  OI $<br />
                  <span className="text-[9px] text-muted-foreground/40 font-normal">
                    (абс)
                  </span>
                </th>
              </tr>
            </thead>
            <tbody>
              {retroEntries.map((e, i) => (
                <RetroRow
                  key={`${e.symbol}-${e.loggedAt}`}
                  e={e}
                  rank={i + 1}
                />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
